﻿using Autofac;
using GocafeDatabaseDataAccess;

namespace gocafe_cashier.Startup
{
    public class Bootstrapper
    {
        /// <summary>
        /// Registers dependencies as a service in the container.
        /// </summary>
        /// <returns>The container object (Autofac).</returns>
        public IContainer Bootstrap()
        {
            var builder = new ContainerBuilder();

            builder.RegisterType<GoCafeDbContext>().AsSelf();

            return builder.Build();
        }
    }
}
