﻿using gocafe_cashier.MessageResource;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace gocafe_cashier.Startup
{
    class Startup
    {
        const int SW_SHOWMAXIMIZED = 3;

        [DllImport("user32.dll")]
        private static extern Boolean ShowWindow(IntPtr hWnd, Int32 nCmdShow);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [STAThread]
        public static void Main()
        {
            Process currentProcess = Process.GetCurrentProcess();
            var runningProcess = (from process in Process.GetProcesses()
                                  where
                                    process.Id != currentProcess.Id &&
                                    process.ProcessName.Equals(
                                      currentProcess.ProcessName,
                                      StringComparison.Ordinal)
                                  select process).FirstOrDefault();
            if (runningProcess != null)
            {
                string myDocumentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);
                string filePath = myDocumentsPath + @"\gocafe-status.txt";

                if (File.Exists(filePath))
                {
                    File.Delete(filePath);

                    App app = new App();
                    app.InitializeComponent();
                    app.Run();

                    return;
                }

                ShowConfirmationWindow(StandardMessageResource.ErrorInstanceAlreadyRunning, Messages.ErrorConfirmation);

                SetForegroundWindow(runningProcess.MainWindowHandle);

                return;
            }
            else
            {
                App app = new App();
                app.InitializeComponent();
                app.Run();
            }
        }

        private static void ShowConfirmationWindow(string warningMessage, string mode)
        {
            GenericDialogWindow genericWindow = new GenericDialogWindow();
            Mediator.Instance.NotifyViewModel(Messages.ConfirmationWindowViewModel, Messages.ConfirmationWindow, genericWindow);
            Mediator.Instance.NotifyViewModel(Messages.ConfirmationWindowViewModel, mode, warningMessage);
            var windowDialogResult = genericWindow.ShowDialog();
        }

    }
}
