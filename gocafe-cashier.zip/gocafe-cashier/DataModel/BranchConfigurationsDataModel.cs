﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class BranchConfigurationsDataModel
    {
        [JsonProperty("settingCode")]
        public string SettingCode { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("value")]
        public string value { get; set; }
    }
}
