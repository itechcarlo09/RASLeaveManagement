﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class MemberTypesDataModel
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("id")]
        public int ID { get; set; }

        [JsonProperty("membershipFee")]
        public decimal MembershipFee { get; set; }

        [JsonProperty("initialBonusLoad")]
        public int InitialBonusLoad { get; set; }

        [JsonProperty("initialLoad")]
        public int InitialLoad { get; set; }

        [JsonProperty("bonusLoadPercentage")]
        public int BonusLoadPercentage { get; set; }

        [JsonProperty("cardReplacementCost")]
        public int CardReplacementCost { get; set; }

        [JsonProperty("rank")]
        public int Rank { get; set; }
    }
}
