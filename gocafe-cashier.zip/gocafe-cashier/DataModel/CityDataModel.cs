﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class CityDataModel
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("id")]
        public string Id { get; set; }
    }
}
