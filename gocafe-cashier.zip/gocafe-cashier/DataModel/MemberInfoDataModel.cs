﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class MemberInfoDataModel
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("middleName")]
        public string MiddleName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("memberType")]
        public MemberTypesDataModel MemberType { get; set; }
    }
}
