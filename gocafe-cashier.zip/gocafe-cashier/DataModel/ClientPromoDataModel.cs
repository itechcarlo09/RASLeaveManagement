﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class ClientPromoDataModel
    {
        [JsonProperty("promoCode")]
        public string PromoCode { get; set; }

        [JsonProperty("price")]
        public decimal Price { get; set; }

        [JsonProperty("promoDescription")]
        public string PromoDescription { get; set; }

        [JsonProperty("reason")]
        public string Reason { get; set; }

        [JsonProperty("refundable")]
        public bool Refundable { get; set; }
    }
}
