﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel
{
    public class PromoDataModel
    {
        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("price")]
        public int Price { get; set; }

        [JsonProperty("startTime")]
        public string StartTime { get; set; }

        [JsonProperty("endTime")]
        public string EndTime { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        [JsonProperty("days")]
        public List<string> Days { get; set; }

        [JsonProperty("promoType")]
        public string PromoType { get; set; }

        [JsonProperty("stationType")]
        public StationTypeDataModel StationType { get; set; }

        [JsonProperty("branch")]
        public BranchDataModel Branch { get; set; }

        [JsonProperty("durationInSeconds")]
        public int Duration { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("memberType")]
        public MemberTypesDataModel MemberType { get; set; }
    }
}
