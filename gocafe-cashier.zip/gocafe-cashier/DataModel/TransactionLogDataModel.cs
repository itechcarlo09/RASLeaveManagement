﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class TransactionLogDataModel
    {

        [JsonProperty("date")]
        public string date { get; set; }

        [JsonProperty("time")]
        public string Time { get; set; }

        [JsonProperty("activity")]
        public string Activity { get; set; }

        [JsonProperty("cashierName")]
        public string CashierName { get; set; }

        [JsonProperty("customerName")]
        public string CustomerName { get; set; }

        [JsonProperty("drCrCode")]
        public string DrCrCode { get; set; }

        [JsonProperty("amount")]
        public decimal Amount { get; set; }

        [JsonProperty("remarks")]
        public string Remarks { get; set; }

        [JsonProperty("referenceNumber")]
        public string ReferenceNumber { get; set; }

        [JsonProperty("isVoidable")]
        public bool IsVoidable { get; set; }

        [JsonProperty("voidStatus")]
        public string VoidStatus { get; set; }

    }
}
