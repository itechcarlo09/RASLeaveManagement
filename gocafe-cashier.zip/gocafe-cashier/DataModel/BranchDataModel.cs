﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class BranchDataModel
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("stationCount")]
        public short StationCount { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("city")]
        public CityDataModel City { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }
    }
}
