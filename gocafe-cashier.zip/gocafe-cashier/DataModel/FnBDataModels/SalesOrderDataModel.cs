﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class SalesOrderDataModel : SalesDataModel
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("customerUsername")]
        public string CustomerUsername { get; set; }

        [JsonProperty("accountBalance")]
        public int AccountBalance { get; set; }

        [JsonProperty("memberFirstName")]
        public string MemberFirstName { get; set; }

        [JsonProperty("memberLastName")]
        public string MemberLastName { get; set; }

        [JsonProperty("stationId")]
        public string StationId { get; set; }

        [JsonProperty("stationName")]
        public string StationName { get; set; }

        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }
        
        [JsonProperty("dateReviewed")]
        public long DateReviewed { get; set; }
    }
}
