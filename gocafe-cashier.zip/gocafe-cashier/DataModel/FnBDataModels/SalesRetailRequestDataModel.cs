﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class SalesRetailRequestDataModel
    {
        [JsonProperty("retailId")]
        public string RetailID { get; set; }

        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        [JsonProperty("retailPrice")]
        public int RetailPrice { get; set; }

    }
}
