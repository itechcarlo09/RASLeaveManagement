﻿using Newtonsoft.Json;
using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.Model;

namespace gocafe_cashier.DataModel.FnBDataModels
{ 
    public class EShopCodeListDataModel: BaseModel
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("denomination")]
        public string Denomination { get; set; }

        [JsonProperty("noOfAvailableCodes")]
        public int NoOfAvailableCodes { get; set; }

        [JsonProperty("amount")]
        public string Amount { get; set; }

        [JsonProperty("denominationDscp")]
        public string DenominationDscp { get; set; }

        [JsonProperty("codeTypeDscp")]
        public string CodeTypeDscp { get; set; }

        [JsonProperty("amountDscp")]
        public string AmountDscp { get; set; }

        [JsonProperty("eshopPicture")]
        public ProductPictureDataModel EshopPicture { get; set; }

        [JsonIgnore]
        public bool IsCodeAvailable { get; set; }

        [JsonIgnore]
        public string CodeUnavailableError { get; set; }
    }
}
