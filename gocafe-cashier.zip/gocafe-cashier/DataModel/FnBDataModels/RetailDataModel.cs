﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class RetailDataModel
    {
        [JsonProperty("compositeProduct")]
        public ProductDataModel CompositeProduct { get; set; }

        [JsonProperty("product")]
        public ProductDataModel Product { get; set; }

        [JsonProperty("sku")]
        public string SKU { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }
    }
}
