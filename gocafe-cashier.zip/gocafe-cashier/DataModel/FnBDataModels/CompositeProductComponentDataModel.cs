﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class CompositeProductComponentDataModel
    {
        [JsonProperty("product")]
        public ProductDataModel Product { get; set; }

        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        [JsonProperty("stockQuantity")]
        public int StockQuantity { get; set; }
    }
}
