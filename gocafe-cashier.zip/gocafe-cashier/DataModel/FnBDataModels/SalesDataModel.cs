﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class SalesDataModel : SalesRequestDataModel
    {
        [JsonProperty("receiptNumber")]
        public string ReceiptNumber { get; set; }

        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("accountBalance")]
        public string Balance { get; set; }

        [JsonProperty("salesRetails")]
        public List<SalesRetailDataModel> SalesRetails { get; set; }
    }
}
