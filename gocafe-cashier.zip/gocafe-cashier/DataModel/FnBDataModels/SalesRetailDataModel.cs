﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class SalesRetailDataModel : SalesRetailRequestDataModel
    {
        [JsonProperty("retailProductName")]
        public string ProductName { get; set; }
    }
}