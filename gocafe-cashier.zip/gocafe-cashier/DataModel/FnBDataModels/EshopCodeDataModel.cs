﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class EshopCodeDataModel
    {
        [JsonProperty("applicationErrorCode")]
        public string ApplicationErrorCode { get; set; }

        [JsonProperty("errorMessage")]
        public string ErrorMessage { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }
    }
}
