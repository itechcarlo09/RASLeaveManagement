﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class ProductDataModel
    {
        [JsonProperty("category")]
        public CategoryDataModel Category { get; set; }

        [JsonProperty("categoryDscp")]
        public string CategoryDescription { get; set; }

        [JsonProperty("deleted")]
        public bool Deleted { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("measurementUnit")]
        public MeasurementUnitDataModel MeasurementUnit { get; set; }

        [JsonProperty("measurementUnitDscp")]
        public string MeasurementUnitDescription { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("productPicture")]
        public ProductPictureDataModel ProductPicture { get; set; }

        [JsonProperty("compositeProductPicture")]
        public ProductPictureDataModel CompositeProductPicture { get; set; }

        [JsonProperty("retailDscp")]
        public string RetailDescription { get; set; }

        [JsonProperty("suggestedRetailPrice")]
        public int SuggestedRetailPrice { get; set; }

        [JsonProperty("requiresPreparation")]
        public bool IsRequirePreparation { get; set; }

        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        [JsonProperty("stockQuantity")]
        public int StockQuantity { get; set; }

        [JsonProperty("compositeProductComponents")]
        public List<CompositeProductComponentDataModel> CompositeProductComponents { get; set; }
    }
}