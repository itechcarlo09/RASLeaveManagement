﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class SalesRequestDataModel
    {
        [JsonProperty("transactionDateTime")]
        public string TransactionDateTime { get; set; }

        [JsonProperty("cashierSessionId")]
        public string CashierSessionID { get; set; }
        
        [JsonProperty("salesRetails")]
        public List<SalesRetailRequestDataModel> SalesRetails { get; set; }
    }
}
