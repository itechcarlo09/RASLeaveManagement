﻿using gocafe_cashier.DataModel;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class BranchRetailDataModel
    {
        [JsonProperty("retail")]
        public RetailDataModel Retail { get; set; }

        [JsonProperty("retailPrice")]
        public decimal RetailPrice { get; set; }

        [JsonProperty("lastUpdate")]
        public string LastUpdate { get; set; }

        [JsonProperty("requiresPreparation")]
        public bool IsPreparationRequired { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }
    }
}
