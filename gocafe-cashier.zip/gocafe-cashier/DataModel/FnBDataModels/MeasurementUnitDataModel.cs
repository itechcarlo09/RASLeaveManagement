﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class MeasurementUnitDataModel
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
