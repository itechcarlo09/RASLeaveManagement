﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.FnBDataModels
{
    public class ProductPictureDataModel
    {
        [JsonProperty("checksum")]
        public string Checksum { get; set; }

        [JsonProperty("createdDateTime")]
        public long CreatedDateTime { get; set; }

        [JsonProperty("fileExtension")]
        public string FileExtension { get; set; }

        [JsonProperty("fileKey")]
        public string FileKey { get; set; }

        [JsonProperty("fileSize")]
        public int FileSize { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("uploadedBy")]
        public string UploadedBy { get; set; }

        [JsonProperty("url")]
        public string URL { get; set; }
    }
}
