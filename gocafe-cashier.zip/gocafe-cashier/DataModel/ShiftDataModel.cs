﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel
{
    public class ShiftDataModel
    {
        [JsonProperty("amount")]
        public int TotalSales { get; set; }

        [JsonProperty("shiftStartDateTime")]
        public DateTime StartDate { get; set; }

        [JsonProperty("shiftEndDateTime")]
        public DateTime EndDate { get; set; }

        [JsonProperty("cashierUsername")]
        public string CashierName { get; set; }

        [JsonProperty("totalHours")]
        public string TotalHours { get; set; }

        [JsonProperty("breakdownMap")]
        public Dictionary<string, int> Breakdown { get; set; }

        [JsonProperty("productBreakdown")]
        public List<ProductBreakdownDataModel> ProductBreakdown { get; set; }
    }

    public class ProductBreakdownDataModel
    {
        [JsonProperty("paymentType")]
        public string PaymentType { get; set; }

        [JsonProperty("productAmount")]
        public int ProductAmount { get; set; }

        [JsonProperty("productName")]
        public string ProductName { get; set; }

        [JsonProperty("quantityBought")]
        public long Quantity { get; set; }

        [JsonProperty("totalAmount")]
        public long TotalAmount { get; set; }
    }
}
