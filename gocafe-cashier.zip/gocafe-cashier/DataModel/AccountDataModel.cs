﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class AccountDataModel
    {
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("expiryDateTime")]
        public string ExpiryDateTime { get; set; }
    }
}
