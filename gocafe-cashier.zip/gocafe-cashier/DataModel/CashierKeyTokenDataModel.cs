﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class CashierKeyTokenDataModel
    {
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        [JsonProperty("key")]
        public string Key { get; set; }
    }
}
