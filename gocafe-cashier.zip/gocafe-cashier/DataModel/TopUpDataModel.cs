﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class TopUpDataModel
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("balance")]
        public int Balance { get; set; }
    }
}
