﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.Store
{
    public class MemberSalesOrderDataModel
    {

    }
}
