﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.Inventory
{
    public class PurchaseProductDataModel
    {
        [JsonProperty("productId")]
        public string ProductId { get; set; }

        [JsonProperty("productName")]
        public string ProductName { get; set; }

        [JsonProperty("measurementUnitName")]
        public string MeasurementUnitName { get; set; }

        [JsonProperty("categoryName")]
        public string CategoryName { get; set; }

        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }
    }
}
