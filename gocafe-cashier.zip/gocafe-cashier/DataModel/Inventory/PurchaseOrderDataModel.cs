﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel.Inventory
{
    public class PurchaseOrderDataModel
    {

        [JsonProperty("transactionDateTime")]
        public string TransactionDateTime { get; set; }

        [JsonProperty("cashierSessionId")]
        public string CashierSessionID { get; set; }

        [JsonProperty("receiptNumber")]
        public string ReceiptNumber { get; set; }

        [JsonProperty("purchaseProducts")]
        public List<PurchaseProductDataModel> PurchaseProducts { get; set; }

    }
}
