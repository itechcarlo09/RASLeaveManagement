﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel.Inventory
{
    public class ItemDataModel
    {
        [JsonProperty("product")]
        public ProductDataModel Product { get; set; }

        [JsonProperty("quantity")]
        public int QuantityInStock { get; set; }

        [JsonProperty("cashiers")]
        public List<CashierInventoryDataModel> Cashiers { get; set; }

        [JsonProperty("retailAmount")]
        public int RetailPrice { get; set; }

        [JsonProperty("totalCashAmount")]
        public int TotalCashAmount { get; set; }

        [JsonProperty("totalOktopayAmount")]
        public int TotalOKTOPayAmount { get; set; }

        [JsonProperty("isComposite")]
        public bool IsCompositeProduct { get; set; }
    }
}
