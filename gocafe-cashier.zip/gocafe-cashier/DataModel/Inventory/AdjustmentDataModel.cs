﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel.Inventory
{
    public class AdjustmentDataModel
    {
        [JsonProperty("dateCreated")]
        public string DateCreated { get; set; }

        [JsonProperty("adjustmentReason")]
        public string AdjustmentReason { get; set; }

        [JsonProperty("transactionDateTime")]
        public string TransactionDateTime { get; set; }

        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }

        [JsonProperty("branchId")]
        public string BranchID { get; set; }

        [JsonProperty("branchName")]
        public string BranchName { get; set; }

        [JsonProperty("adjustmentProducts")]
        public List<AdjustmentProductDataModel> AdjustmentProducts { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("referenceNumber")]
        public string ReferenceNumber { get; set; }

        [JsonProperty("dateCreatedDisplay")]
        public string DateCreatedDisplay { get; set; }

        [JsonProperty("transactionDateTimeDisplay")]
        public string TransactionDateTimeDisplay { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }
    }
}
