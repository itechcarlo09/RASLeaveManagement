﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.Inventory
{
    public class ProductDataModel
    {
        [JsonProperty("retail")]
        public RetailDataModel Retail { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("category")]
        public CategoryDataModel Category { get; set; }

        [JsonProperty("id")]
        public string ProductID { get; set; }
    }
}
