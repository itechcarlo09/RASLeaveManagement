﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel.Inventory
{
    public class RetailDataModel
    {
        [JsonProperty("sku")]
        public string SKU { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }
    }
}
