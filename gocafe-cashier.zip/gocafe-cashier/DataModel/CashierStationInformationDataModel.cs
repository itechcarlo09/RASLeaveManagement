﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel
{
    public class CashierStationInformationDataModel
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("topupMaximumAmount")]
        public int TopupMaximumAmount { get; set; }

        [JsonProperty("currency")]
        public string Currency { get; set; }

        [JsonProperty("currencySign")]
        public string CurrencySign { get; set; }

        [JsonProperty("configuration")]
        public List<BranchConfigurationsDataModel> Configuration { get; set; }
    }
}
