﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using gocafe_cashier.DataModel.Inventory;

namespace gocafe_cashier.DataModel
{
    public class EndShiftDataModel
    {
        [JsonProperty("totalCash")]
        public int TotalSales { get; set; }

        [JsonProperty("shiftStartDateTime")]
        public DateTime StartDate { get; set; }

        [JsonProperty("shiftEndDateTime")]
        public DateTime EndDate { get; set; }

        [JsonProperty("shifts")]
        public List<ShiftDataModel> Shifts { get; set; }

        [JsonProperty("shiftInventory")]
        public List<ItemDataModel> ShiftInventory { get; set; }
    }
}
