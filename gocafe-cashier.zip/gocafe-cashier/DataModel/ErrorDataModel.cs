﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class ErrorDataModel
    {
        [JsonProperty("status")]
        public int Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("timestamp")]
        public string TimeStamp { get; set; }

        [JsonProperty("exception")]
        public string Exception { get; set; }

        [JsonProperty("path")]
        public string Path { get; set; }
    }
}
