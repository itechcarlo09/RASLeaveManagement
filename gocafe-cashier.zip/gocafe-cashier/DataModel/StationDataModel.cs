﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class StationDataModel
    {
        public StationDataModel()
        {
            Initialize();
        }

        private void Initialize()
        {
            Name = "--";
            Remarks = "--";
            StaticIPAddress = "--";
            ID = "--";
        }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("remarks")]
        public string Remarks { get; set; }

        [JsonProperty("branch")]
        public BranchDataModel Branch { get; set; }

        [JsonProperty("stationType")]
        public StationTypeDataModel StationType { get; set; }

        [JsonProperty("staticIpAddress")]
        public string StaticIPAddress { get; set; }

        [JsonProperty("macAddress")]
        public string MacAddress { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }

        public int PcNumber { get; set; }
    }
}
