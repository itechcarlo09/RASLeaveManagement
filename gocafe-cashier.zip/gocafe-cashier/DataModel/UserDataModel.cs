﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class UserDataModel
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("isAvailable")]
        public bool IsAvailable { get; set; }

        [JsonProperty("member")]
        public MemberData MemberData { get; set; }
    }

    public class MemberData
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("balance")]
        public string Balance { get; set; }

        [JsonProperty("customerAccount")]
        public CustomerAccountDataModel CustomerAccount { get; set; }

        [JsonProperty("cardNumber")]
        public string CardNumber { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("memberType")]
        public MemberTypesDataModel MemberType { get; set; }
    }
}
