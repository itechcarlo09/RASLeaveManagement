﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class CustomerAccountDataModel
    {
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("deleted")]
        public bool IsDeleted { get; set; }

        [JsonProperty("id")]
        public string ID { get; set; }
    }
}
