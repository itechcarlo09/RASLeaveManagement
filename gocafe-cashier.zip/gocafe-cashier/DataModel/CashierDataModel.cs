﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace gocafe_cashier.DataModel
{
    public class CashierDataModel
    {
        [JsonProperty("id")]
        public string ID { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("cashierSessionId")]
        public string CashierSessionID { get; set; }

        [JsonProperty("branch")]
        public BranchDataModel Branch { get; set; }

        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        public string AccessKey { get; set; }

        [JsonProperty("cashierActionPermissions")]
        public List<string> CashierActionPermissionList { get; set; }
    }
}