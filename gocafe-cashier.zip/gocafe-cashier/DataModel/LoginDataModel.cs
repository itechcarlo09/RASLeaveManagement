﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class LoginDataModel
    {
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("branchId")]
        public string BranchId { get; set; }

        [JsonProperty("stationId")]
        public string StationId { get; set; }
    }
}
