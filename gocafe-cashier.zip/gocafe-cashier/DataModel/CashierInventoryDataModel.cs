﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class CashierInventoryDataModel
    {
        [JsonProperty("cashierUsername")]
        public string CashierUsername { get; set; }

        [JsonProperty("quantitySoldThroughCash")]
        public int CashQuantity { get; set; }

        [JsonProperty("quantitySoldThroughOKtopay")]
        public int OKTOPayQuantity { get; set; }

        [JsonProperty("totalQuantitySold")]
        public int TotalQuantitySold { get; set; }
    }
}
