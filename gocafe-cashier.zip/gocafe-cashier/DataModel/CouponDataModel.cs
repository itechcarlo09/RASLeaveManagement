﻿using Newtonsoft.Json;

namespace gocafe_cashier.DataModel
{
    public class CouponDataModel
    {
        [JsonProperty("guestID")]
        public string GuestID { get; set; }

        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("secondsRemaining")]
        public int SecondsRemaining { get; set; }
    }
}
