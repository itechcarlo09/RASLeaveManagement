﻿namespace gocafe_cashier.ViewModelMediator
{
    public class Messages
    {
        public const string GetUserInfo = "GetUserInfo";
        public const string SendUserInfo = "SendUserInfo";
        public const string CashierInfo = "CashierInfo";
        public const string TopUpByUser = "TopUpByUser";
        public const string PCAssigned = "PCAssigned";
        public const string StationList = "StationList";
        public const string TransactionModel = "TransactionModel";

        public const string LogoutUser = "LogoutUser";
        public const string SwitchToLoginView = "SwitchToLoginView";

        public const string CardController = "CardController";
        public const string CardTapped = "CardTapped";
        public const string CardEvent = "CardEvent";
        public const string CardID = "CardID";

        public const string LeftUserControl = "LeftUserControl";
        public const string RightUserControl = "RightUserControl";
        public const string MainViewModel = "MainViewModel";

        public const string CashierViewModel = "CashierViewModel";
        public const string ShowBlurBackground = "ShowBlurBackground";

        public const string AccountManagerViewModel = "AccountManagerViewModel";
        public const string AccountManagerWindow = "AccountManagerWindow";

        public const string ResetPasswordViewModel = "ResetPasswordViewModel";
        public const string ResetPasswordWindow = "ResetPasswordWindow";

        public const string TopUpManagerViewModel = "TopUpManagerViewModel";
        public const string TopUpManagerWindow = "TopUpManagerWindow";

        public const string ConfirmationWindowViewModel = "ConfirmationWindowViewModel";
        public const string ConfirmationWindow = "ConfirmationWindow";
        public const string WarningConfirmation = "WarningConfirmation";
        public const string SuccessConfirmation = "SuccessConfirmation";
        public const string ErrorConfirmation = "ErrorConfirmation";

        public const string CouponManagerViewModel = "CouponManagerViewModel";
        public const string CouponManagerWindow = "CouponManagerWindow";
        public const string SelectAllStationType = "SelectAllStationType";
        public const string UnSelectAllStationType = "UnSelectAllStationType";
        public const string SelectAllOnlyTrigger = "SelectAllOnlyTrigger";
        public const string SelectMemberType = "SelectMemberType";

        public const string FoodAndBeverageManagerWindowViewModel = "FoodAndBeverageManagerWindowViewModel";
        public const string FoodAndBeverageManagerWindow = "FoodAndBeverageManagerWindow";
        public const string FilterFoodAndBeverageList = "FilterFoodAndBeverageList";
        public const string SearchFoodAndBeverage = "SearchFoodAndBeverage";

        public const string InventoryManagerWindowViewModel = "InventoryManagerWindowViewModel";
        public const string InventoryManagerWindow = "InventoryManagerWindow";
        public const string InventoryManagerModel = "InventoryManagerModel";
        public const string IsModified = "IsModified";

        public const string EShopWindowViewModel = "EShopWindowViewModel";
        public const string EShopWindow = "EShopWindow";

        public const string EmailPopUpWindowViewModel = "EmailPopUpWindowViewModel";
        public const string EmailPopUpWindow = "EmailPopUpWindow";
        public const string EmailAddress = "EmailAddress";

        public const string InventoryPopUpWindowViewModel = "InventoryPopUpWindowViewModel";
        public const string InventoryPopUpWindow = "InventoryPopUpWindow";
        public const string SelectedItem = "SelectedItem";
        public const string ChangeType = "ChangeType";

        public const string EShopPopUpWindowViewModel = "EShopPopUpWindowViewModel";
        public const string EShopPopUpWindow = "EShopPopUpWindow";
        public const string PurchasedItem = "PurchasedItem";
        public const string ItemPayed = "ItemPayed";

        public const string SummaryWindowViewModel = "SummaryWindowViewModel";
        public const string SummaryWindow = "SummaryWindow";
        public const string SummaryTitle = "SummaryTitle";
        public const string SummaryContent = "SummaryContent";
        public const string OtherSummaryContent = "OtherSummaryContent";
        public const string PurchaseOrderSummaryTitle = "Purchase Order Summary";

        public const string ReplaceCardWindowViewModel = "ReplaceCardWindowViewModel";
        public const string ReplaceCardWindow = "ReplaceCardWindow";

        public const string LogOutCustomerWindowViewModel = "LogOutCustomerWindowViewModel";
        public const string LogOutCustomerWindow = "LogOutCustomerWindow";
      
        public const string TransactionHistoryWindowViewModel = "TransactionHistoryWindowViewModel";
        public const string TransactionHistoryWindow = "TransactionHistoryWindow";

        public const string ReceivedOrdersWindow = "ReceivedOrdersWindow";
        public const string ReceivedOrdersViewModel = "ReceivedOrdersViewModel";
        public const string ReceivedPendingOrdersCount = "ReceivedPendingOrdersCount";
        public const string OpenReceivedOrderWindow = "OpenReceivedOrderWindow";

        public const string PendingOrdersWindow = "PendingOrdersWindow";
        public const string PendingOrdersWindowViewModel = "PendingOrdersWindowViewModel";
        public const string PendingOrdersCount = "PendingOrdersCount";
        public const string OpenClosePendingOrdersWindow = "OpenClosePendingOrdersWindow";

        public const string PasswordConfirmationWindow = "PasswordConfirmationWindow";
        public const string PasswordConfirmationWindowViewModel = "PasswordConfirmationWindowViewModel";
        public const string Username = "Username";

        public const string WindowInitializationError = "WindowInitializationError";

        public const string GenericDialogWindow = "Confirmation Window";

        public const string GuestAccount = "GuestAccount";

        public const string IsProcessing = "IsProcessing";
        public const string ProcessingText = "ProcessingText";

        public const string LoginGuest = "LoginGuest";

        public const string LoginWindows = "LoginWindows";
        public const string StopLoading = "StopLoading";

        public const string PCTransferWindow = "PCTransferWindow";
        public const string PCTransferWindowViewModel = "PCTransferWindowViewModel";
        public const string SelectedWorkstationToTransfer = "SelectedWorkstationToTransfer";

        public const string RefreshAccessToken = "RefreshAccessTokens";
        public const string RefreshAccessKey = "RefreshAccessKeys";

        public const string CancelPromoWindow = "CancelPromoWindow";
        public const string CancelPromoViewModel = "CancelPromoViewModel";

        public const string EndShiftWindow = "EndShiftWindow";
        public const string EndShiftWindowViewModel = "EndShiftWindowViewModel";

        public const string EndShiftSummaryWindow = "EndShiftSummaryWindow";
        public const string EndShiftSummaryWindowViewModel = "EndShiftSummaryWindowViewModel";
        public const string EndShiftData = "EndShiftData";

        public const string PreviousShiftWindow = "PreviousShiftWindow";
        public const string PreviousShiftSummaryWindow = "PreviousShiftSummaryWindow";
        public const string PreviousShiftWindowViewModel = "PreviousShiftWindowViewModel";
        public const string PreviousShiftSummaryWindowViewModel = "PreviousShiftSummaryWindowViewModel";
        public const string PreviousShiftData = "PreviousShiftData";

        public const string CurrentShiftWindow = "CurrentShiftWindow";
        public const string CurrentShiftSummaryWindow = "CurrentShiftSummaryWindow";
        public const string CurrentShiftWindowViewModel = "CurrentShiftWindowViewModel";
        public const string CurrentShiftSummaryWindowViewModel = "CurrentShiftSummaryWindowViewModel";
        public const string CurrentShiftData = "CurrentShiftData";

        public const string VoidConfirmationWindow = "VoidConfirmationWindow";
        public const string VoidConfirmationWindowViewModel = "VoidConfirmationWindowViewModel";

        public const string InformAgentTransaction = "InformAgentTransaction";
        public const string MemberData = "MemberData";

        public const string NetworkStarterModel = "NetworkStarterModel";
        public const string ResetNetComms = "ResetNetComms";

        public const string ConnectionEstablished = "ConnectionEstablished";
        public const string ClientAccountDetails = "ClientAccountDetails";
        public const string ClientDisconnected = "ClientDisconnected";
        public const string ClientUpdatedAccountBalance = "ClientUpdatedAccountBalance";
        public const string LockPC = "LockPC";
        public const string ClientOrderDetail = "InformOrderDetail";
        public const string ClientLogout = "ClientLogout";
        public const string ClientTransferToken = "ClientTransferToken";
        public const string ClientTransferStatusDetail = "ClientTransferStatusDetail";

        public const string ChatWindowViewModel = "ChatWindowViewModel";
        public const string ChatWindow = "ChatWindow";
        public const string ClientChat = "ClientChat";

        public const string OpenTopUpManager = "OpenTopUpManager";
        public const string OpenEShop = "OpenEShop";
        public const string OpenFoodAndBeverage = "OpenFoodAndBeverage";
        public const string OpenAccountManager = "OpenAccountManager";
        public const string OpenInventoryManager = "OpenInventoryManager";
        public const string OpenReceivedOrders = "OpenReceivedOrders";
        public const string OpenTransactionHistory = "OpenTransactionHistory";
        public const string OpenCoupon = "OpenCoupon";
        public const string OpenCancelPromo = "OpenCancelPromo";
        public const string OpenResetPassword = "OpenResetPassword";
        public const string OpenReplaceCard = "OpenReplaceCard";
        public const string OpenLogOutCustomer = "OpenLogOutCustomer";

        public const string IsFocusedOnTextbox = "IsFocusedOnTextbox";
        
        public const string GetUpdatedOrderNumbers = "GetUpdatedOrderNumbers";
        public const string HandledOrder = "HandledOrder";

        public const string OrderRejectReasonWindow = "OrderRejectReasonWindow";
        public const string OrderRejectReasonViewModel = "OrderRejectReasonViewModel";
        public const string OrderRejectReasonMessage = "OrderRejectReasonMessage";
    }
}
