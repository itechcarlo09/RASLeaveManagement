﻿using gocafe_cashier.Model;
using System.Collections.Generic;

namespace gocafe_cashier.ViewModelMediator
{
    public sealed class Mediator
    {
        static readonly Mediator instance = new Mediator();

        MultiDictionary<string, BaseModel> internalList = new MultiDictionary<string, BaseModel>();

        static Mediator()
        {

        }

        private Mediator()
        {

        }

        public static Mediator Instance
        {
            get { return instance; }
        }

        public void Register(BaseModel viewModel, string message)
        {
            internalList.AddValue(message, viewModel);
        }

        public void UnRegister(BaseModel viewModel, string message)
        {
            if (internalList.ContainsKey(message))
            {
                internalList.Remove(message);
            }
        }

        public bool IsRegistered(string message)
        {
            return internalList.ContainsKey(message);
        }

        public void NotifyViewModel(string viewModelName, string message, object args)
        {
            if (internalList.ContainsKey(viewModelName))
            {
                foreach (BaseModel viewModel in internalList[viewModelName])
                {
                    viewModel.SendData(message, args);
                }
            }
        }

        public void NotifyViewModels(List<string> viewModelList, string message, object args)
        {
            foreach(string viewModelName in viewModelList)
            {
                if (internalList.ContainsKey(viewModelName))
                {
                    foreach (BaseModel viewModel in internalList[viewModelName])
                    {
                        viewModel.SendData(message, args);
                    }
                }
            }
        }

        public void ClearInternalList()
        {
            internalList.Clear();
        }
    }
}
