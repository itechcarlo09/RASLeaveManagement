﻿using System.Collections.Generic;
using gocafe_cashier.DataModel;
using GocafeService;
using System.Threading.Tasks;
using gocafe_cashier.Validation;
using System.Threading;
using GocafeShared.Model;
using System;

namespace gocafe_cashier.ServiceProvider
{
    public class CashierServiceProvider : ServiceProvider, ICashierServiceProvider
    {
        CashierService cashierService = new CashierService();

        public async Task<List<StationDataModel>> GetStationList(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await cashierService.GetStationList(
                HostServerIP + RouteAddress.RouteResource.GetStationList(), 
                cashierSessionID, 
                cancellationToken);

            return HttpValidationModel<List<StationDataModel>>.ValidateAndMap(response);
        }

        public async Task<List<StationTypeDataModel>> GetStationTypeList(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await cashierService.GetStationTypeList(
                HostServerIP + RouteAddress.RouteResource.GetStationTypeList(),
                cashierSessionID, 
                cancellationToken);

            return HttpValidationModel<List<StationTypeDataModel>>.ValidateAndMap(response);
        }

        public async Task<CashierStationInformationDataModel> GetStationInformation(string macAddress, CancellationToken cancellationToken)
        {
            var response = await cashierService.GetCashierStationInformation(
                HostServerIP + RouteAddress.RouteResource.GetCashierStationInformation(macAddress),
                cancellationToken);

            return HttpValidationModel<CashierStationInformationDataModel>.ValidateAndMap(response);
        }

        public async Task<CashierKeyTokenDataModel> GenerateCashierKeyToken(string cashierSessionID, string accessToken, CancellationToken cancellationToken)
        {
            var response = await cashierService.GenerateCashierKeyToken(
                HostServerIP + RouteAddress.RouteResource.GetGenerateKey(),
                cashierSessionID,
                accessToken,
                cancellationToken);

            return HttpValidationModel<CashierKeyTokenDataModel>.ValidateAndMap(response);
        }

        public async Task<CashierKeyTokenDataModel> RetrieveCashierKeyToken(string cashierSessionID, string accessToken, string accessKey, CancellationToken cancellationToken)
        {
            var response = await cashierService.RetrieveCashierKeyToken(
                HostServerIP + RouteAddress.RouteResource.GetRetrieveKey(),
                cashierSessionID,
                accessToken,
                accessKey,
                cancellationToken);

            return HttpValidationModel<CashierKeyTokenDataModel>.ValidateAndMap(response);
        }

        public async Task<Tuple<List<TransactionLogDataModel>, ResponseModel>> GetTransactionLog(string cashierSessionID, long startDateTime, long endDateTime, CancellationToken cancellationToken)
        {
            var response = await cashierService.GetTransactionLog(
                HostServerIP + RouteAddress.RouteResource.GetTransactionLog(startDateTime, endDateTime), 
                cashierSessionID, 
                cancellationToken);

            var model = HttpValidationModel<List<TransactionLogDataModel>>.ValidateAndMap(response);

            Tuple<List<TransactionLogDataModel>, ResponseModel> returnObject = new Tuple<List<TransactionLogDataModel>, ResponseModel>(model, response);

            return returnObject;
        }

        public async Task<ResponseModel> ValidateSession(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await cashierService.ValidateCashierSession(
                HostServerIP + RouteAddress.RouteResource.GetSessionValidation(),
                cashierSessionID,
                cancellationToken);

            return HttpValidationModel<ResponseModel>.ValidateAndMap(response);
        }

        public async Task<Tuple<string, ResponseModel>> SendVoidRequest(string cashierSessionID, string transactionReferenceNumber, CancellationToken cancellationToken)
        {
            var response = await cashierService.SendVoidRequest(
                HostServerIP + RouteAddress.RouteResource.SendVoidRequest(),
                cashierSessionID,
                transactionReferenceNumber,
                cancellationToken);

            var model = HttpValidationModel<string>.ValidateAndMap(response);

            Tuple<string, ResponseModel> returnObject = new Tuple<string, ResponseModel>(model, response);

            return returnObject;
        }

        public async Task<Tuple<List<TransactionLogDataModel>, ResponseModel>> GetTransactionLogByCount(string cashierSessionID, int transactionCount, CancellationToken cancellationToken)
        {
            var response = await cashierService.GetTransactionLog(
                HostServerIP + RouteAddress.RouteResource.GetTransactionLogByCount(transactionCount),
                cashierSessionID,
                cancellationToken);

            var model = HttpValidationModel<List<TransactionLogDataModel>>.ValidateAndMap(response);

            Tuple<List<TransactionLogDataModel>, ResponseModel> returnObject = new Tuple<List<TransactionLogDataModel>, ResponseModel>(model, response);

            return returnObject;
        }
    }
}
