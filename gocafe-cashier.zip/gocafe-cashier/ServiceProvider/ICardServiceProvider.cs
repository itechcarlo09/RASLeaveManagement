﻿using GocafeShared.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface ICardServiceProvider
    {
        Task<ResponseModel> UnlockUser(string cashierSessionID, string cardID, CancellationToken cancellationToken);
    }
}
