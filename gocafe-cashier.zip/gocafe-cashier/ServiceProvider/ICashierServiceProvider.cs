﻿using gocafe_cashier.DataModel;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System;
using GocafeShared.Model;

namespace gocafe_cashier.ServiceProvider
{
    public interface ICashierServiceProvider
    {
        Task<List<StationDataModel>> GetStationList(string cashierSessionID, CancellationToken cancellationToken);
        Task<List<StationTypeDataModel>> GetStationTypeList(string cashierSessionID, CancellationToken cancellationToken);
        Task<CashierStationInformationDataModel> GetStationInformation(string macAddress, CancellationToken cancellationToken);
        Task<CashierKeyTokenDataModel> GenerateCashierKeyToken(string cashierSessionID, string accessToken, CancellationToken cancellationToken);
        Task<CashierKeyTokenDataModel> RetrieveCashierKeyToken(string cashierSessionID, string accessToken, string accessKey, CancellationToken cancellationToken);
        Task<Tuple<List<TransactionLogDataModel>, ResponseModel>> GetTransactionLog(string cashierSessionID, long startDateTime, long endDateTime, CancellationToken cancellationToken);
        Task<ResponseModel> ValidateSession(string cashierSessionID, CancellationToken cancellationToken);
        Task<Tuple<string, ResponseModel>> SendVoidRequest(string cashierSessionID, string transactionReferenceNumber, CancellationToken cancellationToken);
        Task<Tuple<List<TransactionLogDataModel>, ResponseModel>> GetTransactionLogByCount(string cashierSessionID, int transactionCount, CancellationToken cancellationToken);
    }
}
