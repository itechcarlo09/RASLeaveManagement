﻿using gocafe_cashier.DataModel;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface ILoginServiceProvider
    {
        Task<CashierDataModel> Login(string username, string password, CancellationToken cancellationToken);
    }
}
