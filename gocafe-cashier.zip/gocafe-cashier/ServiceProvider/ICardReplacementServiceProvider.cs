﻿using gocafe_cashier.DataModel;
using GocafeService.DataTransfer;
using GocafeShared.Model;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface ICardReplacementServiceProvider
    {
        Task<MemberInfoDataModel> GetMemberInfoByUserName(string username, string cashierID, CancellationToken cancellationToken);
        Task<CardReplacementPayload> ReplaceCard(string memberID, string cashierID, string cardNumber, decimal replacementFee, CancellationToken cancellationToken);
    }
}
