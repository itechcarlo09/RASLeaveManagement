﻿using gocafe_cashier.Manager;
using GocafeService;
using System.Collections.Generic;
using gocafe_cashier.RouteAddress;
using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.Validation;
using System.Threading.Tasks;
using System.Threading;

namespace gocafe_cashier.ServiceProvider
{
    public class EShopServiceProvider: ServiceProvider, IEShopServiceProvider
    {
        private static EShopService eShopService = null;

        public EShopServiceProvider()
        {
            eShopService = new EShopService();
        }

        public async Task<List<EShopCodeListDataModel>> GetEShopCodeList(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await eShopService.GetEShopCodeList(
                cashierSessionID,
                Host3ServerIP + RouteResource.GetEshopCodes(), 
                cancellationToken);
            
            return HttpValidationModel<List<EShopCodeListDataModel>>.ValidateAndMap(response);
        }

        public async Task<EshopCodeDataModel> ClaimEShopCodeThruCashier(string codeTypeID, string cashierSessionID, int paymentType, string email, CancellationToken cancellationToken)
        {
            var response = await eShopService.ClaimEShopCodeThruCash(
                Host3ServerIP + RouteResource.ClaimEshopCodeThruCash(),
                codeTypeID,
                cashierSessionID,
                paymentType,
                email, 
                cancellationToken);

            return HttpValidationModel<EshopCodeDataModel>.ValidateAndMap(response);
        }
    }
}
