﻿using gocafe_cashier.DataModel.FnBDataModels;
using GocafeShared.Model;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface IStoreServiceProvider
    {
        Task<List<SalesOrderDataModel>> GetSalesOrderByStatus(string cashierSessionId, string status, string startDateTime, string endDateTime,
            CancellationToken cancellationToken);
        Task<Tuple<SalesDataModel, ResponseModel>> AcceptMemberOrder(string cashierSessionID, string pendingOrderID, CancellationToken cancellationToken);
        Task<ResponseModel> RejectMemberOrder(string cashierSessionID, string pendingOrderID, string remarks, CancellationToken cancellationToken);
        Task<int> GetSalesOrderCount(string cashierSessionID, string status, DateTime startDate, DateTime endDate, CancellationToken cancellationToken);
    }
}
