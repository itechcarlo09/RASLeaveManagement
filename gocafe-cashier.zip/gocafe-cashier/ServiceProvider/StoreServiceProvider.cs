﻿using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.RouteAddress;
using gocafe_cashier.Validation;
using GocafeService;
using GocafeService.Model;
using GocafeShared.Model;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public class StoreServiceProvider : ServiceProvider, IStoreServiceProvider
    {
        private IStoreService storeService;
        
        public StoreServiceProvider()
        {
            storeService = new StoreService();
        }

        public async Task<Tuple<SalesDataModel, ResponseModel>> AcceptMemberOrder(string cashierSessionID, string pendingOrderID, CancellationToken cancellationToken)
        {
            var response = await storeService.AcceptMemberOrder(
                Host3ServerIP + RouteResource.AcceptSalesOrder(),
                cashierSessionID,
                pendingOrderID,
                cancellationToken);

            int httpStatusCode = response.HttpStatusCode;

            var model = HttpValidationModel<SalesDataModel>.ValidateAndMap(response);

            Tuple<SalesDataModel, ResponseModel> data = new Tuple<SalesDataModel, ResponseModel>(model, response);

            return data;
        }

        public async Task<List<SalesOrderDataModel>> GetSalesOrderByStatus(string cashierSessionId, string status, string startDateTime, string endDateTime, CancellationToken cancellationToken)
        {
            var response = await storeService.GetSalesOrderByStatus(
                Host3ServerIP + RouteResource.GetSalesOrderByStatus(status, startDateTime, endDateTime), 
                cashierSessionId, 
                cancellationToken);

            return HttpValidationModel<List<SalesOrderDataModel>>.ValidateAndMap(response);
        }

        public async Task<ResponseModel> RejectMemberOrder(string cashierSessionID, string pendingOrderID, string remarks, CancellationToken cancellationToken)
        {
            var response = await storeService.RejectMemberOrder(
                Host3ServerIP + RouteResource.RejectSalesOrder(),
                cashierSessionID,
                pendingOrderID,
                remarks,
                cancellationToken);

            return HttpValidationModel<ResponseModel>.ValidateAndMap(response);
        }

        public async Task<int> GetSalesOrderCount(string cashierSessionID, string status, DateTime startDate, DateTime endDate, CancellationToken cancellationToken)
        {
            string url = Host3ServerIP + RouteResource.GetSalesOrderCount(status, startDate.ToString($"yyyy-MM-ddTHH:mm:ss"), endDate.AddDays(1).ToString($"yyyy-MM-ddTHH:mm:ss"));

            OrderCountRequestModel historyRequestModel = new OrderCountRequestModel
            {
                Url = url,
                CancellationToken = cancellationToken,
                SessionID = cashierSessionID
            };

            var response = await storeService.GetSalesOrderCount(historyRequestModel);

            return HttpValidationModel<int>.ValidateAndMap(response);
        }
    }
}