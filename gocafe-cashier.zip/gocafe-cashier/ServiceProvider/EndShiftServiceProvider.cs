﻿using gocafe_cashier.DataModel;
using gocafe_cashier.Validation;
using GocafeService;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public class EndShiftServiceProvider: ServiceProvider, IEndShiftServiceProvider
    {
        AuthService authService = new AuthService();

        public async Task<EndShiftDataModel> EndShift(string password, string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await authService.EndShift(
                HostServerIP + RouteAddress.RouteResource.EndCurrentShift(),
                password,
                cashierSessionID,
                cancellationToken);

            return HttpValidationModel<EndShiftDataModel>.ValidateAndMap(response);
        }

        public async Task<EndShiftDataModel> GetPreviousShiftSummary(string username, string password, string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await authService.GetPreviousShiftSummary(
                HostServerIP + RouteAddress.RouteResource.GetPreviousShiftSummary(),
                username,
                password,
                cashierSessionID,
                cancellationToken);

            return HttpValidationModel<EndShiftDataModel>.ValidateAndMap(response);
        }

        public async Task<EndShiftDataModel> GetCurrentShiftSummary(string username, string password, string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await authService.GetCurrentShiftSummary(HostServerIP + RouteAddress.RouteResource.GetCurrentShiftSummary(),
                username,
                password,
                cashierSessionID,
                cancellationToken);

            return HttpValidationModel<EndShiftDataModel>.ValidateAndMap(response);
        }
    }
}
