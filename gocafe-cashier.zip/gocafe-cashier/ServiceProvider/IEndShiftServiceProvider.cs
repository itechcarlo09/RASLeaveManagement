﻿using gocafe_cashier.DataModel;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface IEndShiftServiceProvider
    {
        Task<EndShiftDataModel> EndShift(string password, string cashierSessionID, CancellationToken cancellationToken);
        Task<EndShiftDataModel> GetPreviousShiftSummary(string username, string password, string cashierSessionID, CancellationToken cancellationToken);
    }
}
