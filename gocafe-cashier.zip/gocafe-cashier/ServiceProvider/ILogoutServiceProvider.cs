﻿using GocafeShared.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface ILogoutServiceProvider
    {
        Task<ResponseModel> Logout(string cashierSessionID, CancellationToken cancellationToken);
    }
}
