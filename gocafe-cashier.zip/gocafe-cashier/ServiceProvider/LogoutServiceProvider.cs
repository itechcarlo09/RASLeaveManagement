﻿using gocafe_cashier.RouteAddress;
using gocafe_cashier.Validation;
using GocafeService;
using GocafeShared.Model;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public class LogoutServiceProvider : ServiceProvider, ILogoutServiceProvider
    {
        private static AuthService service = new AuthService();

        public async Task<ResponseModel> Logout(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await service.LogoutCashier(
                HostServerIP + RouteResource.GetLogoutResource(),
                cashierSessionID, cancellationToken);

            return HttpValidationModel<ResponseModel>.ValidateAndMap(response);
        }
    }
}
