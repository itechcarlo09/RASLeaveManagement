﻿using gocafe_cashier.DataModel;
using GocafeService;
using System.Collections.Generic;
using GocafeShared.Model;
using System.Threading.Tasks;
using gocafe_cashier.Validation;
using gocafe_cashier.Cache;
using System.Threading;
using System;

namespace gocafe_cashier.ServiceProvider
{
    public class MemberServiceProvider : ServiceProvider, IMemberServiceProvider
    {
        MemberService memberService = new MemberService();

        public async Task<Tuple<AccountDataModel,ResponseModel>> GenerateGuestAccount(string password, string cashierSessionID, int transactionAmount, int paymentTypeId, string promoId, string signature, CancellationToken cancellationToken)
        {
            var response = await memberService.CreateGuestAccount(
                HostServerIP + RouteAddress.RouteResource.GetGenerateGuestAccountResource(),
                password,
                cashierSessionID,
                transactionAmount, 
                paymentTypeId, 
                promoId,
                signature, 
                cancellationToken);

            var model = HttpValidationModel<AccountDataModel>.ValidateAndMap(response);
            Tuple<AccountDataModel, ResponseModel> returnObject = new Tuple<AccountDataModel, ResponseModel>(model, response);

            return returnObject;
        }

        public async Task<Tuple<AccountDataModel, ResponseModel>> GenerateMemberAccount(string username, string password, string cashierSessionID, int transactionAmount, 
            int paymentTypeId, string email, string firstName, string middleName, string lastName, string address, string cityId, 
            string birthDate, string gender, string mobileNumber, int memberTypeId, string memberShipDate, string cardNumber, 
            string promoId, string occupation, string signature, bool isPondoChecked, string pondoUsername, CancellationToken cancellationToken)
        {
            var response = await memberService.CreateMemberAccount(
                HostServerIP + RouteAddress.RouteResource.GetGenerateMemberAccountResource(), 
                username, 
                password,
                cashierSessionID,
                transactionAmount,
                paymentTypeId, 
                email, 
                firstName, 
                middleName, 
                lastName, 
                address, 
                cityId, 
                cardNumber, 
                birthDate, 
                gender, 
                mobileNumber, 
                memberTypeId, 
                memberShipDate, 
                promoId,
                occupation, 
                signature, 
                isPondoChecked,
                pondoUsername,
                cancellationToken);

            var model = HttpValidationModel<AccountDataModel>.ValidateAndMap(response);

            Tuple<AccountDataModel, ResponseModel> returnObject = new Tuple<AccountDataModel, ResponseModel>(model, response);

            return returnObject;
        }

        public async Task<CouponDataModel> GenerateCoupon(string cashierSessionID, string password, int duration, long expirationDateTime, List<int>stationTypeId, CancellationToken cancellationToken)
        {
            List<string> branchID = new List<string>();
            branchID.Add(DataCacheContext.BranchID);

            var response = await memberService.CreateCoupon(
                HostServerIP + RouteAddress.RouteResource.GetGenerateCoupon(), 
                cashierSessionID, 
                password, 
                duration, 
                branchID, 
                DataCacheContext.BranchID, 
                stationTypeId,expirationDateTime, 
                cancellationToken);

            return HttpValidationModel<CouponDataModel>.ValidateAndMap(response);
        }

        public async Task<List<PromoDataModel>> GetPromos(string cashierSessionID, int memberTypeId, int stationTypeId, bool withGuest, string timezone, CancellationToken cancellationToken)
        {
            var response = await memberService.GetPromos(
                HostServerIP + RouteAddress.RouteResource.GetAvailablePromos(),
                cashierSessionID,
                memberTypeId, 
                stationTypeId, 
                withGuest, 
                timezone, 
                cancellationToken);

            return HttpValidationModel<List<PromoDataModel>>.ValidateAndMap(response);
        }

        public async Task<ClientPromoDataModel> GetClientPromo(string cashierSessionID, string username, CancellationToken cancellationToken)
        {
            var response = await memberService.GetClientPromo(
                HostServerIP + RouteAddress.RouteResource.GetClientPromo(),
                username,
                cashierSessionID,
                cancellationToken);

            return HttpValidationModel<ClientPromoDataModel>.ValidateAndMap(response);
        }

        public async Task<List<MemberTypesDataModel>> GetMemberTypes(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await memberService.GetMemberTypes(
                HostServerIP + RouteAddress.RouteResource.GetMemberTypesResource(),
                cashierSessionID,
                cancellationToken);

            return HttpValidationModel<List<MemberTypesDataModel>>.ValidateAndMap(response);
        }

        public async Task<MemberTypesDataModel> GetMemberTypeByID(string cashierSessionID, int memberTypeID, CancellationToken cancellationToken)
        {
            var response = await memberService.GetMemberTypeByID(
                HostServerIP + RouteAddress.RouteResource.GetMemberTypeByID(memberTypeID), 
                DataCacheContext.CashierSessionID, 
                cancellationToken);

            return HttpValidationModel<MemberTypesDataModel>.ValidateAndMap(response);
        }

        public async Task<ResponseModel> ResetPassword(string email, string mobileNumber, string cardNumber, string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await memberService.ResetMemberPassword(
                HostServerIP + RouteAddress.RouteResource.GetResetPasswordResource(), 
                email, 
                mobileNumber, 
                cardNumber, 
                cashierSessionID,
                cancellationToken);

            return HttpValidationModel<ResponseModel>.ValidateAndMap(response);
        }

        public async Task<ResponseModel> MemberAuthentication(string username, string password, string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await memberService.Authenticate(
                HostServerIP + RouteAddress.RouteResource.GetMemberAuthenticateResource(),
                cashierSessionID,
                username,
                password,
                cancellationToken);

            return HttpValidationModel<ResponseModel>.ValidateAndMap(response);
        }

        public async Task<Tuple<TopUpDataModel, ResponseModel>> MemberTopUp(string customerType, string username, int amount, string cashierSessionID, int paymentId, string promoId, string signature, CancellationToken cancellationToken)
        {
            var response = await memberService.TopUpMember(
                HostServerIP + RouteAddress.RouteResource.GetTopUpResource(), 
                customerType,
                username, 
                amount, 
                cashierSessionID, 
                paymentId, 
                promoId,
                signature,
                cancellationToken);

            var model = HttpValidationModel<TopUpDataModel>.ValidateAndMap(response);
            Tuple<TopUpDataModel, ResponseModel> returnObject = new Tuple<TopUpDataModel, ResponseModel>(model, response);
            
            return returnObject;
        }

        public async Task<UserDataModel> GetMemberInfo(string cardID, string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await memberService.GetMemberInfo(
                HostServerIP + RouteAddress.RouteResource.GetMemberInfo(), 
                cardID,
                cashierSessionID, 
                cancellationToken);

            return HttpValidationModel<UserDataModel>.ValidateAndMap(response);
        }

        public async Task<ResponseModel> ForceLogOutMember(string username, string cashierSession, CancellationToken cancellationToken)
        {
            var response = await memberService.ForceLogOutMember(
                HostServerIP + RouteAddress.RouteResource.ForceLogOutCustomer(), 
                username, 
                cashierSession, 
                cancellationToken);

            return HttpValidationModel<ResponseModel>.ValidateAndMap(response);
        }

        public async Task<ResponseModel> CancelPromo(string cashierSession, string username, int paymentTypeId, CancellationToken cancellationToken)
        {
            var response = await memberService.CancelPromo(
                HostServerIP + RouteAddress.RouteResource.CancelPromo(),
                username, 
                cashierSession, 
                paymentTypeId, 
                cancellationToken);

            return HttpValidationModel<ResponseModel>.ValidateAndMap(response);
        }
    }
}
