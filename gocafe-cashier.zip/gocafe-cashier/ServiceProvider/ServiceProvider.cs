﻿using gocafe_cashier.Manager;
using gocafe_cryptography;
using System;

namespace gocafe_cashier.ServiceProvider
{
    public class ServiceProvider : ServiceProviderBase
    {
        protected AppSettingManager manager = AppSettingManager.Instance;

        protected string HostServerIP
        {
            get
            {
#if DEBUG
                return manager[AppSettingKey.HostServerIP];
#endif
#if RELEASE
                return Decrypt(manager[AppSettingKey.HostServerIP]);
#endif

            }
        }

        protected string Host3ServerIP
        {
            get
            {
#if DEBUG
                return manager[AppSettingKey.Host3ServerIP];
#endif
#if RELEASE
                return Decrypt(manager[AppSettingKey.Host3ServerIP]);
#endif
            }
        }

        public override string Decrypt(string encryptedValue)
        {
            return ConfigDataProtector.NewDecrypt(Convert.FromBase64String(encryptedValue));
        }
    }
}
