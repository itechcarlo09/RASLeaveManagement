﻿using gocafe_cashier.DataModel;
using gocafe_cashier.Manager;
using gocafe_cashier.Validation;
using GocafeService;
using GocafeService.DataTransfer;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public class CardReplacementServiceProvider: ServiceProvider, ICardReplacementServiceProvider
    {
        private static CardReplacementService cardReplacementService = new CardReplacementService();

        public async Task<MemberInfoDataModel> GetMemberInfoByUserName(string username, string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await cardReplacementService.GetMemberInfoByUserName(
                HostServerIP + RouteAddress.RouteResource.GetMemberByUsername(username),
                cashierSessionID, cancellationToken);

            return HttpValidationModel<MemberInfoDataModel>.ValidateAndMap(response);
        }

        public async Task<CardReplacementPayload> ReplaceCard(string memberID, string cashierSessionID, string cardNumber, decimal replacementFee, CancellationToken cancellationToken)
        {
            var response = await cardReplacementService.ReplaceCard(
                HostServerIP + RouteAddress.RouteResource.ReplaceCard(),
                memberID,
                cashierSessionID,
                cardNumber,
                (int)(replacementFee*100), 
                cancellationToken);

            return HttpValidationModel<CardReplacementPayload>.ValidateAndMap(response);
        }
    }
}
