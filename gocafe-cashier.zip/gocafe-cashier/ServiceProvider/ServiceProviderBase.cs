﻿namespace gocafe_cashier.ServiceProvider
{
    public abstract class ServiceProviderBase
    {
        public abstract string Decrypt(string encrytedValue);
    }
}
