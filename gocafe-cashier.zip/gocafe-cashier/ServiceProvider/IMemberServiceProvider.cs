﻿using gocafe_cashier.DataModel;
using GocafeShared.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System;

namespace gocafe_cashier.ServiceProvider
{
    public interface IMemberServiceProvider
    {
        Task<Tuple<AccountDataModel, ResponseModel>> GenerateMemberAccount(string username, string password, string cashierSessionID, int transactionAmount, int paymentTypeId, 
            string email, string firstName, string middleName, string lastName, string address, string cityId, string birthDate, string gender, 
            string mobileNumber, int memberTypeId, string memberShipDate, string cardNumber, string promoId, string occupation, string signature,
            bool isPondoChecked, string pondoUsername, CancellationToken cancellationToken);
        Task<Tuple<AccountDataModel,ResponseModel>> GenerateGuestAccount(string password, string cashierSessionID, int transactionAmount, int paymentTypeId, string promoId, string signature, CancellationToken cancellationToken);
        Task<List<MemberTypesDataModel>> GetMemberTypes(string cashierSessionID, CancellationToken cancellationToken);
        Task<ResponseModel> ResetPassword(string email, string mobileNumber, string cardNumber, string cashierSessionID, CancellationToken cancellationToken);
        Task<Tuple<TopUpDataModel, ResponseModel>> MemberTopUp(string customerType, string username, int amount, string cashierSessionID, int paymentId, string promoId, string signature, CancellationToken cancellationToken);
        Task<UserDataModel> GetMemberInfo(string cardID, string cashierSessionID, CancellationToken cancellationToken);
        Task<List<PromoDataModel>> GetPromos(string cashierSessionID, int memberTypeId, int stationTypeId, bool withGuest, string timezone, CancellationToken cancellationToken);
        Task<ResponseModel> ForceLogOutMember(string username, string cashierSessionID, CancellationToken cancellationToken);
        Task<CouponDataModel> GenerateCoupon(string cashierSessionID, string password, int duration, long expirationDateTime, List<int> stationTypeId, CancellationToken cancellationToken);
        Task<MemberTypesDataModel> GetMemberTypeByID(string cashierSessionID, int memberTypeID, CancellationToken cancellationToken);
        Task<ResponseModel> MemberAuthentication(string username, string password, string casheirSessionID, CancellationToken cancellationToken);
        Task<ResponseModel> CancelPromo(string cashierSession, string username, int paymentTypeId, CancellationToken cancellationToken);
        Task<ClientPromoDataModel> GetClientPromo(string cashierSessionID, string username, CancellationToken cancellationToken);
    }
}
