﻿using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.Inventory;
using gocafe_cashier.Model.InventoryModels;
using GocafeShared.Model;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface IInventoryServiceProvider
    {
        Task<ObservableCollection<ItemDataModel>> GetInventoryList(string cashierSessionID, CancellationToken cancellationToken);
        Task<AdjustmentDataModel> SendAdjustment(ObservableCollection<ItemModel> itemsToAdjust, string cashierID, string reason, CancellationToken cancellationToken);
        Task<PurchaseOrderDataModel> SendPurchaseOrder(ObservableCollection<ItemModel> itemsPurchased, string cashierID, string receiptNumber, CancellationToken cancellationToken);
        Task<ObservableCollection<AdjustmentDataModel>> GetPendingAdjustmentList(string cashierSessionID, CancellationToken cancellationToken);
    }
}
