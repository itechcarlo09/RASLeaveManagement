﻿using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.FnBDataModels;
using GocafeShared.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface IBranchInventoryServiceProvider
    {
        Task<List<BranchRetailDataModel>> GetBranchInventoryList(string cashierSessionID, CancellationToken cancellationToken);

        Task<SalesDataModel> SendSalesOrder(SalesRequestDataModel salesOrder, CancellationToken cancellationToken);
    }
}
