﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using gocafe_cashier.Manager;
using GocafeService;
using GocafeService.DataTransfer;
using gocafe_cashier.Model.InventoryModels;
using gocafe_cashier.DataModel.Inventory;
using gocafe_cashier.Validation;
using System.Threading.Tasks;
using System.Threading;
using gocafe_cashier.Cache;

namespace gocafe_cashier.ServiceProvider
{
    public class InventoryServiceProvider: ServiceProvider, IInventoryServiceProvider
    {
        private InventoryService inventoryService = new InventoryService();

        public async Task<ObservableCollection<ItemDataModel>> GetInventoryList(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await inventoryService.GetInventoryList(
                Host3ServerIP + RouteAddress.RouteResource.GetInventoryList(), 
                cashierSessionID, 
                cancellationToken);

            return HttpValidationModel<ObservableCollection<ItemDataModel>>.ValidateAndMap(response);
        }

        public async Task<ObservableCollection<AdjustmentDataModel>> GetPendingAdjustmentList(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await inventoryService.GetAdjustmentList(
                Host3ServerIP + RouteAddress.RouteResource.GetPendingAdjustments(), 
                cashierSessionID, 
                cancellationToken);

            return HttpValidationModel<ObservableCollection<AdjustmentDataModel>>.ValidateAndMap(response);
        }

        public async Task<AdjustmentDataModel> SendAdjustment(ObservableCollection<ItemModel> itemsToAdjust, string cashierSessionID, string reason, CancellationToken cancellationToken)
        {
            List<AdjustmentProductPayload> adjustmentPayload = new List<AdjustmentProductPayload>();
            foreach (ItemModel item in itemsToAdjust)
            {
                AdjustmentProductPayload productPayload = new AdjustmentProductPayload();
                adjustmentPayload.Add(new AdjustmentProductPayload { ProductID = item.Product.ProductID, Quantity = item.Adjustment });
            }

            var response = await inventoryService.SendAdjustment(
                Host3ServerIP + RouteAddress.RouteResource.SendAdjustment(), 
                DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ"), 
                cashierSessionID, 
                reason, 
                adjustmentPayload, 
                cancellationToken);

            return HttpValidationModel<AdjustmentDataModel>.ValidateAndMap(response);
        }

        public async Task<PurchaseOrderDataModel> SendPurchaseOrder(ObservableCollection<ItemModel> itemsPurchased, string cashierSessionID, string receiptNumber, CancellationToken cancellationToken)
        {
            List<PurchaseProductPayload> purchaseOrderPayload = new List<PurchaseProductPayload>();
            foreach (ItemModel item in itemsPurchased)
            {
                PurchaseProductPayload productPayload = new PurchaseProductPayload();
                purchaseOrderPayload.Add(new PurchaseProductPayload
                {
                    ProductID = item.Product.ProductID,
                    Quantity = item.Adjustment,
                    UnitCost = Convert.ToDecimal((int)(item.UnitCost * 100))
                });
            }

            var response = await inventoryService.SendPurchaseOrder(
                Host3ServerIP + RouteAddress.RouteResource.SendPurchaseOrder(),
                DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ"), 
                cashierSessionID, 
                receiptNumber, 
                purchaseOrderPayload, 
                cancellationToken);

            return HttpValidationModel<PurchaseOrderDataModel>.ValidateAndMap(response);
        }
    }
}
