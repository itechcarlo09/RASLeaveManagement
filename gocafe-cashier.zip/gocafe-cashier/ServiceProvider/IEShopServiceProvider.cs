﻿using gocafe_cashier.DataModel.FnBDataModels;
using GocafeShared.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public interface IEShopServiceProvider
    {
        Task<List<EShopCodeListDataModel>> GetEShopCodeList(string cashierSessionID, CancellationToken cancellationToken);
        Task<EshopCodeDataModel> ClaimEShopCodeThruCashier(string codeTypeID, string cashierSessionID, int paymentType, string email, CancellationToken cancellationToken);
    }
}
