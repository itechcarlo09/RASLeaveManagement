﻿using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.RouteAddress;
using gocafe_cashier.Validation;
using GocafeService;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public class BranchInventoryServiceProvider: ServiceProvider, IBranchInventoryServiceProvider
    {
        private BranchRetailService retailService;

        public BranchInventoryServiceProvider()
        {
            retailService = new BranchRetailService();
        }

        public async Task<List<BranchRetailDataModel>> GetBranchInventoryList(string cashierSessionID, CancellationToken cancellationToken)
        {
            var response = await retailService.GetBranchInventory(
                Host3ServerIP + RouteResource.GetBranchRetail(), 
                cashierSessionID, 
                cancellationToken);

            return HttpValidationModel<List<BranchRetailDataModel>>.ValidateAndMap(response);
        }

        public async Task<SalesDataModel> SendSalesOrder(SalesRequestDataModel salesOrder, CancellationToken cancellationToken)
        {
            var response = await retailService.SendSalesOrder(
                Host3ServerIP + RouteResource.SendSalesOrder(),
                salesOrder, cancellationToken);

            return HttpValidationModel<SalesDataModel>.ValidateAndMap(response);
        }
    }
}
