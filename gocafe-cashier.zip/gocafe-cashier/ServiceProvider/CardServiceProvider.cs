﻿using gocafe_cashier.RouteAddress;
using gocafe_cashier.Validation;
using GocafeService;
using GocafeShared.Model;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public class CardServiceProvider : ServiceProvider, ICardServiceProvider
    {
        private static CardService cardService = new CardService();

        public async Task<ResponseModel> UnlockUser(string cashierSessionID, string cardID, CancellationToken cancellationToken)
        {
            var response = await cardService.TapToUnlock(
                HostServerIP + RouteResource.GetTapToUnlockResource(),
                cashierSessionID,
                cardID, 
                cancellationToken);

            return HttpValidationModel<ResponseModel>.ValidateAndMap(response);
        }
    }
}
