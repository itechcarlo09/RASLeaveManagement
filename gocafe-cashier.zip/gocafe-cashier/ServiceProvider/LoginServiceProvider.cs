﻿using gocafe_cashier.Cache;
using gocafe_cashier.DataModel;
using gocafe_cashier.Validation;
using GocafeService;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ServiceProvider
{
    public class LoginServiceProvider : ServiceProvider, ILoginServiceProvider
    {
        private AuthService service = new AuthService();

        public async Task<CashierDataModel> Login(string username, string password, CancellationToken cancellationToken)
        {
            var response = await service.AuthenticateCashier(
                HostServerIP + RouteAddress.RouteResource.GetLoginResource(),
                username,
                password,
                DataCacheContext.BranchID, 
                cancellationToken
            );

            return HttpValidationModel<CashierDataModel>.ValidateAndMap(response);
        }
    }
}
