﻿using MahApps.Metro.Controls;

namespace gocafe_cashier.View.Member
{
    /// <summary>
    /// Interaction logic for PCTransferWindow.xaml
    /// </summary>
    public partial class PCTransferWindow : MetroWindow
    {
        public PCTransferWindow()
        {
            InitializeComponent();
        }
    }
}
