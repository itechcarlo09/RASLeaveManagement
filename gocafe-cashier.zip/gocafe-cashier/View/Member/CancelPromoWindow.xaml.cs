﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace gocafe_cashier.View.Member
{
    /// <summary>
    /// Interaction logic for CancelPromo.xaml
    /// </summary>
    public partial class CancelPromoWindow : Window
    {
        public CancelPromoWindow()
        {
            InitializeComponent();
        }
    }
}
