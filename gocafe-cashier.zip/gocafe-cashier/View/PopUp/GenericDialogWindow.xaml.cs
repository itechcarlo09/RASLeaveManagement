﻿using System.Windows;

namespace gocafe_cashier.View.PopUp
{
    /// <summary>
    /// Interaction logic for GenericDialogWindow.xaml
    /// </summary>
    public partial class GenericDialogWindow : Window
    {
        public GenericDialogWindow()
        {
            InitializeComponent();
        }
    }
}
