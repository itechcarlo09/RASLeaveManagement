﻿using MahApps.Metro.Controls;

namespace gocafe_cashier.View.PopUp
{
    /// <summary>
    /// Interaction logic for OrderRejectReasonWindow.xaml
    /// </summary>
    public partial class OrderRejectReasonWindow : MetroWindow
    {
        public OrderRejectReasonWindow()
        {
            InitializeComponent();
        }
    }
}
