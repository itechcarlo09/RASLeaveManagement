﻿using MahApps.Metro.Controls;

namespace gocafe_cashier.View.PopUp
{
    /// <summary>
    /// Interaction logic for PasswordConfirmationPopUpWindow.xaml
    /// </summary>
    public partial class PasswordConfirmationPopUpWindow : MetroWindow
    {
        public PasswordConfirmationPopUpWindow()
        {
            InitializeComponent();
        }
    }
}
