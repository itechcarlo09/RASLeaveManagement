﻿using gocafe_cashier.Helper;
using MahApps.Metro.Controls;
using System.Windows;

namespace gocafe_cashier.View
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : MetroWindow, IView
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
    }
}
