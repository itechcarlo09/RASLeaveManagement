﻿using MahApps.Metro.Controls;

namespace gocafe_cashier.View.Store
{
    /// <summary>
    /// Interaction logic for ReceivedOrdersControl.xaml
    /// </summary>
    public partial class ReceivedOrdersControl : MetroWindow
    {
        public ReceivedOrdersControl()
        {
            InitializeComponent();
        }
    }
}
