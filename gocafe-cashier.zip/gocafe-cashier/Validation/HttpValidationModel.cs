﻿using gocafe_cashier.DataModel;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Mapper;
using GocafeShared.Model;
using System;
using System.Net;

namespace gocafe_cashier.Validation
{
    public class HttpValidationModel<T>: BaseModel
    {
        public void DisplayHttpError(int httpStatusCode, string responseMessage)
        {
            ErrorDataModel errorModel;
            try
            {
                errorModel = ConvertErrorDataModel(responseMessage);
            }
            catch
            {
                errorModel = new ErrorDataModel
                {
                    Status = 0,
                    Message = StandardMessageResource.ErrorUnexpected
                };
            }
            responseMessage = errorModel.Message;
            string messageMode = Messages.ErrorConfirmation;

            if (errorModel != null && errorModel.Status == (int)HttpStatusCode.InternalServerError)
            {
                responseMessage = StandardMessageResource.ErrorUnexpected;
            }

            App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                ShowConfirmationWindow(responseMessage, messageMode);

                if (errorModel.Status == 498)
                {
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.SwitchToLoginView, null);
                }
            });
        }

        public static T ValidateAndMap(object response)
        {
            var responseModel = (ResponseModel)response;
            HttpValidationModel<T> httpValidator = new HttpValidationModel<T>();

            if (responseModel.HttpStatusCode != (int)HttpStatusCode.OK)
            {
                httpValidator.DisplayHttpError(responseModel.HttpStatusCode, responseModel.Result);
                return default(T);
            }
            else
            {
                try
                {
                    Type responseType = typeof(T);
                    if (responseType.Name == nameof(ResponseModel))
                    {
                        return (T)response;
                    }

                    return MapperBase<T>.Map(responseModel.Result);
                }
                catch (Exception e)
                {
                    return (T)response;
                };
            }
        }
    }
}
