﻿using gocafe_cashier.Cache;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using GocafeShared.Model;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.Validation
{
    public class CashierSession
    {
        public static async Task<bool> ValidateSession(string viewModel)
        {
            CashierServiceProvider cashierService = new CashierServiceProvider();

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            ResponseModel isValidSession;
            try
            {
                isValidSession = await TaskManagerModel<ResponseModel>.Instance.Run(cashierService.ValidateSession(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, viewModel);

                if (isValidSession != null && isValidSession.HttpStatusCode == 200)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch
            {
                return false;
            }
        }
    }
}
