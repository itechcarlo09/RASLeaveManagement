﻿using gocafe_cryptography;
using System;
using System.Collections.Specialized;
using System.Configuration;

namespace gocafe_cashier.Manager
{
    public class AppSettingManager
    {
        #region Constants and Read-only

        private static readonly AppSettingManager manager = new AppSettingManager();

        #endregion

        private NameValueCollection appSettings = null;


        public AppSettingManager()
        {
            appSettings = ConfigurationManager.AppSettings;
        }

        public string this[string name]
        {
            get
            {
                return appSettings[name];
            }
        }

        public static AppSettingManager Instance
        {
            get
            {
                return manager;
            }
        }

        public string Decrypt(string encryptedValue)
        {
            try
            {
#if DEBUG
                return encryptedValue;
#endif

#if RELEASE
                return ConfigDataProtector.NewDecrypt(Convert.FromBase64String(encryptedValue));
#endif
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
    }

    public sealed class AppSettingKey
    {
        public const string HostServerIP = "HostServerIP";
        public const string Host3ServerIP = "Host3ServerIP";
        public const string CurrencySign = "CurrencySign";
    }
}
