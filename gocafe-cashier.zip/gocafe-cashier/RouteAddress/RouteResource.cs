﻿using System;

namespace gocafe_cashier.RouteAddress
{
    public class RouteResource
    {
        private const string ApiPrefix = "/api";
        private const string ApiVersion = "/v1";
        private const string Get = "/get";
        private const string Add = "/add";
        private const string Code = "/code";
        private const string Codes = "/codes";
        private const string Claim = "/claim";
        private const string Count = "/count";
        private const string Topup = "/topup";

        // Categories
        private const string Inventory = "/inventory";
        private const string Crud = "/crud";
        private const string Cafe = "/cafe";
        private const string WebSocket = "/ws";
        private const string WebSocketMaster = "/wsm";
        private const string AuthenticationServer = "/as";

        public const string CashierSessions = "/cashier-sessions";
        public const string Cashiers = "/cashiers";
        public const string CustomerSessions = "/customer-sessions";
        public const string Members = "/members";
        public const string Member = "/member";
        public const string Guests = "/guests";
        public const string Guest = "/guest";
        public const string Promos = "/promos";
        public const string CustomerAccount = "/customer-account";
        public const string Stations = "/stations";
        public const string StationTypes = "/station-types";
        public const string Username = "/username";

        public const string Login = "/login";
        public const string Logout = "/logout";
        public const string GenerateAccount = "/generate-account";
        public const string GenerateCoupon = "/generate-coupon";
        public const string AvailablePromos = "/available-promos";
        public const string MemberTypes = "/member-types";
        public const string ResetPassword = "/reset-password";
        public const string TopupCustomerAccount = "/topup-customer-account";
        public const string Coupon = "/coupon";
        public const string Authenticate = "/authenticate";

        public const string BranchInventory = "/branch-inventories";

        public const string PendingAdjustmentOrder = "/pending-adjustment-order";
        public const string AdjustmentOrders = "/adjustment-orders";
        public const string PurchaseOrder = "/purchase-order";

        public const string AddByCashier = "/add-by-cashier";

        public const string Card = "/card-session";
        public const string Unlock = "/register";

        public const string GetMember = "/get/member";
        public const string ChangeCardNumber = "/change-card-number";

        public const string BranchRetail = "/branch-retail-pricings";

        public const string SalesOrders = "/sales-orders";
        public const string SalesOrder = "/sales-order";

        public const string EshopCodes = "/code/code-count";
        public const string ClaimEshopCode = "/claim-code";

        public const string ForceLogout = "/force-logout";

        public const string RefundPromo = "/refund-promo";

        public const string RegisterPromo = "/register-promo";

        public const string SalesOrderCount = "/sales-order-count";

        public const string EndShift = "/end-shift";

        public const string TransactionLogs = "/transaction-logs";

        public const string LastShiftBalance = "/last-shift-balance";

        public const string CurrentShiftBalance = "/current-shift-balance";

        public const string VoidTransaction = "/void-transaction";

        public const string Branches = "/branches";

        public const string MacAddress = "/mac-address";

        public static string GetTapToUnlockResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Unlock}{Card}");
        }

        public static string GetLoginResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Login}");
        }

        public static string GetLogoutResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Logout}");
        }

        public static string GetGenerateMemberAccountResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{GenerateAccount}{Member}");
        }

        public static string GetGenerateCoupon()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{GenerateAccount}{Coupon}");
        }

        public static string GetGenerateGuestAccountResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{GenerateAccount}{Guest}");
        }

        public static string GetAvailablePromos()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{AvailablePromos}");
        }

        public static string GetClientPromo()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{Promos}{CustomerAccount}{Username}");
        }

        public static string GetMemberTypesResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{MemberTypes}");
        }

        public static string GetResetPasswordResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{ResetPassword}{Member}");
        }

        public static string GetMemberAuthenticateResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Authenticate}{CustomerAccount}");
        }

        public static string GetTopUpResource()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Topup}{CustomerAccount}");
        }

        public static string GetMemberInfo()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}/check-available-card");
        }

        public static string GetStationList()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{Stations}");
        }

        public static string GetStationTypeList()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{StationTypes}");
        }

        public static string GetCashierStationInformation(string macAddress)
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Branches}{Cashiers}{MacAddress}/{macAddress}");
        }

        public static string GetBranchRetail()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Get}{BranchRetail}");
        }

        public static string SendSalesOrder()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Add}{SalesOrder}");
        }

        public static string GetEshopCodes()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Get}{Codes}{Count}");
        }

        public static string ClaimEshopCodeThruCash()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{ClaimEshopCode}{Member}");
        }

        public static string GetInventoryList()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Get}{BranchInventory}");
        }

        public static string SendAdjustment()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Add}{PendingAdjustmentOrder}");
        }

        public static string SendPurchaseOrder()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Add}{PurchaseOrder}");
        }

        public static string GetPendingAdjustments()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Get}{AdjustmentOrders}?orderStatus=PENDING");
        }

        public static string GetMemberByUsername(string username)
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{Members}{Username}/{username}");
        }

        public static string ReplaceCard()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{ChangeCardNumber}{Member}");
        }

        public static string GetMemberTypeByID(int memberTypeId)
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{MemberTypes}/{memberTypeId}");
        }

        public static string GetMemberSalesOrder()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Add}{SalesOrder}{Member}");
        }

        public static string GetSalesOrderByStatus(string status, string startDateTime, string endDateTime)
        {
            return $"{ApiPrefix}/inventory{ApiVersion}/cashiers/get/sales-order?status={status}&startDateTime={startDateTime}&endDateTime={endDateTime}";
        }

        public static string ForceLogOutCustomer()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{ForceLogout}{CustomerAccount}");
        }

        public static string CancelPromo()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{RefundPromo}{CustomerAccount}");
        }

        public static string RegisterMemberPromo()
        {
            return $"{ApiVersion}{Cashiers}{RegisterPromo}{Member}";
        }

        public static string AcceptSalesOrder()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}/accept/sales-order");
        }

        public static string RejectSalesOrder()
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}/reject/sales-order");
        }

        public static string GetSalesOrderCount(string status, string startDate, string endDate)
        {
            return ($"{ApiPrefix}{Inventory}{ApiVersion}{Cashiers}{Get}{SalesOrderCount}?status={status}&startDateTime={startDate}&endDateTime={endDate}");
        }

        public static string GetGenerateKey()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}/generate/key");
        }

        public static string GetRetrieveKey()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}/get/key");
        }

        public static string EndCurrentShift()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{EndShift}");
        }

        public static string GetTransactionLog(long startDateTime, long endDateTime)
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{TransactionLogs}?startDateTime={startDateTime}&endDateTime={endDateTime}");
        }

        public static string GetSessionValidation()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}/cashiers/cashier-session/available");
        }

        public static string GetTransactionLogByCount(int transactionCount)
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{Get}{TransactionLogs}?transactionCount={transactionCount}");
        }

        public static string GetPreviousShiftSummary()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{LastShiftBalance}");
        }

        public static string GetCurrentShiftSummary()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{CurrentShiftBalance}");
        }

        public static string SendVoidRequest()
        {
            return ($"{ApiPrefix}{Cafe}{ApiVersion}{Cashiers}{VoidTransaction}");
        }
    }
}
