﻿using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.Model;
using GocafeShared.Model.Network;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace gocafe_cashier.Cache
{
    public static class DataCacheContext
    {
        private static readonly Dictionary<string, AccountModel> accountModels = new Dictionary<string, AccountModel>();
        private static readonly ConcurrentDictionary<string, MemberAccountModel> memberAccountModels = new ConcurrentDictionary<string, MemberAccountModel>();
        private static readonly ConcurrentDictionary<string, ClientPC> workstationModels = new ConcurrentDictionary<string, ClientPC>();

        public static Dictionary<string, AccountModel> AccountModels
        {
            get
            {
                return accountModels;
            }
        }

        public static ConcurrentDictionary<string, MemberAccountModel> MemberAccountModels
        {
            get
            {
                return memberAccountModels;
            }
        }

        public static ConcurrentDictionary<string, ClientPC> WorkstationModels
        {
            get
            {
                return workstationModels;
            }
        }

        public static string CashierSessionID = string.Empty;
        public static bool UseLocalDB = false;
        public static string BranchID = string.Empty;
        public static string PrinterName = "POS-58";
        public static int ServerPort = 1000;
        public static int AsyncTimeout = 5;
        public static decimal TopupMaximumAmount = 5000;
        public static string CurrencySymbol = "\u20B1";

        public static string PriceCurrencySymbol
        {
            get { return "Price: "+ CurrencySymbol; }
        }
        public static List<OrderNumberModel> OrderList = new List<OrderNumberModel>();
    }
}