﻿using gocafe_cashier.Cache;
using gocafe_cashier.Helper;
using gocafe_cashier.Network;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModel;
using gocafe_cashier.ViewModelMediator;
using gocafe_cryptography;
using gocafe_log;
using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace gocafe_cashier
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private const string DesktopDirectory = @"C:\Windows\";
        private const string FromAddress = "oktocafelogsender@gmail.com";
        private const string ToAddress = "lorenz.ong@godigitalcorp.com";
        private const string CultureName = "en-US";

        protected override void OnStartup(StartupEventArgs e)
        {
            // Fix: This resolves the issue when Windows' region date, time or number format
            // was changed into a different one aside from en-US or English (United States)
            // Simply force the DefaultThreadCurrentCulture into en-US.
            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo(CultureName);

            ConfigDataProtector configSecurity = new ConfigDataProtector();
            ViewService.Instance.ShowView<LoginWindowViewModel>();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            NetworkServer.Instance.Shutdown();
            base.OnExit(e);
        }

        private void Application_DispatcherUnhandledException(object sender,
          System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            string appName = "Cashier";

#if DEBUG
            string path = DesktopDirectory;
#endif
#if RELEASE
            string path = AppDomain.CurrentDomain.BaseDirectory;
#endif
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            
          
            StringBuilder messageBuilder = new StringBuilder();
            messageBuilder.AppendLine($"*** BEGIN ({appName}) ***");
            messageBuilder.AppendLine($"App.Application_DispatcherUnhandledException() | ExceptionType: {e.Exception.GetType().ToString()}- {DateTime.Now.ToString()}");
            messageBuilder.AppendLine($"ExceptionMessage: {e.Exception.Message} - {DateTime.Now.ToString()}");
            messageBuilder.AppendLine($"StackTrace: {e.Exception.StackTrace} - {DateTime.Now.ToString()}");

            using (StreamWriter file =
                new StreamWriter($"{path}ErrorLog.txt", true))
            {
                file.WriteLine(messageBuilder.ToString());
            }

            string branchId = string.IsNullOrEmpty(DataCacheContext.BranchID) ?
                              "Branch-NA" :
                              DataCacheContext.BranchID;

            string userSessionId = string.IsNullOrEmpty(DataCacheContext.CashierSessionID) ?
                                   "User-NA" :
                                   DataCacheContext.CashierSessionID;

            Task.Run(() =>
            {
                string subject = $"BID-{branchId} UID-{userSessionId} App.Application_DispatcherUnhandledException()";

                EmailLogger logger = new EmailLogger();
                logger.AppName = appName;
                logger.Compose(FromAddress, ToAddress, subject, messageBuilder.ToString());
                logger.SendAsync();
            });

            string message = "Unexpected error occured. Please inform the admin.";
            ShowConfirmationWindow(message, Messages.ErrorConfirmation);

            e.Handled = true;
        }

        private void ShowConfirmationWindow(string warningMessage, string mode)
        {
            GenericDialogWindow genericWindow = new GenericDialogWindow();
            Mediator.Instance.NotifyViewModel(Messages.ConfirmationWindowViewModel, Messages.ConfirmationWindow, genericWindow);
            Mediator.Instance.NotifyViewModel(Messages.ConfirmationWindowViewModel, mode, warningMessage);
            var windowDialogResult = genericWindow.ShowDialog();
        }
    }
}