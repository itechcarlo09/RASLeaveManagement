﻿namespace gocafe_cashier.Definition
{
    public sealed class DateFormatDefinition
    {
        public const string DefaultDateFormat = "MMMM dd, yyyy";

        public static string[] DateFormats =
        {
            "MMMM d, yyyy",
            "MMMM dd, yyyy",
            "MMM dd, yyyy",
            "MMM d, yyyy",
            "MMM dd yyyy",
            "MMM d yyyy",
            "MMMM dd yyyy",
            "MMMM d yyyy"
        };
    }
}
