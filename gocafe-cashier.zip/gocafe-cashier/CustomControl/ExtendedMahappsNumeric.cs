﻿using System.Windows.Input;
using MahApps.Metro.Controls;
using System;
using System.Windows.Controls;
using System.Text.RegularExpressions;

namespace gocafe_cashier.CustomControl
{
    public class ExtendedMahappsNumeric : NumericUpDown
    {
        private const string NumericTextBoxName = "PART_TextBox";
        private const int WholeNumber = 0;
        private const int DecimalPart = 1;
        private const string DecimalFormatWithDigitGroup = "#,##0.00";

        /// <summary>
        /// Accepts 1,000.00 | 1.00 | 0 | 100
        /// </summary>
        private const string RegexForWholeNumber = @"^(?=.)([1-9]{1,3}(,?\d{1,3})*)?(\.\d+)?$|^0{1}$";

        private string actualText = string.Empty;
        private double convertedAmount = 0;
        private bool isMaxValueReached = false;
        private int eventExecutedCounter = 0;
        private double currentValue = 0;
        private double actualMaxValue = 0;
        private TextBox currentTextBox = null;

        protected override void OnPreviewTextInput(TextCompositionEventArgs e)
        {
            string numberText = currentTextBox.Text;
            string[] textBoxParts = currentTextBox.Text.Split(new char[] { '.' });

            base.OnPreviewTextInput(e);

            if (eventExecutedCounter == 2 && isMaxValueReached == false)
            {
                eventExecutedCounter = 0;
            }

            if (isMaxValueReached)
            {
                string tempWithoutComma = string.Empty;

                if (currentTextBox.Text.Contains(","))
                {
                    tempWithoutComma = currentTextBox.Text.Remove(currentTextBox.Text.IndexOf(","), 1);
                }

                double verifiedAmount = 0;

                if (currentTextBox.Text != string.Empty)
                {
                    verifiedAmount = Convert.ToDouble(string.IsNullOrEmpty(tempWithoutComma) ? currentTextBox.Text : tempWithoutComma);
                }
                
                bool isDecimalTooLong = false;

                if (textBoxParts.Length == 2)
                {
                    isDecimalTooLong = textBoxParts[DecimalPart].Length > 2;
                }

                if (currentTextBox.SelectionLength > 0)
                {
                    numberText = numberText.Remove(currentTextBox.SelectionStart, currentTextBox.SelectionLength);
                    verifiedAmount = Convert.ToDouble(numberText.Insert(currentTextBox.SelectionStart, e.Text));
                }

                // Consider the decimals that was encoded.
                if (verifiedAmount == Maximum || isDecimalTooLong || verifiedAmount > Maximum)
                {
                    eventExecutedCounter = 0;
                    e.Handled = true;
                }
                else
                {
                    isMaxValueReached = false;
                }
            }

            if (eventExecutedCounter < 1)
            {
                eventExecutedCounter++;
            }

            double.TryParse(actualText, out convertedAmount);

            if (this.Value == Maximum)
            {
                if (convertedAmount > Maximum && actualText.Length == 5)
                {
                    e.Handled = true;
                }
                // Reset the value since
                // we assume that it reaches the
                // maximum amount.
                actualText = string.Empty;
            }

            bool hasDecimalPoint = currentTextBox.Text.Contains(".");
            int caretIndex = currentTextBox.CaretIndex;

            if (!hasDecimalPoint && (caretIndex >= 0 && caretIndex <= numberText.Length))
            {
                ProcessInputAmount(e, textBoxParts, caretIndex, numberText);
            }

            // Caputure the input with decimal
            // i.e. 0.00
            // Remember that 0.50 or 1.50 are
            // valid for now.
            if (hasDecimalPoint)
            {
                int decimalIndex = currentTextBox.Text.IndexOf(".");

                if (caretIndex > decimalIndex)
                {
                    // For decimal places
                    string numberWithDecimal = string.Empty;
                    string decimalPart = string.Empty;

                    if (currentTextBox.SelectionLength == 0)
                    {
                        numberWithDecimal = currentTextBox.Text.Insert(caretIndex, e.Text);
                    }
                    else
                    {
                        numberWithDecimal = currentTextBox.Text.Replace(currentTextBox.Text.Substring(currentTextBox.SelectionStart, currentTextBox.SelectionLength), e.Text);
                    }

                    decimalPart = numberWithDecimal.Split(new char[] { '.' })[1];

                    if (!Regex.IsMatch(decimalPart, "^[0-9]{1,2}$") || (!Regex.IsMatch(decimalPart, "^[0][0]$") && this.Value == this.Maximum))
                    {
                        e.Handled = true;
                    }
                }
                else
                {
                    ProcessInputAmount(e, textBoxParts, caretIndex, currentTextBox.Text);
                }
            }
        }

        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            base.OnPreviewKeyDown(e);
        }

        protected override void OnValueChanged(double? oldValue, double? newValue)
        {
            if (currentTextBox == null)
            {
                // Look for the control
                // first.
                var gridObjects = this.GetChildObjects(true);

                foreach (var element in gridObjects)
                {
                    var childElements = element.GetChildObjects(true);
                    foreach (var element2 in childElements)
                    {
                        if (element2.GetType() == typeof(Grid))
                        {
                            currentTextBox = element2.FindChild<TextBox>(NumericTextBoxName);

                            currentTextBox.TextChanged += (object sender, TextChangedEventArgs e) =>
                            {
                                string text = currentTextBox.Text;
                                double wholeNumber = 0;
                                string[] numberParts = null;

                                if (!string.IsNullOrEmpty(text))
                                {
                                    if (text.Substring(0, 1) == ",")
                                    {
                                        if (text.Contains("."))
                                        {
                                            numberParts = currentTextBox.Text.Split('.');
                                        }

                                        if (numberParts.Length >= 1)
                                        {
                                            double.TryParse(numberParts[0], out wholeNumber);
                                        }
                                        else
                                        {
                                            double.TryParse(text, out wholeNumber);
                                        }
                                    }
                                    else
                                    {
                                        double.TryParse(text, out wholeNumber);
                                    }

                                    if (numberParts != null)
                                    {
                                        currentTextBox.Text = $"{wholeNumber}.{numberParts[1]}";
                                        return;
                                    }

                                    currentTextBox.Text = $"{wholeNumber}";
                                }
                            };
                            break;
                        }
                    }
                }
            }

            if (eventExecutedCounter < 2)
            {
                eventExecutedCounter++;
            }

            int decimalPart = 0;
            string[] textParts = null;

            if (newValue.HasValue)
            {
                double converted = 0;

                if (currentTextBox != null)
                {
                    if (!string.IsNullOrEmpty(currentTextBox.Text))
                    {
                        string tempWithoutComma = string.Empty;

                        if (currentTextBox.Text.Contains(","))
                        {
                            tempWithoutComma = currentTextBox.Text.Remove(currentTextBox.Text.IndexOf(","), 1);
                        }

                        converted = Convert.ToDouble(string.IsNullOrEmpty(tempWithoutComma) ? currentTextBox.Text : tempWithoutComma);
                    }

                    currentValue = newValue.Value;
                    textParts = newValue.Value.ToString().Split(new char[] { '.' });
                    string[] textBoxParts = currentTextBox.Text.Split(new char[] { '.' });

                    if (newValue.ToString().Contains("."))
                    {
                        string secondPart = textParts[1];
                        decimalPart = Convert.ToInt32(textParts[1]);

                        if (secondPart.ToString().Length > 2)
                        {
                            string tempDecimalPart = secondPart.Substring(0, 2);
                            currentTextBox.Text = $"{textParts[0]}.{tempDecimalPart}";
                        }
                    }
                    else
                    {
                        if ((textParts[0] == "0000" || textParts[0] == "000" || textParts[0] == "00") && textParts[0].Length > Maximum.ToString().Length)
                        {
                            currentTextBox.Text = "0.00";
                        }
                        else if (textParts[0].Length >= Maximum.ToString().Length && newValue.Value == Maximum && converted > Maximum)
                        {
                            string wholeNumber = textBoxParts[0].Substring(0, Maximum.ToString().Length);
                            currentTextBox.Text = oldValue.HasValue ? oldValue.Value.ToString(DecimalFormatWithDigitGroup) : "0.00";
                            currentTextBox.CaretIndex = currentTextBox.Text.Length - 1;
                        }
                    }

                    if (oldValue.HasValue)
                    {
                        if (oldValue.Value != newValue.Value && newValue.Value == Maximum && converted >= Maximum)
                        {
                            isMaxValueReached = true;
                        }
                        else
                        {
                            isMaxValueReached = false;
                        }
                        actualMaxValue = newValue.Value;
                    }
                }

                if (newValue.Value == Maximum)
                {
                    currentTextBox.Text = newValue.Value.ToString(DecimalFormatWithDigitGroup);
                }
            }
            else
            {
                currentTextBox.Text = "0";
            }

            base.OnValueChanged(oldValue, newValue);
        }

        #region Helper Methods

        private void ProcessInputAmount(TextCompositionEventArgs e, string[] textBoxParts, int caretIndex, string numberText)
        {
            string newNumber = string.Empty;

            if (currentTextBox.SelectionLength == 0)
            {
                if (textBoxParts[0].Length <= 4 && Regex.IsMatch(textBoxParts[0], @"^(?=.)([1-9]{1,3}(,?\d{1,3})*)?$|^0{1}$"))
                {
                    newNumber = textBoxParts[0].Insert(caretIndex, e.Text);
                }

                if((textBoxParts[0] == "000" || textBoxParts[0] == "00" || textBoxParts[0] == "0"))
                {
                    if(numberText.Length == 1)
                    {
                        currentTextBox.SelectionStart = 0;
                    }
                    currentTextBox.SelectionLength = textBoxParts[0].Length;

                    newNumber = numberText.Replace(numberText.Substring(currentTextBox.SelectionStart, textBoxParts[0].Length), e.Text);
                }

                if (textBoxParts[0].Length == 0 && string.IsNullOrEmpty(textBoxParts[0]))
                {
                    return;
                }
            }
            else
            {
                newNumber = numberText.Replace(numberText.Substring(currentTextBox.SelectionStart, currentTextBox.SelectionLength), e.Text);
            }

            if (newNumber.Contains(","))
            {
                newNumber.Remove(newNumber.IndexOf(","), 1);
            }

            if (!Regex.IsMatch(newNumber, RegexForWholeNumber))
            {
                e.Handled = true;
            }

        }

        #endregion
    }
}
