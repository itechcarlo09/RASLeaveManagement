﻿using System;
using System.Globalization;
using System.Net.Sockets;

namespace gocafe_cashier.Network.WakeOnLan
{
    /// <summary>
    /// Has the Wake-on-LAN (WoL) access.
    /// Prerequisite: Both hardware and Windows OS must
    /// be configured correctly by port number
    /// and Magic Packet enablement.
    /// 
    /// Original code
    /// From https://www.codeproject.com/Articles/5315/Wake-On-Lan-sample-for-C
    /// By: maxburov
    /// </summary>
    public sealed class NetworkWaker : UdpClient
    {
        public NetworkWaker() : base()
        {

        }
        
        // This is needed to send broadcast packet
        public void SetClientToBroadcastMode()
        {
            if (this.Active)
            {
                this.Client.SetSocketOption(SocketOptionLevel.Socket,
                                          SocketOptionName.Broadcast, 0);
            }
        }
    }

}
