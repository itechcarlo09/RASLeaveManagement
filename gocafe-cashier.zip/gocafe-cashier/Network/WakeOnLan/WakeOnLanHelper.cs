﻿using System;
using System.Globalization;
using System.Net;

namespace gocafe_cashier.Network.WakeOnLan
{
    public sealed class WakeOnLanHelper
    {
        /// <summary>
        /// Wake a targeted machine via broadcasting a datagram with a MAC address.
        /// </summary>
        /// <param name="macAddress">The MAC address of the Network Interface Card (NIC). The hexadecimal format without hypens or dashes.</param>
        public static void WakeByMac(string macAddress)
        {
            NetworkWaker client = new NetworkWaker();

            client.Connect(new
               IPAddress(0xffffffff),  // 255.255.255.255  i.e. broadcast
               0x9); // Use port 9 or the Discard protocol since this is the recommended.

            // NOTE:
            // https://superuser.com/questions/295325/does-it-matter-what-udp-port-a-wol-signal-is-sent-to
            // "However, UDP is recommended because it can be generated without raw sockets which come with
            // security restrictions, and port 9 is recommended because it maps to the old well-known discard
            // protocol whereas port 7 maps to the echo protocol.
            // This means that if there are hosts on your network that support these old simple standard 
            // services you will get unnecessary backscatter traffic when using port 7 but none when using port 9.

            // Set socket options
            client.SetClientToBroadcastMode();

            // Set sending
            int counter = 0;

            // Buffer to be send
            byte[] bytes = new byte[1024];   // more than enough :-)
                                             //first 6 bytes should be 0xFF
            for (int y = 0; y < 6; y++)
                bytes[counter++] = 0xFF;


            // Now repeat MAC 16 times
            for (int y = 0; y < 16; y++)
            {
                int i = 0;
                for (int z = 0; z < 6; z++)
                {
                    string segment = macAddress.Substring(i, 2);

                    bytes[counter++] =
                        byte.Parse(segment,
                        NumberStyles.HexNumber);
                    i += 2;
                }
            }

            try
            {
                // now send wake up packet
                int returned_value = client.Send(bytes, 1024);

#if DEBUG
                System.Diagnostics.Debug
                    .WriteLine($"Return value: {returned_value}\nFinished sending datagram.");
#endif
            }
            catch (Exception ex)
            {
#if DEBUG
                System.Diagnostics.Debug.WriteLine($"Exception: {ex.GetType()}\n" +
                    $"Ex. message: {ex.Message}\nStack trace: {ex.StackTrace}");
#endif
                throw;
            }
        }
    }
}
