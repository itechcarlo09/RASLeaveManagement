﻿using gocafe_cashier.Cache;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Definition;
using GocafeShared.Model.Network;
using NetworkCommsDotNet;
using NetworkCommsDotNet.Connections;
using NetworkCommsDotNet.Connections.TCP;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace gocafe_cashier.Network
{
    public class NetworkServer
    {
        #region Private Fields

        private static readonly NetworkServer instance = new NetworkServer();

        #endregion

        #region Properties

        public static NetworkServer Instance
        {
            get
            {
                return instance;
            }
        }

        #endregion


        public void Start()
        {
            NetworkComms.AppendGlobalIncomingPacketHandler<string>(NetworkMessageType.ClientMessage, HandleMessagesFromClient);
            NetworkComms.AppendGlobalConnectionCloseHandler(OnClientDisconnectedFromServer);
            Connection.StartListening(ConnectionType.TCP, new System.Net.IPEndPoint(System.Net.IPAddress.Any, DataCacheContext.ServerPort));
        }

        public void Shutdown()
        {
            NetworkComms.Shutdown();
        }

        private void HandleMessagesFromClient(PacketHeader header, Connection connection, string message)
        {
            try
            {
                NetworkMessageModel networkMessage = JsonConvert.DeserializeObject<NetworkMessageModel>(message);

                switch (networkMessage.MessageType)
                {
                    case NetworkMessageType.Handshake:
                        SendMessageToClient(connection, NetworkMessageType.HandshakeAcknowledgement, null);
                        break;

                    case NetworkMessageType.ClientPCDetails:
                        try
                        {
                            ClientPC clientPC = JsonConvert.DeserializeObject<ClientPC>((string)networkMessage.Data);
                            clientPC.Connection = connection;
                            clientPC.IPAddress = connection.ConnectionInfo.RemoteEndPoint.ToString().Split(new char[] { ':' }).FirstOrDefault();
                            clientPC.Port = connection.ConnectionInfo.RemoteEndPoint.ToString().Split(new char[] { ':' })[1];

                            Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.ConnectionEstablished, clientPC);
                            Mediator.Instance.NotifyViewModel(Messages.LoginWindows, Messages.ConnectionEstablished, clientPC);
                        }
                        catch(Exception e)
                        {
                            // todo: add logging of error
                        }
                        break;

                    case NetworkMessageType.ClientAccountDetails:
                        Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.ClientAccountDetails, JsonConvert.DeserializeObject<MemberAccountModel>((string)networkMessage.Data));
                        Mediator.Instance.NotifyViewModel(Messages.LoginWindows, Messages.ClientAccountDetails, JsonConvert.DeserializeObject<MemberAccountModel>((string)networkMessage.Data));
                        break;

                    case NetworkMessageType.LockPC:
                        Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.LockPC, JsonConvert.DeserializeObject<ClientPC>((string)networkMessage.Data));
                        Mediator.Instance.NotifyViewModel(Messages.LoginWindows, Messages.LockPC, JsonConvert.DeserializeObject<ClientPC>((string)networkMessage.Data));
                        break;

                    case NetworkMessageType.ClientTransferToken:
                        Mediator.Instance.NotifyViewModel(Messages.PCTransferWindowViewModel, Messages.ClientTransferToken, JsonConvert.DeserializeObject<string>((string)networkMessage.Data));
                        break;

                    case NetworkMessageType.ClientTransferStatusDetail:
                        Mediator.Instance.NotifyViewModel(Messages.PCTransferWindowViewModel, Messages.ClientTransferStatusDetail, JsonConvert.DeserializeObject<string>((string)networkMessage.Data));
                        break;

                    case NetworkMessageType.ClientOrderDetail:
                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.ReceivedPendingOrdersCount, null);
                        break;

                    case NetworkMessageType.ClientChat:
                        ChatMessageModel chatMessage = JsonConvert.DeserializeObject<ChatMessageModel>((string)networkMessage.Data);
                        chatMessage.IPAddress = connection.ConnectionInfo.RemoteEndPoint.ToString().Split(new char[] { ':' }).FirstOrDefault();
                        Mediator.Instance.NotifyViewModel(Messages.ChatWindowViewModel, Messages.ClientChat, chatMessage);
                        break;

                    case NetworkMessageType.GetUpdatedOrderNumbers:
                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.GetUpdatedOrderNumbers, JsonConvert.DeserializeObject<string>((string)networkMessage.Data));
                        break;

                    default:
                        break;
                }
            }
            catch (Exception e)
            {

            }
        }

        public void SendMessageToClient(Connection connection, string messageType, object messageData)
        {
            NetworkMessageModel clientMessage = new NetworkMessageModel
            {
                MessageType = messageType,
                MessageID = Guid.NewGuid(),
                Data = JsonConvert.SerializeObject(messageData)
            };

            if (connection != null)
            {
                connection.SendObject(NetworkMessageType.ServerMessage, JsonConvert.SerializeObject(clientMessage));
            }
        }

        public void SendMessageToClientUsingIP(string ipAddress, string messageType, object messageData)
        {
            if (ipAddress == null || ipAddress == string.Empty)
            {
                return;
            }

            ClientPC clientPC = DataCacheContext.WorkstationModels.Values.ToList().Where(pc => pc.IPAddress == ipAddress).ToList().FirstOrDefault();
            NetworkMessageModel clientMessage = new NetworkMessageModel
            {
                MessageType = messageType,
                MessageID = Guid.NewGuid(),
                Data = JsonConvert.SerializeObject(messageData)
            };

            if (clientPC != null)
            {
                clientPC.Connection.SendObject(NetworkMessageType.ServerMessage, JsonConvert.SerializeObject(clientMessage));
            }
        }

        public void SendMessageToClientUsingStationID(string stationID, string messageType, object messageData)
        {
            if (stationID == null || stationID == string.Empty)
            {
                return;
            }

            ClientPC clientPC = DataCacheContext.WorkstationModels.Values.ToList().Where(pc => pc.PCID == stationID).ToList().FirstOrDefault();
            NetworkMessageModel clientMessage = new NetworkMessageModel
            {
                MessageType = messageType,
                MessageID = Guid.NewGuid(),
                Data = JsonConvert.SerializeObject(messageData)
            };

            if (clientPC != null)
            {
                clientPC.Connection.SendObject(NetworkMessageType.ServerMessage, JsonConvert.SerializeObject(clientMessage));
            }
        }

        private void OnClientDisconnectedFromServer(Connection connection)
        {
            ClientPC clientPC = DataCacheContext.WorkstationModels.Values.ToList().Where(pc => pc.Connection == connection).ToList().FirstOrDefault();
            if (clientPC != null)
            {
                Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.ClientDisconnected, clientPC);
                Mediator.Instance.NotifyViewModel(Messages.LoginWindows, Messages.ClientDisconnected, clientPC);
            }
        }

        public void ReconnectAllClients(List<ClientPC> clientPCs)
        {
            NetworkMessageModel clientMessage = new NetworkMessageModel
            {
                MessageType = NetworkMessageType.ReconnectClient,
                MessageID = Guid.NewGuid(),
                Data = null
            };

            foreach (ClientPC clientPC in clientPCs)
            {
                if (clientPC != null)
                {
                    clientPC.Connection.SendObject(NetworkMessageType.ServerMessage, JsonConvert.SerializeObject(clientMessage));
                }
            }
        }
    }
}
