﻿using gocafe_cashier.Helper;
using gocafe_cashier.Model;
using GocafeDatabaseModel.Result;
using GocafeShared.Utilities.StringFormat;

namespace gocafe_cashier.Mapper.ModelUI
{
    public class TransactionModelMapper
    {
        public static TransactionModel Map(TransactionLogResultModel transactionLog)
        {
            TransactionModel model = new TransactionModel();

            model.ID = transactionLog.Id;
            model.CustomerName = transactionLog.AccountName;
            model.TransactionType = EnumHelper.ParseTransactionType(transactionLog.TransactionType);
            model.TransactionRemarks = transactionLog.Remarks;
            model.TransactionAmount = $"{transactionLog.TransactionAmount.ToString().ConvertIntToMoney()}";
            model.TransactionTime = transactionLog.TransactionDate.ToString("hh:mm tt");

            return model;
        }

        public static TransactionModel Map(TransactionLogResultModel transactionLog, string currencySign)
        {
            TransactionModel model = new TransactionModel();

            model.ID = transactionLog.Id;
            model.CustomerName = transactionLog.AccountName;
            model.TransactionType = EnumHelper.ParseTransactionType(transactionLog.TransactionType);
            model.TransactionRemarks = transactionLog.Remarks;
            model.TransactionAmount = $"{currencySign}{transactionLog.TransactionAmount.ToString().ConvertIntToMoney()}";
            model.TransactionTime = transactionLog.TransactionDate.ToString("hh:mm tt");

            return model;
        }
    }
}
