﻿using gocafe_cashier.DataModel;
using gocafe_cashier.Model;
using gocafe_cashier.Model.Definition;
using GocafeDatabaseModel;
using GocafeDatabaseModel.Enum;
using GocafeShared.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace gocafe_cashier.Mapper
{
    public class TransactionLogMapper
    {
        /// <summary>
        /// Maps different models to the TransactionLog entity model. Does not have password.
        /// </summary>
        /// <param name="model"></param>
        /// <param name="cashierModel"></param>
        /// <param name="promoModel"></param>
        /// <param name="paymentTypeId"></param>
        /// <param name="topUpModel"></param>
        /// <param name="transactionAmount"></param>
        /// <returns>The TransactionLog entity model. Does not have password.</returns>
        public static TransactionLog Map(TransactionModel model, CashierDataModel cashierModel, AccountPromoModel promoModel,
            int paymentTypeId, TopUpManagerModel topUpModel, int transactionAmount)
        {
            TransactionLog transactionLog = new TransactionLog();
            // Note: by Jerameel
            // Would this be a problem when generating own Guid for the ID locally?
            // Since the back-end server would generate on its own. How is the
            // handling in the system when there is no internet connection?
            // Would this affect?

            int amount = 0;

            if (promoModel != null)
            {
                transactionLog.AvailedPromoCode = promoModel.PackageCode;
                transactionLog.AvailedPromoDescription = promoModel.PackageDescription;
                
                int.TryParse(promoModel.Amount.ToString(), out amount);
            }
            else
            {
                transactionLog.AvailedPromoCode = "N/A";
                transactionLog.AvailedPromoDescription = "N/A";
            }

            transactionLog.AvailedPromoPrice = amount;
            transactionLog.CashierName = cashierModel.Name;
            transactionLog.BranchName = cashierModel.Branch.Name;
            transactionLog.MemberType = MemberType.Regular;
            transactionLog.AccountCardNumber = topUpModel.CardIDNumber;
            transactionLog.AccountName = string.IsNullOrEmpty(topUpModel.Username) ? topUpModel.GuestUsername : topUpModel.Username;
            transactionLog.AccountFirstName = topUpModel.FirstName;
            transactionLog.AccountLastName = topUpModel.LastName;
            transactionLog.TransactionType = (short)TransactionType.TopUp;

            transactionLog.PaymentTypeId = paymentTypeId;
            transactionLog.Remarks = model.TransactionRemarks;
            transactionLog.TransactionAmount = transactionAmount;
            transactionLog.TransactionDate = DateTime.Now;

            return transactionLog;
        }


        /// <summary>
        /// Maps different models to the TransactionLog entity model. Does not have password.
        /// This is exclusive for New Accounts like "Member" only.
        /// </summary>
        /// <param name="model"></param>
        /// <param name="cashierModel"></param>
        /// <param name="promoModel"></param>
        /// <param name="paymentTypeId"></param>
        /// <param name="AccountManagerModel"></param>
        /// <param name="transactionAmount"></param>
        /// <returns>The TransactionLog entity model. Does not have password.</returns>
        public static TransactionLog MapNewAccount(TransactionModel model, CashierDataModel cashierModel, AccountPromoModel promoModel,
            int paymentTypeId, AccountManagerModel accountModel, int transactionAmount)
        {
            TransactionLog transactionLog = new TransactionLog();
            // Note: by Jerameel
            // Would this be a problem when generating own Guid for the ID locally?
            // Since the back-end server would generate on its own. How is the
            // handling in the system when there is no internet connection?
            // Would this affect?

            int amount = 0;

            if (promoModel != null)
            {
                transactionLog.AvailedPromoCode = promoModel.PackageCode;
                transactionLog.AvailedPromoDescription = promoModel.PackageDescription;

                int.TryParse(promoModel.Amount.ToString(), out amount);
            }
            else
            {
                transactionLog.AvailedPromoCode = "N/A";
                transactionLog.AvailedPromoDescription = "N/A";
            }

            transactionLog.AvailedPromoPrice = amount;
            transactionLog.CashierName = cashierModel.Name;
            transactionLog.BranchName = cashierModel.Branch.Name;
            transactionLog.MemberType = MemberType.Regular;
            transactionLog.AccountCardNumber = accountModel.CardIDNumber;
            transactionLog.AccountName = accountModel.Username;
            transactionLog.AccountFirstName = accountModel.FirstName;
            transactionLog.AccountLastName = accountModel.LastName;
            transactionLog.TransactionType = (short)TransactionType.NewAccount;
            transactionLog.MemberType = model.MemberType;

            transactionLog.PaymentTypeId = paymentTypeId;
            transactionLog.Remarks = model.TransactionRemarks;
            transactionLog.TransactionAmount = transactionAmount;
            transactionLog.TransactionDate = DateTime.Now;

            return transactionLog;
        }

        /// <summary>
        /// Maps the different models to the TransactionLog entity model. This supports password mapping (for GUEST only).
        /// This is exclusive for New Accounts like "Guest" only.
        /// </summary>
        /// <param name="model"></param>
        /// <param name="cashierModel"></param>
        /// <param name="promoModel"></param>
        /// <param name="paymentTypeId"></param>
        /// <param name="accountModel"></param>
        /// <param name="transactionAmount"></param>
        /// <param name="password">Generated password locally.</param>
        /// <returns>The TransactionLog entity including password detail.</returns>
        public static TransactionLog MapNewAccount(TransactionModel model, CashierDataModel cashierModel, AccountPromoModel promoModel,
            int paymentTypeId, AccountManagerModel accountModel, int transactionAmount, string password = "")
        {
            TransactionLog transactionLog = new TransactionLog();
            // Would this be a problem when generating own Guid for the ID locally?
            // Since the back-end server would generate on its own. How is the
            // handling in the system when there is no internet connection?
            // Would this affect?

            int amount = 0;

            if (promoModel != null)
            {
                transactionLog.AvailedPromoCode = promoModel.PackageCode;
                transactionLog.AvailedPromoDescription = promoModel.PackageDescription;
                int.TryParse(promoModel.Amount.ToString(), out amount);
            }
            else
            {
                transactionLog.AvailedPromoCode = "N/A";
                transactionLog.AvailedPromoDescription = "N/A";
            }
            
            transactionLog.AvailedPromoPrice = amount;
            transactionLog.CashierName = cashierModel.Name;
            transactionLog.BranchName = cashierModel.Branch.Name;
            transactionLog.MemberType = model.MemberType;
            transactionLog.AccountCardNumber = string.Empty;

            if (model.MemberType == "N/A")
            {
                transactionLog.AccountName = model.CustomerName;
                transactionLog.AccountFirstName = "N/A";
                transactionLog.AccountLastName = "N/A";
            }
            else
            {
                transactionLog.AccountName = accountModel.Username;
                transactionLog.AccountFirstName = accountModel.FirstName;
                transactionLog.AccountLastName = accountModel.LastName;
            }
            

            transactionLog.AccountPassword = password;

            
            transactionLog.TransactionType = (short)TransactionType.NewAccount;

            transactionLog.PaymentTypeId = paymentTypeId;
            transactionLog.Remarks = model.TransactionRemarks;
            transactionLog.TransactionAmount = transactionAmount;
            transactionLog.TransactionDate = DateTime.Now;

            return transactionLog;
        }

        /// <summary>
        /// This maps the coupon details into a TransactionLog model.
        /// </summary>
        /// <param name="model">The TransactionModel object.</param>
        /// <param name="cashierModel">The Cashier object.</param>
        /// <param name="paymentTypeId">The payment type ID (for example Cash).</param>
        /// <param name="couponModel">The coupon object from the response.</param>
        /// <param name="stationTypes">List of station type names.</param>
        /// <returns></returns>
        public static TransactionLog MapNewCoupon(TransactionModel model, CashierDataModel cashierModel,
            int paymentTypeId, CouponDataModel couponModel, List<string> stationTypes, string password)
        {
            TransactionLog transactionLog = new TransactionLog();

            int amount = 0;

            transactionLog.AvailedPromoPrice = amount;
            transactionLog.CashierName = cashierModel.Name;
            transactionLog.BranchName = cashierModel.Branch.Name;
            transactionLog.AccountName = couponModel.Username;
            transactionLog.AccountPassword = couponModel.Password;
            transactionLog.TransactionType = (short)TransactionType.NewCouponAccount;
            transactionLog.AccountPassword = password;

            StringBuilder stationTypeNames = new StringBuilder();
            int length = stationTypes.Count;

            foreach (var type in stationTypes)
            {
                stationTypeNames.Append(type);

                if(!(length == stationTypes.IndexOf(type) + 1))
                {
                    stationTypeNames.Append(", ");
                }
            }

            transactionLog.StationType = stationTypeNames.ToString();

            transactionLog.PaymentTypeId = paymentTypeId;
            transactionLog.Remarks = model.TransactionRemarks;
            transactionLog.TransactionAmount = amount;
            transactionLog.TransactionDate = DateTime.Now;

            return transactionLog;
        }

        /// <summary>
        /// This maps the coupon details into a TransactionLog model.
        /// </summary>
        /// <param name="model">The TransactionModel object.</param>
        /// <param name="cashierModel">The Cashier object.</param>
        /// <param name="paymentTypeId">The payment type ID (for example Cash).</param>
        /// <param name="couponModel">The coupon object from the response.</param>
        /// <param name="stationTypes">List of station type names.</param>
        /// <returns></returns>
        public static TransactionLog MapCardReplacement(TransactionModel model, CashierDataModel cashierModel,
            UserDataModel userDataModel, string newCardID, int transactionAmount)
        {
            TransactionLog transactionLog = new TransactionLog();

            transactionLog.CashierName = cashierModel.Name;
            transactionLog.BranchName = cashierModel.Branch.Name;
            transactionLog.AccountName = userDataModel.MemberData.CustomerAccount.Username;
            transactionLog.NewAccountCardNumber = newCardID;
            transactionLog.TransactionType = (short)TransactionType.CardReplacement;

            transactionLog.PaymentTypeId = PaymentType.Cash;
            transactionLog.Remarks = model.TransactionRemarks;
            transactionLog.TransactionAmount = transactionAmount;
            transactionLog.TransactionDate = DateTime.Now;
            transactionLog.MemberType = model.MemberType;

            return transactionLog;
        }

        /// <summary>
        /// Maps different models to the TransactionLog entity model. Does not have password.
        /// </summary>
        /// <param name="model"></param>
        /// <param name="cashierModel"></param>
        /// <param name="promoModel"></param>
        /// <param name="paymentTypeId"></param>
        /// <param name="topUpModel"></param>
        /// <param name="transactionAmount"></param>
        /// <returns>The TransactionLog entity model. Does not have password.</returns>
        public static TransactionLog MapELoadTransaction(TransactionModel model, CashierDataModel cashierModel, AccountPromoModel promoModel,
            int paymentTypeId, TopUpManagerModel topUpModel, int transactionAmount)
        {
            TransactionLog transactionLog = new TransactionLog();
            // Note: by Jerameel
            // Would this be a problem when generating own Guid for the ID locally?
            // Since the back-end server would generate on its own. How is the
            // handling in the system when there is no internet connection?
            // Would this affect?

            int amount = 0;

            if (promoModel != null)
            {
                transactionLog.AvailedPromoCode = promoModel.PackageCode;
                transactionLog.AvailedPromoDescription = promoModel.PackageDescription;

                int.TryParse(promoModel.Amount.ToString(), out amount);
            }

            transactionLog.AvailedPromoPrice = amount;
            transactionLog.CashierName = cashierModel.Name;
            transactionLog.BranchName = cashierModel.Branch.Name;
            transactionLog.MemberType = MemberType.Regular;
            transactionLog.AccountCardNumber = topUpModel.CardIDNumber;
            transactionLog.AccountName = string.IsNullOrEmpty(topUpModel.Username) ? topUpModel.GuestUsername : topUpModel.Username;
            transactionLog.AccountFirstName = topUpModel.FirstName;
            transactionLog.AccountLastName = topUpModel.LastName;
            transactionLog.TransactionType = (short)TransactionType.ELoad;

            transactionLog.PaymentTypeId = paymentTypeId;
            transactionLog.Remarks = model.TransactionRemarks;
            transactionLog.TransactionAmount = transactionAmount;
            transactionLog.TransactionDate = DateTime.Now;

            return transactionLog;
        }
    }
}
