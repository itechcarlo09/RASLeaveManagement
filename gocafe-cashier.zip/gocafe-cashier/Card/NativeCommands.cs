﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.Card
{
    public class NativeCommands
    {

        [StructLayout(LayoutKind.Sequential)]
        public struct SCardIORequest
        {
            public int dwProtocol;
            public int cbPciLength;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct SCardReaderState
        {
            public string ReaderName;
            public int UserData;
            public int ReaderCurrState;
            public int ReaderEventState;
            public int ATRLength;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 37)]
            public byte[] ATRValue;
        }


        public const int SCardATRLength = 33;




        /*==========================================================================
        ' Prototypes
        '==========================================================================*/


        [DllImport("winscard.dll")]
        public static extern int SCardEstablishContext(int dwScope, int pvReserved1, int pvReserved2, ref int phContext);

        [DllImport("winscard.dll")]
        public static extern int SCardReleaseContext(int phContext);

        [DllImport("winscard.dll")]
        public static extern int SCardConnect(int hContext, string szReaderName, int dwShareMode, int dwPrefProtocol, ref int phCard, ref int activeProtocol);

        [DllImport("winscard.dll")]
        public static extern int SCardBeginTransaction(int hCard);

        [DllImport("winscard.dll")]
        public static extern int SCardDisconnect(int hCard, int disposition);

        [DllImport("winscard.dll")]
        public static extern int SCardListReaderGroups(int hContext, ref string mzGroups, ref int pcchGroups);

        [DllImport("winscard.dll", EntryPoint = "SCardListReadersA", CharSet = CharSet.Ansi)]
        public static extern int SCardListReaders(
            int hContext,
            byte[] groups,
            byte[] readers,
            ref int pcchReaders
            );


        [DllImport("winscard.dll")]
        public static extern int SCardStatus(int hCard, string szReaderName, ref int pcchReaderLen, ref int state, ref int protocol, ref byte ATR, ref int ATRLen);

        [DllImport("winscard.dll")]
        public static extern int SCardEndTransaction(int hCard, int disposition);

        [DllImport("winscard.dll")]
        public static extern int SCardState(int hCard, ref uint state, ref uint protocol, ref byte ATR, ref uint ATRLen);

        [DllImport("winscard.dll")]
        public static extern int SCardTransmit(IntPtr hCard,
                                               ref SCardIORequest pioSendPci,
                                               ref byte[] pbSendBuffer,
                                               int cbSendLength,
                                               ref SCardIORequest pioRecvPci,
                                               ref byte[] pbRecvBuffer,
                                               ref int pcbRecvLength);

        [DllImport("winscard.dll")]
        public static extern int SCardTransmit(int hCard, ref SCardIORequest pioSendRequest, ref byte sendBuff, int sendBuffLen, ref SCardIORequest pioRecvRequest, ref byte recvBuff, ref int recvBuffLen);

        [DllImport("winscard.dll")]
        public static extern int SCardTransmit(int hCard, ref SCardIORequest pioSendRequest, ref byte[] sendBuff, int sendBuffLen, ref SCardIORequest pioRecvRequest, ref byte[] recvBuff, ref int recvBuffLen);

        [DllImport("winscard.dll")]
        public static extern int SCardControl(int hCard, uint dwControlCode, ref byte sendBuff, int sendBuffLen, ref byte recvBuff, int recvBuffLen, ref int pcbBytesReturned);

        [DllImport("winscard.dll")]
        public static extern int SCardGetStatusChange(int hContext, int timeOut, ref SCardReaderState readerState, int readerCount);

    }
}
