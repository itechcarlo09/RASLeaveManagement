﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.Card
{
    public class Errors
    {

        public const int SCardSSuccess = 0;

        /*===========================================================
        '   Error Codes
        '===========================================================*/
        public const int SCardFInternalError = -2146435071;
        public const int SCardECancelled = -2146435070;
        public const int SCardEInvalidHandle = -2146435069;
        public const int SCardEInvalidParameter = -2146435068;
        public const int SCardEInvalidTarget = -2146435067;
        public const int SCardENoMemory = -2146435066;
        public const int SCardFWaitedTooLong = -2146435065;
        public const int SCardEInsufficientBuffer = -2146435064;
        public const int SCardEUnknownReader = -2146435063;


        public const int SCardETimeout = -2146435062;
        public const int SCardESharingViolation = -2146435061;
        public const int SCardENoSmartCard = -2146435060;
        public const int SCardEUnknownCard = -2146435059;
        public const int SCardECantDispose = -2146435058;
        public const int SCardEProtoMismatch = -2146435057;


        public const int SCardENotReady = -2146435056;
        public const int SCardEInvalidValue = -2146435055;
        public const int SCardESystemCancelled = -2146435054;
        public const int SCardFCommError = -2146435053;
        public const int SCardFUnknownError = -2146435052;
        public const int SCardEInvalidATR = -2146435051;
        public const int SCardENotTransacted = -2146435050;
        public const int SCardEReaderUnavailable = -2146435049;
        public const int SCardPShutdown = -2146435048;
        public const int SCardEPCITooSmall = -2146435047;

        public const int SCardEReaderUnsupported = -2146435046;
        public const int SCardEDuplicateReader = -2146435045;
        public const int SCardECardUnsupported = -2146435044;
        public const int SCardENoService = -2146435043;
        public const int SCardEerviceStopped = -2146435042;

        public const int SCardWUnsupportedCard = -2146435041;
        public const int SCardWUnresponsiveCard = -2146435040;
        public const int SCardWUnpoweredCard = -2146435039;
        public const int SCardWResetCard = -2146435038;
        public const int SCardWRemovedCard = -2146435037;

        public static string GetScardErrMsg(int ReturnCode)
        {
            switch (ReturnCode)
            {
                case SCardECancelled:
                    return ("The action was canceled by an SCardCancel request.");
                case SCardECantDispose:
                    return ("The system could not dispose of the media in the requested manner.");
                case SCardECardUnsupported:
                    return ("The smart card does not meet minimal requirements for support.");
                case SCardEDuplicateReader:
                    return ("The reader driver didn't produce a unique reader name.");
                case SCardEInsufficientBuffer:
                    return ("The data buffer for returned data is too small for the returned data.");
                case SCardEInvalidATR:
                    return ("An ATR string obtained from the registry is not a valid ATR string.");
                case SCardEInvalidHandle:
                    return ("The supplied handle was invalid.");
                case SCardEInvalidParameter:
                    return ("One or more of the supplied parameters could not be properly interpreted.");
                case SCardEInvalidTarget:
                    return ("Registry startup information is missing or invalid.");
                case SCardEInvalidValue:
                    return ("One or more of the supplied parameter values could not be properly interpreted.");
                case SCardENotReady:
                    return ("The reader or card is not ready to accept commands.");
                case SCardENotTransacted:
                    return ("An attempt was made to end a non-existent transaction.");
                case SCardENoMemory:
                    return ("Not enough memory available to complete this command.");
                case SCardENoService:
                    return ("The smart card resource manager is not running.");
                case SCardENoSmartCard:
                    return ("The operation requires a smart card, but no smart card is currently in the device.");
                case SCardEPCITooSmall:
                    return ("The PCI receive buffer was too small.");
                case SCardEProtoMismatch:
                    return ("The requested protocols are incompatible with the protocol currently in use with the ");
                case SCardEReaderUnavailable:
                    return ("The specified reader is not currently available for use.");
                case SCardEReaderUnsupported:
                    return ("The reader driver does not meet minimal requirements for support.");
                case SCardEerviceStopped:
                    return ("The smart card resource manager has shut down.");
                case SCardESharingViolation:
                    return ("The smart card cannot be accessed because of other outstanding connections.");
                case SCardESystemCancelled:
                    return ("The action was canceled by the system, presumably to log off or shut down.");
                case SCardETimeout:
                    return ("The user-specified timeout value has expired.");
                case SCardEUnknownCard:
                    return ("The specified smart card name is not recognized.");
                case SCardEUnknownReader:
                    return ("The specified reader name is not recognized.");
                case SCardFCommError:
                    return ("An internal communications error has been detected.");
                case SCardFInternalError:
                    return ("An internal consistency check failed.");
                case SCardFUnknownError:
                    return ("An internal error has been detected, but the source is unknown.");
                case SCardFWaitedTooLong:
                    return ("An internal consistency timer has expired.");
                case SCardSSuccess:
                    return ("No error was encountered.");
                case SCardWRemovedCard:
                    return ("The smart card has been removed, so that further communication is not possible.");
                case SCardWResetCard:
                    return ("The smart card has been reset, so any shared state information is invalid.");
                case SCardWUnpoweredCard:
                    return ("Power has been removed from the smart card, so that further communication is not possible.");
                case SCardWUnresponsiveCard:
                    return ("The smart card is not responding to a reset.");
                case SCardWUnsupportedCard:
                    return ("The reader cannot communicate with the card, due to ATR string configuration conflicts.");
                default:
                    return ("?");
            }
        }
    }
}
