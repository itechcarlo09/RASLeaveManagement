﻿using gocafe_cashier.MessageResource;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using static gocafe_cashier.Card.Constants;
using static gocafe_cashier.Card.Errors;
using static gocafe_cashier.Card.NativeCommands;

namespace gocafe_cashier.Card
{
    public sealed class CardUtilities: Model.BaseModel
    {
        private bool canSendEventsToAccountManager = false;
        private bool canSendEventsToLeftControl = false;
        private bool canSendEventsToTopUpManager = false;
        private bool canSendToPasswordResetWindow = false;
        private bool canSendToReplaceCardWindow = false;

        private int hCard;
        private int hContext;
        private int protocol;
        private string readerName = "ACS ACR1252";
        public SCardReaderState ReaderState;

        private CancellationTokenSource tokenSource;

        private string message = string.Empty;
        private string messageMode = string.Empty;

        private static readonly CardUtilities instance = new CardUtilities();

        static CardUtilities()
        {
        }

        private CardUtilities()
        {
            Mediator.Instance.Register(this, Messages.CardController);
        }

        public static CardUtilities Instance
        {
            get
            {
                return instance;
            }
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                default:
                    break;
            }
        }

        private void MonitorReader()
        {
            SelectDevice();
            EstablishContext();

            int ret;
            SCardReaderState rs = new SCardReaderState();
            rs.ReaderName = readerName;
            rs.ReaderCurrState = SCardStateUnaware;
            rs.ReaderEventState = SCardStateUnknown;
            
            while (!tokenSource.IsCancellationRequested)
            {
                ret = SCardGetStatusChange(hContext, 100, ref rs, 1);
                if (ret == SCardETimeout) continue;

                if ((rs.ReaderEventState & SCardStateUnavailable) == SCardStateUnavailable)
                {
                    SelectDevice();
                    EstablishContext();
                    rs.ReaderCurrState = SCardStateUnaware;
                    rs.ReaderEventState = SCardStateUnknown;
                }
                else if ((rs.ReaderEventState & SCardStatePresent) == SCardStatePresent && (rs.ReaderCurrState & SCardStatePresent) != SCardStatePresent)
                {
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.CardTapped, null);
                }

                rs.ReaderCurrState = rs.ReaderEventState;

                // wait 100ms to avoid double taps
                Thread.Sleep(200);
            }
        }

        public void SelectDevice()
        {
            hContext = 0;
            List<string> availableReaders = this.ListReaders();
            this.ReaderState = new SCardReaderState();

            while(availableReaders == null && !tokenSource.IsCancellationRequested)
            {
                availableReaders = this.ListReaders();
                this.ReaderState = new SCardReaderState();
            }

            while (availableReaders.Count == 0 && !tokenSource.IsCancellationRequested)
            {
                availableReaders = this.ListReaders();
                this.ReaderState = new SCardReaderState();
            }

            //selecting first device
            if (availableReaders.Count != 0)
            {
                readerName = availableReaders[0].ToString();
                this.ReaderState.ReaderName = readerName;
            }
        }

        public List<string> ListReaders()
        {
            int readerCount = 0;
            int returnCode;

            List<string> availableReaderList = new List<string>();

            //Make sure a context has been established before 
            //retrieving the list of smartcard readers.
            returnCode = SCardListReaders(hContext, null, null, ref readerCount);
            if (returnCode != SCardSSuccess)
            {
                Application.Current.Dispatcher.Invoke((Action)delegate
                {
                    message = StandardMessageResource.ErrorCardReaderNotDetected;
                    messageMode = Messages.ErrorConfirmation;
                    ShowConfirmationWindow(message, messageMode);
                });
                return null;
            }

            byte[] readersList = new byte[readerCount];

            //Get the list of reader present again but this time add sReaderGroup, retData as 2rd & 3rd parameter respectively.
            returnCode = SCardListReaders(hContext, null, readersList, ref readerCount);
            if (returnCode != SCardSSuccess)
            {
                Application.Current.Dispatcher.Invoke((Action)delegate
                {
                    message = StandardMessageResource.ErrorCardReaderNotDetected;
                    messageMode = Messages.ErrorConfirmation;
                    ShowConfirmationWindow(message, messageMode);
                });
                return null;
            }

            string rName = "";
            int indx = 0;
            if (readerCount > 0)
            {
                while (readersList[indx] != 0)
                {
                    while (readersList[indx] != 0)
                    {
                        rName = rName + (char)readersList[indx];
                        indx = indx + 1;
                    }
                    availableReaderList.Add(rName);
                    rName = "";
                    indx = indx + 1;
                }
            }
            return availableReaderList;
        }

        internal void EstablishContext()
        {
            int returnCode;
            returnCode = SCardEstablishContext(SCardScopeSystem, 0, 0, ref hContext);
            if (returnCode != SCardSSuccess)
            {
                Application.Current.Dispatcher.Invoke((Action)delegate
                {
                    message = StandardMessageResource.ErrorCardReaderNotDetected;
                    messageMode = Messages.ErrorConfirmation;
                    ShowConfirmationWindow(message, messageMode);
                });
                return;
            }
        }


        public bool ConnectCard()
        {
            int returnCode;
            returnCode = SCardConnect(hContext, readerName, SCardShareShared,
                      SCardProtocolT0 | SCardProtocolT1, ref hCard, ref protocol);

            if (returnCode != SCardSSuccess)
            {
                Application.Current.Dispatcher.Invoke((Action)delegate
                {
                    message = StandardMessageResource.ErrorCardNotRecognized;
                    messageMode = Messages.ErrorConfirmation;
                    ShowConfirmationWindow(message, messageMode);
                });
                return false;
            }
            return true;
        }

        public string GetCardUID()
        {
            string cardUID = "";
            byte[] receivedUID = new byte[256];
            SCardIORequest request = new SCardIORequest();
            request.dwProtocol = SCardProtocolT1;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(SCardIORequest));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 };
            int outBytes = receivedUID.Length;
            int status = SCardTransmit(hCard, ref request, ref sendBytes[0], sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            if (status != SCardSSuccess)
            {
                cardUID = "Unknown Card";
            }
            else
            {
                cardUID = BitConverter.ToString(receivedUID.Take(outBytes - 2).ToArray()).Replace("-", string.Empty).ToLower();
            }

            return cardUID;
        }

        public void StartMonitoring()
        {
            tokenSource = new CancellationTokenSource();
            Task.Run(() => MonitorReader(), tokenSource.Token);
            
        }

        public void StopMonitoring()
        {
            tokenSource.Cancel();
        }
    }
}

