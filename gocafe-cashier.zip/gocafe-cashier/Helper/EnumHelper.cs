﻿using GocafeDatabaseModel.Enum;
using System;

namespace gocafe_cashier.Helper
{
    public class EnumHelper
    {
        public static string ParseTransactionType(short transactionType)
        {
            var type = Enum.Parse(typeof(TransactionType), transactionType.ToString());

            switch ((TransactionType)type)
            {
                case TransactionType.NewAccount:
                    return "New Account";

                case TransactionType.TopUp:
                    return "Top-up";

                case TransactionType.NewCouponAccount:
                    return "New Coupon Account";

                case TransactionType.ELoad:
                    return "E-Load";

                case TransactionType.CardReplacement:
                    return "Card Replacement";

                case TransactionType.NewOrder:
                    return "New Order";

                default:
                    return string.Empty;
            }
        }
    }
}
