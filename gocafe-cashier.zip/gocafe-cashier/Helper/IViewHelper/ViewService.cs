﻿namespace gocafe_cashier.Helper
{
    using gocafe_cashier.View;
    using gocafe_cashier.ViewModel;
    using System;
    using System.Collections.Generic;
    using System.Windows;

    public sealed class ViewService : IViewService
    {
        private static readonly ViewService instance = new ViewService();
        public IDictionary<Type, Type> Mappings { get; }

        private ViewService()
        {
            Mappings = new Dictionary<Type, Type>();

            Register<MainViewModel, MainWindow>();
            Register<LoginWindowViewModel, LoginWindow>();
        }

        public static ViewService Instance
        {
            get
            {
                return instance;
            }
        }

        private void Register<TViewModel, TView>() where TViewModel : AbstractViewModel
                                                  where TView : IView
        {
            if (Mappings.ContainsKey(typeof(TViewModel)))
            {
                throw new ArgumentException($"Type {typeof(TViewModel)} is already mapped to type {typeof(TView)}");
            }

            Mappings.Add(typeof(TViewModel), typeof(TView));
        }

        public delegate AbstractViewModel NewViewModelDelegate(IView view);

        public void ShowView<TViewModel>() where TViewModel : AbstractViewModel
        {
            
            Type viewType = Mappings[typeof(TViewModel)];
            IView view = (IView)Activator.CreateInstance(viewType);
            view.DataContext = (TViewModel)Activator.CreateInstance(typeof(TViewModel), new object[] { view });
            view.Show();
        }

        public void ShowView<TViewModel>(NewViewModelDelegate nvmDelegate) where TViewModel : AbstractViewModel
        {
            Type viewType = Mappings[typeof(TViewModel)];
            IView view = (IView)Activator.CreateInstance(viewType);
            view.DataContext = nvmDelegate(view);
            view.Show();
        }

        public void ShowDialog<TViewModel>(Window owner) where TViewModel : AbstractViewModel
        {
            Type viewType = Mappings[typeof(TViewModel)];

            IView view = (IView)Activator.CreateInstance(viewType);

            view.DataContext = (TViewModel)Activator.CreateInstance(typeof(TViewModel), new object[] { view });
            view.Owner = owner;
            view.ShowDialog();
        }

        public void ShowDialog<TViewModel>(NewViewModelDelegate nvmDelegate, Window owner) where TViewModel : AbstractViewModel
        {
            Type viewType = Mappings[typeof(TViewModel)];

            IView view = (IView)Activator.CreateInstance(viewType);

            view.DataContext = nvmDelegate(view);
            view.Owner = owner;
            view.ShowDialog();
        }
    }
}
