﻿using gocafe_cashier.ViewModel;
using System.Windows;
using static gocafe_cashier.Helper.ViewService;

namespace gocafe_cashier.Helper
{
    public interface IViewService
    {
        /// <summary>
        /// Use this to show views whose view models do not have a parameter.
        /// </summary>
        void ShowView<TViewModel>() where TViewModel : AbstractViewModel;

        /// <summary>
        /// Use this to show views whose view models do not have a parameter.
        /// </summary>
        void ShowDialog<TViewModel>(Window owner) where TViewModel : AbstractViewModel;

        /// <summary>
        /// Use this to show views whose view models contain parameters.
        /// The NewViewModelDelegate is responsible for returning the new instance of the view model given the view.
        /// </summary>
        void ShowView<TViewModel>(NewViewModelDelegate nvmDelegate) where TViewModel : AbstractViewModel;

        /// <summary>
        /// Use this to show views whose view models contain parameters.
        /// The NewViewModelDelegate is responsible for returning the new instance of the view model given the view.2
        /// </summary>
        void ShowDialog<TViewModel>(NewViewModelDelegate nvmDelegate, Window owner) where TViewModel : AbstractViewModel;

    }
}
