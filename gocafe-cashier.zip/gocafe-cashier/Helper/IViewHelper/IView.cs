﻿using System.Windows;

namespace gocafe_cashier.Helper
{
    public interface IView
    {
        object DataContext { get; set; }
        Window Owner { get; set; }
        void Close();
        void Show();
        void Hide();
        bool Activate();
        bool? ShowDialog();
    }
}
