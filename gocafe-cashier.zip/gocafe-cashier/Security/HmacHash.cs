﻿using System;
using System.Text;
using System.Security.Cryptography;

namespace gocafe_cashier.Security
{
    public class HmacHash
    {
        public static string HashHMACHex(string key, string message)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();

            byte[] keybyte = encoding.GetBytes(key);
            byte[] messagebyte = encoding.GetBytes(message);

            HMACSHA256 hmac = new HMACSHA256(keybyte);

            byte[] hmacbyte = hmac.ComputeHash(messagebyte);

            return BitConverter.ToString(hmacbyte).Replace("-", "").ToLower();
        }
    }
}
