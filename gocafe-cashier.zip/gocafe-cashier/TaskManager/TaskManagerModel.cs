﻿using gocafe_cashier.Manager;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using gocafe_cashier.Cache;

namespace gocafe_cashier.TaskManager
{
    public sealed class TaskManagerModel<T> : BaseModel
    {
        private static readonly TaskManagerModel<T> instance = new TaskManagerModel<T>();

        public static TaskManagerModel<T> Instance
        {
            get
            {
                return instance;
            }
        }

        public async Task<T> Run(Task<T> task, CancellationTokenSource cancellationTokenSource, string viewModel = "", int timeOut = int.MaxValue, bool isCriticalTask = false)
        {
            Guid taskID = Guid.NewGuid();

            TaskModel<T> taskModel = new TaskModel<T>
            {
                ID = taskID,
                Task = task,
                CancellationTokenSource = cancellationTokenSource,
                ViewModel = viewModel,
                Name = task.ToString(),
                IsCriticalTask = isCriticalTask
            };

            TaskManagerModel.TaskList.TryAdd(taskID, taskModel);

            if (timeOut != int.MaxValue)
            {
                if (await Task.WhenAny(task, Task.Delay(timeOut * 1000)) == task)
                {
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(taskID, out placeHolderTask);
                    return task.Result;
                }
                else
                {
                    if (CancelTaskByID(taskID))
                    {
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorRequestTimedOut, Messages.ErrorConfirmation);
                        });
                    }
                    return default(T);
                }
            }
            else
            {
                if (await Task.WhenAny(task, Task.Delay(DataCacheContext.AsyncTimeout * 1000)) == task)
                {
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(taskID, out placeHolderTask);
                    return task.Result;
                }
                else
                {
                    if (CancelTaskByID(taskID))
                    {
                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorRequestTimedOut, Messages.ErrorConfirmation);
                        });
                    }
                    return default(T);
                }
            }
        }

        public async Task Run(Task task, CancellationTokenSource cancellationTokenSource, string viewModel = "", int timeOut = int.MaxValue, bool isCriticalTask = false)
        {
            Guid taskID = Guid.NewGuid();

            TaskModel<T> taskModel = new TaskModel<T>
            {
                ID = taskID,
                VoidTask = task,
                CancellationTokenSource = cancellationTokenSource,
                ViewModel = viewModel,
                Name = task.ToString(),
                IsCriticalTask = isCriticalTask
            };

            TaskManagerModel.TaskList.TryAdd(taskID, taskModel);

            if (timeOut != int.MaxValue)
            {
                if (await Task.WhenAny(task, Task.Delay(timeOut * 1000)) == task)
                {
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(taskID, out placeHolderTask);
                    return;
                }
                else
                {
                    if (CancelTaskByID(taskID))
                    {
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorRequestTimedOut, Messages.ErrorConfirmation);
                        });
                    }
                    return;
                }
            }
            else
            {
                if (await Task.WhenAny(task, Task.Delay(DataCacheContext.AsyncTimeout * 1000)) == task)
                {
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(taskID, out placeHolderTask);
                    return;
                }
                else
                {
                    if (CancelTaskByID(taskID))
                    {
                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorRequestTimedOut, Messages.ErrorConfirmation);
                        });
                    }
                    return;
                }
            }
        }

        public async Task<T> Run(Action action, string viewModel = "", string taskName = "", int timeOut = int.MaxValue)
        {
            Guid taskID = Guid.NewGuid();
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            Task<T> task = (Task<T>)Task.Run(action, cancellationTokenSource.Token);

            TaskModel<T> taskModel = new TaskModel<T>
            {
                ID = taskID,
                Task = task,
                CancellationTokenSource = cancellationTokenSource,
                ViewModel = viewModel,
                Name = taskName
            };

            TaskManagerModel.TaskList.TryAdd(taskID, taskModel);

            if (timeOut != int.MaxValue)
            {
                if (await Task.WhenAny(task, Task.Delay(timeOut * 1000)) == task)
                {
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(taskID, out placeHolderTask);
                    return task.Result;
                }
                else
                {
                    if (CancelTaskByID(taskID))
                    {
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorRequestTimedOut, Messages.ErrorConfirmation);
                        });
                    }
                    return default(T);
                }
            }
            else
            {
                if (await Task.WhenAny(task, Task.Delay(DataCacheContext.AsyncTimeout * 1000)) == task)
                {
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(taskID, out placeHolderTask);
                    return task.Result;
                }
                else
                {
                    if (CancelTaskByID(taskID))
                    {
                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorRequestTimedOut, Messages.ErrorConfirmation);
                        });
                    }
                    return default(T);
                }
            }
        }

        public async Task<T> ContinueWith(Func<Task<T>, T> func, string taskToContinueFrom, string viewModel = "", string taskName = "", int timeOut = int.MaxValue)
        {
            Guid taskID = Guid.NewGuid();
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            Task<T> previousTask = FindTaskByName(taskToContinueFrom);

            Task<T> task = previousTask.ContinueWith(func, cancellationTokenSource.Token);

            TaskModel<T> taskModel = new TaskModel<T>
            {
                ID = taskID,
                Task = task,
                CancellationTokenSource = cancellationTokenSource,
                ViewModel = viewModel,
                Name = taskName
            };

            TaskManagerModel.TaskList.TryAdd(taskID, taskModel);

            if (timeOut != int.MaxValue)
            {
                if (await Task.WhenAny(task, Task.Delay(timeOut * 1000)) == task)
                {
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(taskID, out placeHolderTask);
                    return task.Result;
                }
                else
                {
                    if (CancelTaskByID(taskID))
                    {
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorRequestTimedOut, Messages.ErrorConfirmation);
                        });
                    }
                    return default(T);
                }
            }
            else
            {
                if (await Task.WhenAny(task, Task.Delay(DataCacheContext.AsyncTimeout * 1000)) == task)
                {
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(taskID, out placeHolderTask);
                    return task.Result;
                }
                else
                {
                    if (CancelTaskByID(taskID))
                    {
                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorRequestTimedOut, Messages.ErrorConfirmation);
                        });
                    }
                    return default(T);
                }
            }
        }

        public void CancelTask(Task<T> taskToCancel)
        {
            foreach (var task in TaskManagerModel.TaskList)
            {
                if (((TaskModel<T>)task.Value).Task == taskToCancel)
                {
                    task.Value.CancellationTokenSource.Cancel();
                    TaskModel placeHolderTask = new TaskModel();
                    TaskManagerModel.TaskList.TryRemove(task.Key, out placeHolderTask);
                    break;
                }
            }
        }

        public bool CancelAllTasks()
        {
            if (TaskManagerModel.TaskList.Count > 0)
            {
                bool isProcessingCriticalRequest = false;

                foreach (var task in TaskManagerModel.TaskList)
                {
                    if (task.Value.IsCriticalTask == true)
                    {
                        isProcessingCriticalRequest = true;
                        break;
                    }
                }
                if (isProcessingCriticalRequest)
                {
                    if (ShowConfirmationWindow(StandardMessageResource.WarningCancelRequests, Messages.WarningConfirmation))
                    {
                        foreach (var task in TaskManagerModel.TaskList)
                        {
                            task.Value.CancellationTokenSource.Cancel();
                        }
                        TaskManagerModel.TaskList =  new ConcurrentDictionary<Guid, TaskModel>();
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    foreach (var task in TaskManagerModel.TaskList)
                    {
                        task.Value.CancellationTokenSource.Cancel();
                    }
                    TaskManagerModel.TaskList = new ConcurrentDictionary<Guid, TaskModel>();
                }
            }

            return true;
        }

        public void CancelAllTasksWithoutWarning()
        {
            if (TaskManagerModel.TaskList.Count > 0)
            {
                foreach (var task in TaskManagerModel.TaskList)
                {
                    task.Value.CancellationTokenSource.Cancel();
                }
                TaskManagerModel.TaskList = new ConcurrentDictionary<Guid, TaskModel>();
            }
        }

        public void CancelTasksByName(string taskName)
        {
            Guid taskIDToRemove = Guid.NewGuid();
            bool isTaskFound = false;

            foreach (var task in TaskManagerModel.TaskList)
            {
                if (task.Value.Name == taskName)
                {
                    task.Value.CancellationTokenSource.Cancel();
                    taskIDToRemove = task.Key;
                    isTaskFound = true;
                    break;
                }
            }

            if (isTaskFound)
            {
                TaskModel placeHolderTask = new TaskModel();
                TaskManagerModel.TaskList.TryRemove(taskIDToRemove, out placeHolderTask);
                CancelTasksByName(taskName);
            }
        }

        public Task<T> FindTaskByName(string taskName)
        {
            foreach (var task in TaskManagerModel.TaskList)
            {
                if (task.Value.Name == taskName)
                {
                    return ((TaskModel<T>)task.Value).Task;
                }
            }

            return null;
        }

        public void CancelTasksByViewModel(string viewModel)
        {

            Guid taskIDToRemove = Guid.NewGuid();
            bool isTaskFound = false;

            foreach (var task in TaskManagerModel.TaskList)
            {
                if (task.Value.ViewModel == viewModel)
                {
                    task.Value.CancellationTokenSource.Cancel();
                    taskIDToRemove = task.Key;
                    isTaskFound = true;
                    break;
                }
            }

            if (isTaskFound)
            {
                TaskModel placeHolderTask = new TaskModel();
                TaskManagerModel.TaskList.TryRemove(taskIDToRemove, out placeHolderTask);
                CancelTasksByViewModel(viewModel);
            }
        }

        public bool CancelTaskByID(Guid id)
        {
            foreach (var task in TaskManagerModel.TaskList)
            {
                if (task.Key == id)
                {
                    task.Value.CancellationTokenSource.Cancel();
                    TaskModel placeHolderTask = new TaskModel();
                    if (TaskManagerModel.TaskList.TryRemove(task.Key, out placeHolderTask))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            return false;
        }
    }

    public abstract class TaskManagerModel
    {
        public static ConcurrentDictionary<Guid, TaskModel> TaskList = new ConcurrentDictionary<Guid, TaskModel>();
    }
}
