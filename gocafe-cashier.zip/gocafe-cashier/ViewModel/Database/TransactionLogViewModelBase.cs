﻿using gocafe_cashier.Cache;
using gocafe_cashier.Manager;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using GocafeDatabaseDataAccess;
using GocafeDatabaseDataAccess.Data.Repositories;
using System;
using System.Drawing;
using System.Drawing.Printing;

namespace gocafe_cashier.ViewModel.Database
{
    public class TransactionLogViewModelBase : DbContextViewModelBase
    {
        protected readonly ITransactionLogRepository TransactionRepository;
        
        public TransactionLogViewModelBase()
        {
            // This is currently maintained at App.config
            if (DataCacheContext.UseLocalDB)
            {
                TransactionRepository = new TransactionLogRepository(DbContext);
            }
            CurrencySignModel currencySign = new CurrencySignModel();
            CurrencySymbol = currencySign.SelectedCurrency;
            PriceCurrencySymbol = "Price: " + CurrencySymbol;
        }

        private string currencySymbol;
        public string CurrencySymbol
        {
            get { return currencySymbol; }
            set
            {
                currencySymbol = value;
                RaisePropertyChanged(nameof(CurrencySymbol));
            }
        }

        private string priceCurrencySymbol;
        public string PriceCurrencySymbol
        {
            get { return priceCurrencySymbol; }
            set
            {
                priceCurrencySymbol = value;
                RaisePropertyChanged(nameof(PriceCurrencySymbol));
            }
        }

    }
}
