﻿using gocafe_cashier.Cache;
using gocafe_cashier.Manager;
using gocafe_cashier.Model;
using GocafeDatabaseDataAccess;
using System;

namespace gocafe_cashier.ViewModel.Database
{
    public class DbContextViewModelBase : BaseModel
    {
        protected readonly GoCafeDbContext DbContext;

        public DbContextViewModelBase()
        {
            if (DataCacheContext.UseLocalDB)
            {
                DbContext = new GoCafeDbContext();
            }            
        }
    }
}
