﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Helper;
using gocafe_cashier.ViewModelMediator;
using System.Collections.Generic;
using System.Windows.Input;

namespace gocafe_cashier.ViewModel
{
    public class MainViewModel : AbstractViewModel
    {
        public MainViewModel(IView view, CashierDataModel userData) : base(view)
        {
            Mediator.Instance.Register(this, Messages.MainViewModel);

            List<string> viewModelList = new List<string>()
            {
                Messages.LeftUserControl, Messages.RightUserControl
            };

            Mediator.Instance.NotifyViewModels(viewModelList, Messages.SendUserInfo, userData);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.LogoutUser:
                    CloseView();
                    break;

                default:
                    break;
            }
        }

        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(WindowClose);
            }
        }

        public ICommand ClosingCommand
        {
            get
            {
                return new DelegateCommand(WindowClosing);
            }
        }

        #endregion

        #region EventHandlers

        private void WindowClose()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.LogoutUser, null);
        }
        
        private void WindowClosing()
        {
            Mediator.Instance.NotifyViewModel(Messages.PendingOrdersWindowViewModel, Messages.OpenClosePendingOrdersWindow, true);
        }

        #endregion
    }
}
