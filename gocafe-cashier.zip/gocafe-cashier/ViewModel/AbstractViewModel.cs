﻿using gocafe_cashier.Helper;
using gocafe_cashier.Command;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using gocafe_cashier.Model;
using gocafe_cashier.ViewModel.Database;

namespace gocafe_cashier.ViewModel
{
    public abstract class AbstractViewModel : DbContextViewModelBase
    {
        protected readonly IViewService GenerateWindowService;

        string Name { get; }

        private readonly IView view;

        protected AbstractViewModel(IView view)
        {
            this.view = view;
        }

        public ICommand CloseButton
        {
            get
            {
                return new DelegateCommand(CloseView);
            }
        }

        protected void CloseView<T>() where T : Window
        {
            var window = Application.Current.Windows.OfType<T>().FirstOrDefault();
            if (window != null)
                window.Close();
        }

        protected void CloseView()
        {
            if (view != null)
            {
                view.Close();
            }
        }
    }
}
