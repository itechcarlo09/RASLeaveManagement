﻿using gocafe_cashier.Command;
using gocafe_cashier.Model;
using gocafe_cashier.Model.InventoryModels;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using System.Collections.ObjectModel;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class PurchaseOrderSummaryWindowViewModel : BaseModel
    {
        public PurchaseOrderSummaryWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.SummaryWindowViewModel);
            SummaryTitle = string.Empty;
            PurchasedItems = null;
            ReceiptSummary = string.Empty;
            IsOtherContentPresent = false;
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.SummaryWindow:
                    purchaseOrderSummaryWindow = (PurchaseOrderSummaryWindow)data;
                    IsWindowOpen = true;
                    break;
                case Messages.SummaryTitle:
                    SummaryTitle = (string)data;
                    break;
                case Messages.SummaryContent:
                    PurchasedItems = (ObservableCollection<ItemModel>)data;
                    ComputeTotalCost();
                    break;
                case Messages.OtherSummaryContent:
                    ReceiptSummary = (string)data;
                    IsOtherContentPresent = true;
                    break;
                default:
                    break;
            }
        }


        #region Private Fields

        PurchaseOrderSummaryWindow purchaseOrderSummaryWindow;

        #endregion


        #region Properties

        private string summaryTitle;
        public string SummaryTitle
        {
            get { return summaryTitle; }
            set
            {
                summaryTitle = value;
                RaisePropertyChanged(nameof(SummaryTitle));
            }
        }

        private ObservableCollection<ItemModel> purchasedItems;
        public ObservableCollection<ItemModel> PurchasedItems
        {
            get { return purchasedItems; }
            set
            {
                purchasedItems = value;
                RaisePropertyChanged(nameof(PurchasedItems));
            }
        }

        private string receiptSummary;
        public string ReceiptSummary
        {
            get { return receiptSummary; }
            set
            {
                receiptSummary = value;
                RaisePropertyChanged(nameof(ReceiptSummary));
            }
        }

        private bool isOtherContentPresent;
        public bool IsOtherContentPresent
        {
            get { return isOtherContentPresent; }
            set
            {
                isOtherContentPresent = value;
                RaisePropertyChanged(nameof(IsOtherContentPresent));
            }
        }

        private decimal purchasedItemsTotal;
        public decimal PurchasedItemsTotalCost
        {
            get { return purchasedItemsTotal; }
            set
            {
                purchasedItemsTotal = value;
                RaisePropertyChanged(nameof(PurchasedItemsTotalCost));
            }
        }

        #endregion


        #region Commands

        public DelegateCommand ProceedCommand
        {
            get
            {
                return new DelegateCommand(ProceedCommandClicked);
            }
        }

        public DelegateCommand CancelCommand
        {
            get
            {
                return new DelegateCommand(CancelCommandClicked);
            }
        }

        #endregion

        #region EventHandlers

        private void ProceedCommandClicked()
        {
            CloseWindow(true);
        }

        private void CancelCommandClicked()
        {
            CloseWindow(false);
        }

        private void CloseWindow(bool mode)
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    if (purchaseOrderSummaryWindow != null)
                    {
                        if (purchaseOrderSummaryWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            Mediator.Instance.UnRegister(this, Messages.SummaryWindowViewModel);
                            purchaseOrderSummaryWindow.DialogResult = mode;
                            purchaseOrderSummaryWindow.Close();
                        }
                    }
                }
            });
        }

        #endregion

        #region Private Methods

        private void ComputeTotalCost()
        {
            PurchasedItemsTotalCost = 0;
            foreach(ItemModel item in PurchasedItems)
            {
                PurchasedItemsTotalCost += item.TotalCost;
            }
        }

        #endregion

    }
}
