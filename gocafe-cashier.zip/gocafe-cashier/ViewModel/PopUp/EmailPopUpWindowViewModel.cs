﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class EmailPopUpWindowViewModel: BaseModel, IDataErrorInfo
    {
        public EmailPopUpWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.EmailPopUpWindowViewModel);
            EmailAddress = string.Empty;
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.EmailPopUpWindow:
                    emailPopUpWindow = (EmailPopUpWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    break;

                default:
                    break;
            }
        }

        #region Properties

        private string emailAddress;

        public string EmailAddress
        {
            get { return emailAddress; }
            set
            {
                emailAddress = value;
                RaisePropertyChanged(nameof(EmailAddress));
            }
        }

        private bool isSubmitButtonEnabled;

        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }


        #endregion

        #region Private Fields

        EmailPopUpWindow emailPopUpWindow;
        CashierDataModel cashierData;

        #endregion

        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand SubmitCommand
        {
            get
            {
                return new DelegateCommand(SubmitEmail);
            }
        }


        #endregion

        #region Event Handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.EmailPopUpWindowViewModel);
                    if (emailPopUpWindow != null)
                    {
                        if (emailPopUpWindow.IsLoaded == true)
                        {
                            emailPopUpWindow.DialogResult = false;
                            emailPopUpWindow.Close();
                        }
                    }
                }
            });
        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.EmailPopUpWindowViewModel);
                if (emailPopUpWindow != null)
                {
                    if (emailPopUpWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        emailPopUpWindow.DialogResult = true;
                        emailPopUpWindow.Close();
                    }
                }
            });
        }

        private void SubmitEmail()
        {
            if(IsSubmitButtonEnabled || EmailAddress.Trim() == string.Empty || EmailAddress == null)
            {
                Mediator.Instance.NotifyViewModel(Messages.EShopWindowViewModel, Messages.EmailAddress, EmailAddress);
                CloseWindowImmediately();
            }
        }

        #endregion

        #region Error Handling

        private bool isEmailAddressNameFirstLoad = true;

        public string Error { get; set; }

        public string this[string name]
        {
            get
            {
                string result = null;
                if (name == "EmailAddress")
                {
                    if (isEmailAddressNameFirstLoad)
                    {
                        isEmailAddressNameFirstLoad = false;
                    }
                    else if (EmailAddress == null || EmailAddress == string.Empty)
                    {
                        isEmailAddressNameFirstLoad = true;
                    }
                    else if (!IsValidEmail())
                    {
                        result = StandardMessageResource.ErrorTopUpEmailIsValid;
                    }

                    if (IsValidEmail() || EmailAddress.Trim() == string.Empty)
                    {
                        IsSubmitButtonEnabled = true;
                    }
                }

                if (result != null)
                {
                    IsSubmitButtonEnabled = false;
                }

                return result;
            }
        }

        private bool IsValidEmail()
        {
            if (EmailAddress == null)
            {
                return false;
            }

            return Regex.IsMatch(EmailAddress, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        }


        #endregion

    }
}
