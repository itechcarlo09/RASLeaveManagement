﻿using gocafe_cashier.Command;
using gocafe_cashier.Model;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using System.Windows.Input;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class OrderRejectReasonWindowViewModel : BaseModel
    {
        OrderRejectReasonWindow orderRejectReasonWindow;

        public OrderRejectReasonWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.OrderRejectReasonViewModel);
            InitializeUIFields();
        }
        
        private void InitializeUIFields()
        {
            IsProceedButtonEnabled = true;
            ReasonMessage = string.Empty;
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.OrderRejectReasonWindow:
                    orderRejectReasonWindow = (OrderRejectReasonWindow)data;
                    break;

                default:
                    break;
            }
        }

        #region UI Properties

        private bool isProceedButtonEnabled;
        public bool IsProceedButtonEnabled
        {
            get { return isProceedButtonEnabled; }
            set
            {
                isProceedButtonEnabled = value;
                RaisePropertyChanged(nameof(IsProceedButtonEnabled));
            }
        }

        private string reasonMessage;
        public string ReasonMessage
        {
            get { return reasonMessage; }
            set
            {
                reasonMessage = value;
                RaisePropertyChanged(nameof(ReasonMessage));
            }
        }

        #endregion


        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand ProceedCommand
        {
            get
            {
                return new DelegateCommand(ProceedButton);
            }
        }

        #endregion


        #region Method Helpers

        private void CloseWindow()
        {
            orderRejectReasonWindow.DialogResult = false;
            orderRejectReasonWindow.Close();
        }

        private void ProceedButton()
        {
            Mediator.Instance.NotifyViewModel(Messages.ReceivedOrdersViewModel, Messages.OrderRejectReasonMessage, reasonMessage);

            orderRejectReasonWindow.DialogResult = true;
            orderRejectReasonWindow.Close();
        }

        #endregion
    }
}
