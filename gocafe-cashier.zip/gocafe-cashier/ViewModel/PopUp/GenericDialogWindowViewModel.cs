﻿using gocafe_cashier.Command;
using gocafe_cashier.Model;
using gocafe_cashier.ViewModelMediator;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.TaskManager;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class GenericDialogWindowViewModel : BaseModel
    {
        #region PrivateProperties

        GenericDialogWindow genericConfirmationWindow;

        #endregion

        public GenericDialogWindowViewModel()
        {
            Initialization();
        }

        private void Initialization()
        {
            IsSuccess = false;
            SuccessMessage = string.Empty;
            IsWarning = false;
            WarningMessage = string.Empty;
            IsError = false;
            ErrorMessage = string.Empty;

           Mediator.Instance.Register(this, Messages.ConfirmationWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.ConfirmationWindow:
                    if (genericConfirmationWindow == null)
                    {
                        genericConfirmationWindow = (GenericDialogWindow)data;
                        IsWindowOpen = true;
                    }
                    break;

                case Messages.SuccessConfirmation:
                    if (!(IsSuccess || IsError || IsWarning))
                    {
                        IsSuccess = true;
                        SuccessMessage = data.ToString();
                    }
                    break;

                case Messages.ErrorConfirmation:
                    if (!(IsSuccess || IsError || IsWarning))
                    {
                        IsError = true;
                        ErrorMessage = data.ToString();
                    }
                    break;

                case Messages.WarningConfirmation:
                    if (!(IsSuccess || IsError || IsWarning))
                    {
                        IsWarning = true;
                        WarningMessage = data.ToString();
                    }
                    break;
                default:
                    break;
            }
        }


        #region Properties

        private bool isSuccess;
        public bool IsSuccess
        {
            get { return isSuccess; }
            set
            {
                isSuccess = value;
                RaisePropertyChanged(nameof(IsSuccess));
            }
        }

        private string successMessage;
        public string SuccessMessage
        {
            get { return successMessage; }
            set
            {
                successMessage = value;
                RaisePropertyChanged(nameof(SuccessMessage));
            }
        }

        private bool isWarning;
        public bool IsWarning
        {
            get { return isWarning; }
            set
            {
                isWarning = value;
                RaisePropertyChanged(nameof(IsWarning));
            }
        }

        private string warningMessage;
        public string WarningMessage
        {
            get { return warningMessage; }
            set
            {
                warningMessage = value;
                RaisePropertyChanged(nameof(WarningMessage));
            }
        }

        private bool isError;
        public bool IsError
        {
            get { return isError; }
            set
            {
                isError = value;
                RaisePropertyChanged(nameof(IsError));
            }
        }

        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
            set
            {
                errorMessage = value;
                RaisePropertyChanged(nameof(ErrorMessage));
            }
        }

        #endregion

        #region DelegateCommands

        public DelegateCommand OKCommand
        {
            get
            {
                return new DelegateCommand(OKCommandClicked);
            }
        }

        public DelegateCommand ProceedCommand
        {
            get
            {
                return new DelegateCommand(ProceedCommandClicked);
            }
        }

        public DelegateCommand CancelCommand
        {
            get
            {
                return new DelegateCommand(CancelCommandClicked);
            }
        }

        #endregion



        #region EventHandlers

        private void OKCommandClicked()
        {
            CloseWindow(true);
        }

        private void ProceedCommandClicked()
        {
            CloseWindow(true);
        }

        private void CancelCommandClicked()
        {
            CloseWindow(false);
        }

        private void CloseWindow(bool mode)
        {
            if (genericConfirmationWindow != null)
            {
                if (genericConfirmationWindow.IsLoaded == true && IsWindowOpen)
                {
                    genericConfirmationWindow.DialogResult = mode;
                }
                IsWindowOpen = false;
                Mediator.Instance.UnRegister(this, Messages.ConfirmationWindowViewModel);   
                genericConfirmationWindow.Close();
                Mediator.Instance.NotifyViewModel(Messages.LoginWindows, Messages.StopLoading, null);
            }
        }

        #endregion
    }
}
