﻿using gocafe_cashier.Command;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class VoidConfirmationWindowViewModel: BaseModel
    {
        public VoidConfirmationWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.VoidConfirmationWindowViewModel);
            VoidConfirmationText = StandardMessageResource.WarningVoidTransaction;
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.VoidConfirmationWindow:
                    voidConfirmationWindow = (VoidConfirmationWindow)data;
                    IsWindowOpen = true;
                    break;
                case Messages.TransactionModel:
                    if (data == null)
                    {
                        break;
                    }

                    TransactionHistoryModel temporaryBuffer = (TransactionHistoryModel)data;

                    Transaction = new TransactionHistoryModel{
                        Activity = temporaryBuffer.Activity,
                        Date = temporaryBuffer.Date,
                        Time = temporaryBuffer.Time,
                        CashierName = temporaryBuffer.CashierName,
                        CustomerName = temporaryBuffer.CustomerName,
                        Amount = CurrencySymbol + " " + temporaryBuffer.Amount
                    };
                    break;
                default:
                    break;
            }
        }


        #region Private Fields

        private VoidConfirmationWindow voidConfirmationWindow;

        #endregion


        #region Properties

        private string voidConfirmationText;
        public string VoidConfirmationText
        {
            get { return voidConfirmationText; }
            set
            {
                voidConfirmationText = value;
                RaisePropertyChanged(nameof(VoidConfirmationText));
            }
        }

        private TransactionHistoryModel transaction;

        public TransactionHistoryModel Transaction
        {
            get { return transaction; }
            set
            {
                transaction = value;
                RaisePropertyChanged(nameof(Transaction));
            }
        }

        #endregion


        #region Commands

        public DelegateCommand ProceedCommand
        {
            get
            {
                return new DelegateCommand(ProceedCommandClicked);
            }
        }

        public DelegateCommand CancelCommand
        {
            get
            {
                return new DelegateCommand(CancelCommandClicked);
            }
        }

        #endregion

        #region EventHandlers

        private void ProceedCommandClicked()
        {
            CloseWindow(true);
        }

        private void CancelCommandClicked()
        {
            CloseWindow(false);
        }

        private void CloseWindow(bool mode)
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    if (voidConfirmationWindow != null)
                    {
                        if (voidConfirmationWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            Mediator.Instance.UnRegister(this, Messages.SummaryWindowViewModel);
                            voidConfirmationWindow.DialogResult = mode;
                            voidConfirmationWindow.Close();
                        }
                    }
                }
            });
        }

        #endregion
    }
}
