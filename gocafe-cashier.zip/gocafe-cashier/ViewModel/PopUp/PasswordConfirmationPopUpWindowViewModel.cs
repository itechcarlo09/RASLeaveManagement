﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Model;
using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class PasswordConfirmationPopUpWindowViewModel : BaseModel
    {
        private bool isPasswordFirstLoad;

        public PasswordConfirmationPopUpWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.PasswordConfirmationWindowViewModel);
            InitializeUIFields();
        }

        private void InitializeUIFields()
        {
            IsProceedButtonEnabled = true;
            IsProcessShow = false;
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.PasswordConfirmationWindow:
                    passwordConfirmationWindow = (PasswordConfirmationPopUpWindow)data;
                    break;

                case Messages.Username:
                    memberUsername = data.ToString();
                    break;

                default:
                    break;
            }
        }

        #region Private fields

        PasswordConfirmationPopUpWindow passwordConfirmationWindow;
        string memberUsername;
        PasswordBox memberPassword;

        #endregion


        #region UI Properties

        private bool isProceedButtonEnabled;
        public bool IsProceedButtonEnabled
        {
            get { return isProceedButtonEnabled; }
            set
            {
                isProceedButtonEnabled = value;
                RaisePropertyChanged(nameof(IsProceedButtonEnabled));
            }
        }

        private bool isProcessShow;
        public bool IsProcessShow
        {
            get { return isProcessShow; }
            set
            {
                isProcessShow = value;
                RaisePropertyChanged(nameof(IsProcessShow));
            }
        }

        #endregion


        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand ProceedCommand
        {
            get
            {
                return new DelegateCommand<object>(ProceedAuthenticate);
            }
        }

        public ICommand PasswordBoxKeyUpCommand
        {
            get
            {
                return new DelegateCommand<object>(PasswordChanged);
            }
        }

        #endregion


        #region Event handlers

        private void CloseWindow()
        {
            passwordConfirmationWindow.DialogResult = false;
            passwordConfirmationWindow.Close();
        }

        private void PasswordChanged(object pBox)
        {
            PasswordBox passwordBox = (PasswordBox)pBox;

            if(passwordBox.Password != string.Empty)
            {
                passwordBox.ToolTip = null;
                IsProceedButtonEnabled = true;
            }
            else
            {
                passwordBox.ToolTip = StandardMessageResource.ErrorPasswordIsEmpty;
                IsProceedButtonEnabled = false;
            }
        }

        private void ProceedAuthenticate(object parameter)
        {
            try
            {
                if (IsProcessing)
                {
                    return;
                }

                IsProcessing = true;
                memberPassword = (PasswordBox)parameter;

                MemberServiceProvider memberService = new MemberServiceProvider();

                Task.Run(async () =>
                {
                    if(memberPassword.Password == "")
                    {
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            memberPassword.ToolTip = StandardMessageResource.ErrorPasswordIsEmpty;
                            IsProceedButtonEnabled = false;
                            IsProcessing = false;
                        });
                        
                        return;
                    }
                    else if (memberPassword.Password.Length < 4)
                    {
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            memberPassword.ToolTip = StandardMessageResource.ErrorPasswordLessThan4;
                            IsProceedButtonEnabled = false;
                            IsProcessing = false;
                        });
                    }

                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    ResponseModel response = null;
                    try
                    {
                        response = await TaskManagerModel<ResponseModel>.Instance.Run(memberService.MemberAuthentication(memberUsername, memberPassword.Password, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                response = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, passwordConfirmationWindow);
                        }
                    }

                    IsProcessing = false;

                    if (response != null)
                    {
                        if(response.HttpStatusCode == 200)
                        {
                            App.Current.Dispatcher.Invoke(() =>
                            {
                                passwordConfirmationWindow.DialogResult = true;
                                passwordConfirmationWindow.Close();
                            });
                        }                        
                    }
                });
            }
            catch (Exception)
            {

            }
        }

        #endregion
    }
}
