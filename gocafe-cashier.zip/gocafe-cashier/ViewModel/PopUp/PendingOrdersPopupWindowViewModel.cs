﻿using gocafe_cashier.Command;
using gocafe_cashier.Model;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using System;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class PendingOrdersPopupWindowViewModel : BaseModel
    {
        private PendingOrdersPopupWindow pendingOrderPopup;

        public PendingOrdersPopupWindowViewModel()
        {
            PendingOrders = "Pending Orders (0)";
            Mediator.Instance.Register(this, Messages.PendingOrdersWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.PendingOrdersCount:
                    PendingOrders = $"Pending Orders ({Convert.ToInt32(data)})";
                    break;

                case Messages.PendingOrdersWindow:
                    pendingOrderPopup = (PendingOrdersPopupWindow)data;
                    break;

                case Messages.OpenClosePendingOrdersWindow:
                    if ((bool)data)
                    {
                        ClosePopup();
                    }                    
                    break;

                default:
                    break;
            }
            
        }

        #region Properties

        private string pendingOrders;
        public string PendingOrders
        {
            get { return pendingOrders; }
            set
            {
                pendingOrders = value;
                RaisePropertyChanged(nameof(PendingOrders));
            }
        }

        #endregion


        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(ClosePopup);
            }
        }

        public DelegateCommand OpenReceivedOrdersWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenReceivedOrdersWindow);
            }
        }

        #endregion


        #region EventHandlers

        private void ClosePopup()
        {
            if (pendingOrderPopup != null)
            {
                Mediator.Instance.UnRegister(this, Messages.PendingOrdersWindowViewModel);
                pendingOrderPopup.Close();
            }
        }

        private void OpenReceivedOrdersWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenReceivedOrderWindow, null);
        }

        #endregion
    }
}
