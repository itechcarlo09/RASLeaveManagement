﻿using gocafe_cashier.Command;
using gocafe_cashier.Model;
using gocafe_cashier.Model.InventoryModels;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class InventoryPopUpWindowViewModel: BaseModel
    {
        public InventoryPopUpWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.InventoryPopUpWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.InventoryPopUpWindow:
                    inventoryPopUpWindow = (InventoryPopUpWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.SelectedItem:
                    ItemModel item = (ItemModel)data;
                    SelectedItem = new ItemModel { Product = item.Product, Adjustment = item.Adjustment, QuantityInStock = item.QuantityInStock, UnitCost = item.UnitCost};
                    break;

                case Messages.ChangeType:
                    ChangeType = (string)data;
                    break;

                default:
                    break;
            }
        }

        #region Private Fields

        InventoryPopUpWindow inventoryPopUpWindow;

        #endregion

        #region Properties

        private ItemModel selectedItem;

        public ItemModel SelectedItem
        {
            get { return selectedItem; }
            set
            {
                selectedItem = value;
                RaisePropertyChanged(nameof(SelectedItem));
            }
        }

        private string changeType;

        public string ChangeType
        {
            get { return changeType; }
            set
            {
                changeType = value;
                RaisePropertyChanged(nameof(ChangeType));
            }
        }

        #endregion

        #region Commands

        public DelegateCommand OKCommand
        {
            get
            {
                return new DelegateCommand(OKCommandClicked);
            }
        }

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }
        #endregion

        #region Event Handlers

        private void OKCommandClicked()
        {
            Mediator.Instance.NotifyViewModel(Messages.InventoryManagerWindowViewModel, Messages.SelectedItem, SelectedItem);
            CloseWindowImmediately();
        }

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.InventoryPopUpWindowViewModel);
                    if (inventoryPopUpWindow != null)
                    {
                        if (inventoryPopUpWindow.IsLoaded == true && IsWindowOpen)
                        {
                            inventoryPopUpWindow.DialogResult = false;
                            inventoryPopUpWindow.Close();
                        }
                    }
                }
            });
        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.InventoryPopUpWindowViewModel);
                if (inventoryPopUpWindow != null)
                {
                    if (inventoryPopUpWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        inventoryPopUpWindow.DialogResult = false;
                        inventoryPopUpWindow.Close();
                    }
                }
            });
        }

        #endregion
    }
}
