﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.Model;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.ViewModel.PopUp
{
    public class EShopPopUpWindowViewModel: BaseModel
    {
        public EShopPopUpWindowViewModel()
        { 
            Mediator.Instance.Register(this, Messages.EShopPopUpWindowViewModel);
            IsSubmitButtonEnabled = true;
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.EShopPopUpWindow:
                    eShopPopUpWindow = (EShopPopUpWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    break;

                case Messages.PurchasedItem:
                    purchasedItem = (EShopCodeListDataModel)data;
                    ItemName = purchasedItem.CodeTypeDscp;
                    Price = decimal.Parse(purchasedItem.Amount) / 100;
                    break;
                    
                default:
                    break;
            }
        }

        #region Private Fields

        EShopPopUpWindow eShopPopUpWindow;
        CashierDataModel cashierData;
        EShopCodeListDataModel purchasedItem;

        #endregion

        #region Properties

        private string itemName;

        public string ItemName
        {
            get { return itemName; }
            set
            {
                itemName = value;
                RaisePropertyChanged(nameof(ItemName));
            }
        }

        private decimal price;

        public decimal Price
        {
            get { return price; }
            set
            {
                price = value;
                RaisePropertyChanged(nameof(Price));

                Change = TenderedMoney - price;
            }
        }

        private decimal tenderedMoney;

        public decimal TenderedMoney
        {
            get { return tenderedMoney; }
            set
            {
                tenderedMoney = value;
                RaisePropertyChanged(nameof(TenderedMoney));

                Change = tenderedMoney - Price;
            }
        }

        private decimal change;

        public decimal Change
        {
            get { return change; }
            set
            {
                change = value;
                RaisePropertyChanged(nameof(Change));
            }
        }

        private bool isSubmitButtonEnabled;

        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

        #endregion

        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand PayCommand
        {
            get
            {
                return new DelegateCommand(PayWithCash);
            }
        }


        #endregion

        #region Event Handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.EShopPopUpWindowViewModel);
                    if (eShopPopUpWindow != null)
                    {
                        if (eShopPopUpWindow.IsLoaded == true)
                        {
                            eShopPopUpWindow.DialogResult = false;
                            eShopPopUpWindow.Close();
                        }
                    }
                }
            });
        }

        private void PayWithCash()
        {
            Mediator.Instance.NotifyViewModel(Messages.EShopWindowViewModel, Messages.ItemPayed, true);
            CloseWindowImmediately();
        }

        #endregion

        #region Private Methods
        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.EShopPopUpWindowViewModel);
                if (eShopPopUpWindow != null)
                {
                    if (eShopPopUpWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        eShopPopUpWindow.DialogResult = false;
                        eShopPopUpWindow.Close();
                    }
                }
            });
        }
        #endregion

    }
}
