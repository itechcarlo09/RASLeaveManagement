﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Windows.Input;

namespace gocafe_cashier.ViewModel.Member
{
    public class PreviousShiftSummaryWindowViewModel: BaseModel
    {
        #region Private Variables

        private PreviousShiftSummaryWindow previousShiftSummaryWindow;
        private CashierDataModel cashierInformation;

        #endregion


        public PreviousShiftSummaryWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.PreviousShiftSummaryWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.PreviousShiftSummaryWindow:
                    previousShiftSummaryWindow = (PreviousShiftSummaryWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.EndShiftData:
                    EndShiftModel = (EndShiftModel)data;
                    break;

                case Messages.CashierInfo:
                    cashierInformation = (CashierDataModel)data;
                    break;
            }
        }

        #region Properties

        private EndShiftModel endShiftModel;
        public EndShiftModel EndShiftModel
        {
            get { return endShiftModel; }
            set
            {
                endShiftModel = value;
                RaisePropertyChanged(nameof(EndShiftModel));
            }
        }

        #endregion

        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand SaveCommand
        {
            get
            {
                return new DelegateCommand(SaveReport);
            }
        }

        #endregion

        private void SaveReport()
        {
            try
            {
                PDF.Pdf pdfCreator = new PDF.Pdf();
                if(pdfCreator.CreatePdf(cashierInformation.Name, cashierInformation.Branch.Name, EndShiftModel))
                {
                    ShowConfirmationWindow(StandardMessageResource.SuccessReportGenerated, Messages.SuccessConfirmation, previousShiftSummaryWindow);
                }                
            }
            catch (Exception)
            {

            }
        }

        public void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.PreviousShiftSummaryWindowViewModel);
                    if (previousShiftSummaryWindow != null)
                    {
                        if (previousShiftSummaryWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            previousShiftSummaryWindow.DialogResult = false;
                            previousShiftSummaryWindow.Close();
                        }
                    }
                }
            });
        }
    }
}
