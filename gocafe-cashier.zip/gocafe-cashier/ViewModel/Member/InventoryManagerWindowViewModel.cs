﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Collections.ObjectModel;
using System.ComponentModel;
using gocafe_cashier.Manager;
using gocafe_cashier.MessageResource;
using System.Net;
using gocafe_cashier.Model.InventoryModels;
using gocafe_cashier.DataModel.Inventory;
using gocafe_cashier.View.PopUp;
using System.Windows;
using gocafe_cashier.Cache;
using GocafeShared.Model;
using System.Threading;
using gocafe_cashier.TaskManager;

namespace gocafe_cashier.ViewModel.Member
{
    public class InventoryManagerWindowViewModel: BaseModel
    {
        public InventoryManagerWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.InventoryManagerWindowViewModel);
            WindowTitle = StandardMessageResource.TransactWindowTitleInventory;
            Initialize();
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.InventoryManagerWindow:
                    inventoryManagerWindow = (InventoryManagerWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    break;

                case Messages.SelectedItem:
                    SelectedItem.Adjustment = ((ItemModel)data).Adjustment;
                    SelectedItem.UnitCost = ((ItemModel)data).UnitCost;
                    break;

                default:
                    break;
            }
        }

        #region Private Fields

        private CashierDataModel cashierData;
        private InventoryManagerWindow inventoryManagerWindow;
        private InventoryServiceProvider serviceProvider = new InventoryServiceProvider();
        private string reasonForAdjustment = string.Empty;
        private ObservableCollection<ItemModel> itemsToAdjust;
        Task asyncTask = new Task(async () => { });
        private ItemModel SelectedItem = new ItemModel();

        #endregion

        #region Properties

        private InventoryManagerModel inventoryManager;

        public InventoryManagerModel InventoryManager
        {
            get
            {
                FilterLists();
                return inventoryManager;
            }
            set
            {
                inventoryManager = value;
                RaisePropertyChanged(nameof(InventoryManager));
            }
        }

        private String selectedCategory;

        public String SelectedCategory
        {
            get
            {
                FilterLists();
                return selectedCategory;
            }
            set
            {
                selectedCategory = value;
                RaisePropertyChanged(nameof(SelectedCategory));
            }
        }

        private ObservableCollection<ItemModel> filteredItemList;

        public ObservableCollection<ItemModel> FilteredItemList
        {
            get { return filteredItemList; }
            set { filteredItemList = value; RaisePropertyChanged(nameof(FilteredItemList)); }
        }

        private String searchText;

        public String SearchText
        {
            get
            {
                FilterLists();
                return searchText;
            }
            set { searchText = value; RaisePropertyChanged(nameof(SearchText)); }
        }

        private String changeType;

        public String ChangeType
        {
            get { return changeType; }
            set { changeType = value; RaisePropertyChanged(nameof(ChangeType)); }
        }

        private bool isShowBlurBackground;

        public bool IsShowBlurBackground
        {
            get { return isShowBlurBackground; }
            set
            {
                isShowBlurBackground = value;
                RaisePropertyChanged(nameof(IsShowBlurBackground));
            }
        }

        private string windowTitle;
        public string WindowTitle
        {
            get { return windowTitle; }
            set
            {
                windowTitle = value;
                RaisePropertyChanged(nameof(WindowTitle));
            }
        }

        #endregion

        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand SearchItemCommand
        {
            get
            {
                return new DelegateCommand(SearchItem);
            }
        }

        public DelegateCommand SalesReportCommand
        {
            get
            {
                return new DelegateCommand(OpenSalesReportWindow);
            }
        }

        public DelegateCommand AdjustmentCommand
        {
            get
            {
                return new DelegateCommand(SetupWindowForAdjustment);
            }
        }

        public DelegateCommand PurchaseOrderCommand
        {
            get
            {
                return new DelegateCommand(SetupWindowForPurchaseOrder);
            }
        }

        public DelegateCommand InventoryCommand
        {
            get
            {
                return new DelegateCommand(CancelAdjustment);
            }
        }

        public DelegateCommand ProceedCommand
        {
            get
            {
                return new DelegateCommand(SendChangeRequest);
            }
        }

        public DelegateCommand CancelCommand
        {
            get
            {
                return new DelegateCommand(CancelAdjustment);
            }
        }

        public ICommand ItemSelectedCommand
        {
            get
            {
                return new DelegateCommand<object>(ShowInventoryPopUpWindow);
            }
        }


        #endregion

        #region Event Handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.InventoryManagerWindowViewModel);
                    if (inventoryManagerWindow != null)
                    {
                        if (inventoryManagerWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            inventoryManagerWindow.DialogResult = false;
                            inventoryManagerWindow.Close();
                        }
                    }
                }
            });
        }

        private void SearchItem()
        {
            if (searchText == string.Empty || searchText == null)
            {
                return;
            }
            FilteredItemList = SearchItemFromList(FilteredItemList, searchText);
        }

        private void FilterLists()
        {
            if (inventoryManager != null)
            {
                FilteredItemList = FilterByCategory(inventoryManager.Items, selectedCategory);
                SearchItem();
            }
        }

        private async void SendAdjustment()
        {
            if (IsProcessing)
            {
                return;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "SENDING ADJUSTMENT ORDER . . .";
            });

            string validationError;

            InventoryManager.ValidateAdjustmentOrder(InventoryManagerModel.ChangeType.AdjustmentOrder.ToString(), out validationError, out itemsToAdjust);
            if (validationError != string.Empty)
            {
                ShowConfirmationWindow(validationError, Messages.ErrorConfirmation, inventoryManagerWindow);
                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });
                return;
            }
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            
            AdjustmentDataModel adjustmentOrder = null;
            try
            {
                adjustmentOrder = await TaskManagerModel<AdjustmentDataModel>.Instance.Run(serviceProvider.SendAdjustment(itemsToAdjust, DataCacheContext.CashierSessionID, InventoryManager.AdjustmentReason, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        adjustmentOrder = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, inventoryManagerWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });

            if (adjustmentOrder != null)
            {
                ShowConfirmationWindow(StandardMessageResource.SuccessAdjustmentSent, Messages.SuccessConfirmation, inventoryManagerWindow);
                ChangeType = InventoryManagerModel.ChangeType.None.ToString();
                ClearAdjustments();
            }
        }

        private async void SendPurchaseOrder()
        {
            if (IsProcessing)
            {
                return;
            }

            string validationError;

            InventoryManager.ValidatePurchaseOrder(InventoryManagerModel.ChangeType.PurchaseOrder.ToString(), out validationError, out itemsToAdjust);

            if (validationError != string.Empty)
            {
                ShowConfirmationWindow(validationError, Messages.ErrorConfirmation, inventoryManagerWindow);
                return;
            }

            if (!ShowSummaryWindow())
            {
                return;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "SENDING PURCHASE ORDER . . .";
            });
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            
            PurchaseOrderDataModel purchaseOrder = null;
            try
            {
                purchaseOrder = await TaskManagerModel<PurchaseOrderDataModel>.Instance.Run(serviceProvider.SendPurchaseOrder(itemsToAdjust, DataCacheContext.CashierSessionID, InventoryManager.ReceiptNumber, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        purchaseOrder = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, inventoryManagerWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });

            if (purchaseOrder != null)
            {
                ShowConfirmationWindow(StandardMessageResource.SuccessPurchaseOrderSent, Messages.SuccessConfirmation, inventoryManagerWindow);
                ChangeType = InventoryManagerModel.ChangeType.None.ToString();
                ClearAdjustments();
            }
        }

        private void SendChangeRequest()
        {
            if (ChangeType == InventoryManagerModel.ChangeType.AdjustmentOrder.ToString())
            {
                SendAdjustment();
            }
            else if (ChangeType == InventoryManagerModel.ChangeType.PurchaseOrder.ToString())
            {
                SendPurchaseOrder();
            }
            
        }

        private async void SetupWindowForAdjustment()
        {
            WindowTitle = StandardMessageResource.TransactWindowTitleAdjustmentOrder;

            if (IsProcessing)
            {
                return;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "FETCHING INVENTORY LIST . . .";
            });

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            
            ObservableCollection<ItemDataModel> inventoryItems = null;
            try
            {
                inventoryItems = await TaskManagerModel<ObservableCollection<ItemDataModel>>.Instance.Run(serviceProvider.GetInventoryList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        inventoryItems = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, inventoryManagerWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });

            if (inventoryItems == null)
            {
                return;
            }
            else
            {
                ObservableCollection<ItemModel> temporaryItemList = new ObservableCollection<ItemModel>();
                foreach (ItemDataModel item in inventoryItems)
                {
                    temporaryItemList.Add(new ItemModel { Product = item.Product, QuantityInStock = item.QuantityInStock, ChangeType = InventoryManagerModel.ChangeType.AdjustmentOrder.ToString() });
                }
                InventoryManager.Items = temporaryItemList;
            }

            ChangeType = InventoryManagerModel.ChangeType.AdjustmentOrder.ToString();
            FilterLists();
            InventoryManager.ResetFirstLoadFields();
        }

        private async void SetupWindowForPurchaseOrder()
        {
            WindowTitle = StandardMessageResource.TransactWindowTitlePurchaseOrder;
            if (IsProcessing)
            {
                return;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "FETCHING INVENTORY LIST . . .";
            });

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            
            ObservableCollection<ItemDataModel> inventoryItems = null;
            try
            {
                inventoryItems = await TaskManagerModel<ObservableCollection<ItemDataModel>>.Instance.Run(serviceProvider.GetInventoryList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        inventoryItems = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, inventoryManagerWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });
            if (inventoryItems == null)
            {
                return;
            }
            else
            {
                ObservableCollection<ItemModel> temporaryItemList = new ObservableCollection<ItemModel>();
                foreach (ItemDataModel item in inventoryItems)
                {
                    temporaryItemList.Add(new ItemModel { Product = item.Product, QuantityInStock = item.QuantityInStock, ChangeType = InventoryManagerModel.ChangeType.PurchaseOrder.ToString() });
                }
                InventoryManager.Items = temporaryItemList;
            }

            ChangeType = InventoryManagerModel.ChangeType.PurchaseOrder.ToString();
            FilterLists();
            InventoryManager.ResetFirstLoadFields();
        }

        private void OpenSalesReportWindow()
        {

        }

        private void CancelAdjustment()
        {
            WindowTitle = StandardMessageResource.TransactWindowTitleInventory;
            ChangeType = InventoryManagerModel.ChangeType.None.ToString();
            ClearAdjustments();
            InventoryManager.ResetFirstLoadFields();
            FilterLists();
        }

        private async void ClearAdjustments()
        {
            if (IsProcessing)
            {
                return;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "FETCHING INVENTORY LIST . . .";
            });

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            
            ObservableCollection<ItemDataModel> inventoryItems = null;
            try
            {
                inventoryItems = await TaskManagerModel<ObservableCollection<ItemDataModel>>.Instance.Run(serviceProvider.GetInventoryList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        inventoryItems = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, inventoryManagerWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });
            if (inventoryItems == null)
            {
                return;
            }
            else
            {
                ObservableCollection<ItemModel> temporaryItemList = new ObservableCollection<ItemModel>();
                foreach (ItemDataModel item in inventoryItems)
                {
                    temporaryItemList.Add(new ItemModel { Product = item.Product, QuantityInStock = item.QuantityInStock });
                }
                InventoryManager.Items = temporaryItemList;
            }

            foreach (ItemModel item in InventoryManager.Items)
            {
                item.Adjustment = 0;
                item.UnitCost = 0;
            }
            InventoryManager.ResetFirstLoadFields();
            InventoryManager.AdjustmentReason = string.Empty;
            InventoryManager.ReceiptNumber = string.Empty;
            GetAdjustmentStatus();
        }

        private async void GetAdjustmentStatus()
        {
            foreach (ItemModel item in InventoryManager.Items)
            {
                item.AdjustmentStatus = "UP-TO-DATE";
            }

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
            });


            ObservableCollection<AdjustmentDataModel> adjustmentList = null;
            try
            {
                adjustmentList = await TaskManagerModel<ObservableCollection<AdjustmentDataModel>>.Instance.Run(serviceProvider.GetPendingAdjustmentList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        adjustmentList = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, inventoryManagerWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });


            if (adjustmentList == null)
            {
                CloseWindowImmediately();
                return;
            }
            else
            {
                foreach (AdjustmentDataModel adjustment in adjustmentList)
                {
                    if (adjustment.AdjustmentProducts != null)
                    {
                        foreach (AdjustmentProductDataModel product in adjustment.AdjustmentProducts)
                        {
                            foreach (ItemModel item in InventoryManager.Items)
                            {
                                if (item.Product.ProductID == product.ProductId)
                                {
                                    item.AdjustmentStatus = "PENDING";
                                }
                            }
                        }
                    }
                }
            }
        }

        private void ShowInventoryPopUpWindow(object parameter)
        {
            foreach (ItemModel item in FilteredItemList)
            {
                item.IsSelected = false;
            }

            SelectedItem = (ItemModel)parameter;
            SelectedItem.IsSelected = true;

            InventoryPopUpWindow inventoryPopUpWindow = new InventoryPopUpWindow();
            inventoryPopUpWindow.Owner = inventoryManagerWindow;
            Mediator.Instance.NotifyViewModel(Messages.InventoryPopUpWindowViewModel, Messages.InventoryPopUpWindow, inventoryPopUpWindow);
            Mediator.Instance.NotifyViewModel(Messages.InventoryPopUpWindowViewModel, Messages.SelectedItem, SelectedItem);
            Mediator.Instance.NotifyViewModel(Messages.InventoryPopUpWindowViewModel, Messages.ChangeType, ChangeType);

            IsShowBlurBackground = true;
            inventoryPopUpWindow.ShowDialog();
            IsShowBlurBackground = false;
        }

        #endregion

        #region Private Methods

        private ObservableCollection<ItemModel> FilterByCategory(ObservableCollection<ItemModel> itemList, string category)
        {
            if (category == "All Categories")
            {
                return itemList;
            }
            var filteredItemList = itemList.Where(item => item.Product.Category.Name == category);
            return new ObservableCollection<ItemModel>(filteredItemList);
        }

        private ObservableCollection<ItemModel> FilterByItemName(ObservableCollection<ItemModel> itemList, string itemName)
        {
            if (itemName == "All Items")
            {
                return itemList;
            }
            var filteredItemList = itemList.Where(item => item.Product.Name == itemName);
            return new ObservableCollection<ItemModel>(filteredItemList);
        }

        private ObservableCollection<ItemModel> FilterByItemCode(ObservableCollection<ItemModel> itemList, string itemCode)
        {
            if (itemCode == "All Items")
            {
                return itemList;
            }
            var filteredItemList = itemList.Where(item => item.Product.Retail.SKU == itemCode);
            return new ObservableCollection<ItemModel>(filteredItemList);
        }

        private ObservableCollection<ItemModel> SearchItemFromList(ObservableCollection<ItemModel> itemList, string searchText)
        {
            var filteredItemList = itemList.Where(
                item =>
                item.Product.Category.Name.ToUpper().Contains(searchText.ToUpper())
                || item.Product.Retail.SKU.ToUpper().Contains(searchText.ToUpper())
                || item.Product.Name.ToUpper().Contains(searchText.ToUpper())
                );

            var observableItemList = new ObservableCollection<ItemModel>(filteredItemList);

            return observableItemList;
        }

        private string GetReceiptSummary()
        {
            string receiptSummary = string.Empty;

            receiptSummary += $"Receipt Number: {InventoryManager.ReceiptNumber}";

            return receiptSummary;
        }

        private bool ShowSummaryWindow()
        {
            bool isSummaryWindowAlreadyOpen = false;
            bool? windowDialogResult = false;

            return App.Current.Dispatcher.Invoke(() =>
            {
                PurchaseOrderSummaryWindow genericWindow = new PurchaseOrderSummaryWindow();
                string genericSummaryWindowName = genericWindow.Title;
                genericWindow.Close();

                foreach (Window window in App.Current.Windows)
                {
                    if (window.Title == genericSummaryWindowName)
                    {
                        isSummaryWindowAlreadyOpen = true;
                    }
                }

                if (!isSummaryWindowAlreadyOpen)
                {
                    genericWindow = new PurchaseOrderSummaryWindow();
                    genericWindow.Owner = inventoryManagerWindow;
                    Mediator.Instance.NotifyViewModel(Messages.SummaryWindowViewModel, Messages.SummaryWindow, genericWindow);
                    Mediator.Instance.NotifyViewModel(Messages.SummaryWindowViewModel, Messages.SummaryTitle, Messages.PurchaseOrderSummaryTitle);
                    Mediator.Instance.NotifyViewModel(Messages.SummaryWindowViewModel, Messages.SummaryContent, itemsToAdjust);

                    Mediator.Instance.NotifyViewModel(Messages.SummaryWindowViewModel, Messages.OtherSummaryContent, GetReceiptSummary());

                    windowDialogResult = genericWindow.ShowDialog();
                }
                return windowDialogResult.Value;
            });
        }

        private async void Initialize()
        {
            try
            {
                InventoryManager = new InventoryManagerModel();
                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                
                ObservableCollection<ItemDataModel> inventoryItems = null;

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                });

                try
                {
                    inventoryItems = await TaskManagerModel<ObservableCollection<ItemDataModel>>.Instance.Run(serviceProvider.GetInventoryList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            inventoryItems = null;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, inventoryManagerWindow);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });


                if (inventoryItems == null)
                {
                    CloseWindowImmediately();
                    return;
                }
                else
                {
                    ObservableCollection<ItemModel> temporaryItemList = new ObservableCollection<ItemModel>();
                    foreach (ItemDataModel item in inventoryItems)
                    {
                        temporaryItemList.Add(new ItemModel { Product = item.Product, QuantityInStock = item.QuantityInStock });
                    }
                    InventoryManager.Items = temporaryItemList;
                }

                GetAdjustmentStatus();

                FilteredItemList = InventoryManager.Items;
                SelectedCategory = InventoryManager.CategoryList[0];
                SearchText = string.Empty;
                ChangeType = InventoryManagerModel.ChangeType.None.ToString();
                InventoryManager.ResetFirstLoadFields();
            }
            catch (Exception e)
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.InventoryManagerWindow);
            }
        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.InventoryManagerWindowViewModel);
                if (inventoryManagerWindow != null)
                {
                    if (inventoryManagerWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        inventoryManagerWindow.DialogResult = false;
                        inventoryManagerWindow.Close();
                    }
                }
            });
        }
        #endregion
    }
}
