﻿using gocafe_cashier.Card;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.MessageResource;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Net;
using System.Windows;
using gocafe_cashier.Cache;
using System.Threading.Tasks;
using GocafeShared.Model;
using System.Threading;
using gocafe_cashier.TaskManager;

namespace gocafe_cashier.ViewModel.Member
{
    public class ResetPasswordWindowViewModel : BaseModel
    {
        #region Private property

        private ResetPasswordWindow resetPasswordWindow;
        private CashierDataModel cashierData;

        #endregion


        public ResetPasswordWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.ResetPasswordViewModel);
            ResetPasswordModel = new ResetPasswordModel();
            IsCardDetected = false;
        }

        public override async void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.ResetPasswordWindow:
                    resetPasswordWindow = (ResetPasswordWindow)data;
                    IsWindowOpen = true;
                    break;
                case Messages.CashierInfo:
                    cashierData = data as CashierDataModel;
                    break;

                case Messages.CardID:
                    if (!IsCardDetected)
                    {
                        IsCardDetected = true;
                        ResetPasswordModel.IsCardDetected = true;
                        ResetPasswordModel.CardID = (string)data;
                    }
                    break;

                default:
                    break;
            }
        }

        #region Properties

        private ResetPasswordModel resetPasswordModel;
        public ResetPasswordModel ResetPasswordModel
        {
            get { return resetPasswordModel; }
            set
            {
                resetPasswordModel = value;
                RaisePropertyChanged(nameof(ResetPasswordModel));
            }
        }

        #endregion


        #region Commands

        public DelegateCommand SubmitCommand
        {
            get
            {
                return new DelegateCommand(SubmitRequest);
            }
        }

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        #endregion


        #region Event handlers

        private async void SubmitRequest()
        {
            MemberServiceProvider memberServiceProvider = new MemberServiceProvider();
            string message = string.Empty;
            string messageMode = string.Empty;

            try
            {
                if(ResetPasswordModel.IsSubmitButtonEnabled)
                {
                    if (IsProcessing)
                    {
                        return;
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                        ProcessingText = "PROCESSING REQUEST . . .";
                    });

                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    ResponseModel response = null;
                    try
                    {
                        response = await TaskManagerModel<ResponseModel>.Instance.Run(memberServiceProvider.ResetPassword(ResetPasswordModel.EmailAddress, ResetPasswordModel.MobileNumber, ResetPasswordModel.CardID, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                response = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, resetPasswordWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (response == null)
                    {
                        return;
                    }

                    if (response.HttpStatusCode == (int)HttpStatusCode.OK)
                    {
                        if (response.Result.Contains("BAD_REQUEST"))
                        {
                            message = StandardMessageResource.ErrorRessetPasswordBadRequest;
                            messageMode = Messages.ErrorConfirmation;
                            ShowConfirmationWindow(message, messageMode, resetPasswordWindow);
                        }
                        else if (response.Result.Contains("OK"))
                        {
                            message = StandardMessageResource.ErrorRessetPasswordContainsOK;
                            messageMode = Messages.SuccessConfirmation;
                            ShowConfirmationWindow(message, messageMode, resetPasswordWindow);
                            CloseWindowImmediately();
                        }
                    }
                }
            }
            catch(Exception)
            {
                message = string.Format(StandardMessageResource.ErrorConnectionIssue, StandardMessageResource.TransactWordConnect, StandardMessageResource.TransactWordServer);
                messageMode = Messages.ErrorConfirmation;
                ShowConfirmationWindow(message, messageMode, resetPasswordWindow);
                CloseWindowImmediately();
            }
        }

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.ResetPasswordViewModel);
                    if (resetPasswordWindow != null)
                    {
                        if (resetPasswordWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            resetPasswordWindow.DialogResult = false;
                            resetPasswordWindow.Close();
                        }
                    }
                }
            });
        }

        #endregion

        #region Private Methods
        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.ResetPasswordViewModel);
                if (resetPasswordWindow != null)
                {
                    if (resetPasswordWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        resetPasswordWindow.DialogResult = false;
                        resetPasswordWindow.Close();
                    }
                }
            });
        }
        #endregion

    }
}
