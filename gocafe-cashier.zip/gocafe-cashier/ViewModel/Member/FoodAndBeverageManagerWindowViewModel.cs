﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.Model.FnBModels;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using GocafeDatabaseDataAccess.Data.Repositories;
using GocafeDatabaseModel;
using GocafeDatabaseModel.Enum;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using GocafeShared.Utilities.StringFormat;
using gocafe_cashier.Manager;
using gocafe_cashier.ViewModel.Database;
using System.Collections.Specialized;
using GocafeShared.Model;
using gocafe_cashier.DbAccess;
using gocafe_cashier.Cache;
using System.Threading;
using gocafe_cashier.TaskManager;
using System.Data.SqlClient;

namespace gocafe_cashier.ViewModel.Member
{
    public class FoodAndBeverageManagerWindowViewModel : TransactionLogViewModelBase
    {
        #region Private Variables

        private FoodAndBeverageManagerWindow foodAndBeverageManagerWindow;
        private BranchInventoryServiceProvider branchInventoryServiceProvider = new BranchInventoryServiceProvider();
        private CashierDataModel cashierData;
        private SalesRequestDataModel salesOrder;
        private SalesDataModel salesOrderResponse = null;
        private PrintDocument receipt;

        #region Printer Variables
        private const int lineHeight = 11;
        private const int fontSize = 8;
        private const int margin = 3;
        private const int numberWidth = 7;
        private const int maxXPosition = 180;
        #endregion

        #endregion
        

        public FoodAndBeverageManagerWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.FoodAndBeverageManagerWindowViewModel);

            Initialize();
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.FoodAndBeverageManagerWindow:
                    foodAndBeverageManagerWindow = (FoodAndBeverageManagerWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    break;

                case Messages.FilterFoodAndBeverageList:
                    FilterLists();
                    break;

                case Messages.SearchFoodAndBeverage:
                    FilterLists();
                    break;

                default:
                    break;
            }
        }
        
        #region Properties

        private FnbManagerModel foodAndBeverageManager;

        public FnbManagerModel FoodAndBeverageManager
        {
            get { return foodAndBeverageManager; }
            set
            {
                foodAndBeverageManager = value;
                RaisePropertyChanged(nameof(FoodAndBeverageManager));

            }
        }

        #endregion


        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand PayWithCashCommand
        {
            get
            {
                return new DelegateCommand(PayWithCash);
            }
        }

        public ICommand AddToCartCommand
        {
            get
            {
                return new DelegateCommand<object>(AddToCart);
            }
        }

        public ICommand RemoveToCartCommand
        {
            get
            {
                return new DelegateCommand<object>(RemoveFromCart);
            }
        }

        #endregion


        #region Event Handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.FoodAndBeverageManagerWindowViewModel);
                    if (foodAndBeverageManagerWindow != null)
                    {
                        if (foodAndBeverageManagerWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            foodAndBeverageManagerWindow.DialogResult = false;
                            foodAndBeverageManagerWindow.Close();
                        }
                    }
                }
            });
        }

        private void AddToCart(object parameter)
        {
            BranchRetailModel productToAdd = (BranchRetailModel)parameter;
            ItemObservableCollection<SalesRetailModel> temporaryList = FoodAndBeverageManager.Orders;

            var duplicateItem = FoodAndBeverageManager.Orders.FirstOrDefault(x => x.RetailID == productToAdd.Retail.ID);

            if (duplicateItem != null)
            {
                duplicateItem.Quantity += 1;
                RaisePropertyChanged(nameof(temporaryList));
            }
            else
            {
                SalesRetailModel cartItem = new SalesRetailModel();
                cartItem.ProductName = productToAdd.Retail.RetailProduct.Name;
                cartItem.Quantity = 1;
                cartItem.Price = productToAdd.RetailPrice;
                cartItem.RetailID = productToAdd.Retail.ID;

                if (productToAdd != null)
                {
                    cartItem.IsRequirePreparation = productToAdd.IsPreparationRequired;
                }

                temporaryList.Add(cartItem);
            }

            FoodAndBeverageManager.Orders = temporaryList;
        }

        private void RemoveFromCart(object parameter)
        {
            FoodAndBeverageManager.Orders.Remove((SalesRetailModel)parameter);
        }

        private async void PayWithCash()
        {
            if(FoodAndBeverageManager.IsSubmitButtonEnabled)
            {
                try
                {
                    if (IsProcessing)
                    {
                        return;
                    }

                    string message = string.Empty;
                    string messageMode = string.Empty;
                    long total = 0;
                    bool isRequirePreparation = false;
                    salesOrder.CashierSessionID = DataCacheContext.CashierSessionID;
                    salesOrder.TransactionDateTime = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ");
                    salesOrder.SalesRetails = new List<SalesRetailRequestDataModel>();
                    foreach (SalesRetailModel order in FoodAndBeverageManager.Orders)
                    {
                        salesOrder.SalesRetails.Add(new SalesRetailRequestDataModel
                        {
                            Quantity = order.Quantity,
                            RetailID = order.RetailID,
                            RetailPrice = Convert.ToInt32((decimal)order.Price * 100)
                        });
                        total += Convert.ToInt64(order.Price * order.Quantity);

                        if (order.IsRequirePreparation)
                        {
                            isRequirePreparation = true;
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                        ProcessingText = "PROCESSING PAYMENT . . .";
                    });

                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    try
                    {
                        salesOrderResponse = await TaskManagerModel<SalesDataModel>
                                                        .Instance
                                                        .Run(branchInventoryServiceProvider.SendSalesOrder(salesOrder, cancellationTokenSource.Token),
                                                             cancellationTokenSource,
                                                             ToString(),
                                                             isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                salesOrderResponse = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, foodAndBeverageManagerWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (salesOrderResponse == null)
                    {
                        return;
                    }
                    else
                    {
                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.ReceivedPendingOrdersCount, null);
                        

                        ShowConfirmationWindow(isRequirePreparation ? StandardMessageResource.FnbAddToQueue : StandardMessageResource.SuccessFnbSale, Messages.SuccessConfirmation, foodAndBeverageManagerWindow);
                        
                        if (FoodAndBeverageManager.PrintIsChecked)
                        {
                            PrintReceipt();
                        }

                        ClearFields();

                        if (DataCacheContext.UseLocalDB)
                        {
                            DBTaskManager.Instance.LocalDatabaseTask.ContinueWith(a =>
                            {
                                SaveOrderToDatabase(total, isRequirePreparation);
                            });
                        }
                        else
                        {
                            Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, CreateTransactionModel(CreateTransactionLog(total, isRequirePreparation)));
                        }
                    }
                }
                catch (InvalidPrinterException ex)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorPrinter, Messages.ErrorConfirmation, foodAndBeverageManagerWindow);
                }
                catch (Exception ex)
                {
                    if (ex.Message == "The specified printer has been deleted")
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorPrinterNotDetected, Messages.ErrorConfirmation, foodAndBeverageManagerWindow);
                    }
                    else
                    {
                        ShowConfirmationWindow(string.Format(StandardMessageResource.ErrorConnectionIssue, "buy", "server"), Messages.ErrorConfirmation, foodAndBeverageManagerWindow);
                    }
                }
            }
        }

        private void ClearFields()
        {
            FoodAndBeverageManager.Orders.Clear();
            FoodAndBeverageManager.TotalFee = 0;
            FoodAndBeverageManager.TenderedMoney = 0;
        }

        private TransactionLog CreateTransactionLog(long total, bool isRequirePreparation)
        {
            TransactionLog transactionLog = new TransactionLog()
            {
                AccountCardNumber = "--",
                AccountName = cashierData.Name,
                CashierName = cashierData.Name,
                AvailedPromoPrice = 0,
                PaymentTypeId = 2,
                TransactionAmount = total.ConvertLongToMoney(),
                TransactionDate = DateTime.Now,
                TransactionType = (short)TransactionType.NewOrder,
                PcName = "Cashier",
                Remarks = isRequirePreparation ? "Pending order from cashier" : "Purchase complete",
                OrderReferenceNumber = salesOrderResponse.ReceiptNumber
            };

            return transactionLog;
        }

        private async Task SaveOrderToDatabase(long total, bool isRequirePreparation)
        {
            try
            {
                // Change this to: Reply to client no cashier currently logged in.
                TransactionLogRepository transactionRepo = new TransactionLogRepository(new GocafeDatabaseDataAccess.GoCafeDbContext());

                var transactionLog = CreateTransactionLog(total, isRequirePreparation);
                
                transactionRepo.Add(transactionLog);
                
                await transactionRepo.SaveAsync();
                
                App.Current.Dispatcher.Invoke(() =>
                {
                    Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, CreateTransactionModel(transactionLog));
                    ClearFields();
                });                
            }
            catch (Exception ex)
            {
                ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, foodAndBeverageManagerWindow);
            }
        }

        #endregion

        #region Private Methods

        private void FilterLists()
        {
            ObservableCollection<BranchRetailModel> temporaryList = new ObservableCollection<BranchRetailModel>();
            if (FoodAndBeverageManager.SelectedCategory == "All Categories")
            {
                FoodAndBeverageManager.FilteredProductList = FoodAndBeverageManager.ProductList;
            }
            else
            {
                foreach (BranchRetailModel product in FoodAndBeverageManager.ProductList)
                {
                    if (product.Retail.RetailProduct.Category.Name == FoodAndBeverageManager.SelectedCategory)
                    {
                        temporaryList.Add(product);
                    }
                }

                FoodAndBeverageManager.FilteredProductList = temporaryList;
            }
            Search();

        }

        private void Search()
        {
            ObservableCollection<BranchRetailModel> temporaryList = new ObservableCollection<BranchRetailModel>();

            if (FoodAndBeverageManager.SearchText == string.Empty || FoodAndBeverageManager.SearchText == null)
            {
                return;
            }

            foreach (BranchRetailModel product in FoodAndBeverageManager.FilteredProductList)
            {
                if (product.Retail.RetailProduct.Category.Name.ToLower().Contains(FoodAndBeverageManager.SearchText.ToLower())
                    || product.Retail.RetailProduct.Name.ToLower().Contains(FoodAndBeverageManager.SearchText.ToLower()))
                {
                    temporaryList.Add(product);
                }
            }
            FoodAndBeverageManager.FilteredProductList = temporaryList;
        }

        private void InitializeCategoryList()
        {
            List<string> categories = new List<string>();
            categories.Add("All Categories");
            foreach(BranchRetailModel product in FoodAndBeverageManager.ProductList)
            {
                categories.Add(product.Retail.RetailProduct.Category.Name);
            }
            FoodAndBeverageManager.CategoryList = categories.Distinct().ToList();
        }

        private async void Initialize()
        {
            try
            {
                FoodAndBeverageManager = new FnbManagerModel();
                FoodAndBeverageManager.ProductList = new ObservableCollection<BranchRetailModel>();

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                    ProcessingText = "FETCHING LIST OF PRODUCTS . . .";
                });

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                
                List<BranchRetailDataModel> branchRetailList = null;
                try
                {
                    branchRetailList = await TaskManagerModel<List<BranchRetailDataModel>>.Instance.Run(branchInventoryServiceProvider.GetBranchInventoryList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            branchRetailList = null;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, foodAndBeverageManagerWindow);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });

                if (branchRetailList != null)
                {
                    foreach (BranchRetailDataModel item in branchRetailList)
                    {
                        int stockQuantity = 0;
                        if (item.Retail.Product != null)
                        {
                            stockQuantity = item.Retail.Product.StockQuantity;
                        }
                        else if (item.Retail.CompositeProduct != null)
                        {
                            if (item.Retail.CompositeProduct.CompositeProductComponents != null)
                            {
                                int tempStockQuantity = int.MaxValue;
                                foreach (CompositeProductComponentDataModel compositeProductComponent in item.Retail.CompositeProduct.CompositeProductComponents)
                                {
                                    if ((compositeProductComponent.StockQuantity / compositeProductComponent.Quantity) < tempStockQuantity)
                                    {
                                        tempStockQuantity = (compositeProductComponent.StockQuantity / compositeProductComponent.Quantity);
                                    }
                                }
                                stockQuantity = tempStockQuantity;
                            }
                        }

                        string productCategory = string.Empty;
                        string productName = string.Empty;

                        if (item.Retail.Product != null)
                        {
                            productCategory = item.Retail.Product.Category.Name;
                            productName = item.Retail.Product.Name;
                        }
                        else if (item.Retail.CompositeProduct != null)
                        {
                            productCategory = item.Retail.CompositeProduct.Category.Name;
                            productName = item.Retail.CompositeProduct.Name;
                        }

                        FoodAndBeverageManager.ProductList.Add(
                            new BranchRetailModel
                            {
                                ID = item.ID,
                                LastUpdate = item.LastUpdate,
                                Retail = new RetailModel
                                {
                                    CompositeProduct = item.Retail.CompositeProduct,
                                    ID = item.Retail.ID,
                                    Product = item.Retail.Product,
                                    SKU = item.Retail.SKU,
                                },
                                RetailPrice = item.RetailPrice,
                                IsPreparationRequired = item.IsPreparationRequired,
                                StockQuantity = stockQuantity,
                                Category = productCategory,
                                Name = productName
                            });

                        if (FoodAndBeverageManager.ProductList.Last().Retail.CompositeProduct != null)
                        {
                            FoodAndBeverageManager.ProductList.Last().Retail.CompositeProduct.ProductPicture = FoodAndBeverageManager.ProductList.Last().Retail.CompositeProduct.CompositeProductPicture;
                        }
                    }

                    FoodAndBeverageManager.ProductList = new ObservableCollection<BranchRetailModel>(
                        FoodAndBeverageManager.ProductList.OrderBy(product => product.Retail.RetailProduct.Category.Name).
                        ThenBy(product => product.Retail.RetailProduct.Name).ToList());

                    FoodAndBeverageManager.FilteredProductList = FoodAndBeverageManager.ProductList;
                    InitializeCategoryList();
                    FoodAndBeverageManager.SelectedCategory = FoodAndBeverageManager.CategoryList[0];
                    FoodAndBeverageManager.TotalFee = 0;
                    FoodAndBeverageManager.Orders = new ItemObservableCollection<SalesRetailModel>();
                    salesOrder = new SalesRequestDataModel();
                    salesOrderResponse = new SalesDataModel();
                    receipt = new PrintDocument();
                    receipt.PrintPage += PrintReceiptMessage;
                    FoodAndBeverageManager.PrintIsChecked = true;
                    FoodAndBeverageManager.Orders.CollectionChanged += OrdersCollectionChanged; ;
                    FoodAndBeverageManager.Orders.ItemPropertyChanged += OrdersItemPropertyChanged;
                }
                else
                {
                    CloseWindowImmediately();
                }
            }
            catch(Exception ex)
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.FoodAndBeverageManagerWindow);
            }
        }

        private void OrdersItemPropertyChanged(object sender, ItemPropertyChangedEventArgs<SalesRetailModel> e)
        {
            FoodAndBeverageManager.TotalFee = 0;
            foreach(SalesRetailModel order in FoodAndBeverageManager.Orders)
            {
                FoodAndBeverageManager.TotalFee += order.Quantity * order.Price;

                if (order.Quantity < 0)
                {
                    FoodAndBeverageManager.IsSubmitButtonEnabled = false;
                }
            }
            if (FoodAndBeverageManager.TotalFee <= 0)
            {
                FoodAndBeverageManager.IsSubmitButtonEnabled = false;
            }
        }

        private void OrdersCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            FoodAndBeverageManager.TotalFee = 0;
            foreach (SalesRetailModel order in FoodAndBeverageManager.Orders)
            {
                FoodAndBeverageManager.TotalFee += order.Quantity * order.Price;

                if (order.Quantity < 0)
                {
                    FoodAndBeverageManager.IsSubmitButtonEnabled = false;
                }
            }
            if (FoodAndBeverageManager.TotalFee <= 0)
            {
                FoodAndBeverageManager.IsSubmitButtonEnabled = false;
            }
        }

        private string GenerateRandomReceipt()
        {
            Random rndNumber = new Random();
            return rndNumber.Next(10000000, 99999999).ToString();
        }

        private void PrintReceipt()
        {
            System.Windows.Forms.PrintDialog printDialog = new System.Windows.Forms.PrintDialog();
            printDialog.Document = receipt;
            printDialog.UseEXDialog = true;

            printDialog.PrinterSettings.PrinterName = DataCacheContext.PrinterName;
            receipt.DocumentName = "PrintReceipt";

            try
            {
                receipt.Print();
            }
            catch (InvalidPrinterException ex)
            {
                ShowConfirmationWindow(StandardMessageResource.ErrorPrinter, Messages.ErrorConfirmation, foodAndBeverageManagerWindow);
            }

        }

        private void PrintReceiptMessage(object sender, PrintPageEventArgs e)
        {
            int yAxis = 0;

            yAxis = PrintNewLine(3, yAxis, e);
            yAxis = PrintExcessCharacterOnNewLine(e, string.Empty, cashierData.Branch.Name, true, 35, 0, 0, yAxis, 0, lineHeight, FontStyle.Bold);
            yAxis = PrintNewLine(3, yAxis, e);
            yAxis = PrintWithRegularFont($"ORDER #: {salesOrderResponse.ReceiptNumber}", 7, margin, yAxis, e);
            yAxis = PrintWithRegularFont($"CASHIER: {cashierData.Name}", 7, margin, yAxis, e);
            yAxis = PrintWithRegularFont($"DATE: {DateTime.Now.ToShortDateString()} {DateTime.Now.ToLongTimeString()}", 7, margin, yAxis, e);
            yAxis = PrintNewLine(2, yAxis, e);
            yAxis = PrintWithBoldFont("ITEM", 7, margin, yAxis, e);
            yAxis = PrintWithBoldFont("PRICE", 7, maxXPosition - 30, yAxis - lineHeight, e);
            yAxis = PrintNewLine(1, yAxis, e);
            foreach (SalesRetailModel order in FoodAndBeverageManager.Orders)
            {
                yAxis = PrintWithRegularFont($"{order.Quantity} x {order.ProductName}", 7, margin, yAxis, e);
                PrintPrice($"{MoneyFormatter.ConvertIntToMoney((order.Total * 100).ToString())}", yAxis, e);
            }
            PrintLongLine(yAxis, e);
            yAxis = PrintNewLine(1, yAxis, e);
            yAxis = PrintWithBoldFont("TOTAL", 7, margin, yAxis, e);
            PrintPrice($"{MoneyFormatter.ConvertIntToMoney((FoodAndBeverageManager.Orders.Sum(x => x.Total) * 100).ToString())}", yAxis, e);
            yAxis = PrintNewLine(2, yAxis, e);
        }

        private int PrintWithRegularFont(string message, int fontSize, int xPosition, int yPosition, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(message, new Font("Arial Narrow", fontSize, FontStyle.Regular), new SolidBrush(Color.Black), xPosition, yPosition);
            return yPosition + lineHeight;
        }

        private int PrintWithBoldFont(string message, int fontSize, int xPosition, int yPosition, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(message, new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), xPosition, yPosition);
            return yPosition + lineHeight;
        }

        private int PrintNewLine(int numberOfLines, int yPosition, PrintPageEventArgs e)
        {
            for (int x = 0; x < numberOfLines; x++, yPosition += lineHeight)
                e.Graphics.DrawString("", new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), 0, yPosition);

            return yPosition;
        }

        private void PrintPrice(string message, int yPosition, PrintPageEventArgs e)
        {
            int padding = 0;
            for (int x = 0; x < message.Length; x++)
            {
                if (message[message.Length - x - 1].ToString() == ".")
                {
                    padding += 2;
                }
                if (message[message.Length - x - 1].ToString() == "1")
                {
                    padding += 1;
                }
                e.Graphics.DrawString(message[message.Length - x - 1].ToString()
                    , new Font("Arial Narrow", 7, FontStyle.Regular)
                    , new SolidBrush(Color.Black)
                    , maxXPosition - x * numberWidth+padding - 10
                    , yPosition - lineHeight);
            }
        }

        private void PrintBoldPrice(string message, int yPosition, PrintPageEventArgs e)
        {
            int padding = 0;
            for (int x = 0; x < message.Length; x++)
            {
                if (message[message.Length - x - 1].ToString() == ".")
                {
                    padding += 2;
                }
                if (message[message.Length - x - 1].ToString() == "1")
                {
                    padding += 1;
                }
                e.Graphics.DrawString(message[message.Length - x - 1].ToString()
                    , new Font("Arial Narrow", fontSize, FontStyle.Bold)
                    , new SolidBrush(Color.Black)
                    , maxXPosition - x * numberWidth + padding - 10
                    , yPosition - lineHeight);
            }
        }

        private int PrintLongLine(int yPosition, PrintPageEventArgs e)
        {
            for (int x = 0; x < maxXPosition; x+=5)
            {
                e.Graphics.DrawString("-", new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), x, yPosition);
            }

            return yPosition + lineHeight;
        }

        private TransactionModel CreateTransactionModel(TransactionLog transaction)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = transaction.TransactionDate.ToString("hh:mm tt"),
                TransactionType = StandardMessageResource.TransactNewOrder,
                CustomerName = transaction.AccountName,
                CustomerID = transaction.Id.ToString(),
                TransactionAmount = $"{CurrencySymbol}{(Convert.ToDouble(transaction.TransactionAmount) / 100).ToString("N2")}",
                TransactionRemarks = transaction.Remarks,
                CashierName = transaction.CashierName,
            };
            return transactionModel;
        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.FoodAndBeverageManagerWindowViewModel);
                if (foodAndBeverageManagerWindow != null)
                {
                    if (foodAndBeverageManagerWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        foodAndBeverageManagerWindow.DialogResult = false;
                        foodAndBeverageManagerWindow.Close();
                    }
                }
            });
        }
        #endregion
    }
}
