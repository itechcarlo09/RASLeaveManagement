﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.Model;
using gocafe_cashier.Network;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Definition;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;

namespace gocafe_cashier.ViewModel.Member
{
    public class PCTransferWindowViewModel : BaseModel
    {
        #region Private fields

        PCTransferWindow pcTransferWindow;
        WorkstationModel selectedWorkstation;

        private const string ERROR = "ERROR";
        private const string SUCCESS = "SUCCESS";

        #endregion

        public PCTransferWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.PCTransferWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch(message)
            {
                case Messages.StationList:
                    AvailableWorkStationList = (List<WorkstationModel>)data;
                    break;

                case Messages.PCTransferWindow:
                    pcTransferWindow = (PCTransferWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.SelectedWorkstationToTransfer:
                    selectedWorkstation = (WorkstationModel)data;
                    break;

                case Messages.ClientTransferToken:
                    OnTransferDetailReceived((string)data);
                    break;

                case Messages.ClientTransferStatusDetail:
                    OnTransferDetailStatusReceived((string)data);
                    break;

                default:
                    break;
            }
        }

        #region Methods



        #endregion


        #region ICommands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand WindowClosingCommand
        {
            get
            {
                return new DelegateCommand(WindowClosing);
            }
        }

        public ICommand TransferPCCommand
        {
            get
            {
                return new DelegateCommand(TransferPC);
            }
        }

        #endregion


        #region Event handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.PCTransferWindowViewModel);
                    if (pcTransferWindow != null)
                    {
                        if (pcTransferWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            pcTransferWindow.DialogResult = false;
                            pcTransferWindow.Close();
                        }
                    }
                }
            });
        }

        private void WindowClosing()
        {
            Mediator.Instance.UnRegister(this, Messages.PCTransferWindowViewModel);
        }

        private void TransferPC()
        {
            if(SelectedPC != null && SelectedPC != string.Empty)
            {
                var pool = DataCacheContext.WorkstationModels.Values.ToList();
                if (pool.Count > 0)
                {
                    string warningMessage = string.Empty;

                    bool isPCExists = pool.Any(pc => pc.PCID == SelectedPC);

                    if (isPCExists)
                    {
                        IsProcessing = true;
                        NetworkServer.Instance.SendMessageToClientUsingIP(selectedWorkstation.StationModel.StaticIPAddress, NetworkMessageType.LogoutTransfer, null);
                    }
                }
            }
        }

        private void OnTransferDetailReceived(string serverTransferToken)
        {
            var pool = DataCacheContext.WorkstationModels.Values.ToList();

            if (pool.Count > 0)
            {
                string warningMessage = string.Empty;

                bool isPCExists = pool.Any(pc => pc.PCID == SelectedPC);

                if (isPCExists)
                {
                    var pcToTransfer = pool.FirstOrDefault(pc => pc.PCID == SelectedPC);
                    NetworkServer.Instance.SendMessageToClientUsingStationID(pcToTransfer.PCID, NetworkMessageType.ServerTransferToken, serverTransferToken);
                }
            }
        }

        private void OnTransferDetailStatusReceived(string transferStatus)
        {
            if(transferStatus == ERROR)
            {
                ShowConfirmationWindow("An error has occured. Please let the customer login to the designated pc manually.", Messages.ErrorConfirmation, pcTransferWindow);
                CloseWindow();
            }
            else
            {
                App.Current.Dispatcher.Invoke(() =>
                {
                    ShowConfirmationWindow("Successfully transfered the customer to designated pc.", Messages.SuccessConfirmation, pcTransferWindow);
                    CloseWindow();
                });
            }
        }

        #endregion


        #region UI Properties

        private List<WorkstationModel> availableWorkStationList;
        public List<WorkstationModel> AvailableWorkStationList
        {
            get { return availableWorkStationList; }
            set
            {
                availableWorkStationList = value;
                RaisePropertyChanged(nameof(AvailableWorkStationList));
            }
        }

        private string selectedPC;
        public string SelectedPC
        {
            get { return selectedPC; }
            set
            {
                selectedPC = value;
                RaisePropertyChanged(nameof(SelectedPC));
            }
        }

        #endregion
    }
}
