﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Mapper;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.Security;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModel.Database;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Model;
using GocafeShared.Utilities.StringFormat;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ViewModel.Member
{
    public class TopUpManagerWindowViewModel : TransactionLogViewModelBase
    {
        #region Fields

        private string TopUp = StandardMessageResource.TransactTopUp;
        private TopUpManagerWindow topUpManagerWindow;
        private CashierDataModel cashierData;
        private List<PromoDataModel> memberPromoList;
        private List<PromoDataModel> guestPromoList;
        private AccountPromoModel selectedPromo;
        private WorkstationModel workStationData = null;
        private MemberServiceProvider memberService;
        private PrintDocument printDocument;

        private const string member = "MEMBER";
        private const string guest = "GUEST";
        private bool isWindowFirstLoad = true;

        #region Printer Variables
        private const int lineHeight = 11;
        private const int fontSize = 8;
        private const int margin = 3;
        private const int numberWidth = 7;
        private const int maxXPosition = 180;
        #endregion

        #endregion

        public TopUpManagerWindowViewModel()
        {
            memberService = new MemberServiceProvider();
            Mediator.Instance.Register(this, Messages.TopUpManagerViewModel);
            TopUpManagerModel = new TopUpManagerModel();

            TopUpManagerModel.IsShownLoading = true;

            App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
            });

            IsCardDetected = false;
            TopUpManagerModel.IsPCAssigned = false;

            printDocument = new PrintDocument();
            printDocument.PrintPage += PrintTopUp;
        }

        public override async void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.TopUpManagerWindow:
                    topUpManagerWindow = (TopUpManagerWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    Initialize();
                    break;

                case Messages.TopUpByUser:
                    workStationData = (WorkstationModel)data;
                    TopUpManagerModel.SelectedWorkStation = workStationData;
                    if (workStationData.AccountModel.CardNumber != null)
                    {
                        TopUpManagerModel.CardIDNumber = workStationData.AccountModel.CardNumber;
                        TopUpManagerModel.IsTopUpByUser = true;
                        CardIDLostFocus();
                    }
                    else
                    {
                        GuestTypeClicked();
                        TopUpManagerModel.IsTopUpByGuest = true;
                        TopUpManagerModel.IsMember = false;
                        TopUpManagerModel.GuestUsername = workStationData.AccountModel.Username;
                    }
                    break;
                case Messages.StationList:
                    TopUpManagerModel.WorkStationList = (List<WorkstationModel>)data;
                    break;

                case Messages.GuestAccount:
                    IsCardDetected = false;
                    break;

                case Messages.MemberData:
                    if (!IsCardDetected)
                    {
                        UserDataModel userData = (UserDataModel)data;
                        TopUpManagerModel.CardIDNumber = userData.MemberData.CardNumber;
                        IsCardDetected = true;

                        if (userData.MemberData != null)
                        {
                            TopUpManagerModel.Username = userData.MemberData.CustomerAccount.Username;
                            TopUpManagerModel.LastName = userData.MemberData.LastName;
                            TopUpManagerModel.FirstName = userData.MemberData.FirstName;
                            TopUpManagerModel.IsUserFound = true;
                        }
                        else
                        {
                            TopUpManagerModel.Username = string.Empty;
                            TopUpManagerModel.LastName = string.Empty;
                            TopUpManagerModel.FirstName = string.Empty;
                            TopUpManagerModel.IsUserFound = false;
                        }
                    }
                    break;

                case Messages.PCAssigned:
                    TopUpManagerModel.IsPCAssigned = true;
                    break;

                default:
                    break;
            }
        }

        #region Properties

        private TopUpManagerModel topUpManagerModel;
        public TopUpManagerModel TopUpManagerModel
        {
            get { return topUpManagerModel; }
            set
            {
                topUpManagerModel = value;
                RaisePropertyChanged(nameof(TopUpManagerModel));
            }
        }

        private List<MemberTypesDataModel> memberTypeList;
        public List<MemberTypesDataModel> MemberTypeList
        {
            get { return memberTypeList; }
            set
            {
                memberTypeList = value;
                RaisePropertyChanged(nameof(MemberTypeList));
            }
        }

        private string selectedMemberType;
        public string SelectedMemberType
        {
            get { return selectedMemberType; }
            set
            {
                selectedMemberType = value;
                RaisePropertyChanged(nameof(SelectedMemberType));
            }
        }


        #endregion

        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand<object> SelectPromoRow
        {
            get
            {
                return new DelegateCommand<object>(SelectedPromo);
            }
        }

        public DelegateCommand GuestTypeCommand
        {
            get
            {
                return new DelegateCommand(GuestTypeClicked);
            }
        }

        public DelegateCommand MemberTypeCommand
        {
            get
            {
                return new DelegateCommand(MemberTypeClicked);
            }
        }

        public DelegateCommand PayCommand
        {
            get
            {
                return new DelegateCommand(PayCommandClicked);
            }
        }

        public DelegateCommand CardIDLostFocusCommand
        {
            get
            {
                return new DelegateCommand(CardIDLostFocus);
            }
        }

        public DelegateCommand TopUpLostFocusCommand
        {
            get
            {
                return new DelegateCommand(TopUpLostFocus);
            }
        }

        public DelegateCommand LostFocusCommand
        {
            get
            {
                return new DelegateCommand(TopUpManagerModel.LostFocus);
            }
        }

        public DelegateCommand MemberTypeChangedCommand
        {
            get
            {
                return new DelegateCommand(LoadPromoByMemberType);
            }
        }

        #endregion

        #region Event Handlers

        private void ReInitializeFields()
        {
            TopUpManagerModel.ResetFirstLoadFields();
            TopUpManagerModel.CardIDNumber = string.Empty;
            TopUpManagerModel.Username = string.Empty;
            TopUpManagerModel.FirstName = string.Empty;
            TopUpManagerModel.LastName = string.Empty;
            TopUpManagerModel.BranchCreated = string.Empty;
            TopUpManagerModel.DateCreated = null;
            TopUpManagerModel.GuestUsername = string.Empty;
            selectedPromo = null;
            TopUpManagerModel.TotalFee = 0;
            TopUpManagerModel.SelectedPromoPrice = 0;
            TopUpManagerModel.HasSelectedPromo = false;
            TopUpManagerModel.TenderedMoney = 0;
            TopUpManagerModel.ValidatorTenderedMoney = "0.00";
            TopUpManagerModel.ValidatorTopUpFee = "0.00";
            TopUpManagerModel.ChangeFee = 0;
        }

        private void TopUpLostFocus()
        {
            double doubleTopup = double.Parse(TopUpManagerModel.ValidatorTopUpFee, CultureInfo.InvariantCulture);
            if (doubleTopup > 10000)
            {
                TopUpManagerModel.ValidatorTopUpFee = "10000";
            }
            else
            {
                decimal topup = Convert.ToDecimal(doubleTopup);
                topup = Math.Truncate(topup * 100) / 100;
                TopUpManagerModel.ValidatorTopUpFee = topup.ToString();
            }
        }

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.TopUpManagerViewModel);
                    if (topUpManagerWindow != null)
                    {
                        if (topUpManagerWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            topUpManagerWindow.DialogResult = false;
                            topUpManagerWindow.Close();
                        }
                    }
                }
            });
        }

        private void SelectedPromo(object parameter)
        {
            for (int x = 0; x < TopUpManagerModel.AccountPromo.Count; x++)
            {
                TopUpManagerModel.AccountPromo[x].IsSelected = false;
            }

            selectedPromo = (AccountPromoModel)parameter;
            if (selectedPromo.StartTime != "-- NONE --")
            {
                selectedPromo.IsSelected = true;

                if (selectedPromo.PackageID == TopUpManagerModel.SelectedPromoID)
                {
                    selectedPromo.IsSelected = false;
                    TopUpManagerModel.HasSelectedPromo = false;
                    TopUpManagerModel.SelectedPromoDescription = string.Empty;
                    TopUpManagerModel.SelectedPromoPrice = 0;
                    TopUpManagerModel.SelectedPromoID = string.Empty;
                }
                else
                {
                    TopUpManagerModel.HasSelectedPromo = true;
                    TopUpManagerModel.SelectedPromoDescription = selectedPromo.PackageDescription;
                    TopUpManagerModel.SelectedPromoPrice = Convert.ToDecimal(selectedPromo.Amount);
                    TopUpManagerModel.SelectedPromoID = selectedPromo.PackageID;
                }

                TopUpManagerModel.ComputeTotalFee();
                TopUpManagerModel.ComputeChange();
                TopUpManagerModel.ValidatorTopUpFee = TopUpManagerModel.ValidatorTopUpFee;
            }
        }

        private void GuestTypeClicked()
        {
            LoadGuestPromo();
            ReInitializeFields();
        }

        private void MemberTypeClicked()
        {
            LoadMemberPromo();
            ReInitializeFields();
        }

        private async void CardIDLostFocus()
        {
            string message = string.Empty;
            string messageMode = string.Empty;

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
            });

            try
            {
                UserDataModel userData = new UserDataModel();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                userData = null;
                try
                {
                    userData = await TaskManagerModel<UserDataModel>.Instance.Run(memberService.GetMemberInfo(TopUpManagerModel.CardIDNumber, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            userData = null;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, topUpManagerWindow);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });

                if (userData == null)
                {
                    userData = new UserDataModel();
                }
                else
                {
                    if (userData.MemberData != null)
                    {
                        TopUpManagerModel.Username = userData.MemberData.CustomerAccount.Username;
                        TopUpManagerModel.LastName = userData.MemberData.LastName;
                        TopUpManagerModel.FirstName = userData.MemberData.FirstName;
                        TopUpManagerModel.IsUserFound = true;
                    }
                    else
                    {
                        TopUpManagerModel.Username = string.Empty;
                        TopUpManagerModel.LastName = string.Empty;
                        TopUpManagerModel.FirstName = string.Empty;
                        TopUpManagerModel.IsUserFound = false;
                    }
                }
            }
            catch (Exception)
            {
                ShowServerCommunicationIssueError();
            }
        }

        private async Task GetMemberTypes()
        {
            try
            {
                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                });

                List<MemberTypesDataModel> temporaryHolder = MemberTypeList;
                try
                {
                    MemberTypeList = await TaskManagerModel<List<MemberTypesDataModel>>.Instance.Run(memberService.GetMemberTypes(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                    MemberTypeList = MemberTypeList.OrderByDescending(x => x.Rank).ToList();
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            MemberTypeList = temporaryHolder;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, topUpManagerWindow);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });

                if (MemberTypeList == null)
                {
                    CloseWindowImmediately();
                }
                else
                {
                    try
                    {
                        foreach (MemberTypesDataModel memberType in MemberTypeList)
                        {
                            if (memberType.Name.ToUpper() == workStationData.AccountModel.UserType.ToUpper())
                            {
                                SelectedMemberType = memberType.Name;
                            }
                        }

                    }
                    catch
                    {
                        SelectedMemberType = MemberTypeList[0].Name;
                    }

                }
            }
            catch
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.TopUpManagerWindow);
            }
        }

        private async Task LoadAllPromo()
        {
            try
            {
                int allStationType = -1;

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                });

                ExceptionDispatchInfo capturedException = null;

                try
                {
                    if (TopUpManagerModel.IsMember)
                    {
                        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                        memberPromoList = null;
                        try
                        {
                            if (DataCacheContext.CashierSessionID != null && MemberTypeList != null)
                            {
                                if (TopUpManagerModel.IsPCAssigned)
                                {
                                    memberPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                                    GetMemberId(SelectedMemberType), Int16.Parse(TopUpManagerModel.SelectedWorkStation.StationModel.StationType.ID), false, PromoTimeZone.Manila, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                                }
                                else
                                {
                                    memberPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                                    GetMemberId(SelectedMemberType), allStationType, false, PromoTimeZone.Manila, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                                }
                            }
                        }
                        catch (AggregateException aggregateException)
                        {
                            bool wasTaskCanceled = false;
                            foreach (var exception in aggregateException.InnerExceptions)
                            {
                                if (exception is TaskCanceledException)
                                {
                                    memberPromoList = null;
                                    wasTaskCanceled = true;
                                    break;
                                }
                            }

                            if (!wasTaskCanceled)
                            {
                                ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, topUpManagerWindow);
                            }
                        }

                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = false;
                        });

                        if (memberPromoList != null)
                        {
                            memberPromoList.ForEach(promo => promo.Price = promo.Price / 100);
                            LoadMemberPromo();
                        }
                        else
                        {
                            App.Current.Dispatcher.Invoke(() =>
                            {
                                CloseWindowImmediately();
                            });
                        }
                    }
                    else
                    {

                        CancellationTokenSource guestCancellationTokenSource = new CancellationTokenSource();

                        guestPromoList = null;
                        try
                        {
                            if (DataCacheContext.CashierSessionID != null && MemberTypeList != null)
                            {
                                if (TopUpManagerModel.IsPCAssigned)
                                {
                                    guestPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                                    GetMemberId(SelectedMemberType), Int16.Parse(TopUpManagerModel.SelectedWorkStation.StationModel.StationType.ID), true, PromoTimeZone.Manila, guestCancellationTokenSource.Token), guestCancellationTokenSource, ToString());
                                }
                                else
                                {
                                    guestPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                                    GetMemberId(SelectedMemberType), allStationType, true, PromoTimeZone.Manila, guestCancellationTokenSource.Token), guestCancellationTokenSource, ToString());
                                    if (guestPromoList == null)
                                    {

                                    }
                                }
                            }
                        }
                        catch (AggregateException aggregateException)
                        {
                            bool wasTaskCanceled = false;
                            foreach (var exception in aggregateException.InnerExceptions)
                            {
                                if (exception is TaskCanceledException)
                                {
                                    guestPromoList = null;
                                    wasTaskCanceled = true;
                                    break;
                                }
                            }

                            if (!wasTaskCanceled)
                            {
                                ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, topUpManagerWindow);
                            }
                        }

                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = false;
                        });

                        if (guestPromoList != null)
                        {
                            guestPromoList.ForEach(promo => promo.Price = promo.Price / 100);
                            LoadGuestPromo();
                        }
                        else
                        {
                            App.Current.Dispatcher.Invoke(() =>
                            {
                                CloseWindowImmediately();
                            });
                        }
                    }
                    TopUpManagerModel.IsShownLoading = false;
                }
                catch (Exception ex)
                {
                    // Store exception at a ExceptionDispatchInfo when
                    // error happens at the awaiting asynchronous operation.
                    ExceptionDispatchInfo.Capture(ex);
                    ShowServerCommunicationIssueError(StandardMessageResource.TransactLoadPromo, true);
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.TopUpManagerWindow);
                }


                if (capturedException != null)
                {
                    // This can be used also for logging into a text file or any log file.
#if DEBUG
                    // Temporarily log at the Output panel when debugging.
                    System.Diagnostics.Debug
                    .WriteLine($"TopUpManagerWindowViewModel.LoadAllPromo: {capturedException.SourceException.Message}");
#endif
                }
            }
            catch (Exception)
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.TopUpManagerWindow);
            }


        }

        private async void LoadPromoByMemberType()
        {
            try
            {
                if (isWindowFirstLoad || !TopUpManagerModel.IsMember)
                {
                    return;
                }

                int allStationType = -1;

                TopUpManagerModel.IsShownLoading = true;

                ExceptionDispatchInfo capturedException = null;

                try
                {
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    memberPromoList = null;
                    try
                    {
                        if (DataCacheContext.CashierSessionID != null && MemberTypeList != null)
                        {
                            memberPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                            GetMemberId(SelectedMemberType), allStationType, false, PromoTimeZone.Manila, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                        }
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                memberPromoList = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, topUpManagerWindow);
                        }
                    }

                    if (memberPromoList != null)
                    {
                        memberPromoList.ForEach(promo => promo.Price = promo.Price / 100);
                        LoadMemberPromo();
                    }

                    TopUpManagerModel.IsShownLoading = false;
                }
                catch (Exception ex)
                {
                    // Store exception at a ExceptionDispatchInfo when
                    // error happens at the awaiting asynchronous operation.
                    ExceptionDispatchInfo.Capture(ex);
                    ShowServerCommunicationIssueError(StandardMessageResource.TransactLoadPromo, true);
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.TopUpManagerWindow);
                }


                if (capturedException != null)
                {
                    // This can be used also for logging into a text file or any log file.
#if DEBUG
                    // Temporarily log at the Output panel when debugging.
                    System.Diagnostics.Debug
                    .WriteLine($"TopUpManagerWindowViewModel.LoadPromoByMemberType: {capturedException.SourceException.Message}");
#endif
                }
            }
            catch (Exception)
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.TopUpManagerWindow);
            }
        }

        private async void LoadMemberPromo()
        {

            if (memberPromoList == null)
            {
                await Task.Run(async () =>
                {
                    await GetMemberTypes();
                    await LoadAllPromo();
                });
            }

            App.Current.Dispatcher.Invoke(() =>
            {
                TopUpManagerModel.IsShownLoading = false;

                TopUpManagerModel.AccountPromo = new ObservableCollection<AccountPromoModel>();
                foreach (PromoDataModel promo in memberPromoList)
                {
                    DateTime sTime = DateTime.ParseExact(promo.StartTime, "HH:mm:ss", CultureInfo.InvariantCulture);
                    DateTime eTime = DateTime.ParseExact(promo.EndTime, "HH:mm:ss", CultureInfo.InvariantCulture);

                    string promoDuration = string.Empty;
                    if (promo.Duration == 0)
                    {
                        promoDuration = "0m";
                    }
                    else if ((promo.Duration < 60 && promo.Duration > 0) || (promo.Duration > -60 && promo.Duration < 0))
                    {
                        promoDuration = (promo.Duration / 60.0).ToString("N1") + "m";
                    }
                    else
                    {
                        promoDuration = TimeSpan.FromSeconds(promo.Duration).ToString(@"dd\:hh\:mm").ConvertDateTimeToStringWithoutSec();
                    }

                    TopUpManagerModel.IsPromoEmpty = false;
                    TopUpManagerModel.AccountPromo.Add(new AccountPromoModel()
                    {
                        PackageCode = promo.Code,
                        PackageID = promo.ID,
                        PackageDescription = promo.Description,
                        Amount = promo.Price,
                        EndTime = eTime.ToString("hh:mm tt"),
                        StartTime = sTime.ToString("hh:mm tt"),
                        PromoAvailability = $"{sTime.ToString("hh:mm tt")} - {eTime.ToString("hh:mm tt")}",
                        IsSelected = false,
                        PackageType = promo.PromoType,
                        Duration = promoDuration
                    });
                }
            });

            CheckPromoData();
        }

        private async void LoadGuestPromo()
        {

            if (guestPromoList == null)
            {
                await Task.Run(async () =>
                {
                    await GetMemberTypes();
                    await LoadAllPromo();
                });
            }

            App.Current.Dispatcher.Invoke(() =>
            {
                TopUpManagerModel.AccountPromo = new ObservableCollection<AccountPromoModel>();

                foreach (PromoDataModel promo in guestPromoList)
                {
                    DateTime sTime = DateTime.ParseExact(promo.StartTime, "HH:mm:ss", CultureInfo.InvariantCulture);
                    DateTime eTime = DateTime.ParseExact(promo.EndTime, "HH:mm:ss", CultureInfo.InvariantCulture);

                    string promoDuration = string.Empty;

                    if (promo.Duration == 0)
                    {
                        promoDuration = "0m";
                    }
                    else if ((promo.Duration < 60 && promo.Duration > 0) || (promo.Duration > -60 && promo.Duration < 0))
                    {
                        promoDuration = (promo.Duration / 60.0).ToString("N1") + "m";
                    }
                    else
                    {
                        promoDuration = TimeSpan.FromSeconds(promo.Duration).ToString(@"dd\:hh\:mm").ConvertDateTimeToStringWithoutSec();
                    }

                    TopUpManagerModel.IsPromoEmpty = false;
                    TopUpManagerModel.AccountPromo.Add(new AccountPromoModel()
                    {
                        PackageCode = promo.Code,
                        PackageID = promo.ID,
                        PackageDescription = promo.Description,
                        Amount = promo.Price,
                        EndTime = eTime.ToString("hh:mm tt"),
                        StartTime = sTime.ToString("hh:mm tt"),
                        PromoAvailability = $"{sTime.ToString("hh:mm tt")} - {eTime.ToString("hh:mm tt")}",
                        IsSelected = false,
                        PackageType = promo.PromoType,
                        Duration = promoDuration
                    });
                }
            });

            CheckPromoData();
        }

        private void CheckPromoData()
        {
            if (TopUpManagerModel.AccountPromo == null || TopUpManagerModel.AccountPromo.Count <= 0)
            {
                TopUpManagerModel.IsPromoEmpty = true;
                TopUpManagerModel.AccountPromo = new ObservableCollection<AccountPromoModel>()
                {
                    new AccountPromoModel()
                    {
                        StartTime = "-- NONE --"
                    }
                };
            }
        }

        private int GetMemberId(string memberName)
        {
            int memberId = 0;

            foreach (MemberTypesDataModel memberType in MemberTypeList)
            {
                if (memberType.Name == memberName)
                {
                    return memberType.ID;
                }
            }

            return memberId;
        }

        private string GetTotalTime(string startTime, string endTime)
        {
            TimeSpan totalTime = new TimeSpan();
            DateTime start = DateTime.Parse(startTime);
            DateTime end = DateTime.Parse(endTime);
            totalTime = end - start;

            return ($"{totalTime.Hours}:{totalTime.Minutes}");
        }

        private void PayCommandClicked()
        {
            if (IsProcessing)
            {
                return;
            }

            if (!ValidateMember())
            {
                TopUpMember();
            }
        }

        private async void TopUpMember()
        {
            try
            {
                string message = string.Empty;
                string messageMode = string.Empty;
                string responseMessage = string.Empty;
                string username = string.Empty;
                string customerType = string.Empty;

                if (TopUpManagerModel.IsSubmitButtonEnabled)
                {
                    if (TopUpManagerModel.IsMember)
                    {
                        username = TopUpManagerModel.Username;
                        customerType = member;
                    }
                    else
                    {
                        username = TopUpManagerModel.GuestUsername;
                        customerType = guest;
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                    });

                    CashierServiceProvider cashierServiceProvider = new CashierServiceProvider();
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    Tuple<TopUpDataModel, ResponseModel> topUpData = null;
                    try
                    {
                        if (cashierData.AccessKey == null)
                        {
                            var cashierKey = await TaskManagerModel<CashierKeyTokenDataModel>.Instance.Run(cashierServiceProvider.GenerateCashierKeyToken(
                                                        DataCacheContext.CashierSessionID,
                                                        cashierData.AccessToken,
                                                        cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);

                            if (cashierKey != null)
                            {
                                if (cashierKey.AccessToken != null)
                                {
                                    cashierData.AccessToken = cashierKey.AccessToken;
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessToken, cashierKey.AccessToken);
                                }

                                if (cashierKey.Key != null)
                                {
                                    cashierData.AccessKey = cashierKey.Key;
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, cashierKey.Key);
                                }
                            }
                            else
                            {
                                cashierKey = await TaskManagerModel<CashierKeyTokenDataModel>.Instance.Run(cashierServiceProvider.RetrieveCashierKeyToken(
                                                        DataCacheContext.CashierSessionID,
                                                        cashierData.AccessToken,
                                                        cashierData.AccessKey,
                                                        cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);

                                if (cashierKey == null)
                                {
                                    ShowConfirmationWindow(StandardMessageResource.ErrorSystemCalibrationRequired, Messages.ErrorConfirmation, topUpManagerWindow);
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.SwitchToLoginView, null);
                                }

                                if (cashierKey.AccessToken != null)
                                {
                                    cashierData.AccessToken = cashierKey.AccessToken;
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessToken, cashierKey.AccessToken);
                                }

                                if (cashierKey.Key != null)
                                {
                                    cashierData.AccessKey = cashierKey.Key;
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, cashierKey.Key);
                                }
                            }
                        }

                        string signatureKey = HmacHash.HashHMACHex(cashierData.AccessKey, $"{username}{GetTransactionAmount()}{DataCacheContext.CashierSessionID}{PaymentType.Cash}{GetSelectedPromoId()}");

                        cancellationTokenSource = new CancellationTokenSource();
                        topUpData = await TaskManagerModel<Tuple<TopUpDataModel, ResponseModel>>.Instance.Run(memberService.MemberTopUp(
                            customerType,
                            username,
                            GetTransactionAmount(),
                            DataCacheContext.CashierSessionID,
                            PaymentType.Cash,
                            GetSelectedPromoId(),
                            signatureKey,
                            cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                topUpData = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, topUpManagerWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (topUpData != null && topUpData.Item2.HttpStatusCode == 422)
                    {
                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, null);
                    }

                    if (topUpData != null && topUpData.Item2.HttpStatusCode != 422)
                    {
                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, null);

                        string topUpUsername = string.Empty;

                        if (TopUpManagerModel.IsMember)
                        {
                            topUpUsername = TopUpManagerModel.Username;
                        }
                        else
                        {
                            topUpUsername = TopUpManagerModel.GuestUsername;
                        }


                        Tuple<string, string, string> transactionParameter = new Tuple<string, string, string>("TOPUP", topUpData.Item1.Balance.ToString().ConvertIntToMoney(), topUpUsername);
                        Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.InformAgentTransaction, transactionParameter);

                        message = StandardMessageResource.SuccessTopUp;
                        messageMode = Messages.SuccessConfirmation;

                        TransactionModel transactionModel = CreateTransactionModel(topUpData.Item1.ID, GetTransactionRemarks(), $"{username}");

                        Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, transactionModel);

                        ShowConfirmationWindow(message, messageMode, topUpManagerWindow);

                        if (TopUpManagerModel.IsPrintChecked)
                        {
                            PrintNotification();
                        }
                    }

                    if (messageMode == Messages.SuccessConfirmation)
                    {
                        CloseWindowImmediately();
                    }
                }

            }
            catch (Exception ex)
            {
                ShowServerCommunicationIssueError();
            }
        }

        private bool ValidatePCAvailability(string stationID)
        {
            if (DataCacheContext.WorkstationModels.Count == 0)
            {
                return false;
            }

            var connectedClients = DataCacheContext.WorkstationModels.Values.ToList().Where(pc => pc.PCID == stationID);

            if (connectedClients.Count() == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void ShowServerCommunicationIssueError()
        {
            string message = string.Format(StandardMessageResource.ErrorConnectionIssue, StandardMessageResource.TransactWordConnect, StandardMessageResource.TransactWordServer);
            string messageMode = Messages.ErrorConfirmation;
            App.Current.Dispatcher.Invoke(() =>
            {
                ShowConfirmationWindow(message, messageMode, topUpManagerWindow);
                CloseWindowImmediately();
            });
        }

        private void ShowServerCommunicationIssueError(string errorMessage, bool isFromAsync)
        {
            string message = string.Format(StandardMessageResource.ErrorConnectionIssue, errorMessage, StandardMessageResource.TransactWordServer);
            string messageMode = Messages.ErrorConfirmation;

            if (isFromAsync)
            {
                App.Current.Dispatcher.Invoke(() =>
                {
                    ShowConfirmationWindow(message, messageMode, topUpManagerWindow);
                });
            }

            ShowConfirmationWindow(message, messageMode, topUpManagerWindow);
        }

        private string GetTransactionRemarks()
        {
            string topupRemarks = string.Empty;

            if (TopUpManagerModel.IsMember)
            {
                topupRemarks += "MEMBER - ";
            }
            else
            {
                topupRemarks += "GUEST - ";
            }

            if (TopUpManagerModel.TopUpFee != 0)
            {
                topupRemarks += $"Top-up: ₱{TopUpManagerModel.TopUpFee} ";
            }

            if (selectedPromo != null && selectedPromo.IsSelected)
            {
                topupRemarks += $"Promo: {selectedPromo.PackageCode} ";
            }

            return topupRemarks;
        }

        private TransactionModel CreateTransactionModel(string id, string remarks, string name = null)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = TopUp,
                CustomerName = name,
                CustomerID = id,
                TransactionAmount = $"{CurrencySymbol}{(Convert.ToDouble(GetTransactionAmount()) / 100).ToString("N2")}",
                TransactionRemarks = remarks
            };
            return transactionModel;
        }

        private string GenerateRandomNumber()
        {
            Random rndNumber = new Random();
            return rndNumber.Next(0, 99999999).ToString();
        }

        private bool ValidateMember()
        {
            bool hasError = false;

            if (TopUpManagerModel.IsMember && (TopUpManagerModel.Username == null || TopUpManagerModel.Username == string.Empty))
            {
                hasError = true;
                TopUpManagerModel.Username = string.Empty;
            }
            else if (!TopUpManagerModel.IsMember && (TopUpManagerModel.GuestUsername == null || TopUpManagerModel.GuestUsername == string.Empty))
            {
                hasError = true;
                TopUpManagerModel.GuestUsername = string.Empty;
            }

            return hasError;
        }

        private int GetTransactionAmount()
        {
            return (int)(TopUpManagerModel.TotalFee * 100);
        }

        private string GetSelectedPromoId()
        {
            if (selectedPromo != null && selectedPromo.IsSelected)
            {
                return selectedPromo.PackageID;
            }
            else
            {
                return string.Empty;
            }
        }

        private async void Initialize()
        {
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            try
            {
                await TaskManagerModel<List<UserDataModel>>.Instance.Run(
                    InitializeAsync(cancellationTokenSource.Token),
                    cancellationTokenSource,
                    ToString()
                );
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, topUpManagerWindow);
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });
            }
        }

        #endregion

        #region Private methods

        private void SaveTransactionToLocalDB(TransactionModel transactionModel)
        {

            if (TransactionRepository != null)
            {
                // Maps to entity and then save the changes (persist) at local DB.
                TransactionRepository.Add(TransactionLogMapper.Map(transactionModel, cashierData, selectedPromo,
                    PaymentType.Cash, TopUpManagerModel, GetTransactionAmount()));
                TransactionRepository.SaveAsync();
            }

        }

        private void PrintNotification()
        {
            try
            {
                System.Windows.Forms.PrintDialog printDialog = new System.Windows.Forms.PrintDialog();
                printDialog.Document = printDocument;
                printDialog.UseEXDialog = true;
                printDialog.PrinterSettings.PrinterName = DataCacheContext.PrinterName;
                printDocument.DocumentName = "PrintTopUp";
                printDocument.Print();
            }
            catch (Exception)
            {
                string message = StandardMessageResource.ErrorPrinter;
                string messageMode = Messages.ErrorConfirmation;
                ShowConfirmationWindow(message, messageMode, topUpManagerWindow);
            }
        }

        private void PrintTopUp(object sender, PrintPageEventArgs e)
        {
            int yAxis = 0;
            string username = string.Empty;
            if (TopUpManagerModel.IsMember)
            {
                username = TopUpManagerModel.Username;
            }
            else
            {
                username = TopUpManagerModel.GuestUsername;
            }

            yAxis = PrintNewLine(3, yAxis, e);
            yAxis = PrintExcessCharacterOnNewLine(e, string.Empty, cashierData.Branch.Name, true, 35, 0, 0, yAxis, 0, lineHeight, FontStyle.Bold);
            yAxis = PrintNewLine(3, yAxis, e);
            yAxis = PrintWithRegularFont($"CASHIER: {cashierData.Name}", 7, margin, yAxis, e);
            yAxis = PrintWithRegularFont($"CUSTOMER: {username}", 7, margin, yAxis, e);

            if (TopUpManagerModel.TopUpFee > 0)
            {
                yAxis = PrintWithRegularFont($"Top Up: ₱{TopUpManagerModel.ValidatorTopUpFee} ", 7, margin, yAxis, e);
            }
            if (TopUpManagerModel.HasSelectedPromo)
            {
                yAxis = PrintWithRegularFont($"PROMO AVAILED:", 7, margin, yAxis, e);
                yAxis = PrintWithRegularFont($"{TopUpManagerModel.SelectedPromoDescription}", 7, margin, yAxis, e);
            }
            yAxis = PrintWithRegularFont($"DATE: {DateTime.Now.ToShortDateString()} {DateTime.Now.ToLongTimeString()}", 7, margin, yAxis, e);
            yAxis = PrintNewLine(3, yAxis, e);
        }

        private int PrintWithRegularFont(string message, int fontSize, int xPosition, int yPosition, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(message, new Font("Arial Narrow", fontSize, FontStyle.Regular), new SolidBrush(Color.Black), xPosition, yPosition);
            return yPosition + lineHeight;
        }

        private int PrintNewLine(int numberOfLines, int yPosition, PrintPageEventArgs e)
        {
            for (int x = 0; x < numberOfLines; x++, yPosition += lineHeight)
                e.Graphics.DrawString("", new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), 0, yPosition);

            return yPosition;
        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.TopUpManagerViewModel);
                if (topUpManagerWindow != null)
                {
                    if (topUpManagerWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        topUpManagerWindow.DialogResult = false;
                        topUpManagerWindow.Close();
                    }
                }
            });
        }

        private async Task InitializeAsync(CancellationToken cancellationToken)
        {
            try
            {
                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                });

                cancellationToken.ThrowIfCancellationRequested();
                await GetMemberTypes();

                cancellationToken.ThrowIfCancellationRequested();
                await LoadAllPromo();

                isWindowFirstLoad = false;
                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });
            }
            catch (Exception e)
            {

            }
        }

        #endregion
    }
}
