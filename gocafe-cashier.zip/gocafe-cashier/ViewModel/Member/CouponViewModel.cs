﻿using gocafe_cashier.Model;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Windows.Input;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using gocafe_agent.Model;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Mapper;
using GocafeShared.Model;
using System.Drawing.Printing;
using System.Drawing;
using GocafeShared.Utilities.StringFormat;
using gocafe_cashier.Manager;
using System.Globalization;
using gocafe_cashier.ViewModel.Database;
using gocafe_cashier.Cache;
using System.Threading.Tasks;
using gocafe_cashier.TaskManager;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using gocafe_cashier.Definition;

namespace gocafe_cashier.ViewModel.Member
{
    public class CouponViewModel : TransactionLogViewModelBase, IDataErrorInfo
    {
        #region Private Fields

        private string NewCouponAccount = StandardMessageResource.TransactNewCouponAccount;
        private Window couponManagerWindow;
        private DatePicker selectExpiry;
        private System.Windows.Controls.ComboBox cbHour;
        private System.Windows.Controls.ComboBox cbMinute;
        private CashierServiceProvider cashierService;
        private MemberServiceProvider memberService;
        private CashierDataModel userData = new CashierDataModel();
        private DateTime now = DateTime.Now;
        private TimeSpan timeDuration;
        private PrintDocument guestOrMemberDocument;
        private string userName;
        private string password;

        #endregion

        public CouponViewModel()
        {
            Mediator.Instance.Register(this, Messages.CouponManagerViewModel);
            ExpiryDate = DateTime.Now;
            cashierService = new CashierServiceProvider();
            memberService = new MemberServiceProvider();
            StationTypeList = new List<StationTypeDataModel>();
            CouponStationTypeList = new ObservableCollection<CouponStationTypeModel>();
            HourList = new List<int>();
            MinuteList = new List<int>();
            GuestMemberReceiptModel = new GuestMemberReceiptModel();
            guestOrMemberDocument = new PrintDocument();
            guestOrMemberDocument.PrintPage += GuestOrMemberDocument_PrintPage;

            Initialization();
            InitializeStationTypes();

        }
        
        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }   

        public ICommand CreateCommand
        {
            get
            {
                return new DelegateCommand<object[]>(CreateButton);
            }
        }

        #endregion

        #region Properties

        private List<StationTypeDataModel> stationTypeList;
        public List<StationTypeDataModel> StationTypeList
        {
            get { return stationTypeList; }
            set
            {
                stationTypeList = value;
                RaisePropertyChanged(nameof(StationTypeList));
            }
        }

        private ObservableCollection<CouponStationTypeModel> couponStationTypeList;
        public ObservableCollection<CouponStationTypeModel> CouponStationTypeList
        {
            get { return couponStationTypeList; }
            set
            {
                couponStationTypeList = value;
                RaisePropertyChanged(nameof(CouponStationTypeList));
            }
        }

        private List<int> stationTypeIDList;
        public List<int> StationTypeIDList
        {
            get { return stationTypeIDList; }
            set
            {
                stationTypeIDList = value;
                RaisePropertyChanged(nameof(StationTypeIDList));
            }
        }

        private List<int> hourList;
        public List<int> HourList
        {
            get { return hourList; }
            set
            {
                hourList = value;
                RaisePropertyChanged(nameof(HourList));
            }
        }

        private List<int> minuteList;
        public List<int> MinuteList
        {
            get { return minuteList; }
            set
            {
                minuteList = value;
                RaisePropertyChanged(nameof(MinuteList));
            }
        }

        private List<string> stationTypeNames;
        public List<string> StationTypeNames
        {
            get { return stationTypeNames; }
            set
            {
                stationTypeNames = value;
                RaisePropertyChanged(nameof(StationTypeNames));
            }
        }

        private StationTypeDataModel stationTypeDataModel;
        public StationTypeDataModel StationTypeDataModel
        {
            get { return stationTypeDataModel; }
            set
            {
                stationTypeDataModel = value;
                RaisePropertyChanged(nameof(StationTypeDataModel));
            }
        }

        private CouponStationTypeModel couponStationType;
        public CouponStationTypeModel CouponStationType
        {
            get { return couponStationType; }
            set
            {
                couponStationType = value;
                RaisePropertyChanged(nameof(CouponStationType));
            }
        }

        private GuestMemberReceiptModel guestMemberReceiptModel;
        public GuestMemberReceiptModel GuestMemberReceiptModel
        {
            get { return guestMemberReceiptModel; }
            set
            {
                guestMemberReceiptModel = value;
                RaisePropertyChanged(nameof(GuestMemberReceiptModel));
            }
        }

        private DateTime expiryDate;
        public DateTime ExpiryDate
        {
            get { return expiryDate; }
            set
            {
                expiryDate = value;
                SelectedDate = ExpiryDate.ToString(DateFormatDefinition.DefaultDateFormat);
                RaisePropertyChanged(nameof(ExpiryDate));
            }
        }

        private string error;
        public string Error
        {
            get { return error; }
            set
            {
                error = value;
                RaisePropertyChanged(nameof(Error));
            }
        }

        private string durationError;
        public string DurationError
        {
            get { return durationError; }
            set
            {
                durationError = value;
                RaisePropertyChanged(nameof(DurationError));
            }
        }

        private string stationTypeError;
        public string StationTypeError
        {
            get { return stationTypeError; }
            set
            {
                stationTypeError = value;
                RaisePropertyChanged(nameof(StationTypeError));
            }
        }

        private string memberTypeError;
        public string MemberTypeError
        {
            get { return memberTypeError; }
            set
            {
                memberTypeError = value;
                RaisePropertyChanged(nameof(MemberTypeError));
            }
        }

        private string selectedDate;
        public string SelectedDate
        {
            get { return selectedDate; }
            set
            {
                selectedDate = value;
                RaisePropertyChanged(nameof(SelectedDate));
            }
        }

        private string expiryDateError;
        public string ExpiryDateError
        {
            get { return expiryDateError; }
            set
            {
                expiryDateError = value;
                RaisePropertyChanged(nameof(ExpiryDateError));
            }
        }

        private bool durationIsInvalid;
        public bool DurationIsInvalid
        {
            get { return durationIsInvalid; }
            set
            {
                durationIsInvalid = value;
                RaisePropertyChanged(nameof(DurationIsInvalid));
            }
        }

        private bool stationTypeIsInvalid;
        public bool StationTypeIsInvalid
        {
            get { return stationTypeIsInvalid; }
            set
            {
                stationTypeIsInvalid = value;
                RaisePropertyChanged(nameof(StationTypeIsInvalid));
            }
        }

        private bool memberTypeIsInvalid;
        public bool MemberTypeIsInvalid
        {
            get { return memberTypeIsInvalid; }
            set
            {
                memberTypeIsInvalid = value;
                RaisePropertyChanged(nameof(MemberTypeIsInvalid));
            }
        }

        private bool dateIsValid;
        public bool DateIsValid
        {
            get { return dateIsValid; }
            set
            {
                dateIsValid = value;
                RaisePropertyChanged(nameof(DateIsValid));
            }
        }

        private int selectedHour;
        public int SelectedHour
        {
            get { return selectedHour; }
            set
            {
                selectedHour = value;
                RaisePropertyChanged(nameof(SelectedHour));
            }
        }

        private int selectedMinute;
        public int SelectedMinute
        {
            get { return selectedMinute; }
            set
            {
                selectedMinute = value;
                RaisePropertyChanged(nameof(SelectedMinute));
            }
        }

        #endregion

        #region Event Handlers

        private async void InitializeStationTypes()
        {
            try
            {
                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                    ProcessingText = "FETCHING STATION TYPES . . .";
                });
                

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                
                List<StationTypeDataModel> temporaryHolder = StationTypeList;
                try
                {
                    StationTypeList = await TaskManagerModel<List<StationTypeDataModel>>.Instance.Run(cashierService.GetStationTypeList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            StationTypeList = temporaryHolder;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, couponManagerWindow);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });


                if (StationTypeList != null)
                {
                    List<CouponStationTypeModel> temporaryList = new List<CouponStationTypeModel>();

                        CouponStationType = new CouponStationTypeModel();
                        CouponStationType.Name = StandardMessageResource.TransactSelectAll;
                        CouponStationType.IsChecked = false;
                        CouponStationType.ElementIsChild = false;
                        temporaryList.Add(CouponStationType);
                        foreach (StationTypeDataModel stationType in StationTypeList)
                        {
                            CouponStationType = new CouponStationTypeModel();
                            CouponStationType.Name = stationType.Name;
                            CouponStationType.ID = stationType.ID;
                            CouponStationType.IsChecked = false;
                            CouponStationType.ElementIsChild = true;
                            temporaryList.Add(CouponStationType);
                        }

                    CouponStationTypeList = new ObservableCollection<CouponStationTypeModel>(temporaryList);
                       
                }
                else
                {
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.CouponManagerWindow);
                    CouponStationTypeList = null;
                    CloseWindowImmediately();
                }
            }
            catch (Exception)
            {
                string message = string.Format(StandardMessageResource.ErrorConnectionIssue, StandardMessageResource.TransactWordConnect, StandardMessageResource.TransactWordServer);
                string messageMode = Messages.ErrorConfirmation;
                ShowConfirmationWindow(message, messageMode, couponManagerWindow);
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.CouponManagerWindow);
            }
        }

        private void Initialization()
        {
            DurationIsInvalid = false;
            DurationError = string.Empty;
            SelectedDate = ExpiryDate.ToString(DateFormatDefinition.DefaultDateFormat);
            DateIsValid = true;
            userName = GenerateRandomPassword();

            for (int countHour = 0; countHour <= 99; countHour++)
            {
                HourList.Add(countHour);
            }

            for (int countMinute = 0; countMinute <= 59; countMinute++)
            {
                MinuteList.Add(countMinute);
            }
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.CouponManagerWindow:
                    couponManagerWindow = data as Window;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    userData = data as CashierDataModel;
                    break;

                case Messages.SelectAllStationType:
                    bool CheckAllIsSelected = Convert.ToBoolean(data);
                    foreach (CouponStationTypeModel stationType in CouponStationTypeList)
                    {
                        if (stationType.Name != $" {StandardMessageResource.TransactSelectAll}")
                        {
                            stationType.Restarted = false;
                            stationType.IsChecked = CheckAllIsSelected;
                        }
                    }
                    break;

                case Messages.UnSelectAllStationType:
                    foreach (CouponStationTypeModel stationType in CouponStationTypeList)
                    {
                        if (stationType.Name != $" {StandardMessageResource.TransactSelectAll}" && stationType.IsChecked == false)
                        {
                            SelectAllSelection(false);
                            break;
                        }
                        else if (stationType.Name != $" {StandardMessageResource.TransactSelectAll}" && stationType.IsChecked == true)
                        {
                            SelectAllSelection(true);
                        }
                    }
                    break;

                default:
                    break;
            }         
        }

        private void SelectAllSelection(bool selectCheck)
        {
            foreach (CouponStationTypeModel stationType in CouponStationTypeList)
            {
                if (stationType.Name == $" {StandardMessageResource.TransactSelectAll}")
                {
                    stationType.Restarted = false;
                    stationType.IsChecked = selectCheck;
                }
            }
        }

        private long ToUnixTime(DateTime date)
        {
            System.TimeZone localZone = System.TimeZone.CurrentTimeZone;
            var epoch = new DateTime(1969, 12, 31, 23, 59, 59, 59, DateTimeKind.Utc);
            var dateTimeNow = new DateTime(date.Year, date.Month, date.Day, 23, 59, 59, DateTimeKind.Local);
            DateTime currentUTC = localZone.ToUniversalTime(dateTimeNow);
            return Convert.ToInt64((currentUTC - epoch).TotalMilliseconds);
        }

        public void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.CouponManagerViewModel);
                    if (couponManagerWindow != null)
                    {
                        if (couponManagerWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            couponManagerWindow.DialogResult = false;
                            couponManagerWindow.Close();
                        }
                    }
                }
            });
        }

        private string GenerateRandomPassword()
        {
            Random rndNumber = new Random();
            return rndNumber.Next(1000, 9999).ToString();
        }

        private string GenerateRandomUsername()
        {
            Random rndNumber = new Random();
            return rndNumber.Next(10000000, 99999999).ToString();
        }

        public void CreateButton(object[] parameters)
        {
            if (IsProcessing)
            {
                return;
            }

            DateTime dateTime;
            cbHour = parameters[0] as System.Windows.Controls.ComboBox;
            cbMinute = parameters[1] as System.Windows.Controls.ComboBox;
            timeDuration = TimeSpan.FromHours(Convert.ToDouble(cbHour.SelectedItem) + (Convert.ToDouble(cbMinute.SelectedItem) / 60));
            bool dateValidation = DateTime.TryParseExact(SelectedDate, DateFormatDefinition.DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime);

            if(!dateValidation)
            {
                ExpiryDateError = StandardMessageResource.ErrorExpiryDate;
                DateIsValid = true;
                DateIsValid = false;
            }
            else if(Convert.ToDateTime(SelectedDate) < DateTime.Today)
            {
                ExpiryDateError = StandardMessageResource.ErrorExpiryDatePrevious;
                DateIsValid = true;
                DateIsValid = false;
            }
            else if(dateValidation && Convert.ToDateTime(SelectedDate) >= DateTime.Today)
            {
                DateIsValid = true;
            }

            if (CouponStationTypeList.ToList().TrueForAll(s => s.IsChecked == false))
            {
                StationTypeError = StandardMessageResource.ErrorStationType;
                StationTypeIsInvalid = false;
                StationTypeIsInvalid = true;
            }
            else
            {
                StationTypeIsInvalid = false;
            }

            if (timeDuration.TotalMinutes < 10)
            {
                DurationError = StandardMessageResource.ErrorDuration;
                DurationIsInvalid = false;
                DurationIsInvalid = true;
            }
            else if (timeDuration.TotalMinutes >= 10)
            {
                DurationIsInvalid = false;
            }

            if(!StationTypeIsInvalid && !DurationIsInvalid && !MemberTypeIsInvalid)
            {
                // Note: Do not use ExpiryDate property since it is not the updated
                // and binded property at textbox template control in the UI
                // when a date was selected.
                CreateCoupon(Convert.ToInt32(timeDuration.TotalSeconds), ToUnixTime(dateTime));
            }
        }

        public async void CreateCoupon(int duration, long expiry)
        {
            string message = string.Empty;
            string messageMode = string.Empty;

            try
            {
                MemberServiceProvider member = new MemberServiceProvider();
                password = GenerateRandomPassword();
                StationTypeIDList = new List<int>();
                StationTypeNames = new List<string>();
                foreach (CouponStationTypeModel couponStationType in CouponStationTypeList)
                {
                    if (couponStationType.IsChecked && couponStationType.Name != $" {StandardMessageResource.TransactSelectAll}")
                    {
                        StationTypeIDList.Add(Convert.ToInt32(couponStationType.ID));
                        StationTypeNames.Add(couponStationType.Name);
                    }
                }

                if (!CouponStationTypeList.ToList().TrueForAll(s => s.IsChecked == false) && timeDuration.TotalMinutes >= 10 && DateIsValid)
                {
                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                        ProcessingText = "CREATING COUPON . . .";
                    });

                    string responseMessage = string.Empty;
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    CouponDataModel couponUser = null;
                    try
                    {
                        couponUser = await TaskManagerModel<CouponDataModel>.Instance.Run(member.GenerateCoupon(DataCacheContext.CashierSessionID, password, duration, expiry, StationTypeIDList, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                couponUser = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, couponManagerWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (couponUser != null)
                    {
                        message = $"{StandardMessageResource.SuccessCreatedCoupon} coupon{Environment.NewLine}Username: {couponUser.Username}{Environment.NewLine}Password: {couponUser.Password}";
                        messageMode = Messages.SuccessConfirmation;
                        TransactionModel transactionModel = CreateTransactionModel(couponUser.GuestID, GetTransactionRemarks(), couponUser.Username);
                        PrintCoupon(couponUser.Username, couponUser.Password, duration, ExpiryDate);
                        if (DataCacheContext.UseLocalDB)
                        {
                            SaveTransactionToLocalDB(transactionModel, couponUser, stationTypeNames, couponUser.Password);
                        }

                        Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, transactionModel);

                        ShowConfirmationWindow(message, messageMode, couponManagerWindow);
                    }
                    else
                    {
                        ErrorDataModel errorData = ConvertErrorDataModel(responseMessage);
                        message = errorData.Message;
                        messageMode = Messages.ErrorConfirmation;

                        ShowConfirmationWindow(message, messageMode, couponManagerWindow);
                        if (errorData.Status == 498)
                        {
                            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.SwitchToLoginView, null);
                        }
                    }

                    CloseWindowImmediately();
                }
            }
            catch (Exception)
            {
                message = string.Format(StandardMessageResource.ErrorConnectionIssue, StandardMessageResource.TransactWordCreateCoupon, StandardMessageResource.TransactWordServer);
                ShowConfirmationWindow(message, Messages.ErrorConfirmation, couponManagerWindow);
            }
        }

        private TransactionModel CreateTransactionModel(string id, string remarks, string name = null)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = NewCouponAccount,
                CustomerName = name,
                CustomerID = id,
                TransactionAmount = "N/A",
                TransactionRemarks = remarks
            };
            return transactionModel;
        }

        private string GenerateRandomNumber()
        {
            Random rndNumber = new Random();
            return rndNumber.Next(0, 99999999).ToString();
        }

        private string GetTransactionRemarks()
        {
            string transactionRemarks = string.Empty;

            transactionRemarks = $"Coupon duration: {timeDuration} hr(s)";

            return transactionRemarks;
        }

        #endregion

        #region Private Methods

        private void SaveTransactionToLocalDB(TransactionModel model, CouponDataModel couponModel, List<string> stationTypes, string password)
        {
            if(TransactionRepository != null)
            {
                TransactionRepository.Add(TransactionLogMapper.MapNewCoupon(model, userData, PaymentType.Cash, couponModel, stationTypes, password));
                TransactionRepository.SaveAsync();
            }
        }

        public void PrintCoupon()
        {
            try
            {
                System.Windows.Forms.PrintDialog printDialog = new System.Windows.Forms.PrintDialog();
                printDialog.Document = guestOrMemberDocument;
                printDialog.UseEXDialog = true;
                printDialog.PrinterSettings.PrinterName = DataCacheContext.PrinterName;
                guestOrMemberDocument.DocumentName = PrinterMessageResource.CouponDocumentName;
                guestOrMemberDocument.Print();
            }
            catch(Exception)
            {
                string message = StandardMessageResource.ErrorPrinter;
                string messageMode = Messages.ErrorConfirmation;
                ShowConfirmationWindow(message, messageMode, couponManagerWindow);
            }
        }

        private void GuestOrMemberDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            int stationTypeLimitChar = 16;
            int yAxis = 0;
            int yMargin = 16;
            int yLine = 2;
            var splitName = GuestMemberReceiptModel.Name.Split(' ');
            string stationTypes = String.Join(",", StationTypeNames);
            string expirationDateTime = GuestMemberReceiptModel.ExpirationDate.ToString(DateFormatDefinition.DefaultDateFormat);
            
            yAxis = PrintExcessCharacterOnNewLine(e, string.Empty, userData.Branch.Name, true, 35, 0, 0, yAxis, yMargin, yLine, System.Drawing.FontStyle.Bold);

            if (GuestMemberReceiptModel.UserName.Length > 15)
            {
                string cropUsernameFirstLine = GuestMemberReceiptModel.UserName.Substring(0, 16);
                string cropUsernameSecondLine = GuestMemberReceiptModel.UserName.Substring(16);
                e.Graphics.DrawString($"{PrinterMessageResource.Username}: {cropUsernameFirstLine}", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));
                e.Graphics.DrawString($"{cropUsernameSecondLine}", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 74, yAxis += yMargin);
            }

            else if (GuestMemberReceiptModel.UserName.Length <= 15)
            {
                e.Graphics.DrawString($"{PrinterMessageResource.Username}: {GuestMemberReceiptModel.UserName}", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));
            }

            e.Graphics.DrawString($"{PrinterMessageResource.Password}: {GuestMemberReceiptModel.Password}", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);

            e.Graphics.DrawString($"{PrinterMessageResource.Duration}: {TimeSpan.FromSeconds(GuestMemberReceiptModel.Duration).ToString(@"hh\:mm").ConvertTimeToString()}", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));
            e.Graphics.DrawString($"{PrinterMessageResource.ExpirationMessage} ", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);

            e.Graphics.DrawString($"{expirationDateTime}.", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);

            if (stationTypes.Length > stationTypeLimitChar && stationTypes.Substring(stationTypeLimitChar) != "")
            {
                string cropNameFirstLine;
                string cropNameSecondLine;
                for (int x = stationTypeLimitChar; x >= 0; x--)
                {
                    if (stationTypes.Substring(x, 1) == " ")
                    {
                        cropNameFirstLine = stationTypes.Substring(0, x);
                        cropNameSecondLine = stationTypes.Substring(x);
                        e.Graphics.DrawString($"{PrinterMessageResource.StationType}: {cropNameFirstLine} ", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);
                        e.Graphics.DrawString($"{cropNameSecondLine}", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 72, yAxis += yMargin);
                        break;
                    }
                }
            }
            else if (GuestMemberReceiptModel.Name.Length <= stationTypeLimitChar)
            {
                e.Graphics.DrawString($"{PrinterMessageResource.StationType}: {stationTypes}", new Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);
            }

            e.Graphics.DrawString($"{PrinterMessageResource.NoteCouponMessage1}.", new Font("Arial Narrow", 7F, System.Drawing.FontStyle.Italic), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));
            e.Graphics.DrawString($"{PrinterMessageResource.NoteCouponMessage2}", new Font("Arial Narrow", 7F, System.Drawing.FontStyle.Italic), new SolidBrush(Color.Black), 10, yAxis += yMargin);
            e.Graphics.DrawString($"{PrinterMessageResource.NoteCouponMessage3}.", new Font("Arial Narrow", 7F, System.Drawing.FontStyle.Italic), new SolidBrush(Color.Black), 10, yAxis += yMargin);
        }

        private void PrintCoupon(string userName, string password, int duration, DateTime dateExpiry)
        {
            GuestMemberReceiptModel.UserName = userName;
            GuestMemberReceiptModel.Password = password;
            GuestMemberReceiptModel.Duration = duration;
            GuestMemberReceiptModel.ExpirationDate = dateExpiry;
            PrintCoupon();
        }

        public string this[string columnName]
        {
            get
            {
                string result = string.Empty;
                if(columnName == SelectedDate)
                {

                }
                return result;
            }
        }

        public void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                Mediator.Instance.UnRegister(this, Messages.CouponManagerViewModel);
                if (couponManagerWindow != null)
                {
                    if (couponManagerWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                        couponManagerWindow.Close();
                    }
                }
            });
        }

        #endregion
    }
}
