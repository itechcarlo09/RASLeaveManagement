﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.MessageResource;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using gocafe_cashier.Card;
using gocafe_cashier.Mapper;
using gocafe_cashier.ViewModel.Database;
using gocafe_cashier.Cache;
using System.Threading.Tasks;
using GocafeService.DataTransfer;
using System.Threading;
using gocafe_cashier.TaskManager;
using System.Drawing;
using GocafeShared.Utilities.StringFormat;
using System.Drawing.Printing;

namespace gocafe_cashier.ViewModel.Member
{
    public class ReplaceCardWindowViewModel : TransactionLogViewModelBase
    {
        private string cardReplacement = StandardMessageResource.TransactCardReplacement;

         #region Printer Variables
        private const int lineHeight = 11;
        private const int fontSize = 8;
        private const int margin = 3;
        private const int numberWidth = 7;
        private const int maxXPosition = 180;
        private PrintDocument receipt;
        #endregion

        public ReplaceCardWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.ReplaceCardWindowViewModel);

            InitializeMemberTypes();
            ReplacementFee = 0;
            PrintIsChecked = true;
            receipt = new PrintDocument();
            receipt.PrintPage += PrintReceiptMessage;
        }

        public override async void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.ReplaceCardWindow:
                    replaceCardWindow = (ReplaceCardWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    break;

                case Messages.CardID:
                    if (!IsCardDetected)
                    {
                        IsCardDetected = true;
                        cardNumber = (string)data;
                        RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
                    }
                    break;

                default:
                    break;
            }
        }


        #region Private Fields

        private ReplaceCardWindow replaceCardWindow;
        private CardReplacementServiceProvider cardReplacementServiceProvider = new CardReplacementServiceProvider();
        private CashierDataModel cashierData;

        private string message = string.Empty;
        private string messageMode = string.Empty;

        private string cardNumber = string.Empty;
        private string memberID = string.Empty;

        #endregion

        #region Properties

        private string userName;

        public string UserName
        {
            get { return userName; }
            set
            {
                userName = value;
                IsMemberFound = false;
                RaisePropertyChanged(nameof(UserName));
            }
        }

        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            set
            {
                firstName = value;
                RaisePropertyChanged(nameof(FirstName));
            }
        }

        private string lastName;

        public string LastName
        {
            get { return lastName; }
            set
            {
                lastName = value;
                RaisePropertyChanged(nameof(LastName));
            }
        }

        private string memberType;

        public string MemberType
        {
            get { return memberType; }
            set
            {
                memberType = value;
                RaisePropertyChanged(nameof(MemberType));
            }
        }

        private bool isMemberFound;

        public bool IsMemberFound
        {
            get { return isMemberFound; }
            set
            {
                isMemberFound = value;
                RaisePropertyChanged(nameof(IsMemberFound));
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

        public bool IsSubmitButtonEnabled
        {
            get { return (IsMemberFound && IsCardDetected); }
        }

        private decimal totalFee;

        public decimal TotalFee
        {
            get { return totalFee; }
            set
            {
                totalFee = value;
                RaisePropertyChanged(nameof(TotalFee));

                ChangeFee = TenderedMoney - totalFee;
            }
        }

        private decimal replacementFee;

        public decimal ReplacementFee
        {
            get { return replacementFee; }
            set
            {
                replacementFee = value;
                RaisePropertyChanged(nameof(ReplacementFee));
            }
        }

        private decimal changeFee;

        public decimal ChangeFee
        {
            get { return changeFee; }
            set
            {
                changeFee = value;
                RaisePropertyChanged(nameof(ChangeFee));
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

        private decimal tenderedMoney;

        public decimal TenderedMoney
        {
            get { return tenderedMoney; }
            set
            {
                tenderedMoney = value;
                RaisePropertyChanged(nameof(TenderedMoney));

                ChangeFee = tenderedMoney - TotalFee;
            }
        }

        private MemberTypesDataModel memberTypesDataModel;
        public MemberTypesDataModel MemberTypesDataModel
        {
            get { return memberTypesDataModel; }
            set
            {
                memberTypesDataModel = value;
                RaisePropertyChanged(nameof(MemberTypesDataModel));
            }
        }

        private List<MemberTypesDataModel> memberTypeList;
        public List<MemberTypesDataModel> MemberTypeList
        {
            get { return memberTypeList; }
            set
            {
                memberTypeList = value;
                RaisePropertyChanged(nameof(MemberTypeList));
            }
        }

        private string errorMessage;

        public string ErrorMessage
        {
            get { return errorMessage; }
            set
            {
                errorMessage = value;
                RaisePropertyChanged(nameof(ErrorMessage));
            }
        }

        private bool isErrorMessageShown;

        public bool IsErrorMessageShown
        {
            get { return isErrorMessageShown; }
            set
            {
                isErrorMessageShown = value;
                RaisePropertyChanged(nameof(IsErrorMessageShown));
            }
        }

        private bool printIsChecked;
        public bool PrintIsChecked
        {
            get { return printIsChecked; }
            set
            {
                printIsChecked = value;
                RaisePropertyChanged(nameof(PrintIsChecked));
            }
        }


        #endregion

        #region Commands

        public DelegateCommand FindMemberCommand
        {
            get
            {
                return new DelegateCommand(FindMember);
            }
        }

        public DelegateCommand PayCommand
        {
            get
            {
                return new DelegateCommand(PayAmount);
            }
        }

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        #endregion

        #region Event Handlers

        private async void FindMember()
        {
            if (IsProcessing)
            {
                return;
            }

            if (UserName == null || UserName == string.Empty)
            {
                ErrorMessage = StandardMessageResource.ErrorUsernameIsEmpty;
                IsErrorMessageShown = true;
                return;
            }
            else if (UserName.Length < 4)
            {
                ErrorMessage = StandardMessageResource.ErrorUsernameLessThan4;
                IsErrorMessageShown = true;
                return;
            }
            else
            {
                IsErrorMessageShown = false;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "FETCHING MEMBER DETAILS . . .";
            });

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            MemberInfoDataModel memberInfo = null;
            try
            {
                memberInfo = await TaskManagerModel<MemberInfoDataModel>.Instance.Run(cardReplacementServiceProvider.GetMemberInfoByUserName(UserName, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        memberInfo = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, replaceCardWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });

            IsMemberFound = false;
            if (memberInfo != null)
            {
                if (memberInfo.FirstName != null)
                {
                    IsMemberFound = true;
                    FirstName = memberInfo.FirstName;
                    LastName = memberInfo.LastName;
                    MemberType = memberInfo.MemberType.Name;
                    memberID = memberInfo.ID;
                    SetReplacementCost(MemberType);
                }
            }
        }

        private async void PayAmount()
        {
            if(IsSubmitButtonEnabled)
            {
                if (IsProcessing)
                {
                    return;
                }

                if (ShowPasswordConfirmation(UserName, replaceCardWindow))
                {
                    IsProcessing = true;
                    ProcessingText = "PROCESSING REQUEST . . .";

                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    CardReplacementPayload cardReplacementResponse = null;
                    try
                    {
                        cardReplacementResponse = await TaskManagerModel<CardReplacementPayload>.Instance.Run(cardReplacementServiceProvider.ReplaceCard(memberID, DataCacheContext.CashierSessionID, cardNumber, ReplacementFee, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                cardReplacementResponse = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, replaceCardWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (cardReplacementResponse != null)
                    {
                        ShowConfirmationWindow(StandardMessageResource.SuccessCardReplacement, Messages.SuccessConfirmation);
                        if (PrintIsChecked)
                        {
                            PrintReceipt();
                        }
                        CloseWindow();

                        TransactionModel transactionModel = CreateTransactionModel(memberID, GetTransactionRemarks(), $"{UserName}");

                        Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, transactionModel);
                    }
                }

            }
        }

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.ReplaceCardWindowViewModel);
                    if (replaceCardWindow != null)
                    {
                        if (replaceCardWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            replaceCardWindow.DialogResult = false;
                            replaceCardWindow.Close();
                        }
                    }
                }
            });
        }
        #endregion

        #region Private Methods

        private int GetMemberId(string memberName)
        {
            int memberId = 0;

            foreach (MemberTypesDataModel memberType in MemberTypeList)
            {
                if (memberType.Name == memberName)
                {
                    return memberType.ID;
                }
            }

            return memberId;
        }

        private async void InitializeMemberTypes()
        {
            try
            {
                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                    ProcessingText = "FETCHING MEMBER TYPES . . .";
                });

                MemberServiceProvider memberService = new MemberServiceProvider();
                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                List<MemberTypesDataModel> temporaryHolder = MemberTypeList;
                try
                {
                    MemberTypeList = await TaskManagerModel<List<MemberTypesDataModel>>.Instance.Run(memberService.GetMemberTypes(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            MemberTypeList = temporaryHolder;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, replaceCardWindow);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });

                if (MemberTypeList == null)
                {
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.ReplaceCardWindow);
                    CloseWindowImmediately();
                }
            }
            catch
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.ReplaceCardWindow);
            }
        }

        private async void SetReplacementCost(string memberTypeID)
        {
            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "FETCHING REPLACEMENT COST . . .";
            });

            MemberServiceProvider memberService = new MemberServiceProvider();
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            MemberTypesDataModel memberType = null;
            try
            {
                memberType = await TaskManagerModel<MemberTypesDataModel>.Instance.Run(memberService.GetMemberTypeByID(DataCacheContext.CashierSessionID, GetMemberId(memberTypeID), cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        memberType = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, replaceCardWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });

            if (memberType != null)
            {
                ReplacementFee = memberType.CardReplacementCost / 100;
                TotalFee = ReplacementFee;
            }
        }

        private TransactionModel CreateTransactionModel(string id, string remarks, string name = null)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = cardReplacement,
                CustomerName = name,
                CustomerID = id,
                TransactionAmount = $"{CurrencySymbol}{(Convert.ToDouble(GetTransactionAmount()) / 100).ToString("N2")}",
                TransactionRemarks = remarks,
                MemberType = MemberType
            };
            return transactionModel;
        }

        private string GetTransactionRemarks()
        {
            string cardReplacementRemarks = $"Card Replacement Fee ({MemberType}): {CurrencySymbol}{ReplacementFee}";
            return cardReplacementRemarks;
        }

        private int GetTransactionAmount()
        {

            return (int)(TotalFee * 100);
        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.ReplaceCardWindowViewModel);
                if (replaceCardWindow != null)
                {
                    if (replaceCardWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        replaceCardWindow.DialogResult = false;
                        replaceCardWindow.Close();
                    }
                }
            });
        }

        private void PrintReceipt()
        {
            System.Windows.Forms.PrintDialog printDialog = new System.Windows.Forms.PrintDialog();
            printDialog.Document = receipt;
            printDialog.UseEXDialog = true;

            printDialog.PrinterSettings.PrinterName = DataCacheContext.PrinterName;
            receipt.DocumentName = "PrintReceipt";

            try
            {
                receipt.Print();
            }
            catch (InvalidPrinterException ex)
            {
                ShowConfirmationWindow(StandardMessageResource.ErrorPrinter, Messages.ErrorConfirmation, replaceCardWindow);
            }

        }

        private void PrintReceiptMessage(object sender, PrintPageEventArgs e)
        {
            int yAxis = 0;

            yAxis = PrintNewLine(3, yAxis, e);
            yAxis = PrintExcessCharacterOnNewLine(e, string.Empty, cashierData.Branch.Name, true, 35, 0, 0, yAxis, 0, lineHeight, FontStyle.Bold);
            yAxis = PrintNewLine(3, yAxis, e);
            yAxis = PrintWithRegularFont($"CASHIER: {cashierData.Name}", 7, margin, yAxis, e);
            yAxis = PrintWithRegularFont($"DATE: {DateTime.Now.ToShortDateString()} {DateTime.Now.ToLongTimeString()}", 7, margin, yAxis, e);
            yAxis = PrintNewLine(2, yAxis, e);
            yAxis = PrintWithBoldFont("PRICE", 7, maxXPosition - 30, yAxis - lineHeight, e);
            yAxis = PrintNewLine(1, yAxis, e);
            yAxis = PrintWithRegularFont("CARD REPLACEMENT", 7, margin, yAxis, e);
            PrintPrice($"{MoneyFormatter.ConvertIntToMoney($"{TotalFee * 100}")}", yAxis, e);
            yAxis = PrintNewLine(2, yAxis, e);

        }

        private int PrintNewLine(int numberOfLines, int yPosition, PrintPageEventArgs e)
        {
            for (int x = 0; x<numberOfLines; x++, yPosition += lineHeight)
                e.Graphics.DrawString("", new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), 0, yPosition);

            return yPosition;
        }
        private int PrintWithRegularFont(string message, int fontSize, int xPosition, int yPosition, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(message, new Font("Arial Narrow", fontSize, FontStyle.Regular), new SolidBrush(Color.Black), xPosition, yPosition);
            return yPosition + lineHeight;
        }
        private int PrintWithBoldFont(string message, int fontSize, int xPosition, int yPosition, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(message, new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), xPosition, yPosition);
            return yPosition + lineHeight;
        }

        private void PrintPrice(string message, int yPosition, PrintPageEventArgs e)
        {
            int padding = 0;
            for (int x = 0; x<message.Length; x++)
            {
                if (message[message.Length - x - 1].ToString() == ".")
                {
                    padding += 2;
                }
                if (message[message.Length - x - 1].ToString() == "1")
                {
                    padding += 1;
                }
                e.Graphics.DrawString(message[message.Length - x - 1].ToString()
                    , new Font("Arial Narrow", 7, FontStyle.Regular)
                    , new SolidBrush(Color.Black)
                    , maxXPosition - x* numberWidth + padding - 10
                    , yPosition - lineHeight);
            }
        }

        private int PrintLongLine(int yPosition, PrintPageEventArgs e)
        {
            for (int x = 0; x<maxXPosition; x += 5)
            {
                e.Graphics.DrawString("-", new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), x, yPosition);
            }

            return yPosition + lineHeight;
        }
        #endregion

    }
}
