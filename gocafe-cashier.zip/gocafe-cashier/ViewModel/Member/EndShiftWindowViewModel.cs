﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Definition;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;

namespace gocafe_cashier.ViewModel.Member
{
    public class EndShiftWindowViewModel : BaseModel
    {

        public EndShiftWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.EndShiftWindowViewModel);
            EndShiftWarningMessage = StandardMessageResource.WarningEndShift;
        }

        public override void SendData(string message, object data)
        {
            switch(message)
            {
                case Messages.EndShiftWindow:
                    endShiftWindow = (EndShiftWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    userData = (CashierDataModel)data;
                    break;

                default:
                    break;

            }
        }

        #region Private Variables

        private EndShiftServiceProvider endShiftServiceProvider = new EndShiftServiceProvider();
        private EndShiftWindow endShiftWindow;
        private CashierDataModel userData = new CashierDataModel();
        private PasswordBox cashierPassword;

        #endregion


        #region Properties

        private string endShiftWarningMessage;
        public string EndShiftWarningMessage
        {
            get { return endShiftWarningMessage; }
            set
            {
                endShiftWarningMessage = value;
                RaisePropertyChanged(nameof(EndShiftWarningMessage));
            }
        }

        private bool isPasswordInvalid;
        public bool IsPasswordInvalid
        {
            get { return isPasswordInvalid; }
            set
            {
                isPasswordInvalid = value;
                RaisePropertyChanged(nameof(IsPasswordInvalid));
            }
        }

        private string errorMessage;
        public string ErrorMessage
        {
            get { return errorMessage; }
            set
            {
                errorMessage = value;
                RaisePropertyChanged(nameof(ErrorMessage));
            }
        }

        #endregion

        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand ConfirmCommand
        {
            get
            {
                return new DelegateCommand<object>(EndShift);
            }
        }

        #endregion

        #region Event Handlers
        
        public void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.EndShiftWindowViewModel);
                    if (endShiftWindow != null)
                    {
                        if (endShiftWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            endShiftWindow.DialogResult = false;
                            endShiftWindow.Close();
                        }
                    }
                }
            });
        }

        public async void EndShift(object parameter)
        {
            string message = string.Empty;
            string messageMode = string.Empty;

            cashierPassword = parameter as PasswordBox;

            if (cashierPassword.Password == "" || cashierPassword.Password == null)
            {
                ErrorMessage = StandardMessageResource.ErrorPasswordIsEmpty;
                IsPasswordInvalid = false;
                IsPasswordInvalid = true;
            }
            else if (cashierPassword.Password.Length < 4)
            {
                ErrorMessage = StandardMessageResource.ErrorPasswordLessThan4;
                IsPasswordInvalid = false;
                IsPasswordInvalid = true;
            }
            else
            {
                try
                {
                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                        ProcessingText = "ENDING YOUR SHIFT . . .";
                    });

                    string responseMessage = string.Empty;
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    EndShiftDataModel endShiftData = null;
                    try
                    {
                        endShiftData = await TaskManagerModel<EndShiftDataModel>.Instance.Run(endShiftServiceProvider.EndShift(cashierPassword.Password, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                endShiftData = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, endShiftWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (endShiftData != null)
                    {
                        List<ShiftModel> shifts = new List<ShiftModel>();

                        foreach (ShiftDataModel shift in endShiftData.Shifts)
                        {
                            Dictionary<string, string> cashBreakdown = new Dictionary<string, string>();

                            foreach(KeyValuePair<string, int> entry in shift.Breakdown)
                            {
                                cashBreakdown.Add(entry.Key, CurrencySymbol + " " + (entry.Value / 100).ToString($"N2"));
                            }

                            shifts.Add(new ShiftModel
                            {
                                CashierName = shift.CashierName,
                                EndTime = shift.EndDate.ToString($"MMMM dd, yyyy | hh:mm tt", CultureInfo.InvariantCulture),
                                StartTime = shift.StartDate.ToString($"MMMM dd, yyyy | hh:mm tt", CultureInfo.InvariantCulture),
                                TotalSales = CurrencySymbol + " " + (shift.TotalSales / 100).ToString($"N2"),
                                TotalHours = shift.TotalHours,
                                Breakdown = cashBreakdown,
                                ProductBreakdownData = shift.ProductBreakdown
                            });
                        }

                        EndShiftSummaryWindow endShiftSummaryWindow = new EndShiftSummaryWindow();
                        endShiftSummaryWindow.Owner = endShiftWindow;

                        Mediator.Instance.NotifyViewModel(Messages.EndShiftSummaryWindowViewModel, Messages.EndShiftSummaryWindow, endShiftSummaryWindow);
                        Mediator.Instance.NotifyViewModel(Messages.EndShiftSummaryWindowViewModel, Messages.CashierInfo, userData);
                        Mediator.Instance.NotifyViewModel(Messages.EndShiftSummaryWindowViewModel, Messages.EndShiftData, 
                            new EndShiftModel {
                                EndTime = endShiftData.EndDate.ToString($"{DateFormatDefinition.DefaultDateFormat} | hh:mm tt", CultureInfo.InvariantCulture),
                                StartTime = endShiftData.StartDate.ToString($"{DateFormatDefinition.DefaultDateFormat} | hh:mm tt", CultureInfo.InvariantCulture),
                                TotalSales = CurrencySymbol + " " + (endShiftData.TotalSales/100).ToString($"N2"),
                                Shifts = shifts,
                                InventoryItems = endShiftData.ShiftInventory
                            });
                        Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
                        endShiftSummaryWindow.ShowDialog();
                        Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
                    }

                    CloseWindowImmediately();
                }
                catch (Exception e)
                {
                    //fix me: log errors
                }
            }
        }

        #endregion

        #region Private Methods

        public void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                Mediator.Instance.UnRegister(this, Messages.CouponManagerViewModel);
                if (endShiftWindow != null)
                {
                    if (endShiftWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                        endShiftWindow.Close();
                    }
                }
            });
        }

        #endregion
    }
}
