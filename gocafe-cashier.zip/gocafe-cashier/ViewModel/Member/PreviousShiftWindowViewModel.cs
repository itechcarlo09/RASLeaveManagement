﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Definition;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;

namespace gocafe_cashier.ViewModel.Member
{
    public class PreviousShiftWindowViewModel: BaseModel
    {
        public PreviousShiftWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.PreviousShiftWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.PreviousShiftWindow:
                    previousShiftWindow = (PreviousShiftWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    userData = (CashierDataModel)data;
                    break;

                default:
                    break;

            }
        }

        #region Private Variables

        private EndShiftServiceProvider endShiftServiceProvider = new EndShiftServiceProvider();
        private PreviousShiftWindow previousShiftWindow;
        private CashierDataModel userData = new CashierDataModel();
        private PasswordBox cashierPassword;

        #endregion


        #region Properties

        private string username;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                RaisePropertyChanged(nameof(Username));
            }
        }

        private bool isPasswordInvalid;
        public bool IsPasswordInvalid
        {
            get { return isPasswordInvalid; }
            set
            {
                isPasswordInvalid = value;
                RaisePropertyChanged(nameof(IsPasswordInvalid));
            }
        }

        private bool isUsernameInvalid;
        public bool IsUsernameInvalid
        {
            get { return isUsernameInvalid; }
            set
            {
                isUsernameInvalid = value;
                RaisePropertyChanged(nameof(IsUsernameInvalid));
            }
        }

        private string passwordErrorMessage;
        public string PasswordErrorMessage
        {
            get { return passwordErrorMessage; }
            set
            {
                passwordErrorMessage = value;
                RaisePropertyChanged(nameof(PasswordErrorMessage));
            }
        }

        private string usernameErrorMessage;
        public string UsernameErrorMessage
        {
            get { return usernameErrorMessage; }
            set
            {
                usernameErrorMessage = value;
                RaisePropertyChanged(nameof(UsernameErrorMessage));
            }
        }

        #endregion

        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand ConfirmCommand
        {
            get
            {
                return new DelegateCommand<object>(ShowPreviousShiftSummary);
            }
        }

        #endregion

        #region Event Handlers

        public void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.PreviousShiftWindowViewModel);
                    if (previousShiftWindow != null)
                    {
                        if (previousShiftWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            previousShiftWindow.DialogResult = false;
                            previousShiftWindow.Close();
                        }
                    }
                }
            });
        }

        public async void ShowPreviousShiftSummary(object parameter)
        {
            string message = string.Empty;
            string messageMode = string.Empty;

            PasswordErrorMessage = string.Empty;
            UsernameErrorMessage = string.Empty;

            IsUsernameInvalid = false;
            IsPasswordInvalid = false;

            cashierPassword = parameter as PasswordBox;
            if (Username == string.Empty || Username == null)
            {
                UsernameErrorMessage = StandardMessageResource.ErrorUsernameIsEmpty;
                IsUsernameInvalid = true;
            }
            else if (Username.Length < 4)
            {
                UsernameErrorMessage = StandardMessageResource.ErrorUsernameLessThan4;
                IsUsernameInvalid = true;
            }

            if (cashierPassword.Password == "" || cashierPassword.Password == null)
            {
                PasswordErrorMessage = StandardMessageResource.ErrorPasswordIsEmpty;
                IsPasswordInvalid = true;
            }
            else if (cashierPassword.Password.Length < 4)
            {
                PasswordErrorMessage = StandardMessageResource.ErrorPasswordLessThan4;
                IsPasswordInvalid = true;
            }

            if (!IsPasswordInvalid && !IsUsernameInvalid)
            {
                try
                {
                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                        ProcessingText = "GETTING PREVIOUS SHIFT SUMMARY . . .";
                    });

                    string responseMessage = string.Empty;
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    EndShiftDataModel previousShiftData = null;
                    try
                    {
                        previousShiftData = await TaskManagerModel<EndShiftDataModel>.Instance.Run(endShiftServiceProvider.GetPreviousShiftSummary(Username, cashierPassword.Password, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                previousShiftData = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, previousShiftWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (previousShiftData != null)
                    {
                        List<ShiftModel> shifts = new List<ShiftModel>();

                        if (previousShiftData.Shifts != null)
                        {
                            foreach (ShiftDataModel shift in previousShiftData.Shifts)
                            {
                                Dictionary<string, string> cashBreakdown = new Dictionary<string, string>();

                                foreach (KeyValuePair<string, int> entry in shift.Breakdown)
                                {
                                    cashBreakdown.Add(entry.Key, CurrencySymbol + " " + (entry.Value / 100).ToString($"N2"));
                                }

                                shifts.Add(new ShiftModel
                                {
                                    CashierName = shift.CashierName,
                                    EndTime = shift.EndDate.ToString($"MMMM dd, yyyy | hh:mm tt", CultureInfo.InvariantCulture),
                                    StartTime = shift.StartDate.ToString($"MMMM dd, yyyy | hh:mm tt", CultureInfo.InvariantCulture),
                                    TotalSales = CurrencySymbol + " " + (shift.TotalSales / 100).ToString($"N2"),
                                    TotalHours = shift.TotalHours,
                                    Breakdown = cashBreakdown,
                                    ProductBreakdownData = shift.ProductBreakdown
                                });
                            }
                        }

                        PreviousShiftSummaryWindow previousShiftSummaryWindow = new PreviousShiftSummaryWindow();
                        previousShiftSummaryWindow.Owner = previousShiftWindow;

                        Mediator.Instance.NotifyViewModel(Messages.PreviousShiftSummaryWindowViewModel, Messages.PreviousShiftSummaryWindow, previousShiftSummaryWindow);
                        Mediator.Instance.NotifyViewModel(Messages.PreviousShiftSummaryWindowViewModel, Messages.CashierInfo, userData);
                        Mediator.Instance.NotifyViewModel(Messages.PreviousShiftSummaryWindowViewModel, Messages.EndShiftData,
                            new EndShiftModel
                            {
                                EndTime = previousShiftData.EndDate.ToString($"{DateFormatDefinition.DefaultDateFormat} | hh:mm tt", CultureInfo.InvariantCulture),
                                StartTime = previousShiftData.StartDate.ToString($"{DateFormatDefinition.DefaultDateFormat} | hh:mm tt", CultureInfo.InvariantCulture),
                                TotalSales = CurrencySymbol + " " + (previousShiftData.TotalSales / 100).ToString($"N2"),
                                Shifts = shifts,
                                InventoryItems = previousShiftData.ShiftInventory
                            });
                        Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
                        previousShiftSummaryWindow.ShowDialog();
                        Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
                    }

                    CloseWindowImmediately();
                }
                catch (Exception e)
                {
                    //fix me: log errors
                }
            }
        }

        #endregion

        #region Private Methods

        public void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                Mediator.Instance.UnRegister(this, Messages.CouponManagerViewModel);
                if (previousShiftWindow != null)
                {
                    if (previousShiftWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                        previousShiftWindow.Close();
                    }
                }
            });
        }

        #endregion
    }
}
