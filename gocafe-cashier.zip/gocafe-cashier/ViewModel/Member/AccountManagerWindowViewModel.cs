﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.MessageResource;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Drawing;
using GocafeShared.Utilities.StringFormat;
using gocafe_cashier.Mapper;
using gocafe_cashier.ViewModel.Database;
using System.Threading.Tasks;
using System.Runtime.ExceptionServices;
using gocafe_cashier.Cache;
using System.Threading;
using gocafe_cashier.TaskManager;
using gocafe_cashier.Security;
using gocafe_cashier.Definition;
using gocafe_cashier.Network;
using GocafeShared.Definition;
using GocafeShared.Model.Network;

namespace gocafe_cashier.ViewModel.Member
{
    public class AccountManagerWindowViewModel : TransactionLogViewModelBase
    {
        private string NewAccount = StandardMessageResource.TransactNewAccount;
        private PrintDocument guestOrMemberDocument;
        private string printBalance;

        public AccountManagerWindowViewModel()
        {
            printBalance = "0.00";

            Mediator.Instance.Register(this, Messages.AccountManagerViewModel);
            AccountManager = new AccountManagerModel();
            GuestMemberReceiptModel = new GuestMemberReceiptModel();
            guestOrMemberDocument = new PrintDocument();
            MemberTypeList = new List<MemberTypesDataModel>();
            guestOrMemberDocument.PrintPage += GuestOrMemberDocument_PrintPage;
            PrintIsChecked = true;
            MemberTypeIsInvalid = false;

            AccountManager.IsShownLoading = true;
            AccountManager.IsGuestLogin = false;

            //Add branch code or id from art
            IsCardDetected = false;
        }

        public override async void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.AccountManagerWindow:
                    accountManagerWindow = (AccountManagerWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    AccountManager.BranchCreated = cashierData.Branch.Name;
                    AccountManager.CashierID = cashierData.ID;
                    Initialize();
                    break;

                case Messages.StationList:
                    AccountManager.WorkStationList = (List<WorkstationModel>)data;
                    break;

                case Messages.GuestAccount:
                    IsCardDetected = false;
                    break;

                case Messages.LoginGuest:
                    if (AccountManager.WorkStationList != null)
                    {
                        if (AccountManager.WorkStationList.Count > 0)
                        {
                            SelectedPC = AccountManager.WorkStationList[0].StationModel.ID;
                        }
                    }
                    AccountManager.IsGuestLogin = true;
                    AccountManager.IsMember = false;
                    break;

                case Messages.CardID:
                    if (!IsCardDetected)
                    {
                        AccountManager.CardIDNumber = (string)data;
                        IsCardDetected = true;
                        AccountManager.IsCardDetected = true;
                    }
                    break;

                case Messages.PCAssigned:
                    AccountManager.IsPCAssigned = true;
                    break;
                    
                default:
                    break;
            }
        }

        #region Private properties

        private AccountManagerWindow accountManagerWindow;
        private CashierDataModel cashierData;
        private List<PromoDataModel> memberPromoList;
        private List<PromoDataModel> guestPromoList;
        private AccountPromoModel selectedPromo;

        #endregion


        #region Properties

        private AccountManagerModel accountManager;
        public AccountManagerModel AccountManager
        {
            get { return accountManager; }
            set
            {
                accountManager = value;
                RaisePropertyChanged(nameof(AccountManager));
            }
        }

        private GuestMemberReceiptModel guestMemberReceiptModel;
        public GuestMemberReceiptModel GuestMemberReceiptModel
        {
            get { return guestMemberReceiptModel; }
            set
            {
                guestMemberReceiptModel = value;
                RaisePropertyChanged(nameof(GuestMemberReceiptModel));
            }
        }

        private MemberTypesDataModel memberTypesDataModel;
        public MemberTypesDataModel MemberTypesDataModel
        {
            get { return memberTypesDataModel; }
            set
            {
                memberTypesDataModel = value;
                RaisePropertyChanged(nameof(MemberTypesDataModel));
            }
        }

        private List<MemberTypesDataModel> memberTypeList;
        public List<MemberTypesDataModel> MemberTypeList
        {
            get { return memberTypeList; }
            set
            {
                memberTypeList = value;
                RaisePropertyChanged(nameof(MemberTypeList));
            }
        }

        private string selectedPC;
        public string SelectedPC
        {
            get { return selectedPC; }
            set
            {
                selectedPC = value;
                RaisePropertyChanged(nameof(SelectedPC));
            }
        }

        private string selectedMember;
        public string SelectedMemberType
        {
            get { return selectedMember; }
            set
            {
                selectedMember = value;
                RaisePropertyChanged(nameof(SelectedMemberType));
            }
        }

        private string bonusLoad;
        public string BonusLoad
        {
            get { return bonusLoad; }
            set
            {
                bonusLoad = value;
                RaisePropertyChanged(nameof(BonusLoad));
            }
        }

        private bool printIsChecked;
        public bool PrintIsChecked
        {
            get { return printIsChecked; }
            set
            {
                printIsChecked = value;
                RaisePropertyChanged(nameof(PrintIsChecked));
            }
        }

        private bool memberTypeIsInvalid;
        public bool MemberTypeIsInvalid
        {
            get { return memberTypeIsInvalid; }
            set
            {
                memberTypeIsInvalid = value;
                RaisePropertyChanged(nameof(memberTypeIsInvalid));
            }
        }

        #endregion

        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand<object> SelectPromoRow
        {
            get
            {
                return new DelegateCommand<object>(SelectedPromo);
            }
        }

        public DelegateCommand PayWithCashCommand
        {
            get
            {
                return new DelegateCommand(PayWithCash);
            }
        }

        public DelegateCommand MemberTypeCommand
        {
            get
            {
                return new DelegateCommand(MemberTypeClicked);
            }
        }

        public DelegateCommand GuestTypeCommand
        {
            get
            {
                return new DelegateCommand(GuestTypeClicked);
            }
        }

        public DelegateCommand TopUpLostFocusCommand
        {
            get
            {
                return new DelegateCommand(TopUpLostFocus);
            }
        }

        public DelegateCommand LostFocusCommand
        {
            get
            {
                return new DelegateCommand(AccountManager.LostFocus);
            }
        }

        public DelegateCommand SelectionChangedCommand
        {
            get
            {
                return new DelegateCommand(SelectionChange);
            }
        }

        public DelegateCommand ResetCardCommand
        {
            get
            {
                return new DelegateCommand(ResetCard);
            }
        }

        public DelegateCommand CheckCommand
        {
            get
            {
                return new DelegateCommand(AccountManager.ChangeFeeByPondo);
            }
        }

        #endregion

        #region Event handlers

        private void ReInitializeFields()
        {
            AccountManager.FirstName = string.Empty;
            AccountManager.MiddleName = string.Empty;
            AccountManager.LastName = string.Empty;
            AccountManager.CardIDNumber = string.Empty;
            AccountManager.IsMale = true;
            AccountManager.BirthDate = DateTime.Now;
            AccountManager.Username = string.Empty;
            AccountManager.PondoUsername = string.Empty;
            AccountManager.IsPondoChecked = false;
            AccountManager.EmailAddress = string.Empty;
            AccountManager.MobileNumber = string.Empty;
            selectedPromo = null;
            AccountManager.TotalFee = 0;
            AccountManager.SelectedPromoPrice = 0;
            AccountManager.HasSelectedPromo = false;
            AccountManager.TenderedMoney = 0;
            AccountManager.ValidatorTenderedMoney = "0.00";
            AccountManager.ValidatorTopUpFee = "0.00";
            AccountManager.ChangeFee = 0;
        }

        private async Task InitializeMemberTypes()
        {
            MemberServiceProvider memberService = new MemberServiceProvider();

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            bool wasTaskCanceled = false;

            List<MemberTypesDataModel> temporaryHandler = MemberTypeList;
            try
            {
                MemberTypeList = await TaskManagerModel<List<MemberTypesDataModel>>.Instance.Run(
                memberService.GetMemberTypes(DataCacheContext.CashierSessionID, cancellationTokenSource.Token),
                cancellationTokenSource,
                ToString());
            }
            catch (AggregateException aggregateException)
            {
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        MemberTypeList = temporaryHandler;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, accountManagerWindow);
                }
            }

            if (MemberTypeList == null)
            {
                if (!wasTaskCanceled)
                {
                    CloseWindowImmediately();
                }
            }
        }

        private void CheckPromoData()
        {
            if (AccountManager.AccountPromo == null || AccountManager.AccountPromo.Count <= 0)
            {
                AccountManager.IsPromoEmpty = true;
                AccountManager.AccountPromo = new ObservableCollection<AccountPromoModel>()
                {
                    new AccountPromoModel()
                    {
                        PromoAvailability = "-- NONE --",
                        IsSelected = true
                    }
                };
            }
            else
            {
                AccountManager.IsPromoEmpty = false;
            }
        }

        private async void LoadPromoByMemberType()
        {
            int allStationType = -1;
            MemberServiceProvider memberService = new MemberServiceProvider();

            try
            {
                ExceptionDispatchInfo capturedException = null;

                try
                {
                    AccountManager.IsShownLoading = true;
                    AccountManager.AccountPromo = new ObservableCollection<AccountPromoModel>();
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                    });

                    try
                    {
                        memberPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                        GetMemberId(SelectedMemberType), allStationType, false, PromoTimeZone.Manila, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                memberPromoList = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, accountManagerWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    AccountManager.IsShownLoading = false;
                    if (memberPromoList != null)
                    {
                        memberPromoList.ForEach(promo => promo.Price = promo.Price / 100);

                        LoadMemberPromo();
                    }
                    else
                    {
                        CloseWindowImmediately();
                    }
                }
                catch (Exception ex)
                {
                    // Store exception at a ExceptionDispatchInfo when
                    // error happens at the awaiting asynchronous operation.
                    ExceptionDispatchInfo.Capture(ex);
                    ShowServerCommunicationIssueError(StandardMessageResource.TransactLoadPromo, true);
                }


                if (capturedException != null)
                {
                    // This can be used also for logging into a text file or any log file.
#if DEBUG
                    // Temporarily log at the Output panel when debugging.
                    System.Diagnostics.Debug
                    .WriteLine($"AccountManagerWindowViewModel.LoadAllPromo: {capturedException.SourceException.Message}");
#endif
                }
            }
            catch (Exception)
            {

            }
        }

        private async Task LoadMemberTypes()
        {
            try
            {
                MemberServiceProvider memberService = new MemberServiceProvider();

                ExceptionDispatchInfo capturedException = null;

                try
                {
                    //Get membertype async
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                    });

                    List<MemberTypesDataModel> temporaryHandler = MemberTypeList;
                    try
                    {
                        MemberTypeList = await TaskManagerModel<List<MemberTypesDataModel>>.Instance.Run(memberService.GetMemberTypes(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                        MemberTypeList = MemberTypeList.OrderByDescending(x => x.Rank).ToList();

                        if(MemberTypeList != null)
                        {
                            SelectedMemberType = MemberTypeList.FirstOrDefault().Name;
                            AccountManager.MemberShipFee = MemberTypeList.FirstOrDefault().MembershipFee / 100;
                            AccountManager.ComputeTotalFee();
                        }
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                MemberTypeList = temporaryHandler;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, accountManagerWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (MemberTypeList == null)
                    {
                        CloseWindowImmediately();
                    }
                }
                catch (Exception ex)
                {
                    // Store exception at a ExceptionDispatchInfo when
                    // error happens at the awaiting asynchronous operation.
                    ExceptionDispatchInfo.Capture(ex);
                    ShowServerCommunicationIssueError(StandardMessageResource.TransactLoadPromo, true);
                }

                if (capturedException != null)
                {
                    // This can be used also for logging into a text file or any log file.
#if DEBUG
                    // Temporarily log at the Output panel when debugging.
                    System.Diagnostics.Debug
                    .WriteLine($"AccountManagerWindowViewModel.LoadMemberTypes: {capturedException.SourceException.Message}");
#endif
                }
            }
            catch (Exception)
            {

            }
        }

        private async Task LoadAllPromo()
        {
            try
            {
                MemberServiceProvider memberService = new MemberServiceProvider();

                int allStationType = -1;

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                });

                ExceptionDispatchInfo capturedException = null;

                try
                {
                    if (AccountManager.IsMember)
                    {
                        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                        memberPromoList = null;
                        try
                        {
                            if (DataCacheContext.CashierSessionID != null && MemberTypeList != null)
                            {
                                if (AccountManager.IsPCAssigned)
                                {
                                    memberPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                                    GetMemberId(SelectedMemberType), Int16.Parse(AccountManager.WorkStationList[0].StationModel.StationType.ID), false, PromoTimeZone.Manila, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                                }
                                else
                                {
                                    memberPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                                    GetMemberId(SelectedMemberType), allStationType, false, PromoTimeZone.Manila, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                                }
                            }
                        }
                        catch (AggregateException aggregateException)
                        {
                            bool wasTaskCanceled = false;
                            foreach (var exception in aggregateException.InnerExceptions)
                            {
                                if (exception is TaskCanceledException)
                                {
                                    memberPromoList = null;
                                    wasTaskCanceled = true;
                                    break;
                                }
                            }

                            if (!wasTaskCanceled)
                            {
                                ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, accountManagerWindow);
                            }
                        }

                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = false;
                        });

                        if (memberPromoList != null)
                        {
                            memberPromoList.ForEach(promo => promo.Price = promo.Price / 100);
                            LoadMemberPromo();
                        }
                        else
                        {
                            App.Current.Dispatcher.Invoke(() =>
                            {
                                CloseWindowImmediately();
                            });
                        }
                    }
                    else
                    {

                        CancellationTokenSource guestCancellationTokenSource = new CancellationTokenSource();

                        guestPromoList = null;
                        try
                        {
                            if (DataCacheContext.CashierSessionID != null && MemberTypeList != null)
                            {
                                if (AccountManager.IsPCAssigned)
                                {
                                    guestPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                                    GetMemberId(SelectedMemberType), Int16.Parse(AccountManager.WorkStationList[0].StationModel.StationType.ID), true, PromoTimeZone.Manila, guestCancellationTokenSource.Token), guestCancellationTokenSource, ToString());
                                }
                                else
                                {
                                    guestPromoList = await TaskManagerModel<List<PromoDataModel>>.Instance.Run(memberService.GetPromos(DataCacheContext.CashierSessionID,
                                    GetMemberId(SelectedMemberType), allStationType, true, PromoTimeZone.Manila, guestCancellationTokenSource.Token), guestCancellationTokenSource, ToString());
                                }
                            }
                        }
                        catch (AggregateException aggregateException)
                        {
                            bool wasTaskCanceled = false;
                            foreach (var exception in aggregateException.InnerExceptions)
                            {
                                if (exception is TaskCanceledException)
                                {
                                    guestPromoList = null;
                                    wasTaskCanceled = true;
                                    break;
                                }
                            }

                            if (!wasTaskCanceled)
                            {
                                ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, accountManagerWindow);
                            }
                        }

                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = false;
                        });

                        if (guestPromoList != null)
                        {
                            guestPromoList.ForEach(promo => promo.Price = promo.Price / 100);
                            LoadGuestPromo();
                        }
                        else
                        {
                            App.Current.Dispatcher.Invoke(() =>
                            {
                                CloseWindowImmediately();
                            });
                        }
                    }
                    AccountManager.IsShownLoading = false;
                }
                catch (Exception ex)
                {
                    // Store exception at a ExceptionDispatchInfo when
                    // error happens at the awaiting asynchronous operation.
                    ExceptionDispatchInfo.Capture(ex);
                    ShowServerCommunicationIssueError(StandardMessageResource.TransactLoadPromo, true);
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.TopUpManagerWindow);
                }


                if (capturedException != null)
                {
                    // This can be used also for logging into a text file or any log file.
#if DEBUG
                    // Temporarily log at the Output panel when debugging.
                    System.Diagnostics.Debug
                    .WriteLine($"AccountManagerWindowViewModel.LoadAllPromo: {capturedException.SourceException.Message}");
#endif
                }
            }
            catch (Exception)
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.TopUpManagerWindow);
            }
        }

        private async void LoadMemberPromo()
        {

            if (memberPromoList == null)
            {
                await Task.Run(async () =>
                {
                    await InitializeMemberTypes();
                    await LoadAllPromo();
                });
            }

            App.Current.Dispatcher.Invoke(() =>
            {
                AccountManager.IsShownLoading = false;

                AccountManager.AccountPromo = new ObservableCollection<AccountPromoModel>()   ;
                foreach (PromoDataModel promo in memberPromoList)
                {
                    DateTime sTime = DateTime.ParseExact(promo.StartTime, "HH:mm:ss", CultureInfo.InvariantCulture);
                    DateTime eTime = DateTime.ParseExact(promo.EndTime, "HH:mm:ss", CultureInfo.InvariantCulture);

                    string promoDuration = string.Empty;
                    if (promo.Duration == 0)
                    {
                        promoDuration = "0m";
                    }
                    else if ((promo.Duration < 60 && promo.Duration > 0) || (promo.Duration > -60 && promo.Duration < 0))
                    {
                        promoDuration = (promo.Duration / 60.0).ToString("N1") + "m";
                    }
                    else
                    {
                        promoDuration = TimeSpan.FromSeconds(promo.Duration).ToString(@"dd\:hh\:mm").ConvertDateTimeToStringWithoutSec();
                    }

                    AccountManager.IsPromoEmpty = false;
                    AccountManager.AccountPromo.Add(new AccountPromoModel()
                    {
                        PackageCode = promo.Code,
                        PackageID = promo.ID,
                        PackageDescription = promo.Description,
                        Amount = promo.Price,
                        EndTime = eTime.ToString("hh:mm tt"),
                        StartTime = sTime.ToString("hh:mm tt"),
                        PromoAvailability = $"{sTime.ToString("hh:mm tt")} - {eTime.ToString("hh:mm tt")}",
                        IsSelected = false,
                        PackageType = promo.PromoType,
                        Duration = promoDuration
                    });
                }
            });

            CheckPromoData();
        }

        private async void LoadGuestPromo()
        {

            if (guestPromoList == null)
            {
                await Task.Run(async () =>
                {
                    await InitializeMemberTypes();
                    await LoadAllPromo();
                });
            }

            App.Current.Dispatcher.Invoke(() =>
            {
                AccountManager.AccountPromo = new ObservableCollection<AccountPromoModel>();

                foreach (PromoDataModel promo in guestPromoList)
                {
                    DateTime sTime = DateTime.ParseExact(promo.StartTime, "HH:mm:ss", CultureInfo.InvariantCulture);
                    DateTime eTime = DateTime.ParseExact(promo.EndTime, "HH:mm:ss", CultureInfo.InvariantCulture);

                    string promoDuration = string.Empty;

                    if (promo.Duration == 0)
                    {
                        promoDuration = "0m";
                    }
                    else if ((promo.Duration < 60 && promo.Duration > 0) || (promo.Duration > -60 && promo.Duration < 0))
                    {
                        promoDuration = (promo.Duration / 60.0).ToString("N1") + "m";
                    }
                    else
                    {
                        promoDuration = TimeSpan.FromSeconds(promo.Duration).ToString(@"dd\:hh\:mm").ConvertDateTimeToStringWithoutSec();
                    }

                    AccountManager.IsPromoEmpty = false;
                    AccountManager.AccountPromo.Add(new AccountPromoModel()
                    {
                        PackageCode = promo.Code,
                        PackageID = promo.ID,
                        PackageDescription = promo.Description,
                        Amount = promo.Price,
                        EndTime = eTime.ToString("hh:mm tt"),
                        StartTime = sTime.ToString("hh:mm tt"),
                        PromoAvailability = $"{sTime.ToString("hh:mm tt")} - {eTime.ToString("hh:mm tt")}",
                        IsSelected = false,
                        PackageType = promo.PromoType,
                        Duration = promoDuration
                    });
                }
            });

            CheckPromoData();
        }

        private string GetTotalTime(string startTime, string endTime)
        {
            TimeSpan totalTime = new TimeSpan();
            DateTime start = DateTime.Parse(startTime);
            DateTime end = DateTime.Parse(endTime);
            totalTime = end - start;

            return ($"{totalTime.Hours}:{totalTime.Minutes}");
        }

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.AccountManagerViewModel);
                    if (accountManagerWindow != null)
                    {
                        if (accountManagerWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            accountManagerWindow.DialogResult = false;
                            accountManagerWindow.Close();
                        }
                    }
                }
            });
        }

        private void TopUpLostFocus()
        {
            double doubleTopup = double.Parse(AccountManager.ValidatorTopUpFee, CultureInfo.InvariantCulture);
            if (doubleTopup > 10000)
            {
                AccountManager.ValidatorTopUpFee = "10000";
            }
            else
            {
                decimal topup = Convert.ToDecimal(doubleTopup);
                topup = Math.Truncate(topup * 100) / 100;
                AccountManager.ValidatorTopUpFee = topup.ToString();
            }
        }

        private void SelectionChange()
        {
            if (AccountManager.IsMember)
            {
                MemberTypesDataModel = MemberTypeList.Find(x => x.Name == SelectedMemberType);
                if (MemberTypesDataModel != null)
                {
                    AccountManager.MemberShipFee = MemberTypesDataModel.MembershipFee / 100;
                }
                AccountManager.ComputeTotalFee();
                AccountManager.ComputeChange();
                ChangeMemberFee();
                LoadPromoByMemberType();
            }
        }

        private void ChangeMemberFee()
        {
            var memberType = MemberTypeList.Where(x => x.Name == SelectedMemberType).FirstOrDefault();
            if (memberType != null)
            {
                AccountManager.InitialMemberLoad = Convert.ToDecimal(memberType.InitialLoad.ToString().ConvertIntToMoney());
            }
        }

        private void SelectedPromo(object parameter)
        {
            for (int x = 0; x < AccountManager.AccountPromo.Count; x++)
            {
                AccountManager.AccountPromo[x].IsSelected = false;
            }

            selectedPromo = (AccountPromoModel)parameter;
            if (selectedPromo.StartTime != "-- NONE --")
            {
                selectedPromo.IsSelected = true;

                if (selectedPromo.PackageID == AccountManager.SelectedPromoID)
                {
                    selectedPromo.IsSelected = false;
                    AccountManager.HasSelectedPromo = false;
                    AccountManager.SelectedPromoDescription = string.Empty;
                    AccountManager.SelectedPromoPrice = 0;
                    AccountManager.SelectedPromoID = string.Empty;
                }
                else
                {
                    AccountManager.HasSelectedPromo = true;
                    AccountManager.SelectedPromoDescription = selectedPromo.PackageDescription;
                    AccountManager.SelectedPromoPrice = Convert.ToDecimal(selectedPromo.Amount);
                    AccountManager.SelectedPromoID = selectedPromo.PackageID;
                }

                AccountManager.ComputeTotalFee();
                AccountManager.ComputeChange();
                AccountManager.ValidatorTopUpFee = AccountManager.ValidatorTopUpFee;
            }
        }

        private async void PayWithCash()
        {
            if (IsProcessing)
            {
                return;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
            });

            if (AccountManager.IsMember)
            {
                if (!AccountManager.ValidateMember())
                {
                    await MemberPayWithCash();
                }
            }
            else
            {
                await GuestPayWithCash();
            }
            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });
        }

        private async Task MemberPayWithCash()
        {
            try
            {
                string password = GenerateRandomPassword(1);
                string CardId = AccountManager.CardIDNumber; //Change it to AccountManager.CardIDNumber before actual deploy
                string message = string.Empty;
                string messageMode = string.Empty;

                if (CardId != null && CardId != string.Empty)
                {
                    if (AccountManager.IsSubmitButtonEnabled)
                    {
                        MemberServiceProvider memberServiceProvider = new MemberServiceProvider();
                        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                        CashierServiceProvider cashierServiceProvider = new CashierServiceProvider();

                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = true;
                        });

                        Tuple<AccountDataModel, ResponseModel> memberData = null;
                        try
                        {
                            if (cashierData.AccessKey == null)
                            {
                                var cashierKey = await TaskManagerModel<CashierKeyTokenDataModel>.Instance.Run(cashierServiceProvider.GenerateCashierKeyToken(
                                                            DataCacheContext.CashierSessionID,
                                                            cashierData.AccessToken,
                                                            cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);

                                if (cashierKey != null)
                                {
                                    if (cashierKey.AccessToken != null)
                                    {
                                        cashierData.AccessToken = cashierKey.AccessToken;
                                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessToken, cashierKey.AccessToken);
                                    }

                                    if (cashierKey.Key != null)
                                    {
                                        cashierData.AccessKey = cashierKey.Key;
                                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, cashierKey.Key);
                                    }
                                }
                                else
                                {
                                    cashierKey = await TaskManagerModel<CashierKeyTokenDataModel>.Instance.Run(cashierServiceProvider.RetrieveCashierKeyToken(
                                                            DataCacheContext.CashierSessionID,
                                                            cashierData.AccessToken,
                                                            cashierData.AccessKey,
                                                            cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);

                                    if (cashierKey == null)
                                    {
                                        ShowConfirmationWindow(StandardMessageResource.ErrorSystemCalibrationRequired, Messages.ErrorConfirmation, accountManagerWindow);
                                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.SwitchToLoginView, null);
                                    }

                                    if (cashierKey.AccessToken != null)
                                    {
                                        cashierData.AccessToken = cashierKey.AccessToken;
                                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessToken, cashierKey.AccessToken);
                                    }

                                    if (cashierKey.Key != null)
                                    {
                                        cashierData.AccessKey = cashierKey.Key;
                                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, cashierKey.Key);
                                    }
                                }
                            }

                            string signatureKey = HmacHash.HashHMACHex(cashierData.AccessKey, $"{AccountManager.Username}{GetTransactionAmount()}{DataCacheContext.CashierSessionID}{PaymentType.Cash}{GetSelectedPromoId()}");

                            DateTime dateTime;
                            bool dateValidation = DateTime.TryParseExact(AccountManager.SelectedDate, DateFormatDefinition.DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime);
                            
                            memberData = await TaskManagerModel<Tuple<AccountDataModel, ResponseModel>>.Instance.Run(memberServiceProvider.GenerateMemberAccount(
                                AccountManager.Username,
                                password,
                                DataCacheContext.CashierSessionID,
                                GetTransactionAmount(),
                                PaymentType.Cash,
                                AccountManager.EmailAddress,
                                AccountManager.FirstName,
                                AccountManager.MiddleName,
                                AccountManager.LastName,
                                string.Empty, string.Empty,
                                dateTime.ToString("yyyy-MM-dd"),
                                GetGender(),
                                AccountManager.MobileNumber,
                                GetMemberId(SelectedMemberType),
                                DateTime.Now.ToString("yyyy-MM-dd"),
                                CardId,
                                GetSelectedPromoId(),
                                AccountManager.Occupation,
                                signatureKey,
                                AccountManager.IsPondoChecked,
                                AccountManager.PondoUsername,
                                cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                        }
                        catch (AggregateException aggregateException)
                        {
                            bool wasTaskCanceled = false;
                            foreach (var exception in aggregateException.InnerExceptions)
                            {
                                if (exception is TaskCanceledException)
                                {
                                    memberData = null;
                                    wasTaskCanceled = true;
                                    break;
                                }
                            }

                            if (!wasTaskCanceled)
                            {
                                ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, accountManagerWindow);
                            }
                        }

                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = false;
                        });

                        if (memberData != null && memberData.Item2.HttpStatusCode == 422)
                        {
                            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, null);
                        }

                        if (memberData != null && memberData.Item2.HttpStatusCode != 422)
                        {
                            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, null);

                            message = $"Username: {memberData.Item1.Username}\nPassword: {memberData.Item1.Password}";
                            messageMode = Messages.SuccessConfirmation;
                            TransactionModel transactionModel = CreateMemberTransactionModel(memberData.Item1.ID, GetTransactionRemarks(), $"{AccountManager.Username}");

                            // This is currently maintained at App.config
                            if (DataCacheContext.UseLocalDB)
                            {
                                SaveTransactionToLocalDB(transactionModel, password);
                            }

                            Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, transactionModel);

                            if ((message != string.Empty && messageMode != string.Empty) && !ShowConfirmationWindow(message, messageMode, accountManagerWindow))
                            {
                                return;
                            }
                        }
                        else
                        {
                            if (SelectedMemberType == "" || SelectedMemberType == null)
                            {
                                MemberTypeIsInvalid = false;
                                MemberTypeIsInvalid = true;
                            }
                            else
                            {
                                MemberTypeIsInvalid = false;
                            }
                        }

                        if (messageMode == Messages.SuccessConfirmation)
                        {
                            if (PrintIsChecked)
                            {
                                PrintMember(memberData.Item1.Username, memberData.Item1.Password, selectedMember);
                            }
                            CloseWindowImmediately();
                        }
                    }
                }
                else
                {
                    message = StandardMessageResource.ErrorCardNotTapped;
                    messageMode = Messages.ErrorConfirmation;
                    ShowConfirmationWindow(message, messageMode, accountManagerWindow);
                }
            }
            catch (Exception ex)
            {
                ShowServerCommunicationIssueError();
            }
        }

        private async Task GuestPayWithCash()
        {
            if (AccountManager.IsSubmitButtonEnabled)
            {
                try
                {
                    Tuple<AccountDataModel, ResponseModel> memberData;
                    string responseMessage = string.Empty;
                    string password = GenerateRandomPassword(0);

                    MemberServiceProvider memberServiceProvider = new MemberServiceProvider();
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                    CashierServiceProvider cashierServiceProvider = new CashierServiceProvider();

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                    });

                    memberData = null;
                    try
                    {
                        if (cashierData.AccessKey == null)
                        {
                            var cashierKey = await TaskManagerModel<CashierKeyTokenDataModel>.Instance.Run(cashierServiceProvider.GenerateCashierKeyToken(
                                                        DataCacheContext.CashierSessionID,
                                                        cashierData.AccessToken,
                                                        cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);

                            if (cashierKey != null)
                            {
                                if (cashierKey.AccessToken != null)
                                {
                                    cashierData.AccessToken = cashierKey.AccessToken;
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessToken, cashierKey.AccessToken);
                                }

                                if (cashierKey.Key != null)
                                {
                                    cashierData.AccessKey = cashierKey.Key;
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, cashierKey.Key);
                                }
                            }
                            else
                            {
                                cashierKey = await TaskManagerModel<CashierKeyTokenDataModel>.Instance.Run(cashierServiceProvider.RetrieveCashierKeyToken(
                                                        DataCacheContext.CashierSessionID,
                                                        cashierData.AccessToken,
                                                        cashierData.AccessKey,
                                                        cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);

                                if (cashierKey == null)
                                {
                                    ShowConfirmationWindow(StandardMessageResource.ErrorSystemCalibrationRequired, Messages.ErrorConfirmation, accountManagerWindow);
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.SwitchToLoginView, null);
                                }

                                if (cashierKey.AccessToken != null)
                                {
                                    cashierData.AccessToken = cashierKey.AccessToken;
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessToken, cashierKey.AccessToken);
                                }

                                if (cashierKey.Key != null)
                                {
                                    cashierData.AccessKey = cashierKey.Key;
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, cashierKey.Key);
                                }
                            }
                        }

                        string signatureKey = HmacHash.HashHMACHex(cashierData.AccessKey, $"{GetTransactionAmount()}{DataCacheContext.CashierSessionID}{PaymentType.Cash}{GetSelectedPromoId()}");

                        memberData = await TaskManagerModel<Tuple<AccountDataModel, ResponseModel>>.Instance.Run(memberServiceProvider.GenerateGuestAccount(
                            password,
                            DataCacheContext.CashierSessionID,
                            GetTransactionAmount(),
                            PaymentType.Cash,
                            GetSelectedPromoId(),
                            signatureKey,
                            cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                memberData = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, accountManagerWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    string message = string.Empty;
                    string messageMode = string.Empty;

                    if (memberData != null && memberData.Item2.HttpStatusCode == 422)
                    {
                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, null);
                    }

                    if (memberData != null && memberData.Item2.HttpStatusCode != 422)
                    {
                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.RefreshAccessKey, null);
                        bool isAvailable = false;

                        if (!string.IsNullOrEmpty(selectedPC))
                        {
                            isAvailable = ValidatePCAvailability(selectedPC);
                        }

                        if (isAvailable)
                        {
                            var guestModel = MapToGuestAccountModel(memberData.Item1);
                            guestModel.StationID = selectedPC;
                            NetworkServer.Instance.SendMessageToClientUsingStationID(guestModel.StationID, NetworkMessageType.GuestLogin, guestModel);
                        }

                        message = $"Username: {memberData.Item1.Username}\nPassword: {memberData.Item1.Password}";
                        messageMode = Messages.SuccessConfirmation;
                        TransactionModel transactionModel = CreateGuestTransactionModel(memberData.Item1.ID, GetTransactionRemarks(), memberData.Item1.Username);

                        // This is currently maintained at App.config
                        if (DataCacheContext.UseLocalDB)
                        {
                            SaveTransactionToLocalDB(transactionModel, password);
                        }

                        Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, transactionModel);

                        if (!ShowConfirmationWindow(message, messageMode, accountManagerWindow))
                        {
                            return;
                        }

                    }

                    if (messageMode == Messages.SuccessConfirmation)
                    {
                        if (PrintIsChecked)
                        {
                            PrintGuest(memberData.Item1.Username, memberData.Item1.Password, memberData.Item1.ExpiryDateTime);
                        }
                        CloseWindowImmediately();
                    }
                }
                catch (Exception)
                {
                    ShowServerCommunicationIssueError();
                }
            }
        }

        private void PrintMember(string username, string password, string member)
        {
            GuestMemberReceiptModel.Cashier = cashierData.Name;
            GuestMemberReceiptModel.Name = $"{AccountManager.FirstName} {AccountManager.LastName}";
            GuestMemberReceiptModel.UserName = username;
            GuestMemberReceiptModel.Password = password;
            GuestMemberReceiptModel.UserLevel = member;
            printBalance = (AccountManager.TopUpFee + Convert.ToDecimal(AccountManager.InitialMemberLoad)).ToString("N2");

            PrintAccount();
        }

        private void PrintGuest(string username, string password, string expiryDate)
        {
            GuestMemberReceiptModel.Cashier = cashierData.Name;
            GuestMemberReceiptModel.Name = "Guest";
            GuestMemberReceiptModel.UserName = username;
            GuestMemberReceiptModel.Password = password;
            GuestMemberReceiptModel.UserLevel = "Guest";
            GuestMemberReceiptModel.ExpirationDate = Convert.ToDateTime(expiryDate);
            printBalance = AccountManager.TopUpFee.ToString("N2");
            PrintAccount();
        }

        public void PrintAccount()
        {
            try
            {
                PrintDialog printDialog = new PrintDialog();
                printDialog.Document = guestOrMemberDocument;

                printDialog.UseEXDialog = true;
                printDialog.PrinterSettings.PrinterName = DataCacheContext.PrinterName;
                guestOrMemberDocument.DocumentName = PrinterMessageResource.AccountDocumentName;
                guestOrMemberDocument.Print();
            }
            catch (Exception)
            {
                string message = StandardMessageResource.ErrorPrinter;
                string messageMode = Messages.ErrorConfirmation;
                ShowConfirmationWindow(message, messageMode, accountManagerWindow);
            }
        }

        private void GuestOrMemberDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            int yAxis = 0;
            int yMargin = 16;
            int yLine = 2;

            yAxis = PrintExcessCharacterOnNewLine(e, string.Empty, cashierData.Branch.Name, true, 35, 0, 0, yAxis, yMargin, yLine, FontStyle.Bold);

            e.Graphics.DrawString($"{PrinterMessageResource.Cashier}: {GuestMemberReceiptModel.Cashier}", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * 3));

            yAxis = PrintExcessCharacterOnNewLine(e, PrinterMessageResource.Name, GuestMemberReceiptModel.Name, false, 20, 10, 46, yAxis, yMargin, yLine, FontStyle.Regular);

            if (GuestMemberReceiptModel.UserName.Length > 15)
            {
                string cropUsernameFirstLine = GuestMemberReceiptModel.UserName.Substring(0, 16);
                string cropUsernameSecondLine = GuestMemberReceiptModel.UserName.Substring(16);
                e.Graphics.DrawString($"{PrinterMessageResource.Username}: {cropUsernameFirstLine}", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));
                e.Graphics.DrawString($"{cropUsernameSecondLine}", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 74, yAxis += yMargin);
            }

            else if (GuestMemberReceiptModel.UserName.Length <= 15)
            {
                e.Graphics.DrawString($"{PrinterMessageResource.Username}: {GuestMemberReceiptModel.UserName}", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));
            }

            e.Graphics.DrawString($"{PrinterMessageResource.Password}: {GuestMemberReceiptModel.Password}", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);

            e.Graphics.DrawString($"{PrinterMessageResource.UserLevel}: {GuestMemberReceiptModel.UserLevel}", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);

            e.Graphics.DrawString($"{PrinterMessageResource.Balance}: {printBalance}", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));

            if (selectedPromo != null && selectedPromo.IsSelected)
            {
                e.Graphics.DrawString($"{PrinterMessageResource.PromoAvailed}:", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);
                e.Graphics.DrawString($"{selectedPromo.PackageCode}", new Font("Arial Narrow", 8F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin));
            }

            if (AccountManager.IsMember)
            {
                e.Graphics.DrawString($"{PrinterMessageResource.CreatedDateTime}:", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));
                e.Graphics.DrawString(DateTime.Now.ToString(), new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);
            }
            else
            {
                e.Graphics.DrawString($"{PrinterMessageResource.ExpirationDateTime}:", new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += (yMargin * yLine));
                e.Graphics.DrawString(GuestMemberReceiptModel.ExpirationDate.ToString(), new Font("Arial Narrow", 9F, FontStyle.Regular), new SolidBrush(Color.Black), 10, yAxis += yMargin);
            }
            
        }

        private void ShowServerCommunicationIssueError()
        {
            string message = string.Format(StandardMessageResource.ErrorConnectionIssue, StandardMessageResource.TransactWordCreateAccount, StandardMessageResource.TransactWordServer);
            string messageMode = Messages.ErrorConfirmation;
            ShowConfirmationWindow(message, messageMode, accountManagerWindow);
        }

        private void ShowServerCommunicationIssueError(string errorMessage, bool isFromAsync)
        {
            string message = string.Format(StandardMessageResource.ErrorConnectionIssue, errorMessage, StandardMessageResource.TransactWordServer);
            string messageMode = Messages.ErrorConfirmation;

            if (isFromAsync)
            {
                App.Current.Dispatcher.Invoke(() =>
                {
                    ShowConfirmationWindow(message, messageMode, accountManagerWindow);
                });
            }

            ShowConfirmationWindow(message, messageMode, accountManagerWindow);
        }

        private string GetTransactionRemarks()
        {
            string topupRemarks = string.Empty;

            if (AccountManager.IsMember)
            {
                topupRemarks += $"MEMBER - MembershipFee: ₱{AccountManager.MemberShipFee} ";
            }
            else
            {
                topupRemarks += $"GUEST - ";
            }

            if (AccountManager.TopUpFee != 0)
            {
                topupRemarks += $"Top-up: ₱{AccountManager.TopUpFee} ";
            }

            if (selectedPromo != null && selectedPromo.IsSelected)
            {
                topupRemarks += $"Promo: {selectedPromo.PackageCode} ";
            }

            return topupRemarks;
        }

        private TransactionModel CreateMemberTransactionModel(string id, string remarks, string name = null)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = NewAccount,
                CustomerName = name,
                CustomerID = id,
                TransactionAmount = $"{CurrencySymbol}{(Convert.ToDouble(GetTransactionAmount()) / 100).ToString("N2")}",
                TransactionRemarks = remarks,
                MemberType = selectedMember
            };
            return transactionModel;
        }

        private TransactionModel CreateGuestTransactionModel(string id, string remarks, string name = null)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = NewAccount,
                CustomerName = name,
                CustomerID = id,
                TransactionAmount = $"{CurrencySymbol}{(Convert.ToDouble(GetTransactionAmount()) / 100).ToString("N2")}",
                TransactionRemarks = remarks,
                MemberType = "N/A",
            };
            return transactionModel;
        }

        private bool ValidatePCAvailability(string stationID)
        {
            if (DataCacheContext.WorkstationModels.Count() == 0)
            {
                return false;
            }

            var connectedClients = DataCacheContext.WorkstationModels.Values.ToList().Where(pc => pc.PCID == stationID);

            if (connectedClients.Count() == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private GuestAccountModel MapToGuestAccountModel(AccountDataModel memberData)
        {
            GuestAccountModel model = new GuestAccountModel
            {
                Username = memberData.Username,
                Password = memberData.Password
            };

            return model;
        }

        private void MemberTypeClicked()
        {
            LoadMemberPromo();
            AccountManager.ResetFirstLoadFields();
            ReInitializeFields();

        }

        private void GuestTypeClicked()
        {
            LoadGuestPromo();
            AccountManager.ResetFirstLoadFields();
            ReInitializeFields();
        }

        private int GetMemberId(string memberName)
        {
            int memberId = 0;

            foreach (MemberTypesDataModel memberType in MemberTypeList)
            {
                if (memberType.Name == memberName)
                {
                    return memberType.ID;
                }
            }

            return memberId;
        }

        private string GetSelectedPromoId()
        {
            if (selectedPromo != null && selectedPromo.IsSelected)
            {
                return selectedPromo.PackageID;
            }
            else
            {
                return "";
            }
        }

        private string GetGender()
        {
            if (AccountManager.IsMale)
            {
                return "MALE";
            }
            else
            {
                return "FEMALE";
            }
        }

        private int GetTransactionAmount()
        {

            return (int)(AccountManager.TotalFee * 100);
        }

        private string GenerateRandomPassword(int mode)
        {
            Random rndNumber = new Random();

            if (mode == 1)
            {
                return rndNumber.Next(10000000, 99999999).ToString();
            }
            else
            {
                return rndNumber.Next(1000, 9999).ToString();
            }
        }

        private string GenerateRandomNumber()
        {
            Random rndNumber = new Random();
            return rndNumber.Next(0, 99999999).ToString();
        }

        #endregion

        #region Private methods

        private void SaveTransactionToLocalDB(TransactionModel transactionModel, string password = "")
        {

            if (TransactionRepository != null)
            {
                // Maps to entity and then save the changes (persist) at local DB.
                TransactionRepository.Add(TransactionLogMapper.MapNewAccount(transactionModel, cashierData, selectedPromo,
                    PaymentType.Cash, AccountManager, GetTransactionAmount(), password));
                TransactionRepository.SaveAsync();
            }

        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.AccountManagerViewModel);
                if (accountManagerWindow != null)
                {
                    if (accountManagerWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        accountManagerWindow.DialogResult = false;
                        accountManagerWindow.Close();
                    }
                }
            });
        }

        private async void Initialize()
        {
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            try
            {
                await TaskManagerModel<List<UserDataModel>>.Instance.Run(
                    Task.Run(async () =>
                    {
                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = true;
                        });

                        cancellationTokenSource.Token.ThrowIfCancellationRequested();
                        await LoadMemberTypes();

                        cancellationTokenSource.Token.ThrowIfCancellationRequested();
                        await LoadAllPromo();

                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = false;
                        });
                    },
                    cancellationTokenSource.Token),
                 cancellationTokenSource,
                 ToString()
                 );
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, accountManagerWindow);
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });
            }
        }

        private void ResetCard()
        {
            IsCardDetected = false;
            AccountManager.IsCardDetected = false;
        }

        #endregion
    }
}
