﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Windows.Input;

namespace gocafe_cashier.ViewModel.Member
{
    public class CurrentShiftSummaryWindowViewModel : BaseModel
    {
        public CurrentShiftSummaryWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.CurrentShiftSummaryWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.CurrentShiftSummaryWindow:
                    currentShiftSummaryWindow = (CurrentShiftSummaryWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.EndShiftData:
                    EndShiftModel = (EndShiftModel)data;
                    break;

                case Messages.CashierInfo:
                    cashierInformation = (CashierDataModel)data;
                    break;
            }
        }

        #region Private Variables

        private CurrentShiftSummaryWindow currentShiftSummaryWindow;
        private CashierDataModel cashierInformation;

        #endregion



        #region Properties

        private EndShiftModel endShiftModel;
        public EndShiftModel EndShiftModel
        {
            get { return endShiftModel; }
            set
            {
                endShiftModel = value;
                RaisePropertyChanged(nameof(EndShiftModel));
            }
        }

        #endregion

        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand SaveCommand
        {
            get
            {
                return new DelegateCommand(SaveReport);
            }
        }

        #endregion

        private void SaveReport()
        {
            try
            {
                PDF.Pdf pdfCreator = new PDF.Pdf();
                if(pdfCreator.CreatePdf(cashierInformation.Name, cashierInformation.Branch.Name, EndShiftModel))
                {
                    ShowConfirmationWindow(StandardMessageResource.SuccessReportGenerated, Messages.SuccessConfirmation, currentShiftSummaryWindow);
                }
            }
            catch (Exception ex)
            {

            }
        }

        public void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.CurrentShiftSummaryWindowViewModel);
                    if (currentShiftSummaryWindow != null)
                    {
                        if (currentShiftSummaryWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            currentShiftSummaryWindow.DialogResult = false;
                            currentShiftSummaryWindow.Close();
                        }
                    }
                }
            });
        }
    }
}
