﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ViewModel.Member
{
    public class LogOutCustomerWindowViewModel: BaseModel
    {
        public LogOutCustomerWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.LogOutCustomerWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.LogOutCustomerWindow:
                    logOutCustomerWindow = (LogOutCustomerWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    break;

                default:
                    break;
            }
        }

        #region Private Fields

        LogOutCustomerWindow logOutCustomerWindow;
        CashierDataModel cashierData;
        MemberServiceProvider memberService = new MemberServiceProvider();

        #endregion

        #region Properties

        private string userName;

        public string UserName
        {
            get { return userName; }
            set
            {
                userName = value;
                RaisePropertyChanged(nameof(UserName));

                if (userName == null || userName == string.Empty)
                {
                    IsSubmitButtonEnabled = false;
                }
                else
                {
                    IsSubmitButtonEnabled = true;
                }
            }
        }

        private bool isSubmitButtonEnabled;

        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }


        #endregion

        #region Commands
        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand SubmitCommand
        {
            get
            {
                return new DelegateCommand(LogOutCustomer);
            }
        }
        #endregion

        #region Event Handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.LogOutCustomerWindowViewModel);
                    if (logOutCustomerWindow != null)
                    {
                        if (logOutCustomerWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            logOutCustomerWindow.DialogResult = false;
                            logOutCustomerWindow.Close();
                        }
                    }
                }
            });
        }

        private async void LogOutCustomer()
        {
            if (IsProcessing)
            {
                return;
            }

            if (UserName == null || UserName == string.Empty)
            {
                return;
            }
            else if (UserName.Length < 4)
            {
                ShowConfirmationWindow(StandardMessageResource.ErrorUsernameLessThan4, Messages.ErrorConfirmation, logOutCustomerWindow);
                return;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "PROCESSING REQUEST . . .";
            });

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            
            ResponseModel response = null;
            try
            {
                response = await TaskManagerModel<ResponseModel>.Instance.Run(memberService.ForceLogOutMember(UserName, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        response = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, logOutCustomerWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });

            if (response == null)
            {
                return;
            }

            if (response.HttpStatusCode == (int)HttpStatusCode.OK)
            {
                ShowConfirmationWindow(StandardMessageResource.SuccessUserLoggedOut, Messages.SuccessConfirmation, logOutCustomerWindow);
                CloseWindowImmediately();
            }
        }

        #endregion

        #region Private Methods
        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.LogOutCustomerWindowViewModel);
                if (logOutCustomerWindow != null)
                {
                    if (logOutCustomerWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        logOutCustomerWindow.DialogResult = false;
                        logOutCustomerWindow.Close();
                    }
                }
            });
        }
        #endregion

    }
}
