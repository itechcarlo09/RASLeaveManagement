﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.Mapper;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.Model.EShopModels;
using gocafe_cashier.Model.FnBModels;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.View.Member;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModel.Database;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Runtime.ExceptionServices;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Linq;
using System.Threading;
using gocafe_cashier.TaskManager;

namespace gocafe_cashier.ViewModel.Member
{
    public class EShopWindowViewModel : TransactionLogViewModelBase
    {

        public EShopWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.EShopWindowViewModel);
            IsShownLoading = true;

            Initialize();
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.EShopWindow:
                    eShopWindow = (EShopWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    break;

                case Messages.EmailAddress:
                    emailAddress = (string)data;
                    break;

                case Messages.ItemPayed:
                    isItemPaid = (bool)data;
                    break;

                default:
                    break;
            }
        }


        #region Private Fields

        private EShopWindow eShopWindow;
        private EShopServiceProvider eShopServiceProvider = new EShopServiceProvider();
        private CashierDataModel cashierData;
        private string message = string.Empty;
        private string messageMode = string.Empty;
        private PrintDocument printDocument;

        private const int lineHeight = 11;
        private const int fontSize = 8;
        private const int margin = 3;
        private const int numberWidth = 7;
        private const int maxXPosition = 180;

        private bool isItemPaid;

        private EShopCodeModel codeClaimed = new EShopCodeModel();
        EShopCodeListDataModel itemToBuy;

        private string emailAddress = string.Empty;

        private string purchaseEload = StandardMessageResource.TransactPurchaseEload;

        #endregion

        #region Properties

        private bool isShownLoading;
        public bool IsShownLoading
        {
            get
            {
                return isShownLoading;
            }
            set
            {
                isShownLoading = value;
                RaisePropertyChanged(nameof(IsShownLoading));
            }
        }

        private List<EShopCodeListDataModel> filteredList;

        public List<EShopCodeListDataModel> FilteredList
        {
            get { return filteredList; }
            set
            {
                filteredList = value;
                RaisePropertyChanged(nameof(FilteredList));
            }
        }

        private string searchText;

        public string SearchText
        {
            get { return searchText; }
            set
            {
                searchText = value;
                FilterLists();
                RaisePropertyChanged(nameof(SearchText));
            }
        }

        private ObservableCollection<EShopSalesModel> orders;

        public ObservableCollection<EShopSalesModel> Orders
        {
            get { return orders; }
            set
            {
                orders = value;
                RaisePropertyChanged(nameof(Orders));
            }
        }

        private EShopManagerModel eShopManager;

        public EShopManagerModel EShopManager
        {
            get { return eShopManager; }
            set
            {
                eShopManager = value;
                RaisePropertyChanged(nameof(EShopManager));
            }
        }

        private List<EShopCodeListDataModel> eShopCodeList;

        public List<EShopCodeListDataModel> EShopCodeList
        {
            get { return eShopCodeList; }
            set
            {
                eShopCodeList = value;
                FilterLists();
            }
        }

        private string codeType;

        public string CodeType
        {
            get { return codeType; }
            set { codeType = value; }
        }

        #endregion

        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand BuyCommand
        {
            get
            {
                return new DelegateCommand<object>(BuyItem);
            }
        }


        #endregion

        #region Event Handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.FoodAndBeverageManagerWindowViewModel);
                    if (eShopWindow != null)
                    {
                        if (eShopWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            eShopWindow.DialogResult = false;
                            eShopWindow.Close();
                        }
                    }
                }
            });
        }

        private async void BuyItem(object parameter)
        {
            try
            {
                if (IsProcessing)
                {
                    return;
                }

                itemToBuy = (EShopCodeListDataModel)parameter;

                isItemPaid = false;
                EShopPopUpWindow eShopPopUpWindow = new EShopPopUpWindow();
                eShopPopUpWindow.Owner = eShopWindow;
                Mediator.Instance.NotifyViewModel(Messages.EShopPopUpWindowViewModel, Messages.EShopPopUpWindow, eShopPopUpWindow);
                Mediator.Instance.NotifyViewModel(Messages.EShopPopUpWindowViewModel, Messages.PurchasedItem, itemToBuy);
                eShopPopUpWindow.ShowDialog();

                if (isItemPaid)
                {
                    EmailPopUpWindow emailPopUpWindow = new EmailPopUpWindow();
                    emailPopUpWindow.Owner = eShopWindow;
                    Mediator.Instance.NotifyViewModel(Messages.EmailPopUpWindowViewModel, Messages.EmailPopUpWindow, emailPopUpWindow);
                    bool? isRequestConfirmed = false;
                    isRequestConfirmed = emailPopUpWindow.ShowDialog();

                    if ((bool)isRequestConfirmed)
                    {

                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = true;
                            ProcessingText = "PROCESSING REQUEST . . .";
                        });

                        ExceptionDispatchInfo capturedException = null;

                        try
                        {
                            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                            EshopCodeDataModel code = null;
                            try
                            {
                                code = await TaskManagerModel<EshopCodeDataModel>.Instance.Run(eShopServiceProvider.ClaimEShopCodeThruCashier(itemToBuy.ID, DataCacheContext.CashierSessionID, PaymentType.Cash, emailAddress, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                            }
                            catch (AggregateException aggregateException)
                            {
                                bool wasTaskCanceled = false;
                                foreach (var exception in aggregateException.InnerExceptions)
                                {
                                    if (exception is TaskCanceledException)
                                    {
                                        code = null;
                                        wasTaskCanceled = true;
                                        break;
                                    }
                                }

                                if (!wasTaskCanceled)
                                {
                                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, eShopWindow);
                                }
                            }

                            await App.Current.Dispatcher.BeginInvoke((Action)delegate
                            {
                                IsProcessing = false;
                            });

                            if (code != null)
                            {
                                if (code.ApplicationErrorCode == "NO_ERROR")
                                {
                                    ShowConfirmationWindow(StandardMessageResource.SuccessEloadPurchased, Messages.SuccessConfirmation, eShopWindow);
                                    codeClaimed = new EShopCodeModel { CodeType = itemToBuy.CodeTypeDscp, Code = code.Code };
                                    PrintDocument();

                                    TransactionModel transactionModel = CreateTransactionModel(cashierData.ID, GetTransactionRemarks(), $"{cashierData.Name}");
                                    // This is currently maintained at App.config
                                    if (DataCacheContext.UseLocalDB)
                                    {
                                        SaveTransactionToLocalDB(transactionModel);
                                    }
                                    Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, transactionModel);
                                }
                                else
                                {
                                    ShowConfirmationWindow(code.ApplicationErrorCode, Messages.ErrorConfirmation, eShopWindow);
                                }
                            }
                            await App.Current.Dispatcher.BeginInvoke((Action)delegate
                            {
                                IsProcessing = true;
                                ProcessingText = "FETCHING CODE LIST . . .";
                            });
                            CancellationTokenSource codeListCancellationTokenSource = new CancellationTokenSource();

                            List<EShopCodeListDataModel> temporaryList = null;
                            try
                            {
                                temporaryList = await TaskManagerModel<List<EShopCodeListDataModel>>.Instance.Run(eShopServiceProvider.GetEShopCodeList(DataCacheContext.CashierSessionID, codeListCancellationTokenSource.Token), codeListCancellationTokenSource, ToString(), isCriticalTask: true);
                            }
                            catch (AggregateException aggregateException)
                            {
                                bool wasTaskCanceled = false;
                                foreach (var exception in aggregateException.InnerExceptions)
                                {
                                    if (exception is TaskCanceledException)
                                    {
                                        temporaryList = null;
                                        wasTaskCanceled = true;
                                        break;
                                    }
                                }

                                if (!wasTaskCanceled)
                                {
                                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, eShopWindow);
                                }
                            }

                            if (temporaryList != null)
                            {
                                EShopCodeList = FilterUnavailableCodes(temporaryList);
                            }
                            await App.Current.Dispatcher.BeginInvoke((Action)delegate
                            {
                                IsProcessing = false;
                            });
                        }
                        catch (Exception ex)
                        {
                            // Store exception at a ExceptionDispatchInfo when
                            // error happens at the awaiting asynchronous operation.
                            ExceptionDispatchInfo.Capture(ex);

                            string message = StandardMessageResource.ErrorContactAdmin;
                            string messageMode = Messages.ErrorConfirmation;


                            if (eShopWindow == null)
                            {
                                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.EShopWindow);
                            }
                            else
                            {
                                CloseWindowImmediately();
                            }

                            App.Current.Dispatcher.Invoke(() =>
                            {
                                ShowConfirmationWindow(message, messageMode, eShopWindow);
                            });
                        }

                        if (capturedException != null)
                        {
                            // This can be used also for logging into a text file or any log file.
#if DEBUG
                            // Temporarily log at the Output panel when debugging.
                            System.Diagnostics.Debug
                                .WriteLine($"Place holder. Fix me later: {capturedException.SourceException.Message}");
#endif
                        }
                    }
                }
            }
            catch (Exception e)
            {
                // Fix me: need to add action
            }
        }

        #endregion

        #region Private Methods

        private void FilterLists()
        {
            Search();
        }

        private void Search()
        {
            List<EShopCodeListDataModel> temporaryList = new List<EShopCodeListDataModel>();

            if (SearchText == string.Empty || SearchText == null)
            {
                FilteredList = EShopCodeList;
                return;
            }

            if (EShopCodeList != null)
            {
                foreach (EShopCodeListDataModel item in EShopCodeList)
                {
                    if (item.Name.ToLower().Contains(SearchText.ToLower())
                        || item.CodeTypeDscp.ToLower().Contains(SearchText.ToLower()))
                    {
                        temporaryList.Add(item);
                    }
                }
                FilteredList = temporaryList;
            }
        }

        private async void Initialize()
        {
            EShopManager = EShopManagerModel.Instance;

            ExceptionDispatchInfo capturedException = null;

            try
            {
                await RequestEShopCodes();
            }
            catch (Exception ex)
            {
                // Store exception at a ExceptionDispatchInfo when
                // error happens at the awaiting asynchronous operation.
                ExceptionDispatchInfo.Capture(ex);

                string message = StandardMessageResource.ErrorShopCode;
                string messageMode = Messages.ErrorConfirmation;


                if (eShopWindow == null)
                {
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.EShopWindow);
                }
                else
                {
                    //fix me: is this intended?
                    CloseWindowImmediately();
                }

                App.Current.Dispatcher.Invoke(() =>
                {
                    ShowConfirmationWindow(message, messageMode, eShopWindow);
                });
            }

            if (capturedException != null)
            {
                // This can be used also for logging into a text file or any log file.
#if DEBUG
                // Temporarily log at the Output panel when debugging.
                System.Diagnostics.Debug
                .WriteLine($"EShopWindowViewModel.RequestEShopCodes: {capturedException.SourceException.Message}");
#endif
            }

            printDocument = new PrintDocument();
            printDocument.PrintPage += PrintCodes;
        }

        private async Task RequestEShopCodes()
        {
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = true;
                ProcessingText = "FETCHING CODE LIST . . .";
            });

            List<EShopCodeListDataModel> shopCodes = null;
            try
            {
                shopCodes = await TaskManagerModel<List<EShopCodeListDataModel>>.Instance.Run(eShopServiceProvider.GetEShopCodeList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        shopCodes = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, eShopWindow);
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });

            if (shopCodes != null)
            {
                EShopCodeList = FilterUnavailableCodes(shopCodes);
                FilteredList = EShopCodeList;
            }
            else
            {
                CloseWindowImmediately();
            }

            IsShownLoading = false;
        }

        private void PrintDocument()
        {
            try
            {
                System.Windows.Forms.PrintDialog printDialog = new System.Windows.Forms.PrintDialog();
                printDialog.Document = printDocument;
                printDialog.UseEXDialog = true;
                printDialog.PrinterSettings.PrinterName = DataCacheContext.PrinterName;
                printDocument.DocumentName = "PrintCodes";
                printDocument.Print();
            }
            catch (Exception)
            {
                string message = StandardMessageResource.ErrorPrinter;
                string messageMode = Messages.ErrorConfirmation;
                ShowConfirmationWindow(message, messageMode, eShopWindow);
            }
        }

        private void PrintCodes(object sender, PrintPageEventArgs e)
        {
            int yAxis = 0;
            yAxis = PrintExcessCharacterOnNewLine(e, string.Empty, cashierData.Branch.Name, true, 35, 0, 0, yAxis, 0, lineHeight, FontStyle.Bold) + 34;
            yAxis = PrintWithRegularFont($"{codeClaimed.CodeType}", 7, margin, yAxis, e);
            yAxis = PrintWithRegularFont($"CODE: {codeClaimed.Code}", 7, margin, yAxis, e);
        }

        private int PrintWithRegularFont(string message, int fontSize, int xPosition, int yPosition, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(message, new Font("Arial Narrow", fontSize, FontStyle.Regular), new SolidBrush(Color.Black), xPosition, yPosition);
            return yPosition + lineHeight;
        }

        private void SaveTransactionToLocalDB(TransactionModel transactionModel, string password = "")
        {

            if (TransactionRepository != null)
            {
                // Maps to entity and then save the changes (persist) at local DB.
                TransactionRepository.Add(TransactionLogMapper.MapELoadTransaction(transactionModel, cashierData, null,
                    PaymentType.Cash, new TopUpManagerModel { CardIDNumber = string.Empty, Username = cashierData.Username, FirstName = cashierData.Name, LastName = cashierData.Name }, GetTransactionAmount()));
                TransactionRepository.SaveAsync();
            }

        }

        private TransactionModel CreateTransactionModel(string id, string remarks, string name = null)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = purchaseEload,
                CustomerName = name,
                CustomerID = id,
                TransactionAmount = $"{CurrencySymbol}{(Convert.ToDouble(GetTransactionAmount()) / 100).ToString("N2")}",
                TransactionRemarks = remarks,
                CashierName = cashierData.Name
            };
            return transactionModel;
        }

        private int GetTransactionAmount()
        {
            return int.Parse(itemToBuy.Amount);
        }

        private string GetTransactionRemarks()
        {
            string eloadPurchaseRemarks = string.Empty;

            eloadPurchaseRemarks += $"ELoad Purchase - {itemToBuy.CodeTypeDscp}: ₱{itemToBuy.AmountDscp} ";

            return eloadPurchaseRemarks;
        }

        private List<EShopCodeListDataModel> FilterUnavailableCodes(List<EShopCodeListDataModel> codeList)
        {
            List<EShopCodeListDataModel> filteredCodeList = new List<EShopCodeListDataModel>();

            foreach (EShopCodeListDataModel code in codeList)
            {
                if (code.NoOfAvailableCodes > 0)
                {
                    code.IsCodeAvailable = true;
                }
                else
                {
                    code.IsCodeAvailable = false;
                    code.CodeUnavailableError = StandardMessageResource.ErrorCodeUnavailable;
                }
                filteredCodeList.Add(code);
            }

            filteredCodeList = filteredCodeList.OrderBy(code => code.Name).ToList();

            return filteredCodeList;
        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.FoodAndBeverageManagerWindowViewModel);
                if (eShopWindow != null)
                {
                    if (eShopWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        eShopWindow.DialogResult = false;
                        eShopWindow.Close();
                    }
                }
            });
        }

        #endregion
    }
}