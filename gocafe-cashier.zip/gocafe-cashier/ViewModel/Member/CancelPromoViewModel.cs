﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.MessageResource;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModel.Database;
using gocafe_cashier.ViewModelMediator;
using GocafeShared.Model;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace gocafe_cashier.ViewModel.Member
{
    public class CancelPromoViewModel: TransactionLogViewModelBase
    {
        private CancelPromoWindow cancelPromoWindow;
        private CashierDataModel cashierData;
        private MemberServiceProvider memberService = new MemberServiceProvider();

        public CancelPromoViewModel()
        {
            Mediator.Instance.Register(this, Messages.CancelPromoViewModel);
        }

        public override void SendData(string message, object data)
        {
            if(message == Messages.CancelPromoWindow)
            {
                cancelPromoWindow = (CancelPromoWindow)data;
                IsWindowOpen = true;
            }
            else if(message == Messages.CashierInfo)
            {
                cashierData = (CashierDataModel)data;
            }
        }

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand SubmitCommand
        {
            get
            {
                return new DelegateCommand(CancelPromo);
            }
        }

        private bool isSubmitButtonEnabled;
        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

        private string userName;
        public string UserName
        {
            get { return userName; }
            set
            {
                userName = value;
                RaisePropertyChanged(nameof(UserName));

                if (userName == null || userName == string.Empty)
                {
                    IsSubmitButtonEnabled = false;
                }
                else
                {
                    IsSubmitButtonEnabled = true;
                }
            }
        }

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.CancelPromoViewModel);
                    if (cancelPromoWindow != null)
                    {
                        if (cancelPromoWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            cancelPromoWindow.DialogResult = false;
                            cancelPromoWindow.Close();
                        }
                    }
                }
            });
        }

        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                Mediator.Instance.UnRegister(this, Messages.CancelPromoViewModel);
                if (cancelPromoWindow != null)
                {
                    if (cancelPromoWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        cancelPromoWindow.DialogResult = false;
                        cancelPromoWindow.Close();
                    }
                }
            });
        }

        private async void CancelPromo()
        {
            string messageMode = string.Empty;
            string message = string.Empty;

            if(IsSubmitButtonEnabled)
            {
                if (IsProcessing)
                {
                    return;
                }

                if (UserName == null || UserName == string.Empty)
                {
                    return;
                }
                else if (userName.Length < 4)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUsernameLessThan4, Messages.ErrorConfirmation, cancelPromoWindow);
                    return;
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                    ProcessingText = "PROCESSING REQUEST . . .";
                });

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                ResponseModel response = null;
                ClientPromoDataModel clientPromoData = null;
                try
                {
                    clientPromoData = await TaskManagerModel<ClientPromoDataModel>.Instance.Run(memberService.GetClientPromo(DataCacheContext.CashierSessionID, UserName, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    if(clientPromoData != null)
                    {
                        if (clientPromoData.Refundable)
                        {
                            message = string.Format(StandardMessageResource.WarningConfirmationCancelClientPromo, clientPromoData.PromoDescription, (clientPromoData.Price / 100).ToString("N2"), CurrencySymbol);
                            messageMode = Messages.WarningConfirmation;
                            if (ShowConfirmationWindow(message, messageMode, cancelPromoWindow))
                            {
                                response = await TaskManagerModel<ResponseModel>.Instance.Run(memberService.CancelPromo(DataCacheContext.CashierSessionID, UserName, PaymentType.Cash, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                            }
                        }
                        else
                        {
                            messageMode = Messages.ErrorConfirmation;
                            ShowConfirmationWindow(clientPromoData.Reason, messageMode, cancelPromoWindow);
                        }
                    }                    
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            response = null;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, cancelPromoWindow);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });

                if (response == null)
                {
                    return;
                }

                if (response.HttpStatusCode == (int)HttpStatusCode.OK)
                {
                    ShowConfirmationWindow(StandardMessageResource.SuccessCancelPromo, Messages.SuccessConfirmation, cancelPromoWindow);
                    CloseWindowImmediately();
                }
            }
        }
    }
}
