﻿using gocafe_cashier.Command;
using gocafe_cashier.Model;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Windows.Input;
using gocafe_cashier.DataModel;
using gocafe_cashier.MessageResource;

namespace gocafe_cashier.ViewModel.Member
{
    public class EndShiftSummaryWindowViewModel : BaseModel
    {
        #region Private Variables

        private EndShiftSummaryWindow endShiftSummaryWindow;
        private CashierDataModel cashierInformation;

        #endregion

        public EndShiftSummaryWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.EndShiftSummaryWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch(message)
            {
                case Messages.EndShiftSummaryWindow:
                    endShiftSummaryWindow = (EndShiftSummaryWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.EndShiftData:
                    EndShiftModel = (EndShiftModel)data;
                    break;

                case Messages.CashierInfo:
                    cashierInformation = (CashierDataModel)data;
                    break;
            }
        }


        #region Properties

        private EndShiftModel endShiftModel;
        public EndShiftModel EndShiftModel
        {
            get { return endShiftModel; }
            set
            {
                endShiftModel = value;
                RaisePropertyChanged(nameof(EndShiftModel));
            }
        }

        #endregion

        #region Commands

        public ICommand LogoutCommand
        {
            get
            {
                return new DelegateCommand(Logout);
            }
        }

        public ICommand SaveCommand
        {
            get
            {
                return new DelegateCommand(SaveReport);
            }
        }

        #endregion

        private void SaveReport()
        {
            try
            {
                PDF.Pdf pdfCreator = new PDF.Pdf();
                if(pdfCreator.CreatePdf(cashierInformation.Name, cashierInformation.Branch.Name, EndShiftModel))
                {
                    ShowConfirmationWindow(StandardMessageResource.SuccessReportGenerated, Messages.SuccessConfirmation, endShiftSummaryWindow);
                }                
            }
            catch (Exception)
            {

            }
        }

        private void Logout()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.SwitchToLoginView, null);
        }
    }
}
