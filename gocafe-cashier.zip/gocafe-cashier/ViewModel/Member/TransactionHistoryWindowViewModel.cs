﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Model;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModel.Database;
using gocafe_cashier.ViewModelMediator;
using GocafeDatabaseModel.Enum;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using GocafeShared.Utilities.StringFormat;
using System.Threading;
using gocafe_cashier.TaskManager;
using System.Data.SqlClient;
using gocafe_cashier.Cache;
using Swordfish.NET.Collections;
using gocafe_cashier.ServiceProvider;
using GocafeShared.Model;
using System.Net;
using System.Globalization;
using gocafe_cashier.MessageResource;
using gocafe_cashier.View.PopUp;

namespace gocafe_cashier.ViewModel.Member
{
    public class TransactionHistoryWindowViewModel : TransactionLogViewModelBase
    {
        public TransactionHistoryWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.TransactionHistoryWindowViewModel);
            Initialize();
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.TransactionHistoryWindow:
                    transactionHistoryWindow = (TransactionHistoryWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    break;

                default:
                    break;
            }
        }

        #region Private Variables

        private TransactionHistoryWindow transactionHistoryWindow;
        private CashierDataModel cashierData;
        private ConcurrentObservableCollection<TransactionHistoryModel> TransactionList = new ConcurrentObservableCollection<TransactionHistoryModel>();
        private bool isFirstRun = true;
        private CashierServiceProvider cashierService = new CashierServiceProvider();
        private bool isGettingTransactionData = false;
        private const string allTransactions = "All Transactions";

        #endregion

        #region Properties

        private ConcurrentObservableCollection<TransactionHistoryModel> filteredTransactionList;

        public ConcurrentObservableCollection<TransactionHistoryModel> FilteredTransactionList
        {
            get { return filteredTransactionList; }
            set
            {
                filteredTransactionList = value;
                RaisePropertyChanged(nameof(FilteredTransactionList));
            }
        }

        private ObservableCollection<string> transactionTypeList;

        public ObservableCollection<string> TransactionTypeList
        {
            get { return transactionTypeList; }
            set
            {
                transactionTypeList = value;
                RaisePropertyChanged(nameof(TransactionTypeList));
            }
        }

        private string selectedTransactionType;

        public string SelectedTransactionType
        {
            get { return selectedTransactionType; }
            set
            {
                selectedTransactionType = value;
                RaisePropertyChanged(nameof(SelectedTransactionType));
                FilterLists();
            }
        }

        private string searchText;

        public string SearchText
        {
            get { return searchText; }
            set
            {
                searchText = value;
                RaisePropertyChanged(nameof(SearchText));
                FilterLists();
            }
        }

        private DateTime startDate;

        public DateTime StartDate
        {
            get { return startDate; }
            set
            {
                startDate = value;
                RaisePropertyChanged(nameof(StartDate));
            }
        }

        private DateTime endDate;

        public DateTime EndDate
        {
            get { return endDate; }
            set
            {
                endDate = value;
                RaisePropertyChanged(nameof(EndDate));
            }
        }

        private DateTime startDateSelected;

        public DateTime StartDateSelected
        {
            get { return startDateSelected; }
            set
            {
                startDateSelected = value;
                RaisePropertyChanged(nameof(StartDateSelected));
                if (StartDateSelected != null && EndDateSelected != null)
                {
                    Task.Run(async () =>
                    {
                        if (!isGettingTransactionData)
                        {
                            isGettingTransactionData = true;
                            await PopulateTransactionList();
                            isGettingTransactionData = false;
                        }
                    });
                }
            }
        }

        private DateTime endDateSelected;

        public DateTime EndDateSelected
        {
            get { return endDateSelected; }
            set
            {
                endDateSelected = value;
                RaisePropertyChanged(nameof(EndDateSelected));

                IsTransactionShownLoading = true;

                if (StartDateSelected != null && EndDateSelected != null)
                {
                    Task.Run(async () =>
                   {
                       if (!isGettingTransactionData)
                       {
                           isGettingTransactionData = true;
                           await PopulateTransactionList();
                           isGettingTransactionData = false;
                       }
                   });
                }
            }
        }

        private bool isTransactionShownLoading;

        public bool IsTransactionShownLoading
        {
            get { return isTransactionShownLoading; }
            set
            {
                isTransactionShownLoading = value;
                RaisePropertyChanged(nameof(IsTransactionShownLoading));
            }
        }

        public DateTime CurrentDate
        {
            get
            {
                return DateTime.Today.Date;
            }
            set { }
        }


        #endregion

        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand ShowDetailsCommand
        {
            get
            {
                return new DelegateCommand<object>(ShowTransactionDetails);
            }
        }

        public ICommand VoidTransactionCommand
        {
            get
            {
                return new DelegateCommand<object>(VoidTransaction);
            }
        }

        #endregion

        #region Event Handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.TransactionHistoryWindowViewModel);
                    if (transactionHistoryWindow != null)
                    {
                        if (transactionHistoryWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            transactionHistoryWindow.DialogResult = false;
                            transactionHistoryWindow.Close();
                        }
                    }
                }
            });
        }

        private void ShowTransactionDetails(object parameter)
        {
            TransactionHistoryModel transaction = (TransactionHistoryModel)parameter;

            if (!transaction.IsRemarksNull)
            {
                transaction.IsMoreDetailsShown ^= true;
            }            
        }

        private async void VoidTransaction(object parameter)
        {
            TransactionHistoryModel transaction = (TransactionHistoryModel)parameter;

            VoidConfirmationWindow voidConfirmationWindow = new VoidConfirmationWindow();
            voidConfirmationWindow.Owner = transactionHistoryWindow;
            Mediator.Instance.NotifyViewModel(Messages.VoidConfirmationWindowViewModel, Messages.VoidConfirmationWindow, voidConfirmationWindow);
            Mediator.Instance.NotifyViewModel(Messages.VoidConfirmationWindowViewModel, Messages.TransactionModel, transaction);

            bool? isVoidTransactionContinued = voidConfirmationWindow.ShowDialog();

            if (! (bool)isVoidTransactionContinued)
            {
                return;
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsTransactionShownLoading = true;
            });

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            Tuple<string, ResponseModel> response = null;

            try
            {
                response = await TaskManagerModel<Tuple<string, ResponseModel>>.Instance.Run(
                    cashierService.SendVoidRequest(DataCacheContext.CashierSessionID,
                    transaction.ReferenceNumber,
                    cancellationTokenSource.Token), cancellationTokenSource);
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                bool isSqlHavingErrors = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        response = null;
                        wasTaskCanceled = true;
                        break;
                    }
                    else if (exception is SqlException)
                    {
                        isSqlHavingErrors = true;
                    }
                }

                if (!wasTaskCanceled)
                {
                    if (isSqlHavingErrors)
                    {
                        //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                        //ShowConfirmationWindow(StandardMessageResource.ErrorDatabaseError, Messages.ErrorConfirmation);
                    }
                    else
                    {
                        //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                        //ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                    }
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsTransactionShownLoading = false;
            });

            if (response == null)
            {
                return;
            }

            if (response != null && response.Item1 == null && response.Item2.HttpStatusCode != (int)HttpStatusCode.OK)
            {
                return;
            }
            else
            {
                App.Current.Dispatcher.Invoke((Action)delegate
                {
                    ShowConfirmationWindow(StandardMessageResource.SuccessVoidTransactionRequestSent, Messages.SuccessConfirmation, transactionHistoryWindow);
                    transaction.IsTransactionVoidable = false;
                });
                await PopulateTransactionList();
            }

        }

        #endregion


        #region Task Handler

        private async Task PopulateTransactionList()
        {
            if ((StartDateSelected != DateTime.Today.AddDays(-6) || EndDateSelected != DateTime.Today) && isFirstRun)
            {
                return;
            }

            isFirstRun = false;

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            Tuple<List<TransactionLogDataModel>, ResponseModel> transactionLogList = null;
            try
            {
                transactionLogList = await TaskManagerModel<Tuple<List<TransactionLogDataModel>, ResponseModel>>.Instance.Run(
                    cashierService.GetTransactionLog(DataCacheContext.CashierSessionID,
                    ToUnixTimeStartDate(StartDateSelected),
                    ToUnixTimeEndDate(EndDateSelected),
                    cancellationTokenSource.Token), cancellationTokenSource);
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                bool isSqlHavingErrors = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        transactionLogList = null;
                        wasTaskCanceled = true;
                        break;
                    }
                    else if (exception is SqlException)
                    {
                        isSqlHavingErrors = true;
                    }
                }

                if (!wasTaskCanceled)
                {
                    if (isSqlHavingErrors)
                    {
                        //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                        //ShowConfirmationWindow(StandardMessageResource.ErrorDatabaseError, Messages.ErrorConfirmation);
                    }
                    else
                    {
                        //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                        //ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                    }
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsTransactionShownLoading = false;
            });

            if (transactionLogList == null)
            {
                return;
            }

            if(transactionLogList != null && transactionLogList.Item1 == null && transactionLogList.Item2.HttpStatusCode != (int)HttpStatusCode.OK)
            {
                return;
            }
            else
            {
                App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    TransactionList = new ConcurrentObservableCollection<TransactionHistoryModel>();

                    foreach (TransactionLogDataModel transaction in transactionLogList.Item1)
                    {
                        TransactionList.Add(new TransactionHistoryModel
                        {
                            Date = transaction.date,
                            Time = transaction.Time,
                            Activity = transaction.Activity,
                            CustomerName = transaction.CustomerName == null ? $"CASHIER-{transaction.CashierName}" : transaction.CustomerName,
                            Remarks = transaction.Remarks,
                            CashierName = transaction.CashierName,
                            Amount = transaction.Amount.ToString().ConvertIntToMoney(),
                            IsRemarksNull = transaction.Remarks == null ? true : false,
                            IsTransactionVoidable = transaction.IsVoidable,
                            ReferenceNumber = transaction.ReferenceNumber,
                            VoidStatus = transaction.VoidStatus
                        });
                    }
                    CollectTransactionTypeList();
                    FilterLists();
                });
            }
        }

        private long ToUnixTimeEndDate(DateTime date)
        {
            System.TimeZone localZone = System.TimeZone.CurrentTimeZone;
            var epoch = new DateTime(1969, 12, 31, 23, 59, 59, 59, DateTimeKind.Utc);
            var dateTimeNow = new DateTime(date.Year, date.Month, date.Day, 23, 59, 59, DateTimeKind.Local);
            DateTime currentUTC = localZone.ToUniversalTime(dateTimeNow);
            return Convert.ToInt64((currentUTC - epoch).TotalMilliseconds);
        }

        private long ToUnixTimeStartDate(DateTime date)
        {
            System.TimeZone localZone = System.TimeZone.CurrentTimeZone;
            var epoch = new DateTime(1969, 12, 31, 23, 59, 59, 59, DateTimeKind.Utc);
            var dateTimeNow = new DateTime(date.Year, date.Month, date.Day, 0, 0, 0, DateTimeKind.Local);
            DateTime currentUTC = localZone.ToUniversalTime(dateTimeNow);
            return Convert.ToInt64((currentUTC - epoch).TotalMilliseconds);
        }
        #endregion

        #region Private Methods

        private void FilterByTransactionType()
        {
            if (SelectedTransactionType == null)
            {
                SelectedTransactionType =  allTransactions;
            }
            FilteredTransactionList = new ConcurrentObservableCollection<TransactionHistoryModel>();

            var decendByDateTransactionList = TransactionList.OrderByDescending(x => ConvertToDateTime(x.Date, x.Time));

            if (SelectedTransactionType == allTransactions)
            {
                foreach (TransactionHistoryModel transaction in decendByDateTransactionList)
                {
                    FilteredTransactionList.Add(transaction);
                }

                return;
            }

            if (TransactionList == null)
            {
                FilteredTransactionList = null;
                return;
            }


            foreach (TransactionHistoryModel transaction in decendByDateTransactionList)
            {
                if (transaction.Activity.ToLower() == SelectedTransactionType.ToLower())
                {
                    FilteredTransactionList.Add(transaction);
                }
            }
        }

        private DateTime ConvertToDateTime(string date, string time)
        {
            DateTime dtReceived = Convert.ToDateTime(date);
            DateTime dateTime = DateTime.ParseExact(time, "hh:mm tt", CultureInfo.InvariantCulture);
            DateTime newDateTime = dtReceived.Date.Add(dateTime.TimeOfDay);

            return newDateTime;
        }

        private void Search()
        {
            if (FilteredTransactionList == null)
            {
                return;
            }

            ConcurrentObservableCollection<TransactionHistoryModel> temporaryList = new ConcurrentObservableCollection<TransactionHistoryModel>();

            foreach (TransactionHistoryModel transaction in FilteredTransactionList)
            {
                if (transaction.Activity.ToUpper().Contains(searchText.ToUpper())
                || transaction.CustomerName.ToUpper().Contains(searchText.ToUpper())
                || transaction.CashierName.ToUpper().Contains(searchText.ToUpper()))
                {
                    temporaryList.Add(transaction);
                }
            }

            FilteredTransactionList = temporaryList;
        }

        private void FilterLists()
        {
            FilterByTransactionType();
            Search();
        }

        private short GetTransactionTypeByName(string transactionType)
        {
            switch (transactionType)
            {
                case "Top Up":
                    return (short)TransactionType.TopUp;

                case "New Account":
                    return (short)TransactionType.NewAccount;

                case "New Coupon Account":
                    return (short)TransactionType.NewCouponAccount;

                case "New Order":
                    return (short)TransactionType.NewOrder;

                case "E-Load":
                    return (short)TransactionType.ELoad;

                case "Card Replacement":
                    return (short)TransactionType.CardReplacement;

                default:
                    return 0;
            }

        }

        private void CollectTransactionTypeList()
        {
            if(TransactionTypeList != null)
            {
                TransactionTypeList.Clear();
            }

            TransactionTypeList.Add(allTransactions);
            foreach (TransactionHistoryModel transaction in TransactionList)
            {
                if (transaction != null && !TransactionTypeList.Contains(transaction.Activity))
                {
                    TransactionTypeList.Add(transaction.Activity);
                }
            }
            SelectedTransactionType = TransactionTypeList.First();
        }

        private void Initialize()
        {
            try
            {
                FilteredTransactionList = new ConcurrentObservableCollection<TransactionHistoryModel>();
                TransactionTypeList = new ObservableCollection<string>();
                SearchText = string.Empty;
                StartDate = DateTime.Today.AddDays(-6);
                StartDateSelected = DateTime.Today.AddDays(-6);
                EndDate = DateTime.Today;
                EndDateSelected = DateTime.Today;
                IsTransactionShownLoading = true;
                SelectedTransactionType = allTransactions;
                RaisePropertyChanged(nameof(CurrentDate));
            }
            catch (Exception ex)
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.WindowInitializationError, Messages.TransactionHistoryWindow);
            }
        }

        #endregion
    }
}
