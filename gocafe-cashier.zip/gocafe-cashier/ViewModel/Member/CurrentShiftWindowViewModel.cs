﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Definition;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;

namespace gocafe_cashier.ViewModel.Member
{
    public class CurrentShiftWindowViewModel : BaseModel
    {
        public CurrentShiftWindowViewModel()
        {
            Mediator.Instance.Register(this, Messages.CurrentShiftWindowViewModel);
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.CurrentShiftWindow:
                    currentShiftWindow = (CurrentShiftWindow)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    userData = (CashierDataModel)data;
                    break;

                default:
                    break;

            }
        }

        #region Private Variables

        private EndShiftServiceProvider endShiftServiceProvider = new EndShiftServiceProvider();
        private CurrentShiftWindow currentShiftWindow;
        private CashierDataModel userData = new CashierDataModel();
        private PasswordBox cashierPassword;

        #endregion


        #region Properties

        private string username;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                RaisePropertyChanged(nameof(Username));
            }
        }

        private bool isPasswordInvalid;
        public bool IsPasswordInvalid
        {
            get { return isPasswordInvalid; }
            set
            {
                isPasswordInvalid = value;
                RaisePropertyChanged(nameof(IsPasswordInvalid));
            }
        }

        private bool isUsernameInvalid;
        public bool IsUsernameInvalid
        {
            get { return isUsernameInvalid; }
            set
            {
                isUsernameInvalid = value;
                RaisePropertyChanged(nameof(IsUsernameInvalid));
            }
        }

        private string passwordErrorMessage;
        public string PasswordErrorMessage
        {
            get { return passwordErrorMessage; }
            set
            {
                passwordErrorMessage = value;
                RaisePropertyChanged(nameof(PasswordErrorMessage));
            }
        }

        private string usernameErrorMessage;
        public string UsernameErrorMessage
        {
            get { return usernameErrorMessage; }
            set
            {
                usernameErrorMessage = value;
                RaisePropertyChanged(nameof(UsernameErrorMessage));
            }
        }

        private bool isShowBlurBackground;
        public bool IsShowBlurBackground
        {
            get { return isShowBlurBackground; }
            set
            {
                isShowBlurBackground = value;
                RaisePropertyChanged(nameof(IsShowBlurBackground));
            }
        }

        #endregion

        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public ICommand ConfirmCommand
        {
            get
            {
                return new DelegateCommand<object>(ShowCurrentShiftSummary);
            }
        }

        #endregion

        #region Event Handlers

        public void CloseWindow()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                if (TaskManagerModel<object>.Instance.CancelAllTasks())
                {
                    Mediator.Instance.UnRegister(this, Messages.CurrentShiftWindowViewModel);
                    if (currentShiftWindow != null)
                    {
                        if (currentShiftWindow.IsLoaded == true && IsWindowOpen)
                        {
                            IsWindowOpen = false;
                            currentShiftWindow.DialogResult = false;
                            currentShiftWindow.Close();
                        }
                    }
                }
            });
        }

        public async void ShowCurrentShiftSummary(object parameter)
        {
            string message = string.Empty;
            string messageMode = string.Empty;

            PasswordErrorMessage = string.Empty;
            UsernameErrorMessage = string.Empty;

            IsUsernameInvalid = false;
            IsPasswordInvalid = false;

            cashierPassword = parameter as PasswordBox;
            if (Username == string.Empty || Username == null)
            {
                UsernameErrorMessage = StandardMessageResource.ErrorUsernameIsEmpty;
                IsUsernameInvalid = true;
            }
            else if (Username.Length < 4)
            {
                UsernameErrorMessage = StandardMessageResource.ErrorUsernameLessThan4;
                IsUsernameInvalid = true;
            }

            if (cashierPassword.Password == "" || cashierPassword.Password == null)
            {
                PasswordErrorMessage = StandardMessageResource.ErrorPasswordIsEmpty;
                IsPasswordInvalid = true;
            }
            else if (cashierPassword.Password.Length < 4)
            {
                PasswordErrorMessage = StandardMessageResource.ErrorPasswordLessThan4;
                IsPasswordInvalid = true;
            }

            if (!IsPasswordInvalid && !IsUsernameInvalid)
            {
                try
                {
                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                        ProcessingText = "GETTING CURRENT SHIFT SUMMARY . . .";
                    });

                    string responseMessage = string.Empty;
                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    EndShiftDataModel currentShiftData = null;
                    try
                    {
                        currentShiftData = await TaskManagerModel<EndShiftDataModel>.Instance.Run(endShiftServiceProvider.GetCurrentShiftSummary(Username, cashierPassword.Password, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                currentShiftData = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, currentShiftWindow);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (currentShiftData != null)
                    {
                        List<ShiftModel> shifts = new List<ShiftModel>();

                        if (currentShiftData.Shifts != null)
                        {
                            foreach (ShiftDataModel shift in currentShiftData.Shifts)
                            {
                                Dictionary<string, string> cashBreakdown = new Dictionary<string, string>();

                                foreach (KeyValuePair<string, int> entry in shift.Breakdown)
                                {
                                    cashBreakdown.Add(entry.Key, CurrencySymbol + " " + (entry.Value / 100).ToString($"N2"));
                                }

                                string endTime = shift.EndDate.ToString($"MMMM dd, yyyy | hh:mm tt", CultureInfo.InvariantCulture);

                                if(endTime == new DateTime().ToString($"MMMM dd, yyyy | hh:mm tt", CultureInfo.InvariantCulture))
                                {
                                    endTime = DateTime.Now.ToString($"MMMM dd, yyyy | hh:mm tt", CultureInfo.InvariantCulture);
                                }

                                shifts.Add(new ShiftModel
                                {
                                    CashierName = shift.CashierName,
                                    EndTime = endTime,
                                    StartTime = shift.StartDate.ToString($"MMMM dd, yyyy | hh:mm tt", CultureInfo.InvariantCulture),
                                    TotalSales = CurrencySymbol + " " + (shift.TotalSales / 100).ToString($"N2"),
                                    TotalHours = shift.TotalHours,
                                    Breakdown = cashBreakdown,
                                    ProductBreakdownData = shift.ProductBreakdown
                                });
                            }
                        }

                        IsShowBlurBackground = true;

                        CurrentShiftSummaryWindow currentShiftSummaryWindow = new CurrentShiftSummaryWindow();
                        currentShiftSummaryWindow.Owner = currentShiftWindow;

                        Mediator.Instance.NotifyViewModel(Messages.CurrentShiftSummaryWindowViewModel, Messages.CurrentShiftSummaryWindow, currentShiftSummaryWindow);
                        Mediator.Instance.NotifyViewModel(Messages.CurrentShiftSummaryWindowViewModel, Messages.CashierInfo, userData);
                        Mediator.Instance.NotifyViewModel(Messages.CurrentShiftSummaryWindowViewModel, Messages.EndShiftData,
                            new EndShiftModel
                            {
                                EndTime = currentShiftData.EndDate.ToString($"{DateFormatDefinition.DefaultDateFormat} | hh:mm tt", CultureInfo.InvariantCulture),
                                StartTime = currentShiftData.StartDate.ToString($"{DateFormatDefinition.DefaultDateFormat} | hh:mm tt", CultureInfo.InvariantCulture),
                                TotalSales = CurrencySymbol + " " + (currentShiftData.TotalSales / 100).ToString($"N2"),
                                Shifts = shifts,
                                InventoryItems = currentShiftData.ShiftInventory
                            });
                        Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
                        currentShiftSummaryWindow.ShowDialog();
                        Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
                    }

                    CloseWindowImmediately();
                }
                catch (Exception e)
                {
                    //fix me: log errors
                }
            }
        }

        #endregion

        #region Private Methods

        public void CloseWindowImmediately()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                Mediator.Instance.UnRegister(this, Messages.CouponManagerViewModel);
                if (currentShiftWindow != null)
                {
                    if (currentShiftWindow.IsLoaded == true && IsWindowOpen)
                    {
                        IsWindowOpen = false;
                        TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
                        currentShiftWindow.Close();
                    }
                }
            });
        }

        #endregion
    }
}
