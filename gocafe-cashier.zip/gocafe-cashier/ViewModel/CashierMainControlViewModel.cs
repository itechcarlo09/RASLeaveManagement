﻿using gocafe_cashier.Command;
using gocafe_cashier.Model;
using System.Windows.Input;
using gocafe_cashier.ViewModelMediator;
using gocafe_cashier.TaskManager;
using AutoUpdaterDotNET;

namespace gocafe_cashier.ViewModel
{
    public class CashierMainControlViewModel : BaseModel
    {
        #region Private properties

        private int windowPopupCount;

        #endregion

        public CashierMainControlViewModel()
        {
            AutoUpdater.Start(@"https://raw.githubusercontent.com/itechcarlo09/RASLeaveManagement/master/RAS%20Leave%20Management/bin/Debug/update.xml");
            Mediator.Instance.Register(this, Messages.CashierViewModel);
            windowPopupCount = 0;
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.ShowBlurBackground:
                    bool isShow = (bool)data;

                    if (isShow)
                    {
                        windowPopupCount += 1;
                        IsShowBlurBackground = isShow;
                    }
                    else
                    {
                        windowPopupCount -= 1;
                    }
                    
                    if(windowPopupCount <= 0)
                    {
                        IsShowBlurBackground = isShow;
                    }
                    
                    break;

                case Messages.IsProcessing:
                    IsProcessing = (bool)data;
                    break;

                case Messages.ProcessingText:
                    ProcessingText = (string)data;
                    break;

                default:
                    break;
            }
        }

        #region Properties

        private bool isShowBlurBackground;
        public bool IsShowBlurBackground
        {
            get { return isShowBlurBackground; }
            set
            {
                isShowBlurBackground = value;
                RaisePropertyChanged(nameof(IsShowBlurBackground));
            }
        }

        #endregion

        #region Commands

        public ICommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        #endregion

        #region Event handlers

        private void CloseWindow()
        {
            if (TaskManagerModel<object>.Instance.CancelAllTasks())
            {
                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.LogoutUser, null);
            }
        }

        #endregion
    }
}
