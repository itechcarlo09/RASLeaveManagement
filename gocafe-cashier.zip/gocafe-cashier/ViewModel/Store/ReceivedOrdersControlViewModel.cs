﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.FnBDataModels;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.Model.Store;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.TaskManager;
using gocafe_cashier.View.Store;
using gocafe_cashier.ViewModel.Database;
using gocafe_cashier.ViewModelMediator;
using GocafeDatabaseModel;
using GocafeDatabaseModel.Enum;
using GocafeShared.Model;
using GocafeShared.Utilities.StringFormat;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using GocafeShared.Utilities.Extensions;
using System.Drawing.Printing;
using System.Drawing;
using gocafe_cashier.View.PopUp;

namespace gocafe_cashier.ViewModel.Store
{
    public class ReceivedOrdersControlViewModel : TransactionLogViewModelBase
    {
        #region Private fields

        private const string OrderAccepted = "Order accepted";
        private const string PendingOrder = "PENDING";
        private const string AcceptedOrder = "ACCEPTED";
        private const string CashierLabel = "CASHIER";
        private const int InsufficientFundHttpStatusCode = 495;

        private ReceivedOrdersControl ordersControl;
        private CashierDataModel cashierData;
        private ItemOrderModel selectedItemOrder;
        private List<TransactionLog> TransactionList;
        private StoreServiceProvider storeServiceProvider;
        private List<SalesOrderDataModel> salesOrders = new List<SalesOrderDataModel>();
        private Tuple<SalesDataModel, ResponseModel> salesDataModel = null;
        private PrintDocument receipt;

        private string orderType = string.Empty;
        private string reasonMessage = string.Empty;

        #endregion

        #region Printer Variables
        private const int lineHeight = 11;
        private const int fontSize = 8;
        private const int margin = 3;
        private const int numberWidth = 7;
        private const int maxXPosition = 180;
        #endregion

        public ReceivedOrdersControlViewModel()
        {
            storeServiceProvider = new StoreServiceProvider();

            Mediator.Instance.Register(this, Messages.ReceivedOrdersViewModel);
            Mediator.Instance.NotifyViewModel(Messages.PendingOrdersWindowViewModel, Messages.OpenClosePendingOrdersWindow, true);

            InitializeProperty();
            IsProcessing = true;

        }

        private void InitializeProperty()
        {
            ReceivedOrdersModel = new ReceivedOrdersModel();
            selectedItemOrder = new ItemOrderModel();

            orderType = OrderStatusDefinition.Pending.ToUpper();

            PrintIsChecked = true;

            receipt = new PrintDocument();
            receipt.PrintPage += PrintReceiptMessage;
        }

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.ReceivedOrdersWindow:
                    ordersControl = (ReceivedOrdersControl)data;
                    IsWindowOpen = true;
                    break;

                case Messages.CashierInfo:
                    cashierData = (CashierDataModel)data;
                    Task.Run(async () =>
                    {
                        PopulateOrders(OrderStatusDefinition.Pending.ToUpper());
                    });
                    break;

                case Messages.PendingOrdersCount:
                    int pendingOrdersCount = (int)data;

                    if (pendingOrdersCount != ReceivedOrdersModel.ItemOrderList.Count() && orderType == OrderStatusDefinition.Pending.ToUpper())
                    {
                        Task.Run(async () =>
                        {
                            PopulateOrders(OrderStatusDefinition.Pending.ToUpper());
                        });
                    }
                    break;

                case Messages.OrderRejectReasonMessage:
                    reasonMessage = data.ToString();
                    break;

                default:
                    break;
            }
        }

        #region Properties

        private ReceivedOrdersModel receivedOrdersModel;
        public ReceivedOrdersModel ReceivedOrdersModel
        {
            get { return receivedOrdersModel; }
            set
            {
                receivedOrdersModel = value;
                RaisePropertyChanged(nameof(ReceivedOrdersModel));
            }
        }

        private bool printIsChecked;
        public bool PrintIsChecked
        {
            get { return printIsChecked; }
            set
            {
                printIsChecked = value;
                RaisePropertyChanged(nameof(PrintIsChecked));
            }
        }

        #endregion

        #region Commands

        public DelegateCommand CloseCommand
        {
            get
            {
                return new DelegateCommand(CloseWindow);
            }
        }

        public DelegateCommand<object> OrderTypeSelectionChangedCommand
        {
            get
            {
                return new DelegateCommand<object>(OrderTypeSelectionChanged);
            }
        }

        public DelegateCommand<object> SelectedOrderCommand
        {
            get
            {
                return new DelegateCommand<object>(SelectedOrder);
            }
        }

        public DelegateCommand CancelOrderCommand
        {
            get
            {
                return new DelegateCommand(CancelOrder);
            }
        }

        public DelegateCommand AcceptOrderCommand
        {
            get
            {
                return new DelegateCommand(AcceptOrder);
            }
        }

        public DelegateCommand WindowClosingCommand
        {
            get
            {
                return new DelegateCommand(WindowClosing);
            }
        }

        #endregion

        #region Event handlers

        private void CloseWindow()
        {
            App.Current.Dispatcher.BeginInvoke((Action)delegate
           {
               if (TaskManagerModel<object>.Instance.CancelAllTasks())
               {
                   if (ordersControl != null)
                   {
                       if (ordersControl.IsLoaded == true && IsWindowOpen)
                       {
                           IsWindowOpen = false;
                           ordersControl.DialogResult = false;
                           ordersControl.Close();
                       }
                   }
               }
           });
        }

        private void WindowClosing()
        {
            Mediator.Instance.UnRegister(this, Messages.ReceivedOrdersViewModel);
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.ReceivedPendingOrdersCount, null);
        }

        private async void OrderTypeSelectionChanged(object parameter)
        {
            IsProcessing = true;
            PopulateOrders(parameter.ToString().ToUpper());
            orderType = parameter.ToString().ToUpper();
        }

        private void SelectedOrder(object parameter)
        {
            for (int x = 0; x < ReceivedOrdersModel.ItemOrderList.Count; x++)
            {
                ReceivedOrdersModel.ItemOrderList[x].IsSelected = false;
            }

            selectedItemOrder = (ItemOrderModel)parameter;
            selectedItemOrder.IsSelected = true;

            if (selectedItemOrder.OrderNumber == ReceivedOrdersModel.SelectedItemOrder.OrderNumber)
            {
                selectedItemOrder.IsSelected = false;
                ReceivedOrdersModel.SelectedItemOrder = new ItemOrderModel();
            }
            else
            {
                selectedItemOrder.IsSelected = true;
                ReceivedOrdersModel.SelectedItemOrder = selectedItemOrder;
            }
        }

        private async void CancelOrder()
        {
            if (selectedItemOrder.IsSelected)
            {
                OrderRejectReasonWindow orderWindow = new OrderRejectReasonWindow();

                Mediator.Instance.NotifyViewModel(Messages.OrderRejectReasonViewModel, Messages.OrderRejectReasonWindow, orderWindow);

                var windowDialogResult = orderWindow.ShowDialog();
                if (!windowDialogResult.Value)
                {
                    return;   
                }

                StoreServiceProvider storeServiceProvider = new StoreServiceProvider();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                });

                ResponseModel responseModel = null;
                try
                {
                    responseModel = await TaskManagerModel<ResponseModel>.Instance.Run(storeServiceProvider.RejectMemberOrder(DataCacheContext.CashierSessionID, selectedItemOrder.OrderID, reasonMessage, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            responseModel = null;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, ordersControl);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });

                if (responseModel != null)
                {
                    ReceivedOrdersModel.ItemOrderList.Remove(selectedItemOrder);
                    selectedItemOrder.IsSelected = false;
                    ReceivedOrdersModel.SelectedItemOrder = new ItemOrderModel();
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.HandledOrder, selectedItemOrder.OrderNumber);
                    UpdatePendingOrderCount();

                    SendOrderNotification(OrderStatusDefinition.Rejected);
                    ShowConfirmationWindow(StandardMessageResource.SuccessOrderReject, Messages.SuccessConfirmation, ordersControl);
                }

                // NOTE: No need to save to
                // the local DB since there was no
                // deduction to the account balance if the
                // order came from a customer through Client app.
                // (Applicable also to order(s) taken by the cashier through Cashier app.)
            }
        }

        private async void AcceptOrder()
        {
            if (selectedItemOrder.IsSelected)
            {
                try
                {
                    if(selectedItemOrder.IsCashier)
                    {
                        selectedItemOrder.IsCashier = false;
                        selectedItemOrder.IsAccepted = true;
                    }

                   StoreServiceProvider storeServiceProvider = new StoreServiceProvider();

                    CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = true;
                    });

                    // Used Tuple<T1, T2> to support additional data since
                    // output parameter is not supported by async
                    // methods.

                    try
                    {
                        salesDataModel = await TaskManagerModel<Tuple<SalesDataModel, ResponseModel>>
                                                    .Instance
                                                    .Run(storeServiceProvider.AcceptMemberOrder(DataCacheContext.CashierSessionID,
                                                                                                selectedItemOrder.OrderID,
                                                                                                cancellationTokenSource.Token),
                                                         cancellationTokenSource,
                                                         ToString(),
                                                         isCriticalTask: true);

                    }
                    catch (AggregateException aggregateException)
                    {
                        bool wasTaskCanceled = false;
                        foreach (var exception in aggregateException.InnerExceptions)
                        {
                            if (exception is TaskCanceledException)
                            {
                                salesDataModel = null;
                                wasTaskCanceled = true;
                                break;
                            }
                        }

                        if (!wasTaskCanceled)
                        {
                            ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation, ordersControl);
                        }
                    }

                    await App.Current.Dispatcher.BeginInvoke((Action)delegate
                    {
                        IsProcessing = false;
                    });

                    if (salesDataModel != null && salesDataModel.Item1 != null)
                    {
                        UpdateStatus(OrderStatusDefinition.Accepted);
                        RecomputeAccountBalance();
                        ReceivedOrdersModel.ItemOrderList.Remove(selectedItemOrder);
                        selectedItemOrder.IsSelected = false;
                        ReceivedOrdersModel.SelectedItemOrder = new ItemOrderModel();
                        SendOrderNotification(OrderStatusDefinition.Accepted, salesDataModel.Item1.Balance.ConvertIntToMoney());
                        Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.HandledOrder, selectedItemOrder.OrderNumber);
                        UpdatePendingOrderCount();

                        ShowConfirmationWindow(StandardMessageResource.SuccessOrderAccept, Messages.SuccessConfirmation, ordersControl);
                    }

                    if (salesDataModel != null)
                    {
                        if (salesDataModel.Item2 != null)
                        {
                            if (salesDataModel.Item2.Result != null)
                            {
                                if (salesDataModel.Item2.Result.GetStatusCode() == InsufficientFundHttpStatusCode)
                                {
                                    SendOrderNotification(OrderStatusDefinition.Rejected);

                                    ReceivedOrdersModel.ItemOrderList.Remove(selectedItemOrder);
                                    selectedItemOrder.IsSelected = false;
                                    ReceivedOrdersModel.SelectedItemOrder = new ItemOrderModel();
                                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.HandledOrder, selectedItemOrder.OrderNumber);
                                    UpdatePendingOrderCount();
                                }

                                if (PrintIsChecked)
                                {
                                    PrintReceipt();
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        UpdatePendingOrderCount();
                    }
                    catch (Exception newEx)
                    {


                    }
                }
            }
        }

        private void UpdateStatus(string orderMode)
        {
            foreach (var transaction in TransactionList)
            {
                if (transaction.Id == selectedItemOrder.TransactionId)
                {
                    var itemOrder = ReceivedOrdersModel.ItemOrderList.FirstOrDefault(x => x.TransactionId == transaction.Id);
                    itemOrder.OrderStatus = orderMode;
                    ReceivedOrdersModel.ItemOrderList.FirstOrDefault(x => x.TransactionId == transaction.Id).IsAccepted = true;
                    var currentOrder = salesOrders.FirstOrDefault(order => order.ReceiptNumber == transaction.OrderReferenceNumber);
                    Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, CreateTransactionModel(transaction));
                }
            }

            if (DataCacheContext.UseLocalDB)
            {
                TransactionRepository.SaveAsync();
            }
        }

        private void UpdatePendingOrderCount()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.ReceivedPendingOrdersCount, null);
        }

        private void SendOrderNotification(string mode, string balance = "")
        {
            Tuple<string, string, string> transactionParameter = new Tuple<string, string, string>(mode, balance, selectedItemOrder.CustomerDetail.CustomerUsername);
            Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.InformAgentTransaction, transactionParameter);
        }

        private void PrintReceipt()
        {
            System.Windows.Forms.PrintDialog printDialog = new System.Windows.Forms.PrintDialog();
            printDialog.Document = receipt;
            printDialog.UseEXDialog = true;

            printDialog.PrinterSettings.PrinterName = DataCacheContext.PrinterName;
            receipt.DocumentName = "PrintReceipt";

            try
            {
                receipt.Print();
            }
            catch (InvalidPrinterException ex)
            {
                ShowConfirmationWindow(StandardMessageResource.ErrorPrinter, Messages.ErrorConfirmation, ordersControl);
            }

        }

        private void PrintReceiptMessage(object sender, PrintPageEventArgs e)
        {
            int yAxis = 0;

            yAxis = PrintNewLine(3, yAxis, e);
            yAxis = PrintExcessCharacterOnNewLine(e, string.Empty, cashierData.Branch.Name, true, 35, 0, 0, yAxis, 0, lineHeight, FontStyle.Bold);
            yAxis = PrintNewLine(3, yAxis, e);
            yAxis = PrintWithRegularFont($"ORDER #: {salesDataModel.Item1.ReceiptNumber}", 7, margin, yAxis, e);
            yAxis = PrintWithRegularFont($"CASHIER: {cashierData.Name}", 7, margin, yAxis, e);
            yAxis = PrintWithRegularFont($"DATE: {DateTime.Now.ToShortDateString()} {DateTime.Now.ToLongTimeString()}", 7, margin, yAxis, e);
            yAxis = PrintNewLine(2, yAxis, e);
            yAxis = PrintWithBoldFont("ITEM", 7, margin, yAxis, e);
            yAxis = PrintWithBoldFont("PRICE", 7, maxXPosition - 30, yAxis - lineHeight, e);
            yAxis = PrintNewLine(1, yAxis, e);
            foreach(SalesRetailDataModel order in salesDataModel.Item1.SalesRetails)
            {
                yAxis = PrintWithRegularFont($"{order.Quantity} x {order.ProductName}", 7, margin, yAxis, e);
                PrintPrice($"{MoneyFormatter.ConvertIntToMoney((order.RetailPrice * order.Quantity).ToString())}", yAxis, e);
            }
            PrintLongLine(yAxis, e);
            yAxis = PrintNewLine(1, yAxis, e);
            yAxis = PrintWithBoldFont("TOTAL", 7, margin, yAxis, e);
            PrintPrice($"{MoneyFormatter.ConvertIntToMoney((salesDataModel.Item1.SalesRetails.Sum(x => x.RetailPrice * x.Quantity)).ToString())}", yAxis, e);
            yAxis = PrintNewLine(2, yAxis, e);

        }

        private int PrintNewLine(int numberOfLines, int yPosition, PrintPageEventArgs e)
        {
            for (int x = 0; x < numberOfLines; x++, yPosition += lineHeight)
                e.Graphics.DrawString("", new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), 0, yPosition);

            return yPosition;
        }
        private int PrintWithRegularFont(string message, int fontSize, int xPosition, int yPosition, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(message, new Font("Arial Narrow", fontSize, FontStyle.Regular), new SolidBrush(Color.Black), xPosition, yPosition);
            return yPosition + lineHeight;
        }
        private int PrintWithBoldFont(string message, int fontSize, int xPosition, int yPosition, PrintPageEventArgs e)
        {
            e.Graphics.DrawString(message, new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), xPosition, yPosition);
            return yPosition + lineHeight;
        }

        private void PrintPrice(string message, int yPosition, PrintPageEventArgs e)
        {
            int padding = 0;
            for (int x = 0; x < message.Length; x++)
            {
                if (message[message.Length - x - 1].ToString() == ".")
                {
                    padding += 2;
                }
                if (message[message.Length - x - 1].ToString() == "1")
                {
                    padding += 1;
                }
                e.Graphics.DrawString(message[message.Length - x - 1].ToString()
                    , new Font("Arial Narrow", 7, FontStyle.Regular)
                    , new SolidBrush(Color.Black)
                    , maxXPosition - x * numberWidth + padding - 10
                    , yPosition - lineHeight);
            }
        }

        private int PrintLongLine(int yPosition, PrintPageEventArgs e)
        {
            for (int x = 0; x < maxXPosition; x += 5)
            {
                e.Graphics.DrawString("-", new Font("Arial Narrow", fontSize, FontStyle.Bold), new SolidBrush(Color.Black), x, yPosition);
            }

            return yPosition + lineHeight;
        }

        #endregion

        #region Async Methods

        private async void PopulateOrders(string orderStatus)
        {
            try
            {
                ReceivedOrdersModel.SelectedItemOrder = new ItemOrderModel();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                var selectedItemOrderNumber = ReceivedOrdersModel.ItemOrderList.Where(x => x.IsSelected).FirstOrDefault();

                TransactionList = null;
                try
                {
                    salesOrders = await TaskManagerModel<List<SalesOrderDataModel>>
                                                .Instance
                                                .Run(storeServiceProvider.GetSalesOrderByStatus(
                                                    cashierData.CashierSessionID,
                                                    orderStatus,
                                                    DateTime.Today.AddDays(-7).ToString("yyyy-MM-ddTHH:mm:ss"),
                                                    DateTime.Today.AddDays(1).ToString("yyyy-MM-ddTHH:mm:ss"),
                                                    cancellationTokenSource.Token), cancellationTokenSource,
                                                    string.Empty,
                                                    isCriticalTask: true);
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    bool isSqlHavingErrors = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            TransactionList = null;
                            wasTaskCanceled = true;
                            break;
                        }
                        else if (exception is SqlException)
                        {
                            isSqlHavingErrors = true;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        if (isSqlHavingErrors)
                        {
                            //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                            //ShowConfirmationWindow(StandardMessageResource.ErrorDatabaseError, Messages.ErrorConfirmation);
                        }
                        else
                        {
                            //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                            //ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                        }
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });


                App.Current.Dispatcher.Invoke(() =>
                {
                    TransactionList = new List<TransactionLog>();
                    ReceivedOrdersModel.ItemOrderList.Clear();
                    string customerID = string.Empty;

                    if (salesOrders != null)
                    {
                        foreach (var order in salesOrders)
                        {
                            bool isCashier = false;
                            ObservableCollection<Items> itemList = new ObservableCollection<Items>();
                            long totalAmount = 0;

                            foreach (var item in order.SalesRetails)
                            {
                                var productItem = new Items()
                                {
                                    Name = item.ProductName,
                                    Price = item.RetailPrice / 100,
                                    Quantity = item.Quantity,
                                    Total = item.Quantity * item.RetailPrice / 100,
                                    ID = item.RetailID.ToString()
                                };

                                itemList.Add(productItem);

                                totalAmount += Convert.ToInt64(productItem.Total);
                            }

                            isCashier = order.CreatedBy.ToLower().Contains("cashier");

                            decimal accountBalance = 0;

                            accountBalance = Convert.ToDecimal(order.AccountBalance.ToString().ConvertIntToMoney());

                            string customerName = string.Empty;

                            if (string.IsNullOrEmpty(order.MemberFirstName) && string.IsNullOrEmpty(order.MemberLastName))
                            {
                                customerName = GetNameOnly(order.CreatedBy);
                            }
                            else
                            {
                                customerName = $"{order.MemberFirstName} {order.MemberLastName}";
                            }

                            CustomerDetail customerInfo = new CustomerDetail()
                            {
                                CustomerName = customerName,
                                TotalAmount = totalAmount,
                                PcName = string.IsNullOrEmpty(order.StationName) ? CashierLabel : order.StationName,
                                StationID = order.StationId,
                                AccountBalance = accountBalance,
                                CustomerUsername = order.CustomerUsername
                            };

                            string itemTime = string.Empty;

                            if (orderStatus == PendingOrder)
                            {
                                itemTime = order.TransactionDateTime.ConvertDateTimeStringToTimeString();
                            }
                            else
                            {
                                itemTime = TimeFormatter.FromEpochToLocalDateTime(order.DateReviewed).ToString().ConvertDateTimeStringToTimeString();
                            }

                            var itemOrder = new ItemOrderModel()
                            {
                                CustomerDetail = customerInfo,
                                IsCashier = isCashier,
                                OrderStatus = orderStatus,
                                IsSelected = false,
                                ItemList = itemList,
                                OrderDate = order.TransactionDateTime.ConvertDateTimeStringToDateString(),
                                OrderDateTime = order.TransactionDateTime.ConvertDateTimeStringToDateTimeMeridiem(),
                                OrderNumber = order.ReceiptNumber,
                                IsAccepted = orderStatus == PendingOrder ? false : true,
                                OrderTime = itemTime,
                                TransactionId = Guid.NewGuid(),
                                OrderID = order.ID
                            };

                            ReceivedOrdersModel.ItemOrderList.Add(itemOrder);

                            TransactionList.Add(CreateTransactionLogModel(order, itemOrder));
                        }

                        IOrderedEnumerable<ItemOrderModel> sortedPendingOrders = null;

                        if (orderStatus == OrderStatusDefinition.Pending.ToUpper())
                        {
                            // Sort first the date in ascending order then sort the time in
                            // ascending order also since there might be branch(es) that would operate
                            // and service 24 hours or more.
                            sortedPendingOrders = ReceivedOrdersModel
                                                    .ItemOrderList
                                                    .OrderBy(x => x.OrderDate).ThenBy(x => x.OrderTime.Split(' ')[1]).ThenBy(x => DateTime.Parse(x.OrderTime)).ThenBy(x => x.OrderNumber.Split('-')[2]);
                        }
                        else
                        {
                            // Sort only by date and time in descending order.
                            sortedPendingOrders = ReceivedOrdersModel
                                                    .ItemOrderList
                                                    .OrderByDescending(x => x.OrderDate).ThenByDescending(x => x.OrderTime.Split(' ')[1]).ThenByDescending(x => DateTime.Parse(x.OrderTime)).ThenByDescending(x => x.OrderNumber.Split('-')[2]);
                        }

                        ReceivedOrdersModel.ItemOrderList = new ObservableCollection<ItemOrderModel>(sortedPendingOrders);

                        if (selectedItemOrderNumber != null)
                        {
                            var itemToBeSelected = ReceivedOrdersModel.ItemOrderList.Where(x => x.OrderNumber == selectedItemOrderNumber.OrderNumber).FirstOrDefault();
                            if (itemToBeSelected != null)
                            {
                                itemToBeSelected.IsSelected = true;
                            }
                        }
                    }
                });

            }
            catch (SqlException ex)
            {

            }
        }

        #endregion

        #region Private Methods

        private string GetNameOnly(string createdBy)
        {
            string[] name = createdBy.Split(new char[] { '-' });

            return name.Last();
        }

        private TransactionLog CreateTransactionLogModel(SalesOrderDataModel model, ItemOrderModel itemOrder)
        {
            DateTime transactionDateTime = new DateTime();

            DateTime.TryParse(model.TransactionDateTime, out transactionDateTime);

            var log = new TransactionLog()
            {
                Id = itemOrder.TransactionId,
                AccountName = itemOrder.CustomerDetail.CustomerName,
                TransactionType = (short)TransactionType.NewOrder,
                TransactionAmount = itemOrder.CustomerDetail.TotalAmount.ConvertLongToMoney(),
                Remarks = itemOrder.IsAccepted ? OrderAccepted : PendingOrder,
                TransactionDate = transactionDateTime,
                CashierName = GetNameOnly(model.CreatedBy)
            };

            return log;
        }

        private TransactionModel CreateTransactionModel(TransactionLog transaction)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = StandardMessageResource.TransactNewOrder,
                CustomerName = transaction.AccountName,
                CustomerID = transaction.Id.ToString(),
                TransactionAmount = $"{CurrencySymbol}{(Convert.ToDouble(transaction.TransactionAmount) / 100).ToString("N2")}",
                TransactionRemarks = OrderAccepted,
                CashierName = transaction.CashierName
            };
            return transactionModel;
        }

        private TransactionModel CreateTransactionModel(TransactionLog transaction, string createdBy)
        {
            var model = CreateTransactionModel(transaction);

            if (string.IsNullOrEmpty(model.CustomerName))
            {
                model.CustomerName = createdBy;
            }

            return model;
        }
        
        private void CloseWindowImmediately()
        {
            App.Current.Dispatcher.BeginInvoke((Action)delegate
           {
               TaskManagerModel<object>.Instance.CancelAllTasksWithoutWarning();
               if (ordersControl != null)
               {
                   if (ordersControl.IsLoaded == true && IsWindowOpen)
                   {
                       IsWindowOpen = false;
                       ordersControl.DialogResult = false;
                       ordersControl.Close();
                   }
               }
           });
        }

        private void RecomputeAccountBalance()
        {
            if (ReceivedOrdersModel.ItemOrderList != null && ReceivedOrdersModel.SelectedItemOrder != null)
            {
                foreach (ItemOrderModel order in ReceivedOrdersModel.ItemOrderList)
                {
                    if (order.CustomerDetail != null && ReceivedOrdersModel.SelectedItemOrder.CustomerDetail != null)
                    {
                        if (order.CustomerDetail.CustomerUsername == ReceivedOrdersModel.SelectedItemOrder.CustomerDetail.CustomerUsername)
                        {
                            order.CustomerDetail.AccountBalance -= ReceivedOrdersModel.SelectedItemOrder.CustomerDetail.TotalAmount;
                        }
                    }
                }
            }
        }

        #endregion
    }
}
