﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Helper;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.MessageResource;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using gocafe_cashier.Card;
using System.Linq;
using System;
using System.Threading.Tasks;
using gocafe_cashier.TaskManager;
using System.Threading;
using gocafe_cashier.ViewModelMediator;
using System.ServiceProcess;
using GocafeShared.Utilities;
using GocafeShared.Model.Network;
using gocafe_cashier.Network;
using GocafeShared.Definition;

namespace gocafe_cashier.ViewModel
{
    public class LoginWindowViewModel : AbstractViewModel
    {
        public LoginWindowViewModel(IView view) : base(view)
        {
            LoginModel = new LoginModel();
            Mediator.Instance.Register(this, Messages.LoginWindows);

            CheckSQLServerStatus();
            GetStationInformation();
        }

        #region Private constant variables

        private const string WorkstationStatusOccupied = "Occupied";
        private const string ComputerName = "COMPUTERNAME";
        private const string AsyncTimeout = "AsyncTimeout";
        private const string PrinterName = "PrinterName";
        private const string ServerPort = "ServerPort";
        private CashierStationInformationDataModel cashierStationInformation;

        #endregion

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.StopLoading:
                    StopLoading();
                    break;

                case Messages.ClientAccountDetails:
                    OnAccountDetailReceived((MemberAccountModel)data);
                    break;

                case Messages.ConnectionEstablished:
                    OnConnectionEstablished((ClientPC)data);
                    break;

                case Messages.ClientDisconnected:
                    OnClientDisconnected((ClientPC)data);
                    break;

                case Messages.LockPC:
                    OnClientPCLocked((ClientPC)data);
                    break;

                default:
                    break;
            }
        }

        #region Properties

        private LoginModel loginModel;
        public LoginModel LoginModel
        {
            get { return loginModel; }
            set
            {
                loginModel = value;
                RaisePropertyChanged(nameof(LoginModel));
            }
        }

        #endregion


        #region Commands

        public ICommand LoginCommand
        {
            get
            {
                return new DelegateCommand<object>(LoginClicked);
            }
        }

        public ICommand ValidateFieldsCommand
        {
            get
            {
                return new DelegateCommand<object>(ValidateFields);
            }
        }

        public ICommand CancelCommand
        {
            get
            {
                return new DelegateCommand(CancelButtonClick);
            }
        }

        #endregion


        #region Event handlers
        
        private void ValidateFields(object parameter)
        {
            string message = string.Empty;
            string messageMode = string.Empty;

            LoginModel.PasswordErrorMessage = string.Empty;
            LoginModel.UsernameErrorMessage = string.Empty;

            LoginModel.IsUsernameInvalid = false;
            LoginModel.IsPasswordInvalid = false;

            LoginModel.PasswordBorderBrush = Brushes.Transparent;
            LoginModel.UsernameBorderBrush = Brushes.Transparent;

            LoginModel.ButtonIsEnabled = true;

            PasswordBox cashierPassword = parameter as PasswordBox;
            if (LoginModel.Username == string.Empty || LoginModel.Username == null)
            {
                LoginModel.UsernameErrorMessage = StandardMessageResource.ErrorUsernameIsEmpty;
                LoginModel.IsUsernameInvalid = true;
                LoginModel.UsernameBorderBrush = Brushes.Red;
                LoginModel.ButtonIsEnabled = false;
            }
            else if (LoginModel.Username.Length < 4)
            {
                LoginModel.UsernameErrorMessage = StandardMessageResource.ErrorUsernameLessThan4;
                LoginModel.IsUsernameInvalid = true;
                LoginModel.UsernameBorderBrush = Brushes.Red;
                LoginModel.ButtonIsEnabled = false;
            }

            if (cashierPassword.Password == "" || cashierPassword.Password == null)
            {
                LoginModel.PasswordErrorMessage = StandardMessageResource.ErrorPasswordIsEmpty;
                LoginModel.IsPasswordInvalid = true;
                LoginModel.PasswordBorderBrush = Brushes.Red;
                LoginModel.ButtonIsEnabled = false;
            }
            else if (cashierPassword.Password.Length < 4)
            {
                LoginModel.PasswordErrorMessage = StandardMessageResource.ErrorPasswordLessThan4;
                LoginModel.IsPasswordInvalid = true;
                LoginModel.PasswordBorderBrush = Brushes.Red;
                LoginModel.ButtonIsEnabled = false;
            }
        }

        private void CancelButtonClick()
        {
            CloseView();
        }

        private async void LoginClicked(object parameter)
        {
            if (!LoginModel.IsPasswordInvalid && !LoginModel.IsUsernameInvalid && LoginModel.ButtonIsEnabled)
            {
                try
                {
                    if (IsProcessing)
                    {
                        return;
                    }

                    ProcessingText = "LOGGING IN . . .";

                    if (cashierStationInformation == null)
                    {
                        IsProcessing = true;
                        await GetStationInformation();

                        if(cashierStationInformation == null)
                        {
                            return;
                        }                        
                    }

                    //For access token
                    //string accessToken = HttpUtilities.GetAccessToken();
                    string responseMessage = string.Empty;
                    PasswordBox passwordBox = parameter as PasswordBox;

                    if (LoginModel.Username != null && passwordBox.Password != string.Empty)
                    {
                        await App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            IsProcessing = true;
                        });

                        // TODO: by Jemeel (bypass actual login for testing)
                        LoginServiceProvider loginService = new LoginServiceProvider();
                        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                        CashierDataModel loginData = null;
                        try
                        {
                            loginData = await TaskManagerModel<CashierDataModel>.Instance.Run(loginService.Login(LoginModel.Username, passwordBox.Password, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                        }
                        catch (AggregateException aggregateException)
                        {
                            bool wasTaskCanceled = false;
                            foreach (var exception in aggregateException.InnerExceptions)
                            {
                                if (exception is TaskCanceledException)
                                {
                                    loginData = null;
                                    wasTaskCanceled = true;
                                    break;
                                }
                            }

                            if (!wasTaskCanceled)
                            {
                                ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                            }
                        }
                        
                        //CashierDataModel loginData = new CashierDataModel();
                        //loginData.ID = "33fc322d-4e0d-4018-976f-e02c0a1de6e6";
                        //loginData.Branch = new BranchDataModel()
                        //{
                        //    Address = "Address",
                        //    Name = "Lorenji"
                        //};
                        //loginData.Email = "testemail@godigitalcorp.com";
                        //loginData.Name = "Test Cashier";
                        //loginData.Username = "lorenji";
                        //statusCode = 200;

                        if (loginData != null)
                        {
                            DataCacheContext.CashierSessionID = loginData.CashierSessionID;
                            loginData.Password = passwordBox.Password;

                            App.Current.Dispatcher.Invoke(() =>
                            {
                                ViewService.Instance.ShowView<MainViewModel>((view) => { return new MainViewModel(view, loginData); });
                                CloseView();
                            });
                            CardUtilities card = CardUtilities.Instance;
                            card.StartMonitoring();
                        }
                    }
                }
                catch(Exception ex)
                {
                    LoginModel.Error = string.Format(StandardMessageResource.ErrorConnectionIssue, StandardMessageResource.TransactWordLogin, StandardMessageResource.TransactWordServer);
                    LoginModel.IsErrorMessageShown = true;
                }
            }
        }

        #endregion

        private async void StopLoading()
        {
            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                IsProcessing = false;
            });
        }

        #region Event Handler - observer for network lib

        private void OnAccountDetailReceived(MemberAccountModel model)
        {
            if (!DataCacheContext.MemberAccountModels.ContainsKey(model.StationID))
            {
                try
                {
                    DataCacheContext.MemberAccountModels.TryAdd(model.StationID, model);
                }
                catch (ArgumentException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        private void SendCancelOrderNotification(OrderDetailModel orderDetail)
        {
            var pool = DataCacheContext.WorkstationModels.Values.ToList();

            if (pool.Count > 0)
            {
                var clientPcList = pool.Where(pc => pc.PCID == orderDetail.StationID);
                bool isExists = clientPcList.Count() > 0 ? true : false;

                if (isExists)
                {
                    ClientPC clientPc = clientPcList.First();

                    NetworkServer.Instance.SendMessageToClientUsingIP(clientPc.IPAddress, NetworkMessageType.NoActiveCashier, null);
                }
            }
        }

        private void OnConnectionEstablished(ClientPC pcInfo)
        {
            if (pcInfo.PCID != null && pcInfo.PCID != string.Empty)
            {
                if (!DataCacheContext.WorkstationModels.ContainsKey(pcInfo.PCID))
                {
                    DataCacheContext.WorkstationModels.TryAdd(pcInfo.PCID, pcInfo);
                }
            }
        }

        private void OnClientDisconnected(ClientPC pcInfo)
        {
            if (pcInfo.PCID != null && pcInfo.PCID != string.Empty)
            {
                if (DataCacheContext.WorkstationModels.ContainsKey(pcInfo.PCID))
                {
                    ClientPC tempBuffer = new ClientPC();
                    DataCacheContext.WorkstationModels.TryRemove(pcInfo.PCID, out tempBuffer);
                }
            }
        }

        private void OnClientPCLocked(ClientPC pcInfo)
        {
            if (pcInfo.PCID != null && pcInfo.PCID != string.Empty)
            {
                if (DataCacheContext.WorkstationModels.ContainsKey(pcInfo.PCID))
                {
                    ClientPC tempBuffer = new ClientPC();
                    DataCacheContext.WorkstationModels.TryRemove(pcInfo.PCID, out tempBuffer);
                    tempBuffer.IsLocked = pcInfo.IsLocked;
                    DataCacheContext.WorkstationModels.TryAdd(pcInfo.PCID, tempBuffer);
                }
            }
        }

        #endregion

        #region Private Methods

        private void CheckSQLServerStatus()
        {
            ServiceController sqlService = new ServiceController("MSSQL$SQLEXPRESS");
            string sqlServiceStatus = string.Empty;

            try
            {
                sqlServiceStatus = sqlService.Status.ToString().ToUpper();
            }
            catch (Exception ex)
            {
                DataCacheContext.UseLocalDB = false;
            }

            if (sqlServiceStatus == "RUNNING")
            {
                //temporarily commented out. will remove db later
                //DataCacheContext.UseLocalDB = true;
            }
            else
            {
                DataCacheContext.UseLocalDB = false;
            }
        }

        private async Task GetStationInformation()
        {
            IsProcessing = true;
            string macAddress = NetworkInterfaceHelper.GetMacAddress().ToString();
            string macAddressDashed = NetworkInterfaceHelper.FormatMacAddress(macAddress, ":");

            CashierServiceProvider cashierService = new CashierServiceProvider();
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            cashierStationInformation = await TaskManagerModel<CashierStationInformationDataModel>.Instance.Run(cashierService.GetStationInformation(macAddressDashed, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);

            App.Current.Dispatcher.Invoke(() =>
            {
                IsProcessing = false;
            });
            if (cashierStationInformation != null)
            {
                DataCacheContext.BranchID = cashierStationInformation.ID;

                DataCacheContext.TopupMaximumAmount = cashierStationInformation.TopupMaximumAmount / 100;

                DataCacheContext.CurrencySymbol = cashierStationInformation.CurrencySign;

                foreach (BranchConfigurationsDataModel config in cashierStationInformation.Configuration)
                {
                    switch (config.SettingCode)
                    {
                        case AsyncTimeout:
                            int timeoutValue = 0;
                            if(Int32.TryParse(config.value, out timeoutValue))
                            {
                                DataCacheContext.AsyncTimeout = Convert.ToInt32(timeoutValue);
                            }                            
                            break;

                        case ServerPort:
                            int portValue = 0;
                            if(Int32.TryParse(config.value, out portValue))
                            {
                                DataCacheContext.ServerPort = Convert.ToInt32(config.value);
                            }                            
                            break;

                        case PrinterName:
                            DataCacheContext.PrinterName = config.value;
                            break;

                        default:
                            break;
                    }
                }

                NetworkServer.Instance.Start();
            }
        }

        #endregion
    }
}
