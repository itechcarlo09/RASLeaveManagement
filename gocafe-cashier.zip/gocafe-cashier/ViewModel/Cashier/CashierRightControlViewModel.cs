﻿using gocafe_cashier.Cache;
using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Mapper.ModelUI;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.MessageResource;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using NetworkCommsDotNet.Connections;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using GocafeDatabaseModel;
using gocafe_cashier.ViewModel.Database;
using GocafeShared.Utilities.StringFormat;
using gocafe_cashier.DbAccess;
using System.Threading;
using gocafe_cashier.TaskManager;
using GocafeDatabaseModel.Result;
using System.Data.SqlClient;
using GocafeShared.Model;
using gocafe_cashier.Validation;
using System.Net;
using GocafeShared.Model.Network;
using gocafe_cashier.Network;
using GocafeShared.Definition;
using gocafe_cashier.Network.WakeOnLan;

namespace gocafe_cashier.ViewModel.Cashier
{
    class CashierRightControlViewModel : TransactionLogViewModelBase
    {
        #region Private constant variables

        private const string WorkstationStatusOffline = "Offline";
        private const string WorkstationStatusAvailable = "Available";
        private const string WorkstationStatusOccupied = "Occupied";
        private const string MemberTypeGuest = "GUEST";

        #endregion


        #region Private Fields

        private CashierDataModel userData;
        private List<WorkstationModel> selectedPCs = new List<WorkstationModel>();

        #endregion

        public CashierRightControlViewModel()
        {
            Mediator.Instance.Register(this, Messages.RightUserControl);

            CashierRightControlModel = new CashierRightControlModel();
            ListViewVisibility = false;
            GridViewVisibility = true;

            CashierRightControlModel.IsShownLoading = true;

            CashierRightControlModel.IsTransactionShownLoading = true;

            InitializeStationList();

            if (DataCacheContext.UseLocalDB)
            {
                DBTaskManager.Instance.LocalDatabaseTask = Task.Run(() =>
                {
                    PopulateRecentTransactionLogsFromLocalDB();
                });
            }
            else
            {
                DBTaskManager.Instance.LocalDatabaseTask = Task.Run(() =>
                {
                    PopulateRecentTransactionLogs();
                });
            }
        }

        private async void RefreshStationList()
        {
            InitializeStationList();
        }

        private async void InitializeStationList()
        {
            try
            {
                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, true);

                List<ClientPC> clientPCList = DataCacheContext.WorkstationModels.Values.ToList();

                ClearAllWorkStations();
                await GetStationTypeList();
                await GetStationList();

                CashierRightControlModel.RegularSortMode = "ALL";
                CashierRightControlModel.GoldSortMode = "ALL";
                CashierRightControlModel.VIPSortMode = "ALL";

                NetworkServer.Instance.ReconnectAllClients(clientPCList);

                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, false);
            }
            catch (AggregateException ae)
            {
                ae.Handle(x =>
                {
                    if (ae is Exception)
                    {
                        string message = string.Format(StandardMessageResource.ErrorConnectionIssue, StandardMessageResource.TransactWordConnect, StandardMessageResource.TransactWordServer);
                        ShowErrorMessage(message);
                        Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, false);
                        return true;
                    }
                    Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, false);
                    return false;
                });
            }
        }

        private async void OpenTopUpManagerWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenTopUpManager, null);
        }

        private async void OpenAccountManager()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenAccountManager, null);
        }

        private async void OpenResetPasswordWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenResetPassword, null);
        }

        private async void OpenCouponWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenCoupon, null);
        }

        private async void OpenReplaceCardWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenReplaceCard, null);
        }

        private async void OpenFoodAndBeverageWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenFoodAndBeverage, null);
        }

        private async void OpenReceivedOrdersWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenReceivedOrders, null);
        }

        private async void OpenInventoryManagerWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenInventoryManager, null);
        }

        private async void OpenEShopWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenEShop, null);
        }

        private async void OpenLogOutCustomerWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenLogOutCustomer, null);
        }

        private async void OpenCancelPromoWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenCancelPromo, null);
        }

        private async void OpenTransactionHistoryWindow()
        {
            Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.OpenTransactionHistory, null);
        }
        #region Commands

        public ICommand PcButtonCommand
        {
            get
            {
                return new DelegateCommand(PcButtonClick);
            }
        }

        public ICommand TransactionSelectedCommand
        {
            get
            {
                return new DelegateCommand<object>(TransactionSelected);
            }
        }

        public ICommand PcRightButtonCommand
        {
            get
            {
                return new DelegateCommand<object>(PcRightButtonClick);
            }
        }

        public ICommand GridViewCommand
        {
            get
            {
                return new DelegateCommand(GridViewClicked);
            }
        }

        public ICommand ListViewCommand
        {
            get
            {
                return new DelegateCommand(ListViewClicked);
            }
        }

        public ICommand PcNameSortCommand
        {
            get
            {
                return new DelegateCommand(PcNameSort);
            }
        }

        public ICommand PcAreaSortCommand
        {
            get
            {
                return new DelegateCommand(PcAreaSort);
            }
        }

        public ICommand PcStatusSortCommand
        {
            get
            {
                return new DelegateCommand(PcStatusSort);
            }
        }

        public ICommand PcUserTypeSortCommand
        {
            get
            {
                return new DelegateCommand(PcUserTypeSort);
            }
        }

        public ICommand ShowRegularPcCommand
        {
            get
            {
                return new DelegateCommand<object>(ShowRegularPc);
            }
        }

        public ICommand ShowGoldPcCommand
        {
            get
            {
                return new DelegateCommand<object>(ShowGoldPc);
            }
        }

        public ICommand ShowVIPPcCommand
        {
            get
            {
                return new DelegateCommand<object>(ShowVIPPc);
            }
        }

        public ICommand ShutdownPcCommand
        {
            get
            {
                return new DelegateCommand(ShutdownPc);
            }
        }

        public ICommand PowerControlCommand
        {
            get
            {
                return new DelegateCommand(PowerControl);
            }
        }

        public ICommand WakePCCommand
        {
            get
            {
                return new DelegateCommand(WakePC);
            }
        }

        public ICommand TopupPcCommand
        {
            get
            {
                return new DelegateCommand(TopupPc);
            }
        }

        public ICommand LogoutPcCommand
        {
            get
            {
                return new DelegateCommand(LogoutPc);
            }
        }

        public ICommand EndPromoCommand
        {
            get
            {
                return new DelegateCommand(EndUserPromo);
            }
        }

        public ICommand LoginGuestCommand
        {
            get
            {
                return new DelegateCommand(LoginGuest);
            }
        }

        public ICommand PCTransferCommand
        {
            get
            {
                return new DelegateCommand(PCTransfer);
            }
        }

        public ICommand RefreshStationListCommand
        {
            get
            {
                return new DelegateCommand(RefreshStationList);
            }
        }

        public ICommand TopUpManagerCommand
        {
            get
            {
                return new DelegateCommand(OpenTopUpManagerWindow);
            }
        }

        public ICommand NewCustomerCommand
        {
            get
            {
                return new DelegateCommand(OpenAccountManager);
            }
        }

        public ICommand ResetPasswordCommand
        {
            get
            {
                return new DelegateCommand(OpenResetPasswordWindow);
            }
        }

        public ICommand CouponManagerWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenCouponWindow);
            }
        }

        public ICommand ReplaceCardCommand
        {
            get
            {
                return new DelegateCommand(OpenReplaceCardWindow);
            }
        }

        public ICommand FoodAndBeverageManagerWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenFoodAndBeverageWindow);
            }
        }

        public ICommand ReceivedOrdersWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenReceivedOrdersWindow);
            }
        }

        public ICommand InventoryManagerWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenInventoryManagerWindow);
            }
        }

        public ICommand EShopWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenEShopWindow);
            }
        }

        public ICommand ForceLogOutCommand
        {
            get
            {
                return new DelegateCommand(OpenLogOutCustomerWindow);
            }
        }

        public ICommand CancelPromoCommand
        {
            get
            {
                return new DelegateCommand(OpenCancelPromoWindow);
            }
        }

        public ICommand TransactionHistoryWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenTransactionHistoryWindow);
            }
        }
        #endregion

        #region EventHandlers

        public override void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.StationList:
                    Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.StationList, CashierRightControlModel.GetAvailableWorkStation());
                    break;
                case Messages.SendUserInfo:
                    userData = data as CashierDataModel;
                    break;

                case Messages.TransactionModel:
                    AddThenRemoveTransaction(data);
                    break;

                case Messages.InformAgentTransaction:
                    //Item1 = TransactionMode (TOPUP / ACCEPTORDER / REJECTORDER) : Item2 (Updated balance of user) : Item3 (Username)
                    Tuple<string, string, string> transactionParameter = (Tuple<string, string, string>)data;
                    WorkstationModel memberWorkstation = cashierRightControlModel.AllWorkStationList.FirstOrDefault(x => x.AccountModel.Username == transactionParameter.Item3);

                    switch (transactionParameter.Item1)
                    {
                        case "TOPUP":
                            if (memberWorkstation != null)
                            {
                                NetworkServer.Instance.SendMessageToClientUsingIP(memberWorkstation.StationModel.StaticIPAddress, NetworkMessageType.TopupSignal, null);
                                memberWorkstation.AccountModel.Balance = transactionParameter.Item2;
                            }
                            break;

                        case "Accepted":
                        case "Rejected":
                            var pool = DataCacheContext.WorkstationModels.Values.ToList();
                            if (pool.Count > 0 && memberWorkstation != null)
                            {
                                var clientPcList = pool.Where(pc => pc.PCID == memberWorkstation.StationModel.ID);
                                bool isExists = clientPcList.Count() > 0 ? true : false;

                                if (isExists)
                                {
                                    ClientPC clientPc = clientPcList.First();

                                    if (transactionParameter.Item1 == "Accepted")
                                    {
                                        NetworkServer.Instance.SendMessageToClientUsingIP(clientPc.IPAddress, NetworkMessageType.AcceptOrder, null);
                                    }
                                    else
                                    {
                                        NetworkServer.Instance.SendMessageToClientUsingIP(clientPc.IPAddress, NetworkMessageType.RejectOrder, null);
                                    }

                                    if (transactionParameter.Item1 == "Accepted" && memberWorkstation != null)
                                    {
                                        memberWorkstation.AccountModel.Balance = transactionParameter.Item2;
                                    }
                                }
                            }
                            break;

                        default:
                            break;
                    }
                    break;

                case Messages.ConnectionEstablished:
                    OnConnectionEstablished((ClientPC)data);
                    Mediator.Instance.NotifyViewModel(Messages.PCTransferWindowViewModel, Messages.StationList, CashierRightControlModel.GetAvailableWorkStation());
                    break;

                case Messages.ClientAccountDetails:
                    OnAccountDetailReceived((MemberAccountModel)data);
                    break;

                case Messages.ClientDisconnected:
                    OnClientDisconnected((ClientPC)data);
                    Mediator.Instance.NotifyViewModel(Messages.PCTransferWindowViewModel, Messages.StationList, CashierRightControlModel.GetAvailableWorkStation());
                    break;

                case Messages.LockPC:
                    UpdatePCLockStatus((ClientPC)data);
                    break;

                case Messages.ClientUpdatedAccountBalance:
                    OnUpdateAccountBalanceReceived((MemberAccountModel)data);
                    break;

                default:
                    break;
            }
        }

        private void AddThenRemoveTransaction(object data)
        {
            TransactionModel transactionData = data as TransactionModel;

            App.Current.Dispatcher.Invoke(() =>
            {
                CashierRightControlModel.TransactionLogsList.Insert(0, transactionData);

                if (CashierRightControlModel.TransactionLogsList.Count > 30)
                {
                    CashierRightControlModel.TransactionLogsList.RemoveAt(30);
                }
            });

        }

        public void ListViewClicked()
        {
            ListViewVisibility = true;
            GridViewVisibility = false;
        }

        public void GridViewClicked()
        {
            GridViewVisibility = true;
            ListViewVisibility = false;
        }

        public void PcButtonClick()
        {
            List<WorkstationModel> previouslySelectedPCs = new List<WorkstationModel>(selectedPCs);

            selectedPCs = new List<WorkstationModel>();
            foreach (WorkstationModel workStationModelData in CashierRightControlModel.RegularWorkStationList)
            {
                workStationModelData.IsShow = false;
                if (workStationModelData.IsSelected)
                {
                    selectedPCs.Add(workStationModelData);
                }
            }

            foreach (WorkstationModel workStationModelData in CashierRightControlModel.GoldWorkStationList)
            {
                workStationModelData.IsShow = false;
                if (workStationModelData.IsSelected)
                {
                    selectedPCs.Add(workStationModelData);
                }
            }

            foreach (WorkstationModel workStationModelData in CashierRightControlModel.VIPWorkStationList)
            {
                workStationModelData.IsShow = false;
                if (workStationModelData.IsSelected)
                {
                    selectedPCs.Add(workStationModelData);
                }
            }

            if (selectedPCs.Count < 1)
            {
                return;
            }
            else if (selectedPCs.Count == 1)
            {
                WorkstationModel workStationModelData = selectedPCs[0];

                if(workStationModelData.AccountModel.UserType == MemberTypeGuest)
                {
                    workStationModelData.AccountModel.Customer = workStationModelData.AccountModel.Username;
                }

                if (CashierLeftControlViewModel.Default.WorkStationModel.StationModel != null && CashierLeftControlViewModel.Default.WorkStationModel.StationModel.StaticIPAddress == workStationModelData.StationModel.StaticIPAddress && CashierLeftControlViewModel.Default.WorkStationModel.IsShow)
                {
                    CashierLeftControlViewModel.Default.WorkStationModel.IsShow = false;
                }
                else if (CashierLeftControlViewModel.Default.WorkStationModel.StationModel != null && CashierLeftControlViewModel.Default.WorkStationModel.StationModel.StaticIPAddress != workStationModelData.StationModel.StaticIPAddress && CashierLeftControlViewModel.Default.WorkStationModel.IsShow)
                {
                    CashierLeftControlViewModel.Default.WorkStationModel.IsShow = false;
                    workStationModelData.IsShow = true;
                    workStationModelData.AccountModel.TimeElapsed = GetTimeElapsed(workStationModelData.AccountModel.StartTime);
                    CashierLeftControlViewModel.Default.PcNumber = workStationModelData.StationModel.Name;
                    CashierLeftControlViewModel.Default.WorkStationModel = workStationModelData;
                }
                else
                {
                    workStationModelData.IsShow = true;
                    workStationModelData.AccountModel.TimeElapsed = GetTimeElapsed(workStationModelData.AccountModel.StartTime);
                    CashierLeftControlViewModel.Default.PcNumber = workStationModelData.StationModel.Name;
                    CashierLeftControlViewModel.Default.WorkStationModel = workStationModelData;
                }
            }
            else
            {
                CashierLeftControlViewModel.Default.WorkStationModel = new WorkstationModel();
                CashierLeftControlViewModel.Default.WorkStationModel.IsShow = false;
                foreach (WorkstationModel workStationModelData in selectedPCs)
                {
                    workStationModelData.IsShow = true;
                }
            }

        }

        private void TransactionSelected(object parameter)
        {
            for (int x = 0; x < CashierRightControlModel.TransactionLogsList.Count; x++)
            {
                CashierRightControlModel.TransactionLogsList[x].IsSelected = false;
            }
        }

        public void PcRightButtonClick(object parameter)
        {
            CashierRightControlModel.IsTopUpPCButtonShown = false;
            CashierRightControlModel.IsLoginGuestButtonShown = false;
            CashierRightControlModel.IsLogoutPCButtonShown = false;
            CashierRightControlModel.IsPowerOnPCButtonShown = true;
            CashierRightControlModel.IsTransferPcButtonShown = false;
            CashierRightControlModel.IsEndPromoButtonShown = false;

            if (parameter != null)
            {
                CashierRightControlModel.SelectedWorkStations = new List<WorkstationModel>();

                if (selectedPCs.Count < 1)
                {
                    WorkstationModel workStationModelData = new WorkstationModel();
                    workStationModelData = (WorkstationModel)parameter;

                    workStationModelData.IsSelected = true;
                    workStationModelData.IsShow = true;
                    if (CashierLeftControlViewModel.Default.WorkStationModel.StationModel != null && CashierLeftControlViewModel.Default.WorkStationModel.StationModel.StaticIPAddress == workStationModelData.StationModel.StaticIPAddress && CashierLeftControlViewModel.Default.WorkStationModel.IsShow)
                    {
                        CashierLeftControlViewModel.Default.WorkStationModel.IsShow = true;
                    }
                    else if (CashierLeftControlViewModel.Default.WorkStationModel.StationModel != null && CashierLeftControlViewModel.Default.WorkStationModel.StationModel.StaticIPAddress != workStationModelData.StationModel.StaticIPAddress && CashierLeftControlViewModel.Default.WorkStationModel.IsShow)
                    {
                        CashierLeftControlViewModel.Default.WorkStationModel.IsShow = false;
                        workStationModelData.IsShow = true;
                    }
                    else
                    {
                        workStationModelData.IsShow = true;
                    }

                    workStationModelData.AccountModel.TimeElapsed = GetTimeElapsed(workStationModelData.AccountModel.StartTime);
                    CashierLeftControlViewModel.Default.PcNumber = workStationModelData.StationModel.Name;
                    CashierLeftControlViewModel.Default.WorkStationModel = workStationModelData;
                    CashierRightControlModel.SelectedWorkStations.Add(workStationModelData);
                }
                else
                {
                    bool rightClickedPCAlreadySelected = false;
                    foreach (WorkstationModel workStationModelData in selectedPCs)
                    {
                        if (workStationModelData == (WorkstationModel)parameter)
                        {
                            rightClickedPCAlreadySelected = true;
                            break;
                        }
                    }

                    if (rightClickedPCAlreadySelected)
                    {
                        foreach (WorkstationModel workStationModelData in selectedPCs)
                        {
                            CashierRightControlModel.SelectedWorkStations.Add(workStationModelData);
                        }
                    }
                    else
                    {
                        foreach (WorkstationModel selectedPC in selectedPCs)
                        {
                            selectedPC.IsSelected = false;
                        }

                        WorkstationModel workStationModelData = new WorkstationModel();
                        workStationModelData = (WorkstationModel)parameter;

                        workStationModelData.IsSelected = true;
                        workStationModelData.IsShow = true;
                        if (CashierLeftControlViewModel.Default.WorkStationModel.StationModel != null && CashierLeftControlViewModel.Default.WorkStationModel.StationModel.StaticIPAddress == workStationModelData.StationModel.StaticIPAddress && CashierLeftControlViewModel.Default.WorkStationModel.IsShow)
                        {
                            CashierLeftControlViewModel.Default.WorkStationModel.IsShow = true;
                        }
                        else if (CashierLeftControlViewModel.Default.WorkStationModel.StationModel != null && CashierLeftControlViewModel.Default.WorkStationModel.StationModel.StaticIPAddress != workStationModelData.StationModel.StaticIPAddress && CashierLeftControlViewModel.Default.WorkStationModel.IsShow)
                        {
                            CashierLeftControlViewModel.Default.WorkStationModel.IsShow = false;
                            workStationModelData.IsShow = true;
                        }
                        else
                        {
                            workStationModelData.IsShow = true;
                        }

                        workStationModelData.AccountModel.TimeElapsed = GetTimeElapsed(workStationModelData.AccountModel.StartTime);
                        CashierLeftControlViewModel.Default.PcNumber = workStationModelData.StationModel.Name;
                        CashierLeftControlViewModel.Default.WorkStationModel = workStationModelData;
                        CashierRightControlModel.SelectedWorkStations.Add(workStationModelData);
                    }
                }

                foreach (WorkstationModel workStationModelData in CashierRightControlModel.RegularWorkStationList)
                {
                    if (workStationModelData.IsSelected)
                    {
                        if (workStationModelData.IsOccupied)
                        {
                            CashierRightControlModel.IsTopUpPCButtonShown = true;
                            CashierRightControlModel.IsLogoutPCButtonShown = true;
                            CashierRightControlModel.IsTransferPcButtonShown = true;
                            CashierRightControlModel.IsEndPromoButtonShown = true;
                            CashierRightControlModel.IsPowerOnPCButtonShown = false;
                        }
                        else if (!workStationModelData.IsOff)
                        {
                            CashierRightControlModel.IsLoginGuestButtonShown = true;
                        }
                    }
                }

                foreach (WorkstationModel workStationModelData in CashierRightControlModel.GoldWorkStationList)
                {
                    if (workStationModelData.IsSelected)
                    {
                        if (workStationModelData.IsOccupied)
                        {
                            CashierRightControlModel.IsTopUpPCButtonShown = true;
                            CashierRightControlModel.IsLogoutPCButtonShown = true;
                            CashierRightControlModel.IsTransferPcButtonShown = true;
                            CashierRightControlModel.IsEndPromoButtonShown = true;
                            CashierRightControlModel.IsPowerOnPCButtonShown = false;
                        }
                        else if (!workStationModelData.IsOff)
                        {
                            CashierRightControlModel.IsLoginGuestButtonShown = true;
                        }
                    }
                }

                foreach (WorkstationModel workStationModelData in CashierRightControlModel.VIPWorkStationList)
                {
                    if (workStationModelData.IsSelected)
                    {
                        if (workStationModelData.IsOccupied)
                        {
                            CashierRightControlModel.IsTopUpPCButtonShown = true;
                            CashierRightControlModel.IsLogoutPCButtonShown = true;
                            CashierRightControlModel.IsTransferPcButtonShown = true;
                            CashierRightControlModel.IsEndPromoButtonShown = true;
                            CashierRightControlModel.IsPowerOnPCButtonShown = false;
                        }
                        else if (!workStationModelData.IsOff)
                        {
                            CashierRightControlModel.IsLoginGuestButtonShown = true;
                        }
                    }
                }

                if (selectedPCs.Count > 1)
                {
                    CashierRightControlModel.IsTopUpPCButtonShown = false;
                    CashierRightControlModel.IsLoginGuestButtonShown = false;
                    CashierRightControlModel.IsPowerOnPCButtonShown = true;
                    CashierRightControlModel.IsTransferPcButtonShown = false;
                    CashierRightControlModel.IsEndPromoButtonShown = false;
                }
            }
        }

        private void PcNameSort()
        {
            CashierRightControlModel.SortAllWorkStationBy("PCNAME");
        }

        private void PcStatusSort()
        {
            CashierRightControlModel.SortAllWorkStationBy("PCSTATUS");
        }

        private void PcAreaSort()
        {
            CashierRightControlModel.SortAllWorkStationBy("PCAREA");
        }

        private void PcUserTypeSort()
        {
            CashierRightControlModel.SortAllWorkStationBy("PCUSERTYPE");
        }

        private void ShowRegularPc(object parameter)
        {
            string mode = parameter.ToString().Split(' ')[0];
            CashierRightControlModel.RegularSortMode = mode;
            CashierRightControlModel.RegularWorkStationList.ToList().ForEach(x => x.ShowInUIBy(mode));
        }

        private void ShowGoldPc(object parameter)
        {
            string mode = parameter.ToString().Split(' ')[0];
            CashierRightControlModel.GoldSortMode = mode;
            CashierRightControlModel.GoldWorkStationList.ToList().ForEach(x => x.ShowInUIBy(mode));
        }

        private void ShowVIPPc(object parameter)
        {
            string mode = parameter.ToString().Split(' ')[0];
            CashierRightControlModel.VIPSortMode = mode;
            CashierRightControlModel.VIPWorkStationList.ToList().ForEach(x => x.ShowInUIBy(mode));
        }

        public void ShutdownPc()
        {
            ShutdownLogoutPc(NetworkMessageType.ShutdownPC);
        }

        public async void PowerControl()
        {
            await ValidateAndShutdownPC();
        }

        public async Task ValidateAndShutdownPC()
        {
            await ValidateCashierSession();

            var pool = DataCacheContext.WorkstationModels.Values.ToList();

            bool areSomePCsTurnedOn = false;
            bool areSomePCsTurnedOff = false;

            foreach (WorkstationModel workstation in CashierRightControlModel.SelectedWorkStations)
            {
                bool isPCTurnedOn = pool.Where(pc => pc.IPAddress == workstation.StationModel.StaticIPAddress).Count() > 0 ? true : false;

                if (isPCTurnedOn)
                {
                    areSomePCsTurnedOn = true;
                }
                else
                {
                    areSomePCsTurnedOff = true;
                }

                if (areSomePCsTurnedOn && areSomePCsTurnedOff)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorCannotPowerOnOffSelection, Messages.ErrorConfirmation);
                    return;
                }
            }

            if (areSomePCsTurnedOn)
            {
                ShutdownPc();
            }
            else
            {
                WakePC();
            }
        }

        private void WakePC()
        {
            List<ClientPC> pool = DataCacheContext.WorkstationModels.Values.ToList();

            string warningMessage = string.Empty;

            // Make sure that selected station(s) are not in the Network pool.
            // This will be used to identify if power on must be performed.
            bool isPowerOnNeccessary = !pool.Any(pc =>
            {
                // Look for the selected station at the Cashier dashboard
                // if station was existing also on the network pool.
                var foundStation = CashierRightControlModel.SelectedWorkStations
                                                      .Find(station => station.PcStatus == "Offline");

                if (foundStation == null)
                {
                    return false;
                }

                bool doesExists = pc.IPAddress == foundStation.StationModel.StaticIPAddress;

                return doesExists;
            });

            if (isPowerOnNeccessary)
            {
                int totalSelected = CashierRightControlModel.SelectedWorkStations.Where(x => x.PcStatus == "Offline").Count();
                if (totalSelected > 0)
                {
                    warningMessage = string.Format(StandardMessageResource.WarningConfirmationPowerOnNumberOfPCs, totalSelected);
                }
                else
                {
                    warningMessage = StandardMessageResource.WarningConfirmationPowerOn;
                }

                if (!ShowConfirmationWindow(warningMessage, Messages.WarningConfirmation))
                {
                    return;
                }

                WakeBySelectedStations(pool);
            }
        }

        public async void LogoutPc()
        {
            await ValidateCashierSession();

            ShutdownLogoutPc(NetworkMessageType.Logout);
        }

        public async void EndUserPromo()
        {
            await ValidateCashierSession();

            WorkstationModel selectedPc = CashierRightControlModel.SelectedWorkStations.FirstOrDefault();

            if (selectedPc != null)
            {
                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
                if (ShowConfirmationWindow($"Are you sure you want to end {selectedPc.AccountModel.Customer}'s promo?", Messages.WarningConfirmation))
                {
                    var pool = DataCacheContext.WorkstationModels.Values.ToList();
                    if (pool.Count > 0)
                    {
                        string warningMessage = string.Empty;

                        bool isPCExists = pool.Any(pc => pc.PCID == selectedPc.StationModel.ID);

                        if (isPCExists)
                        {
                            ClientPC clientPC = pool.Where(pc => pc.PCID == selectedPc.StationModel.ID).ToList().FirstOrDefault();
                            IsProcessing = true;

                            NetworkServer.Instance.SendMessageToClient(clientPC.Connection, NetworkMessageType.EndPromo, userData.Username);

                            IsProcessing = false;
                        }
                    }
                }
                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
            }
        }

        private async void LoginGuest()
        {
            await ValidateCashierSession();

            AccountManagerWindow accountManagerWindow = new AccountManagerWindow();
            Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.AccountManagerWindow, accountManagerWindow);
            Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.StationList, new List<WorkstationModel> { CashierRightControlModel.SelectedWorkStations[0] });
            Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.LoginGuest, null);
            Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.PCAssigned, null);
            Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.CashierInfo, userData);

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);

            accountManagerWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.67);
            accountManagerWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.54);
            accountManagerWindow.ShowDialog();

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private async void PCTransfer()
        {
            await ValidateCashierSession();

            if (CashierRightControlModel.SelectedWorkStations.FirstOrDefault() != null)
            {
                PCTransferWindow pcTransferWindow = new PCTransferWindow();

                Mediator.Instance.NotifyViewModel(Messages.PCTransferWindowViewModel, Messages.PCTransferWindow, pcTransferWindow);
                Mediator.Instance.NotifyViewModel(Messages.PCTransferWindowViewModel, Messages.StationList, CashierRightControlModel.GetAvailableWorkStation());
                Mediator.Instance.NotifyViewModel(Messages.PCTransferWindowViewModel, Messages.SelectedWorkstationToTransfer, CashierRightControlModel.SelectedWorkStations.FirstOrDefault());

                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
                pcTransferWindow.ShowDialog();
                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
            }
        }

        public async void TopupPc()
        {
            await ValidateCashierSession();

            if (CashierRightControlModel.SelectedWorkStations[0].AccountModel.CardNumber != "--")
            {
                TopUpManagerWindow topUpWindow = new TopUpManagerWindow();
                Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.TopUpManagerWindow, topUpWindow);
                Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.TopUpByUser, CashierRightControlModel.SelectedWorkStations[0]);
                Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.PCAssigned, true);
                Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.CashierInfo, userData);

                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
                topUpWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.678);
                topUpWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.543);
                topUpWindow.ShowDialog();
                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
            }
        }

        private void ShutdownLogoutPc(string mode)
        {
            var pool = DataCacheContext.WorkstationModels.Values.ToList();

            if (pool.Count > 0)
            {
                string warningMessage = string.Empty;
                int numberOfOccupiedPCs = 0;
                bool isShutdownNecessary = false;

                foreach (WorkstationModel workstation in CashierRightControlModel.SelectedWorkStations)
                {
                    bool isExists = pool.Where(pc => pc.IPAddress == workstation.StationModel.StaticIPAddress).Count() > 0 ? true : false;

                    if (isExists)
                    {
                        isShutdownNecessary = true;
                        if (workstation.IsOccupied)
                        {
                            numberOfOccupiedPCs++;
                        }
                    }
                }

                if (isShutdownNecessary)
                {
                    if (numberOfOccupiedPCs > 0)
                    {
                        if (mode == NetworkMessageType.Logout)
                        {
                            warningMessage = numberOfOccupiedPCs.ToString() + " " + StandardMessageResource.WarningConfirmationLogoutNumberOfPCs;
                        }
                        else
                        {
                            warningMessage = numberOfOccupiedPCs.ToString() + " " + StandardMessageResource.WarningConfirmationShutdownNumberOfPCs;
                        }
                    }
                    else
                    {
                        if (mode == NetworkMessageType.Logout)
                        {
                            warningMessage = StandardMessageResource.WarningConfirmationLogout;
                        }
                        else
                        {
                            warningMessage = StandardMessageResource.WarningConfirmationShutdown;
                            mode = NetworkMessageType.ShutdownPC;
                        }
                    }

                    if (!ShowConfirmationWindow(warningMessage, Messages.WarningConfirmation))
                    {
                        return;
                    }

                    foreach (WorkstationModel workstation in CashierRightControlModel.SelectedWorkStations)
                    {
                        bool isExists = pool.Where(pc => pc.IPAddress == workstation.StationModel.StaticIPAddress).Count() > 0 ? true : false;

                        if (isExists)
                        {
                            NetworkServer.Instance.SendMessageToClientUsingIP(workstation.StationModel.StaticIPAddress, mode, null);
                        }
                    }
                }
            }
        }

        private void WakeBySelectedStations(List<ClientPC> pool)
        {
            foreach (WorkstationModel workstation in CashierRightControlModel.SelectedWorkStations)
            {
                bool doesNotExists = !pool.Any(pc => pc.IPAddress == workstation.StationModel.StaticIPAddress);

                string mac = workstation.StationModel.MacAddress.ToPlainMac();

                if (doesNotExists)
                {
                    WakeOnLanHelper.WakeByMac(mac);
                }
            }
        }

        #endregion

        #region NetworkComms - implmentation

        private void UpdatePcStatus(int pcNumber, Connection pcConnection)
        {
            WorkStationModelList[pcNumber].PcStatus = "Online";
            workstationModelList[pcNumber].PcConnection = pcConnection;
        }

        private Double getItemHeight(Double itemCount)
        {
            double height = Math.Ceiling(itemCount / 9) * 100;

            if ((height / 100) > 9)
                return height;
            else
                return 900;
        }

        private string GetTimeElapsed(string startTime)
        {
            if (startTime == "--")
            {
                return "--";
            }

            DateTime start = Convert.ToDateTime(startTime, CultureInfo.InvariantCulture);
            return TimeSpan.FromSeconds(DateTime.Now.Subtract(start).TotalSeconds).ToString(@"hh\:mm");
        }

        private async Task GetStationList()
        {
            CashierServiceProvider cashierService = new CashierServiceProvider();
            try
            {
                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                });

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                List<StationDataModel> stationList = null;
                try
                {
                    stationList = await TaskManagerModel<List<StationDataModel>>.Instance.Run(cashierService.GetStationList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            stationList = null;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });

                if (stationList != null)
                {
                    CashierRightControlModel.LoadStationInfo(stationList);
                }

                if (DataCacheContext.WorkstationModels.Count > 0)
                {
                    var workstationCacheModel = DataCacheContext.WorkstationModels.Values.ToList();
                    foreach (var workstation in workstationCacheModel)
                    {
                        UpdatePCStatus(workstation, true);
                    }
                }

                if (DataCacheContext.MemberAccountModels.Count > 0)
                {
                    foreach (var account in DataCacheContext.MemberAccountModels.Values)
                    {
                        UpdateAllWorkstationList(account);
                    }
                }
            }
            catch (Exception ex)
            {
                //Fix me: need to add action
            }
        }

        private async Task GetStationTypeList()
        {
            CashierServiceProvider cashierService = new CashierServiceProvider();

            try
            {
                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                });

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                List<StationTypeDataModel> stationTypeList = null;
                try
                {
                    stationTypeList = await TaskManagerModel<List<StationTypeDataModel>>.Instance.Run(cashierService.GetStationTypeList(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            stationTypeList = null;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                });

                if (stationTypeList != null)
                {
                    CashierRightControlModel.StationTypeList = stationTypeList;
                }
            }
            catch (Exception)
            {

            }
        }

        #endregion

        #region Properties

        private CashierRightControlModel cashierRightControlModel;
        public CashierRightControlModel CashierRightControlModel
        {
            get { return cashierRightControlModel; }
            set
            {
                cashierRightControlModel = value;
                RaisePropertyChanged(nameof(CashierRightControlModel));
            }
        }

        private Double pcPanelWidth;
        public Double PcPanelWidth
        {
            get { return pcPanelWidth; }
            set
            {
                pcPanelWidth = value;
                RaisePropertyChanged(nameof(PcPanelWidth));
            }
        }

        private Double pcPanelHeight;
        public Double PcPanelHeight
        {
            get { return pcPanelHeight; }
            set
            {
                pcPanelHeight = value;
                RaisePropertyChanged(nameof(PcPanelHeight));
            }
        }

        private String regularPcCount;
        public String RegularPcCount
        {
            get { return regularPcCount; }
            set
            {
                regularPcCount = value;
                RaisePropertyChanged(nameof(RegularPcCount));
            }
        }

        private String goldPcCount;
        public String GoldPcCount
        {
            get { return goldPcCount; }
            set
            {
                goldPcCount = value;
                RaisePropertyChanged(nameof(GoldPcCount));
            }
        }

        private String vipPcCount;
        public String VipPcCount
        {
            get { return vipPcCount; }
            set
            {
                vipPcCount = value;
                RaisePropertyChanged(nameof(VipPcCount));
            }
        }

        private ItemsControl pcList;
        public ItemsControl PcList
        {
            get { return pcList; }
            set
            {
                pcList = value;
                RaisePropertyChanged(nameof(PcList));
            }
        }

        private ObservableCollection<WorkstationModel> workstationModelList;
        public ObservableCollection<WorkstationModel> WorkStationModelList
        {
            get { return workstationModelList; }
            set
            {
                workstationModelList = value;
                RaisePropertyChanged(nameof(WorkStationModelList));
            }
        }

        private bool gridViewVisibility;
        public bool GridViewVisibility
        {
            get { return gridViewVisibility; }
            set
            {
                gridViewVisibility = value;
                RaisePropertyChanged(nameof(GridViewVisibility));
            }
        }

        private bool listViewVisibility;
        public bool ListViewVisibility
        {
            get { return listViewVisibility; }
            set
            {
                listViewVisibility = value;
                RaisePropertyChanged(nameof(ListViewVisibility));
            }
        }

        #endregion

        #region Helper Methods

        private void ShowErrorMessage(string errorMessage)
        {
            string messageMode = Messages.ErrorConfirmation;
            ShowConfirmationWindow(errorMessage, messageMode);
        }

        private async Task PopulateRecentTransactionLogsFromLocalDB()
        {
            if (TransactionRepository != null)
            {
                #region Original Code

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                IEnumerable<TransactionLogResultModel> transactions = null;
                try
                {
                    if (TransactionRepository != null && DataCacheContext.UseLocalDB)
                    {
                        transactions = await TaskManagerModel<IEnumerable<TransactionLogResultModel>>.Instance.Run(TransactionRepository.GetFiveRecentTransactionsAsync(cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                    }
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    bool isSqlHavingErrors = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            transactions = null;
                            wasTaskCanceled = true;
                            break;
                        }
                        else if (exception is SqlException)
                        {
                            isSqlHavingErrors = true;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        if (isSqlHavingErrors)
                        {
                            //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                            //ShowConfirmationWindow(StandardMessageResource.ErrorDatabaseError, Messages.ErrorConfirmation);
                        }
                        else
                        {
                            //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                            //ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                        }
                    }
                }

                CashierRightControlModel.IsTransactionShownLoading = false;

                if (transactions == null)
                {
                    return;
                }

                App.Current.Dispatcher.Invoke(() =>
                {
                    foreach (var transaction in transactions)
                    {
                        CashierRightControlModel.TransactionLogsList.Add(TransactionModelMapper.Map(transaction, CurrencySymbol));
                    }
                });

                Mediator.Instance.NotifyViewModel(Messages.LeftUserControl, Messages.ReceivedPendingOrdersCount, null);

                #endregion
            }

        }

        private async Task PopulateRecentTransactionLogs()
        {
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            int transactionCount = 5;

            Tuple<List<TransactionLogDataModel>, ResponseModel> transactionLogList = null;
            CashierServiceProvider cashierService = new CashierServiceProvider();

            try
            {
                transactionLogList = await TaskManagerModel<Tuple<List<TransactionLogDataModel>, ResponseModel>>.Instance.Run(
                    cashierService.GetTransactionLogByCount(DataCacheContext.CashierSessionID,
                    transactionCount,
                    cancellationTokenSource.Token), cancellationTokenSource);
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                bool isSqlHavingErrors = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        transactionLogList = null;
                        wasTaskCanceled = true;
                        break;
                    }
                    else if (exception is SqlException)
                    {
                        isSqlHavingErrors = true;
                    }
                }

                if (!wasTaskCanceled)
                {
                    if (isSqlHavingErrors)
                    {
                        //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                        //ShowConfirmationWindow(StandardMessageResource.ErrorDatabaseError, Messages.ErrorConfirmation);
                    }
                    else
                    {
                        //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                        //ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                    }
                }
            }

            await App.Current.Dispatcher.BeginInvoke((Action)delegate
            {
                CashierRightControlModel.IsTransactionShownLoading = false;
            });

            if (transactionLogList == null)
            {
                return;
            }

            if ((transactionLogList != null && transactionLogList.Item1 == null) || transactionLogList.Item2.HttpStatusCode != (int)HttpStatusCode.OK)
            {
                return;
            }
            else
            {
                App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    App.Current.Dispatcher.Invoke(() =>
                    {
                        foreach (TransactionLogDataModel transaction in transactionLogList.Item1)
                        {
                            CashierRightControlModel.TransactionLogsList.Add(
                                new TransactionModel
                                {
                                    CustomerName = transaction.CustomerName,
                                    TransactionType = transaction.Activity,
                                    TransactionRemarks = transaction.Remarks,
                                    TransactionAmount = CurrencySymbol + transaction.Amount / 100,
                                    TransactionTime = transaction.Time
                                });
                        }
                    });
                });
            }
        }

        private long ToUnixTime(DateTime date)
        {
            System.TimeZone localZone = System.TimeZone.CurrentTimeZone;
            var epoch = new DateTime(1969, 12, 31, 23, 59, 59, 59, DateTimeKind.Utc);
            var dateTimeNow = new DateTime(date.Year, date.Month, date.Day, 23, 59, 59, DateTimeKind.Local);
            DateTime currentUTC = localZone.ToUniversalTime(dateTimeNow);
            return Convert.ToInt64((currentUTC - epoch).TotalMilliseconds);
        }

        private void UpdateAllWorkstationList(MemberAccountModel model)
        {
            foreach (WorkstationModel workStation in CashierRightControlModel.RegularWorkStationList)
            {
                if (workStation.StationModel.ID == model.StationID)
                {
                    UpdateStationInfo(model, workStation);
                    CashierRightControlModel.OccupiedRegularPCCount++;
                    return;
                }
            }

            foreach (WorkstationModel workStation in CashierRightControlModel.GoldWorkStationList)
            {
                if (workStation.StationModel.ID == model.StationID)
                {
                    UpdateStationInfo(model, workStation);
                    CashierRightControlModel.OccupiedGoldPCCount++;
                    return;
                }
            }

            foreach (WorkstationModel workStation in CashierRightControlModel.VIPWorkStationList)
            {
                if (workStation.StationModel.ID == model.StationID)
                {
                    UpdateStationInfo(model, workStation);
                    CashierRightControlModel.OccupiedVIPPCCount++;
                    return;
                }
            }
        }

        private void UpdatePCStatus(ClientPC pcInfo, bool isConnected)
        {
            foreach (WorkstationModel workStation in CashierRightControlModel.VIPWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    ClearWorkStationAccountStationModel(workStation);

                    if (isConnected)
                    {
                        workStation.IsOff = false;
                    }
                    else
                    {
                        workStation.PcStatus = WorkstationStatusOffline;
                        ClientPC tempBuffer = new ClientPC();
                        MemberAccountModel tempBuffer2 = new MemberAccountModel();
                        DataCacheContext.WorkstationModels.TryRemove(workStation.StationModel.ID, out tempBuffer);
                        DataCacheContext.MemberAccountModels.TryRemove(workStation.StationModel.ID, out tempBuffer2);
                    }

                    return;
                }
            }

            foreach (WorkstationModel workStation in CashierRightControlModel.RegularWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    ClearWorkStationAccountStationModel(workStation);

                    if (isConnected)
                    {
                        workStation.PcStatus = WorkstationStatusAvailable;
                        workStation.IsOff = false;
                    }
                    else
                    {
                        workStation.PcStatus = WorkstationStatusOffline;
                        ClientPC tempBuffer = new ClientPC();
                        MemberAccountModel tempBuffer2 = new MemberAccountModel();
                        DataCacheContext.WorkstationModels.TryRemove(workStation.StationModel.ID, out tempBuffer);
                        DataCacheContext.MemberAccountModels.TryRemove(workStation.StationModel.ID, out tempBuffer2);
                    }
                    return;
                }
            }

            foreach (WorkstationModel workStation in CashierRightControlModel.GoldWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    ClearWorkStationAccountStationModel(workStation);

                    if (isConnected)
                    {
                        workStation.PcStatus = WorkstationStatusAvailable;
                        workStation.IsOff = false;
                    }
                    else
                    {
                        workStation.PcStatus = WorkstationStatusOffline;
                        ClientPC tempBuffer = new ClientPC();
                        MemberAccountModel tempBuffer2 = new MemberAccountModel();
                        DataCacheContext.WorkstationModels.TryRemove(workStation.StationModel.ID, out tempBuffer);
                        DataCacheContext.MemberAccountModels.TryRemove(workStation.StationModel.ID, out tempBuffer2);
                    }
                    return;
                }
            }
        }

        private void ClearAllWorkStations()
        {
            CashierRightControlModel.OccupiedRegularPCCount = 0;
            CashierRightControlModel.OccupiedGoldPCCount = 0;
            CashierRightControlModel.OccupiedVIPPCCount = 0;

            foreach (WorkstationModel workStation in CashierRightControlModel.RegularWorkStationList)
            {
                ClearWorkStationAccountStationModel(workStation);
                workStation.PcStatus = WorkstationStatusOffline;
                ClientPC tempBuffer = new ClientPC();
                MemberAccountModel tempBuffer2 = new MemberAccountModel();

                try
                {
                    DataCacheContext.WorkstationModels.TryRemove(workStation.StationModel.ID, out tempBuffer);
                    DataCacheContext.MemberAccountModels.TryRemove(workStation.StationModel.ID, out tempBuffer2);
                }
                catch
                {
                    // todo: remove try catch and check if station is in the list instead
                }
            }

            foreach (WorkstationModel workStation in CashierRightControlModel.VIPWorkStationList)
            {
                ClearWorkStationAccountStationModel(workStation);
                workStation.PcStatus = WorkstationStatusOffline;
                ClientPC tempBuffer = new ClientPC();
                MemberAccountModel tempBuffer2 = new MemberAccountModel();

                try
                {
                    DataCacheContext.WorkstationModels.TryRemove(workStation.StationModel.ID, out tempBuffer);
                    DataCacheContext.MemberAccountModels.TryRemove(workStation.StationModel.ID, out tempBuffer2);
                }
                catch
                {
                    // todo: remove try catch and check if station is in the list instead
                }
            }

            foreach (WorkstationModel workStation in CashierRightControlModel.GoldWorkStationList)
            {
                ClearWorkStationAccountStationModel(workStation);
                workStation.PcStatus = WorkstationStatusOffline;
                ClientPC tempBuffer = new ClientPC();
                MemberAccountModel tempBuffer2 = new MemberAccountModel();

                try
                {
                    DataCacheContext.WorkstationModels.TryRemove(workStation.StationModel.ID, out tempBuffer);
                    DataCacheContext.MemberAccountModels.TryRemove(workStation.StationModel.ID, out tempBuffer2);
                }
                catch
                {
                    // todo: remove try catch and check if station is in the list instead
                }
            }
        }

        private void UpdatePCLockStatus(ClientPC pcInfo)
        {
            foreach (WorkstationModel workStation in CashierRightControlModel.VIPWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    workStation.IsLocked = pcInfo.IsLocked;
                    return;
                }
            }

            foreach (WorkstationModel workStation in CashierRightControlModel.RegularWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    workStation.IsLocked = pcInfo.IsLocked;
                    return;
                }
            }

            foreach (WorkstationModel workStation in CashierRightControlModel.GoldWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    workStation.IsLocked = pcInfo.IsLocked;
                    return;
                }
            }
        }

        private void ClearWorkStationAccountStationModel(WorkstationModel workStation)
        {
            workStation.IsShow = false;
            workStation.IsOccupied = false;
            workStation.IsOff = true;
            workStation.AccountModel = new AccountModel();
            workStation.PcStatus = WorkstationStatusAvailable;
            workStation.IsLocked = false;
        }

        private void ResetPCDetails(WorkstationModel workstation)
        {
            workstation.AccountModel.IdNumber = "";
            workstation.AccountModel.Balance = "";
            workstation.AccountModel.Customer = "";
            workstation.AccountModel.StartTime = "";
            workstation.AccountModel.TimeElapsed = "";
            workstation.AccountModel.Username = "";
            workstation.PcStatus = WorkstationStatusAvailable;
            workstation.PcStatus = WorkstationStatusOffline;
        }

        #endregion

        #region Event Handlers - Socket (observer)

        private void OnConnectionEstablished(ClientPC pcInfo)
        {
            if (pcInfo.PCID != null && pcInfo.PCID != string.Empty)
            {
                if (!DataCacheContext.WorkstationModels.ContainsKey(pcInfo.PCID))
                {
                    DataCacheContext.WorkstationModels.TryAdd(pcInfo.PCID, pcInfo);
                    UpdatePCStatus(pcInfo, true);
                }
            }
        }

        private void OnClientDisconnected(ClientPC pcInfo)
        {           
            foreach (WorkstationModel workStation in CashierRightControlModel.VIPWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    if (workStation.IsOccupied)
                    {
                        CashierRightControlModel.OccupiedVIPPCCount--;
                    }
                }
            }
            foreach (WorkstationModel workStation in CashierRightControlModel.RegularWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    if (workStation.IsOccupied)
                    {
                        CashierRightControlModel.OccupiedRegularPCCount--;
                    }
                }
            }
            foreach (WorkstationModel workStation in CashierRightControlModel.GoldWorkStationList)
            {
                if (workStation.StationModel.ID == pcInfo.PCID)
                {
                    if (workStation.IsOccupied)
                    {
                        CashierRightControlModel.OccupiedGoldPCCount--;
                    }
                }
            }

            UpdatePCStatus(pcInfo, false);
        }

        private int receivedAccountCounter;

        private void OnAccountDetailReceived(MemberAccountModel model)
        {
            List<string> stationList = new List<string>();

            if (!DataCacheContext.MemberAccountModels.ContainsKey(model.StationID))
            {
                try
                {
                    DataCacheContext.MemberAccountModels.TryAdd(model.StationID, model);
                    stationList.Add(model.StationID);

                    AccountModel account = new AccountModel();
                    account.Balance = model.AccountBalance;

                    if (model.CardNumber == null)
                    {
                        account.Customer = model.Username;
                    }
                    else
                    {
                        account.Customer = model.CustomerName;
                    }

                    account.IdNumber = model.CardNumber;

                    var vipWorkStation = CashierRightControlModel.VIPWorkStationList.Where(x => x.StationModel.ID == model.StationID).FirstOrDefault();
                    var goldWorkStation = CashierRightControlModel.GoldWorkStationList.Where(x => x.StationModel.ID == model.StationID).FirstOrDefault();
                    var regularWorkStation = CashierRightControlModel.RegularWorkStationList.Where(x => x.StationModel.ID == model.StationID).FirstOrDefault();

                    if (vipWorkStation != null)
                    {
                        App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            UpdateStationInfo(model, vipWorkStation);
                            CashierRightControlModel.OccupiedVIPPCCount++;
                        });
                    }
                    else if (goldWorkStation != null)
                    {
                        App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            UpdateStationInfo(model, goldWorkStation);
                            CashierRightControlModel.OccupiedGoldPCCount++;
                        });
                    }
                    else if (regularWorkStation != null)
                    {
                        App.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            UpdateStationInfo(model, regularWorkStation);
                            CashierRightControlModel.OccupiedRegularPCCount++;
                        });
                    }
                }
                catch (ArgumentException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        private void OnUpdateAccountBalanceReceived(MemberAccountModel model)
        {

            var occupiedVIPs = CashierRightControlModel.VIPWorkStationList.Where(pc => pc.IsOccupied);
            var occupiedRegulars = CashierRightControlModel.RegularWorkStationList.Where(pc => pc.IsOccupied);
            var occupiedGolds = CashierRightControlModel.GoldWorkStationList.Where(pc => pc.IsOccupied);

            foreach (WorkstationModel workStation in occupiedVIPs)
            {
                if (workStation.StationModel.ID == model.StationID)
                {
                    UpdateStationAccountBalance(model.AccountBalance, workStation);
                    workStation.AccountModel.ChargingType = model.ChargingType;
                    return;
                }
            }
            foreach (WorkstationModel workStation in occupiedRegulars)
            {
                if (workStation.StationModel.ID == model.StationID)
                {
                    UpdateStationAccountBalance(model.AccountBalance, workStation);
                    workStation.AccountModel.ChargingType = model.ChargingType;
                    return;
                }
            }
            foreach (WorkstationModel workStation in occupiedGolds)
            {
                if (workStation.StationModel.ID == model.StationID)
                {
                    UpdateStationAccountBalance(model.AccountBalance, workStation);
                    workStation.AccountModel.ChargingType = model.ChargingType;
                    return;
                }
            }

        }

        private void UpdateStationInfo(MemberAccountModel accountModel, WorkstationModel workStationModel)
        {
            workStationModel.IsOff = false;
            workStationModel.IsOccupied = true;
            workStationModel.AccountModel.Balance = accountModel.AccountBalance;
            workStationModel.AccountModel.Customer = accountModel.CustomerName;
            workStationModel.AccountModel.IdNumber = accountModel.AccountID;
            workStationModel.AccountModel.CardNumber = accountModel.CardNumber;
            workStationModel.AccountModel.StartTime = accountModel.StartTime.ToString("MM/dd/yyyy hh:mm tt");
            workStationModel.AccountModel.Username = accountModel.Username;
            workStationModel.AccountModel.UserType = accountModel.UserType;
            workStationModel.PcStatus = WorkstationStatusOccupied;
            workStationModel.AccountModel.ChargingType = accountModel.ChargingType;

            Mediator.Instance.NotifyViewModel(Messages.PCTransferWindowViewModel, Messages.StationList, CashierRightControlModel.GetAvailableWorkStation());
        }

        private void UpdateStationAccountBalance(string balance, WorkstationModel workstation)
        {
            workstation.AccountModel.Balance = balance;
        }

        private TransactionModel CreateTransactionModel(TransactionLog transaction)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = StandardMessageResource.TransactNewOrder,
                CustomerName = transaction.AccountName,
                CustomerID = transaction.Id.ToString(),
                TransactionAmount = $"{CurrencySymbol}{(Convert.ToDouble(transaction.TransactionAmount) / 100).ToString("N2")}",
                TransactionRemarks = "Pending order from member PC",
                CashierName = transaction.CashierName
            };
            return transactionModel;
        }

        private async Task ValidateCashierSession()
        {
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, true);
            bool isCashierSessionValid = await CashierSession.ValidateSession(ToString());
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, false);

            if (!isCashierSessionValid)
            {
                return;
            }
        }

        #endregion
    }
}
