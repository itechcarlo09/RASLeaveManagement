﻿using gocafe_cashier.Command;
using gocafe_cashier.DataModel;
using gocafe_cashier.Helper;
using gocafe_cashier.Model;
using gocafe_cashier.ServiceProvider;
using gocafe_cashier.MessageResource;
using gocafe_cashier.View.Member;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Linq;
using gocafe_cashier.Card;
using System.Windows;
using System.Net;
using System.Windows.Input;
using gocafe_cashier.View.Store;
using gocafe_cashier.ViewModel.Database;
using System.Threading.Tasks;
using System.IO;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.Cache;
using GocafeShared.Model;
using gocafe_cashier.TaskManager;
using System.Threading;
using System.Data.SqlClient;
using gocafe_cashier.Validation;
using gocafe_cashier.Network;
using GocafeShared.Model.Network;
using GocafeShared.Definition;
using GocafeShared.Utilities.StringFormat;
using NetworkCommsDotNet.Connections;
using gocafe_cashier.DataModel.FnBDataModels;
using GocafeDatabaseModel;
using System.Windows.Interop;
using RawInput_dll;
using System.Diagnostics;
using Gma.System.MouseKeyHook;

namespace gocafe_cashier.ViewModel.Cashier
{
    class CashierLeftControlViewModel : DbContextViewModelBase
    {
        #region Static Properties

        public static CashierLeftControlViewModel Default { get; set; }
        private static CashierDataModel userData = new CashierDataModel();
        PendingOrdersPopupWindow pendingOrdersWindow;
        ReceivedOrdersControl receivedOrdersWindow;
        public RawInput keyboardRawInput;
        private string cardLastString = string.Empty;
        private const string GUEST_PASSWORD_PERMISSION = "SHOW_GUEST_PASSWORD";
        private const string COUPON_PERMISSION = "GENERATE_COUPON";

        private IKeyboardMouseEvents m_globalKeyboardHook;

        #endregion

        #region Private Variables

        private string tapToUnlock = StandardMessageResource.TapToUnlock;
        private bool isCardTapped = false;
        private bool isAccountManagerOpen = false;
        private bool isTopUpManagerOpen = false;
        private bool isResetPasswordWindowOpen = false;
        private bool isReplaceCardWindowOpen = false;
        private List<string> windowWithError = new List<string>();
        private string notesFileName = AppDomain.CurrentDomain.BaseDirectory + "notes.rtf";
        private string cardUID = "Unknown Card";
        private OrderNumberModel acceptedOrRejectedOrder = new OrderNumberModel();

        private bool isKeyDownHandled;

        #endregion

        public CashierLeftControlViewModel()
        {
            isKeyDownHandled = false;

            Mediator.Instance.Register(this, Messages.LeftUserControl);

            Default = this;
            IDNumber = "0123456789";
            CashierName = "Alphonsine L'Heureux";
            BranchName = "Mineski Taft";
            PcNumber = "PC --";
            IsCouponShowed = false;
            WorkStationModel = new WorkstationModel();
            WorkStationList = new List<WorkstationModel>();

            Task.Run(async () =>
            {
                await GetOrderTotalCount();
                await InitializeOrderNumberList();
                UpdateAllOrderNumbers();
            });
            LoadNotes();
        }

        public override async void SendData(string message, object data)
        {
            switch (message)
            {
                case Messages.SendUserInfo:
                    userData = data as CashierDataModel;
                    CashierName = $"{userData.Name}";
                    BranchName = userData.Branch.Name;
                    IDNumber = userData.ID.Substring(Math.Max(0, userData.ID.Length - 10));
                    Password = $"{userData.Password}";

                    if(userData.CashierActionPermissionList != null)
                    {
                        IsCouponShowed = userData.CashierActionPermissionList.Contains(COUPON_PERMISSION);
                    }                    

                    break;
                case Messages.StationList:
                    WorkStationList = (List<WorkstationModel>)data;
                    break;
                case Messages.CardTapped:
                    MemberServiceProvider memberService = new MemberServiceProvider();
                    UserDataModel memberData = new UserDataModel();

                    CardUtilities card = CardUtilities.Instance;

                    if (card.ConnectCard()) cardUID = card.GetCardUID();
                    if (cardUID != "Unknown Card")
                    {
                        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                        try
                        {
                            memberData = await TaskManagerModel<UserDataModel>.Instance.Run(memberService.GetMemberInfo(cardUID, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
                        }
                        catch (AggregateException aggregateException)
                        {
                            bool wasTaskCanceled = false;
                            foreach (var exception in aggregateException.InnerExceptions)
                            {
                                if (exception is TaskCanceledException)
                                {
                                    memberData = null;
                                    wasTaskCanceled = true;
                                    break;
                                }
                            }

                            if (!wasTaskCanceled)
                            {
                                ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                            }
                        }

                        if (memberData == null)
                        {
                            memberData = new UserDataModel();
                        }
                        else
                        {
                            if (memberData.IsAvailable)
                            {
                                if (isAccountManagerOpen)
                                {
                                    Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.CardID, cardUID);
                                }
                                else if (isReplaceCardWindowOpen)
                                {
                                    Mediator.Instance.NotifyViewModel(Messages.ReplaceCardWindowViewModel, Messages.CardID, cardUID);
                                }
                                else if (!isAccountManagerOpen && !isTopUpManagerOpen && !isResetPasswordWindowOpen && !isReplaceCardWindowOpen)
                                {
                                    await Application.Current.Dispatcher.BeginInvoke((Action)delegate
                                    {
                                        isCardTapped = true;
                                        OpenAccountManager();
                                    });
                                }
                            }
                            else if (memberData.MemberData != null)
                            {
                                if (isTopUpManagerOpen)
                                {
                                    Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.MemberData, memberData);
                                }
                                else if (isResetPasswordWindowOpen)
                                {
                                    Mediator.Instance.NotifyViewModel(Messages.ResetPasswordViewModel, Messages.CardID, cardUID);
                                }
                                UnlockUser(memberData);
                            }
                            else
                            {

                                ShowConfirmationWindow("Card is not allowed", Messages.ErrorConfirmation);
                            }
                        }
                    }
                    break;
                case Messages.TopUpByUser:
                    WorkStationModel.AccountModel.Balance = data.ToString();
                    break;
                case Messages.LogoutUser:
                    LogoutUser();
                    break;
                case Messages.SwitchToLoginView:
                    SwitchToLoginView();
                    break;
                case Messages.ReceivedPendingOrdersCount:
                    Task.Run(async () =>
                    {
                        await GetOrderTotalCount();
                        await InitializeOrderNumberList();
                        UpdateAllOrderNumbers();
                    });
                    break;
                case Messages.OpenReceivedOrderWindow:
                    App.Current.Dispatcher.Invoke(() =>
                    {
                        OpenReceivedOrdersWindow();
                    });
                    break;
                case Messages.WindowInitializationError:
                    windowWithError.Add((string)data);
                    break;
                case Messages.RefreshAccessToken:
                    userData.AccessToken = data.ToString();
                    break;
                case Messages.RefreshAccessKey:
                    if (data == null)
                    {
                        userData.AccessKey = null;
                    }
                    else
                    {
                        userData.AccessKey = data.ToString();
                    }
                    break;

                case Messages.GetUpdatedOrderNumbers:
                    SendOrderNumbersToStation((string)data);
                    break;
                case Messages.OpenTopUpManager:
                    OpenTopUpManagerWindow();
                    break;
                case Messages.OpenAccountManager:
                    OpenAccountManager();
                    break;
                case Messages.OpenCancelPromo:
                    OpenCancelPromoWindow();
                    break;
                case Messages.OpenCoupon:
                    OpenCouponWindow();
                    break;
                case Messages.OpenEShop:
                    OpenEShopWindow();
                    break;
                case Messages.OpenFoodAndBeverage:
                    OpenFoodAndBeverageWindow();
                    break;
                case Messages.OpenInventoryManager:
                    OpenInventoryManagerWindow();
                    break;
                case Messages.OpenLogOutCustomer:
                    OpenLogOutCustomerWindow();
                    break;
                case Messages.OpenReceivedOrders:
                    OpenReceivedOrdersWindow();
                    break;
                case Messages.OpenReplaceCard:
                    OpenReplaceCardWindow();
                    break;
                case Messages.OpenResetPassword:
                    OpenResetPasswordWindow();
                    break;
                case Messages.OpenTransactionHistory:
                    OpenTransactionHistoryWindow();
                    break;

                case Messages.HandledOrder:
                    foreach(OrderNumberModel order in DataCacheContext.OrderList)
                    {
                        if (order.ReferenceNumber == (string)data)
                        {
                            acceptedOrRejectedOrder = order;
                        }
                    }

                    break;

                default:
                    break;
            }
        }


        #region Properties

        private List<WorkstationModel> workStationList;
        public List<WorkstationModel> WorkStationList
        {
            get { return workStationList; }
            set
            {
                workStationList = value;
                RaisePropertyChanged(nameof(WorkStationList));
            }
        }

        private WorkstationModel workStationModel;
        public WorkstationModel WorkStationModel
        {
            get { return workStationModel; }
            set
            {
                workStationModel = value;
                RaisePropertyChanged(nameof(WorkStationModel));
            }
        }

        private string pcNumber;
        public string PcNumber
        {
            get { return pcNumber; }
            set
            {
                pcNumber = value;
                RaisePropertyChanged(nameof(PcNumber));
            }
        }

        private string idNumber;
        public string IDNumber
        {
            get { return idNumber; }
            set
            {
                idNumber = value;
                RaisePropertyChanged(nameof(IDNumber));
            }
        }

        private string cashierName;
        public string CashierName
        {
            get { return cashierName; }
            set
            {
                cashierName = value;
                RaisePropertyChanged(nameof(CashierName));
            }
        }

        private string password;
        public string Password
        {
            get { return password; }
            set
            {
                password = value;
                RaisePropertyChanged(nameof(Password));
            }
        }

        private string branchName;
        public string BranchName
        {
            get { return branchName; }
            set
            {
                branchName = value;
                RaisePropertyChanged(nameof(BranchName));
            }
        }

        private int pendingOrderCount;
        public int PendingOrderCount
        {
            get { return pendingOrderCount; }
            set
            {
                pendingOrderCount = value;
                RaisePropertyChanged(nameof(PendingOrderCount));
            }
        }

        private string notesText;
        public string NotesText
        {
            get { return notesText; }
            set
            {
                notesText = value;
                RaisePropertyChanged(nameof(NotesText));
            }
        }

        private bool isCouponShowed;
        public bool IsCouponShowed
        {
            get { return isCouponShowed; }
            set
            {
                isCouponShowed = value;
                RaisePropertyChanged(nameof(IsCouponShowed));
            }
        }

        #endregion


        #region Commands

        public ICommand WindowLoadedCommand
        {
            get
            {
                return new DelegateCommand(InitializeKeyboardRawInput);
            }
        }

        public ICommand ShutdownCommand
        {
            get
            {
                return new DelegateCommand(Shutdown);
            }
        }

        public ICommand LogoutCommand
        {
            get
            {
                return new DelegateCommand(LogoutUser);
            }
        }

        public ICommand NewCustomerCommand
        {
            get
            {
                return new DelegateCommand(OpenAccountManager);
            }
        }

        public ICommand ResetPasswordCommand
        {
            get
            {
                return new DelegateCommand(OpenResetPasswordWindow);
            }
        }

        public ICommand TopUpManagerCommand
        {
            get
            {
                return new DelegateCommand(OpenTopUpManagerWindow);
            }
        }

        public ICommand UserTopUpManagerCommand
        {
            get
            {
                return new DelegateCommand(OpenUserTopUpManagerWindow);
            }
        }

        public ICommand CouponManagerWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenCouponWindow);
            }
        }

        public ICommand ReplaceCardCommand
        {
            get
            {
                return new DelegateCommand(OpenReplaceCardWindow);
            }
        }

        public ICommand FoodAndBeverageManagerWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenFoodAndBeverageWindow);
            }
        }

        public ICommand ReceivedOrdersWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenReceivedOrdersWindow);
            }
        }

        public ICommand InventoryManagerWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenInventoryManagerWindow);
            }
        }

        public ICommand EShopWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenEShopWindow);
            }
        }

        public ICommand ForceLogOutCommand
        {
            get
            {
                return new DelegateCommand(OpenLogOutCustomerWindow);
            }
        }

        public ICommand CancelPromoCommand
        {
            get
            {
                return new DelegateCommand(OpenCancelPromoWindow);
            }
        }

        public ICommand TransactionHistoryWindowCommand
        {
            get
            {
                return new DelegateCommand(OpenTransactionHistoryWindow);
            }
        }

        public ICommand EndShiftCommand
        {
            get
            {
                return new DelegateCommand(OpenEndShiftWindow);
            }
        }

        public ICommand PreviousShiftCommand
        {
            get
            {
                return new DelegateCommand(OpenPreviousShiftWindow);
            }
        }

        public ICommand CurrentShiftCommand
        {
            get
            {
                return new DelegateCommand(OpenCurrentShiftWindow);
            }
        }

        public ICommand SaveNotesCommand
        {
            get
            {
                return new DelegateCommand(SaveNotes);
            }
        }

        #endregion


        #region Event Handlers

        private void InitializeKeyboardRawInput()
        {
            var mainWindow = Application.Current.MainWindow;
            var source = HwndSource.FromHwnd(new WindowInteropHelper(mainWindow).Handle);

            keyboardRawInput = new RawInput(source.Handle, true);

            keyboardRawInput.AddMessageFilter();
            Win32.DeviceAudit();

            keyboardRawInput.KeyPressed += OnRawInputChanged;

            m_globalKeyboardHook = Hook.AppEvents();
            m_globalKeyboardHook.KeyDown += KeyboardHook_Keydown;
        }

        private void OnRawInputChanged(object sender, RawInputEventArg e)
        {
            if (e.KeyPressEvent.KeyPressState == "BREAK")
            {
                var digits = KeyMapper.GetMicrosoftKeyName(e.KeyPressEvent.VKey);
                RawKeyboard rawKeyboard = (RawKeyboard)sender;
                cardLastString = KeyMapper.GetMicrosoftKeyName(e.KeyPressEvent.VKey);
                isKeyDownHandled = false;

                if(rawKeyboard.tempNumberHolder.Length == 14)
                {
                    NewCardReaderTap(rawKeyboard.tempNumberHolder);
                }
            }
            else
            {
                isKeyDownHandled = true;
            }
        }

        private void KeyboardHook_Keydown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (isKeyDownHandled)
            {
                e.Handled = true;
            }
        }

        private void Shutdown()
        {
            var pool = DataCacheContext.WorkstationModels.Values.ToList();

            if (pool.Count > 0)
            {
                bool isExists = pool.Where(pc => pc.IPAddress == WorkStationModel.StationModel.StaticIPAddress).Count() > 0 ? true : false;

                if (isExists)
                {
                    ClientPC clientPC = pool.Where(pc => pc.IPAddress == WorkStationModel.StationModel.StaticIPAddress).ToList().FirstOrDefault();
                    string warningMessage = string.Empty;

                    if (WorkStationModel.IsOccupied)
                    {
                        warningMessage = StandardMessageResource.WarningConfirmationShutdownWhenOccupied;
                    }
                    else
                    {
                        warningMessage = StandardMessageResource.WarningConfirmationShutdown;
                    }

                    if (!ShowConfirmationWindow(warningMessage, Messages.WarningConfirmation))
                    {
                        return;
                    }

                    NetworkServer.Instance.SendMessageToClient(clientPC.Connection, NetworkMessageType.ShutdownPC, null);
                }
            }

        }

        private async void LogoutUser()
        {
            try
            {
                await ValidateCashierSession();

                string warningMessage = StandardMessageResource.WarningConfirmationCashierUserLogout;
                if (!ShowConfirmationWindow(warningMessage, Messages.WarningConfirmation))
                {
                    return;
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = true;
                    ProcessingText = "LOGGING OUT . . .";
                    Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, IsProcessing);
                    Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ProcessingText, ProcessingText);
                });

                LogoutServiceProvider logoutService = new LogoutServiceProvider();
                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

                ResponseModel response = null;
                try
                {
                    response = await TaskManagerModel<ResponseModel>.Instance.Run(logoutService.Logout(DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString(), isCriticalTask: true);
                }
                catch (AggregateException aggregateException)
                {
                    bool wasTaskCanceled = false;
                    foreach (var exception in aggregateException.InnerExceptions)
                    {
                        if (exception is TaskCanceledException)
                        {
                            response = null;
                            wasTaskCanceled = true;
                            break;
                        }
                    }

                    if (!wasTaskCanceled)
                    {
                        ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                    }
                }

                await App.Current.Dispatcher.BeginInvoke((Action)delegate
                {
                    IsProcessing = false;
                    Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, IsProcessing);
                });

                if (response == null)
                {
                    return;
                }

                if (response.HttpStatusCode == (int)HttpStatusCode.OK)
                {
                    App.Current.Dispatcher.Invoke(() =>
                    {
                        ViewService.Instance.ShowView<LoginWindowViewModel>();
                        Mediator.Instance.NotifyViewModel(Messages.MainViewModel, Messages.LogoutUser, null);

                        // Note:
                        // This will locate the directory of the .exe and run it (so there would be two instance) then
                        // entirely close the current running .exe.

                        CardUtilities card = CardUtilities.Instance;
                        card.StopMonitoring();
                        SwitchToLoginView();
                    });
                }
            }
            catch (Exception)
            {
                string message = string.Format(StandardMessageResource.ErrorConnectionIssue, StandardMessageResource.TransactWordConnect, StandardMessageResource.TransactWordServer);
                ShowErrorMessage(message);
            }
        }

        private void SwitchToLoginView()
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                UpdateStartStatus("restarting");
                NetworkServer.Instance.Shutdown();
                System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
                Application.Current.Shutdown();
            });
        }

        private async void UnlockUser(UserDataModel memberData)
        {
            CardServiceProvider unlockUserService = new CardServiceProvider();

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            ResponseModel response = null;
            try
            {
                response = await TaskManagerModel<ResponseModel>.Instance.Run(unlockUserService.UnlockUser(DataCacheContext.CashierSessionID, memberData.MemberData.CardNumber, cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        response = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                }
            }

            if (response == null)
            {
                return;
            }

            if (response.HttpStatusCode == (int)HttpStatusCode.OK)
            {
                TransactionModel transactionModel = CreateTransactionModel(memberData.MemberData.CardNumber, GetMemberUnlockedTransactionRemarks(memberData.MemberData.Balance), $"{memberData.MemberData.CustomerAccount.Username}");
                Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.TransactionModel, transactionModel);
            }
        }

        private TransactionModel CreateTransactionModel(string id, string remarks, string name = null)
        {
            TransactionModel transactionModel = new TransactionModel()
            {
                TransactionTime = DateTime.Now.ToString("hh:mm tt"),
                TransactionType = tapToUnlock,
                CustomerName = name,
                CustomerID = id,
                TransactionAmount = "N/A",
                TransactionRemarks = remarks
            };
            return transactionModel;
        }

        private string GetMemberUnlockedTransactionRemarks(string userBalance)
        {
            string cardUnlockedRemarks = string.Empty;

            cardUnlockedRemarks = "Member Unlocked. ";

            if (userBalance != null && userBalance != string.Empty)
            {
                cardUnlockedRemarks += $"Remaining balance: {CurrencySymbol} {userBalance.ConvertIntToMoney()}. ";
            }

            return cardUnlockedRemarks;
        }

        private string GenerateRandomNumber()
        {
            Random rndNumber = new Random();
            return rndNumber.Next(0, 99999999).ToString();
        }

        private void ShowErrorMessage(string errorMessage)
        {
            string messageMode = Messages.ErrorConfirmation;
            ShowConfirmationWindow(errorMessage, messageMode);
        }

        private async void OpenResetPasswordWindow()
        {
            await ValidateCashierSession();

            windowWithError = new List<string>();
            ResetPasswordWindow resetPassword = new ResetPasswordWindow();
            resetPassword.Owner = App.Current.MainWindow;

            if (windowWithError.Exists(window => window == Messages.ResetPasswordWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.ResetPasswordWindow);
                return;
            }

            Mediator.Instance.NotifyViewModel(Messages.ResetPasswordViewModel, Messages.ResetPasswordWindow, resetPassword);
            Mediator.Instance.NotifyViewModel(Messages.ResetPasswordViewModel, Messages.CashierInfo, userData);
            isResetPasswordWindowOpen = true;

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            resetPassword.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.26);
            resetPassword.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.317);
            resetPassword.ShowDialog();
            //execution will stop in the line above while the reset password window is still open
            isResetPasswordWindowOpen = false;
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private void OpenReceivedOrdersWindow()
        {
            if (!Mediator.Instance.IsRegistered(Messages.ReceivedOrdersViewModel))
            {
                windowWithError = new List<string>();
                receivedOrdersWindow = new ReceivedOrdersControl();
                receivedOrdersWindow.Owner = App.Current.MainWindow;
                if (windowWithError.Exists(window => window == Messages.ReceivedOrdersWindow))
                {
                    windowWithError.RemoveAll(window => window == Messages.ReceivedOrdersWindow);
                    return;
                }
                Mediator.Instance.NotifyViewModel(Messages.ReceivedOrdersViewModel, Messages.ReceivedOrdersWindow, receivedOrdersWindow);
                Mediator.Instance.NotifyViewModel(Messages.ReceivedOrdersViewModel, Messages.CashierInfo, userData);

                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
                receivedOrdersWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.545);
                receivedOrdersWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.538);
                receivedOrdersWindow.ShowDialog();
                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
            }
        }

        private void OpenCouponWindow()
        {
            if (IsCouponShowed)
            {
                windowWithError = new List<string>();
                CouponManagerWindow coupon = new CouponManagerWindow();
                coupon.Owner = App.Current.MainWindow;

                if (windowWithError.Exists(window => window == Messages.CouponManagerWindow))
                {
                    windowWithError.RemoveAll(window => window == Messages.CouponManagerWindow);
                    return;
                }

                Mediator.Instance.NotifyViewModel(Messages.CouponManagerViewModel, Messages.CouponManagerWindow, coupon);
                Mediator.Instance.NotifyViewModel(Messages.CouponManagerViewModel, Messages.CashierInfo, userData);
                Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.StationList, null);
                Mediator.Instance.NotifyViewModel(Messages.CouponManagerViewModel, Messages.StationList, WorkStationList);

                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);

                App.Current.Dispatcher.Invoke(() =>
                {
                    coupon.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.339);
                    coupon.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.247);
                    coupon.ShowDialog();
                    Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
                });
            }
            else
            {
                ShowConfirmationWindow(StandardMessageResource.ErrorNotAllowedToCreateCoupon, Messages.ErrorConfirmation);
            }
        }

        private void OpenAccountManager()
        {
            windowWithError = new List<string>();
            AccountManagerWindow accountManagerWindow = new AccountManagerWindow();
            accountManagerWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.AccountManagerWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.AccountManagerWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.StationList, null);
            Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.AccountManagerWindow, accountManagerWindow);
            Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.StationList, WorkStationList);
            Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.CashierInfo, userData);

            if (isCardTapped)
            {
                Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.CardID, cardUID);
                isCardTapped = false;
            }
            isAccountManagerOpen = true;

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);

            accountManagerWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.678);
            accountManagerWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.543);

            accountManagerWindow.ShowDialog();
            //execution will stop in the line above while the account manager window is still open
            isAccountManagerOpen = false;
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private void OpenTopUpManagerWindow()
        {
            windowWithError = new List<string>();
            TopUpManagerWindow topUpWindow = new TopUpManagerWindow();
            topUpWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.TopUpManagerWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.TopUpManagerWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.StationList, null);
            Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.TopUpManagerWindow, topUpWindow);
            Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.StationList, WorkStationList);
            Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.CashierInfo, userData);
            isTopUpManagerOpen = true;

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            topUpWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.678);
            topUpWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.543);
            topUpWindow.ShowDialog();
            //execution will stop in the line above while the top up manager window is still open
            isTopUpManagerOpen = false;
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);

        }

        private void OpenUserTopUpManagerWindow()
        {
            if (WorkStationModel.AccountModel.CardNumber != "--")
            {
                windowWithError = new List<string>();
                TopUpManagerWindow topUpWindow = new TopUpManagerWindow();
                topUpWindow.Owner = Application.Current.MainWindow;
                if (windowWithError.Exists(window => window == Messages.TopUpManagerWindow))
                {
                    windowWithError.RemoveAll(window => window == Messages.TopUpManagerWindow);
                    return;
                }
                Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.StationList, null);
                Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.TopUpManagerWindow, topUpWindow);
                Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.TopUpByUser, WorkStationModel);
                Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.CashierInfo, userData);
                Mediator.Instance.NotifyViewModel(Messages.RightUserControl, Messages.StationList, null);
                isTopUpManagerOpen = true;

                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
                topUpWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.678);
                topUpWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.543);
                topUpWindow.ShowDialog();
                //execution will stop in the line above while the top up manager window is still open
                isTopUpManagerOpen = false;
                Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
            }
        }

        private void OpenFoodAndBeverageWindow()
        {
            windowWithError = new List<string>();
            FoodAndBeverageManagerWindow foodAndBeverageManagerWindow = new FoodAndBeverageManagerWindow();
            foodAndBeverageManagerWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.FoodAndBeverageManagerWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.FoodAndBeverageManagerWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.FoodAndBeverageManagerWindowViewModel, Messages.FoodAndBeverageManagerWindow, foodAndBeverageManagerWindow);
            Mediator.Instance.NotifyViewModel(Messages.FoodAndBeverageManagerWindowViewModel, Messages.CashierInfo, userData);

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            foodAndBeverageManagerWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.678);
            foodAndBeverageManagerWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.673);
            foodAndBeverageManagerWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private void OpenInventoryManagerWindow()
        {
            windowWithError = new List<string>();
            InventoryManagerWindow inventoryWindow = new InventoryManagerWindow();
            inventoryWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.InventoryManagerWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.InventoryManagerWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.InventoryManagerWindowViewModel, Messages.InventoryManagerWindow, inventoryWindow);
            Mediator.Instance.NotifyViewModel(Messages.InventoryManagerWindowViewModel, Messages.CashierInfo, userData);

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            inventoryWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.625);
            inventoryWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.538);
            inventoryWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private void OpenReplaceCardWindow()
        {
            windowWithError = new List<string>();
            ReplaceCardWindow replaceCardWindow = new ReplaceCardWindow();
            replaceCardWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.ReplaceCardWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.ReplaceCardWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.ReplaceCardWindowViewModel, Messages.ReplaceCardWindow, replaceCardWindow);
            Mediator.Instance.NotifyViewModel(Messages.ReplaceCardWindowViewModel, Messages.CashierInfo, userData);
            isReplaceCardWindowOpen = true;

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            replaceCardWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.442);
            replaceCardWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.384);
            replaceCardWindow.ShowDialog();
            isReplaceCardWindowOpen = false;
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private void OpenEShopWindow()
        {
            windowWithError = new List<string>();
            EShopWindow eShopWindow = new EShopWindow();
            eShopWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.EShopWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.EShopWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.EShopWindowViewModel, Messages.EShopWindow, eShopWindow);
            Mediator.Instance.NotifyViewModel(Messages.EShopWindowViewModel, Messages.CashierInfo, userData);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            eShopWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.625);
            eShopWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.673);
            eShopWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private async void OpenLogOutCustomerWindow()
        {
            await ValidateCashierSession();

            windowWithError = new List<string>();
            LogOutCustomerWindow logOutCustomerWindow = new LogOutCustomerWindow();
            logOutCustomerWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.LogOutCustomerWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.LogOutCustomerWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.LogOutCustomerWindowViewModel, Messages.LogOutCustomerWindow, logOutCustomerWindow);
            Mediator.Instance.NotifyViewModel(Messages.LogOutCustomerWindowViewModel, Messages.CashierInfo, userData);

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            logOutCustomerWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.156);
            logOutCustomerWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.240);
            logOutCustomerWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private async void OpenCancelPromoWindow()
        {
            await ValidateCashierSession();

            windowWithError = new List<string>();
            CancelPromoWindow cancelPromoWindow = new CancelPromoWindow();
            cancelPromoWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.CancelPromoWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.CancelPromoWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.CancelPromoViewModel, Messages.CancelPromoWindow, cancelPromoWindow);
            Mediator.Instance.NotifyViewModel(Messages.CancelPromoViewModel, Messages.CashierInfo, userData);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            cancelPromoWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.156);
            cancelPromoWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.240);
            cancelPromoWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private void OpenTransactionHistoryWindow()
        {
            windowWithError = new List<string>();
            TransactionHistoryWindow transactionHistoryWindow = new TransactionHistoryWindow();
            transactionHistoryWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.TransactionHistoryWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.TransactionHistoryWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.TransactionHistoryWindowViewModel, Messages.TransactionHistoryWindow, transactionHistoryWindow);
            Mediator.Instance.NotifyViewModel(Messages.TransactionHistoryWindowViewModel, Messages.CashierInfo, userData);

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            transactionHistoryWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.572);
            transactionHistoryWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.769);
            transactionHistoryWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private async void OpenEndShiftWindow()
        {
            await ValidateCashierSession();

            windowWithError = new List<string>();
            EndShiftWindow endShiftWindow = new EndShiftWindow();
            endShiftWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.EndShiftWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.EndShiftWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.EndShiftWindowViewModel, Messages.EndShiftWindow, endShiftWindow);
            Mediator.Instance.NotifyViewModel(Messages.EndShiftWindowViewModel, Messages.CashierInfo, userData);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            endShiftWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.208);
            endShiftWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.288);
            endShiftWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private async void OpenPreviousShiftWindow()
        {
            await ValidateCashierSession();

            windowWithError = new List<string>();
            PreviousShiftWindow previousShiftWindow = new PreviousShiftWindow();
            previousShiftWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.EndShiftWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.EndShiftWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.PreviousShiftWindowViewModel, Messages.PreviousShiftWindow, previousShiftWindow);
            Mediator.Instance.NotifyViewModel(Messages.PreviousShiftWindowViewModel, Messages.CashierInfo, userData);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            previousShiftWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.208);
            previousShiftWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.288);
            previousShiftWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private async void OpenCurrentShiftWindow()
        {
            await ValidateCashierSession();

            windowWithError = new List<string>();
            CurrentShiftWindow currentShiftWindow = new CurrentShiftWindow();
            currentShiftWindow.Owner = Application.Current.MainWindow;
            if (windowWithError.Exists(window => window == Messages.EndShiftWindow))
            {
                windowWithError.RemoveAll(window => window == Messages.EndShiftWindow);
                return;
            }
            Mediator.Instance.NotifyViewModel(Messages.CurrentShiftWindowViewModel, Messages.CurrentShiftWindow, currentShiftWindow);
            Mediator.Instance.NotifyViewModel(Messages.CurrentShiftWindowViewModel, Messages.CashierInfo, userData);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            currentShiftWindow.Width = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width * 0.208);
            currentShiftWindow.Height = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Height * 0.288);
            currentShiftWindow.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
        }

        private void OpenPendingOrdersNotificationWindow(int pendingOrdersCount)
        {
            if (!Mediator.Instance.IsRegistered(Messages.PendingOrdersWindowViewModel))
            {
                windowWithError = new List<string>();
                pendingOrdersWindow = new PendingOrdersPopupWindow();
                if (windowWithError.Exists(window => window == Messages.PendingOrdersWindow))
                {
                    windowWithError.RemoveAll(window => window == Messages.PendingOrdersWindow);
                    return;
                }

                Mediator.Instance.NotifyViewModel(Messages.PendingOrdersWindowViewModel, Messages.PendingOrdersWindow, pendingOrdersWindow);
                Mediator.Instance.NotifyViewModel(Messages.PendingOrdersWindowViewModel, Messages.PendingOrdersCount, pendingOrdersCount);

                pendingOrdersWindow.Topmost = true;
                int screenW = (System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Left + System.Windows.Forms.Screen.PrimaryScreen.WorkingArea.Width) / 2;
                pendingOrdersWindow.WindowStartupLocation = WindowStartupLocation.Manual;
                pendingOrdersWindow.Top = 0;
                pendingOrdersWindow.Left = screenW - (pendingOrdersWindow.Width / 2);

                pendingOrdersWindow.Show();
            }
            else
            {
                Mediator.Instance.NotifyViewModel(Messages.PendingOrdersWindowViewModel, Messages.PendingOrdersCount, pendingOrdersCount);
            }
        }

        private async Task GetOrderTotalCount()
        {
            StoreServiceProvider storeServiceProvider = new StoreServiceProvider();

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            int pendingOrdersCount = 0;
            try
            {
                pendingOrdersCount = await TaskManagerModel<int>.Instance.Run(storeServiceProvider.GetSalesOrderCount(DataCacheContext.CashierSessionID, "PENDING", DateTime.Today.AddDays(-7), DateTime.Today, cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                bool isSqlHavingErrors = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        pendingOrdersCount = 0;
                        wasTaskCanceled = true;
                        break;
                    }
                    else if (exception is SqlException)
                    {
                        isSqlHavingErrors = true;
                    }
                }

                if (!wasTaskCanceled)
                {
                    if (isSqlHavingErrors)
                    {
                        //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                        //ShowConfirmationWindow(StandardMessageResource.ErrorDatabaseError, Messages.ErrorConfirmation);
                    }
                    else
                    {
                        //Fix me: We don't want the user to know that there is an error in the database. Is there a better way to do this?
                        //ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                    }
                }
            }

            if (pendingOrdersCount > 0 && !Mediator.Instance.IsRegistered(Messages.ReceivedOrdersViewModel))
            {
                App.Current.Dispatcher.Invoke(() =>
                {
                    OpenPendingOrdersNotificationWindow(pendingOrdersCount);
                });
            }

            App.Current.Dispatcher.Invoke(() =>
            {
                PendingOrderCount = pendingOrdersCount;
            });

            Mediator.Instance.NotifyViewModel(Messages.ReceivedOrdersViewModel, Messages.PendingOrdersCount, pendingOrdersCount);
        }

        private void UpdateStartStatus(string status)
        {
            string myDocumentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments);

            using (StreamWriter outputFile = new StreamWriter(myDocumentsPath + @"\gocafe-status.txt"))
            {
                outputFile.WriteLine($"{status}");
            }
        }

        private async Task ValidateCashierSession()
        {
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, true);
            bool isCashierSessionValid = await CashierSession.ValidateSession(ToString());
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.IsProcessing, false);

            if (!isCashierSessionValid)
            {
                return;
            }
        }

        private void SaveNotes()
        {
            File.WriteAllText(notesFileName, NotesText);
        }

        private void LoadNotes()
        {
            if (File.Exists(notesFileName))
            {
                NotesText = File.ReadAllText(notesFileName);
            }
        }

        private async Task InitializeOrderNumberList()
        {
            StoreServiceProvider storeServiceProvider = new StoreServiceProvider();
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            DataCacheContext.OrderList = new List<OrderNumberModel>();

            List<SalesOrderDataModel> salesOrders = null;
            try
            {
                salesOrders = await TaskManagerModel<List<SalesOrderDataModel>>
                                            .Instance
                                            .Run(storeServiceProvider.GetSalesOrderByStatus(
                                                userData.CashierSessionID,
                                                OrderStatusDefinition.Pending.ToUpper(),
                                                DateTime.Today.AddDays(-7).ToString("yyyy-MM-ddTHH:mm:ss"),
                                                DateTime.Today.AddDays(1).ToString("yyyy-MM-ddTHH:mm:ss"),
                                                cancellationTokenSource.Token), cancellationTokenSource,
                                                string.Empty,
                                                isCriticalTask: true);
            }
            catch (Exception e)
            {

            }

            if (salesOrders != null)
            {
                List<SalesOrderDataModel> sortedSalesOrders = new List<SalesOrderDataModel>(salesOrders.OrderBy(x => DateTime.Parse(x.TransactionDateTime)));

                foreach(var salesOrder in sortedSalesOrders.Select((value, index) => new { value, index }))
                {
                    DataCacheContext.OrderList.Add(new OrderNumberModel
                    {
                        StationID = salesOrder.value.StationId,
                        ReferenceNumber = salesOrder.value.ReceiptNumber,
                        OrderQueueNumber = salesOrder.index + 1
                    });
                }
                DataCacheContext.OrderList.Add(acceptedOrRejectedOrder);
            }
        }

        private void SendOrderNumbersToStation(string stationID)
        {
            List<OrderNumberModel> ordersFromRequestingStation = new List<OrderNumberModel>();
            foreach(OrderNumberModel order in DataCacheContext.OrderList)
            {
                if (order.StationID == stationID)
                {
                    ordersFromRequestingStation.Add(order);
                }
            }

            NetworkServer.Instance.SendMessageToClientUsingStationID(
                stationID,
                NetworkMessageType.UpdatedOrderNumbers,
                ordersFromRequestingStation
            );
        }

        private void UpdateAllOrderNumbers()
        {
            List<string> stationIDsWithOrders = new List<string>();

            foreach (OrderNumberModel order in DataCacheContext.OrderList)
            {
                if (!stationIDsWithOrders.Contains(order.StationID))
                {
                    stationIDsWithOrders.Add(order.StationID);
                }
            }

            foreach(string stationID in stationIDsWithOrders)
            {
                SendOrderNumbersToStation(stationID);
            }
        }

        private async void NewCardReaderTap(string cardUID)
        {
            MemberServiceProvider memberService = new MemberServiceProvider();
            UserDataModel memberData = new UserDataModel();

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

            try
            {
                memberData = await TaskManagerModel<UserDataModel>.Instance.Run(memberService.GetMemberInfo(cardUID, DataCacheContext.CashierSessionID, cancellationTokenSource.Token), cancellationTokenSource, ToString());
            }
            catch (AggregateException aggregateException)
            {
                bool wasTaskCanceled = false;
                foreach (var exception in aggregateException.InnerExceptions)
                {
                    if (exception is TaskCanceledException)
                    {
                        memberData = null;
                        wasTaskCanceled = true;
                        break;
                    }
                }

                if (!wasTaskCanceled)
                {
                    ShowConfirmationWindow(StandardMessageResource.ErrorUnexpected, Messages.ErrorConfirmation);
                }
            }

            if (memberData == null)
            {
                memberData = new UserDataModel();
            }
            else
            {
                if (memberData.IsAvailable)
                {
                    if (isAccountManagerOpen)
                    {
                        Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.CardID, cardUID);
                    }
                    else if (isReplaceCardWindowOpen)
                    {
                        Mediator.Instance.NotifyViewModel(Messages.ReplaceCardWindowViewModel, Messages.CardID, cardUID);
                    }
                    else if (!isAccountManagerOpen && !isTopUpManagerOpen && !isResetPasswordWindowOpen && !isReplaceCardWindowOpen)
                    {
                        await Application.Current.Dispatcher.BeginInvoke((Action)delegate
                        {
                            isCardTapped = true;
                            OpenAccountManager();
                        });
                    }
                }
                else if (memberData.MemberData != null)
                {
                    if (isTopUpManagerOpen)
                    {
                        Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.MemberData, memberData);
                    }
                    else if (isResetPasswordWindowOpen)
                    {
                        Mediator.Instance.NotifyViewModel(Messages.ResetPasswordViewModel, Messages.CardID, cardUID);
                    }
                    UnlockUser(memberData);
                }
                else
                {

                    ShowConfirmationWindow("Card is not allowed", Messages.ErrorConfirmation);
                }
            }
        }

        #endregion
    }
}