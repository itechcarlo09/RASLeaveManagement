﻿namespace gocafe_cashier.Model.Store
{
    public class CustomerDetail : BaseModel
    {
        public CustomerDetail()
        {
            Initialize();
        }

        private void Initialize()
        {
            PcName = "--";
            CustomerName = "--";
            AccountBalance = 0;
            TotalAmount = 0;
            StationID = "--";
            CustomerUsername = "--";
        }

        #region Properties

        private string pcName;
        public string PcName
        {
            get { return pcName; }
            set
            {
                pcName = value;
                RaisePropertyChanged(nameof(PcName));
            }
        }

        private string customerName;
        public string CustomerName
        {
            get { return customerName; }
            set
            {
                customerName = value;
                RaisePropertyChanged(nameof(CustomerName));
            }
        }

        private decimal accountBalance;
        public decimal AccountBalance
        {
            get { return accountBalance; }
            set
            {
                accountBalance = value;
                RaisePropertyChanged(nameof(AccountBalance));
            }
        }

        private long totalAmount;
        public long TotalAmount
        {
            get { return totalAmount; }
            set
            {
                totalAmount = value;
                RaisePropertyChanged(nameof(TotalAmount));
            }
        }

        private string stationID;
        public string StationID
        {
            get { return stationID; }
            set
            {
                stationID = value;
                RaisePropertyChanged(nameof(StationID));
            }
        }

        private string customerUsername;
        public string CustomerUsername
        {
            get { return customerUsername; }
            set
            {
                customerUsername = value;
                RaisePropertyChanged(nameof(CustomerUsername));
            }
        }

        #endregion
    }
}
