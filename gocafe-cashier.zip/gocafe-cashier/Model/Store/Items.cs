﻿namespace gocafe_cashier.Model.Store
{
    public class Items : BaseModel
    {
        public Items()
        {
            InitializeProperties();
        }

        private void InitializeProperties()
        {
            Name = "--";
            Quantity = 0;
            Price = 0;
            Total = 0;
            ID = "--";
        }

        #region Properties

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                RaisePropertyChanged(nameof(Name));
            }
        }

        private string id;
        public string ID
        {
            get { return id; }
            set
            {
                id = value;
                RaisePropertyChanged(nameof(ID));
            }
        }

        private int quantity;
        public int Quantity
        {
            get { return quantity; }
            set
            {
                quantity = value;
                RaisePropertyChanged(nameof(Quantity));
            }
        }

        private decimal price;
        public decimal Price
        {
            get { return price; }
            set
            {
                price = value;
                RaisePropertyChanged(nameof(Price));
            }
        }

        private decimal total;
        public decimal Total
        {
            get { return total; }
            set
            {
                total = value;
                RaisePropertyChanged(nameof(Total));
            }
        }

        #endregion
    }
}
