﻿using GocafeDatabaseModel;
using System;
using System.Collections.ObjectModel;

namespace gocafe_cashier.Model.Store
{
    public class ItemOrderModel : BaseModel
    {
        public ItemOrderModel()
        {
            InitializeProperties();
        }

        private void InitializeProperties()
        {
            
            OrderNumber = "Order# --";
            OrderDate = "--";
            OrderTime = "--";
            OrderDateTime = "--";
            ItemList = new ObservableCollection<Items>();
            OrderStatus = OrderStatusDefinition.Pending;
            CustomerDetail = new CustomerDetail();
            IsCashier = false;
            IsSelected = false;
            IsAccepted = false;
            OrderID = "--";
        }

        #region Properties

        private bool isSelected;
        public bool IsSelected
        {
            get { return isSelected; }
            set
            {
                isSelected = value;
                RaisePropertyChanged(nameof(IsSelected));
            }
        }

        private bool isCashier;
        public bool IsCashier
        {
            get { return isCashier; }
            set
            {
                isCashier = value;
                RaisePropertyChanged(nameof(IsCashier));
            }
        }

        private bool isAccepted;
        public bool IsAccepted
        {
            get { return isAccepted; }
            set
            {
                isAccepted = value;
                RaisePropertyChanged(nameof(IsAccepted));
            }
        }

        private string orderStatus;
        public string OrderStatus
        {
            get { return orderStatus; }
            set
            {
                orderStatus = value;
                RaisePropertyChanged(nameof(OrderStatus));
            }
        }

        private string orderNumber;
        public string OrderNumber
        {
            get { return orderNumber; }
            set
            {
                orderNumber = value;
                RaisePropertyChanged(nameof(OrderNumber));
            }
        }

        private Guid transactionId;
        public Guid TransactionId
        {
            get { return transactionId; }
            set
            {
                transactionId = value;
                RaisePropertyChanged(nameof(TransactionId));
            }
        }

        private string orderDate;
        public string OrderDate
        {
            get { return orderDate; }
            set
            {
                orderDate = value;
                RaisePropertyChanged(nameof(OrderDate));
            }
        }

        private string orderDateTime;
        public string OrderDateTime
        {
            get { return orderDateTime; }
            set
            {
                orderDateTime = value;
                RaisePropertyChanged(nameof(OrderDateTime));
            }
        }

        private string orderTime;
        public string OrderTime
        {
            get { return orderTime; }
            set
            {
                orderTime = value;
                RaisePropertyChanged(nameof(OrderTime));
            }
        }

        private ObservableCollection<Items> itemList;
        public ObservableCollection<Items> ItemList
        {
            get { return itemList; }
            set
            {
                itemList = value;
                RaisePropertyChanged(nameof(ItemList));
            }
        }

        private CustomerDetail customerDetail;
        public CustomerDetail CustomerDetail
        {
            get { return customerDetail; }
            set
            {
                customerDetail = value;
                RaisePropertyChanged(nameof(CustomerDetail));
            }
        }

        public string OrderID { get; set; }

        #endregion
    }
}
