﻿using GocafeDatabaseModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace gocafe_cashier.Model.Store
{
    public class ReceivedOrdersModel : BaseModel
    {
        public ReceivedOrdersModel()
        {
            Initialize();
        }

        private void Initialize()
        {
            ItemOrderList = new ObservableCollection<ItemOrderModel>();
            SelectedItemOrder = new ItemOrderModel();
            OrderTypeList = new List<string>();
            OrderTypeList.Add(OrderStatusDefinition.Pending);
            OrderTypeList.Add(OrderStatusDefinition.Accepted);
            OrderTypeList.Add(OrderStatusDefinition.Rejected);
            SelectedOrderType = OrderStatusDefinition.Pending;

            //LoadSampleOrders();
            //LoadSampleOrders();
        }

        #region Properties

        private string selectedOrderType;
        public string SelectedOrderType
        {
            get { return selectedOrderType; }
            set
            {
                selectedOrderType = value;
                RaisePropertyChanged(nameof(SelectedOrderType));
            }
        }

        private List<string> orderTypeList;
        public List<string> OrderTypeList
        {
            get { return orderTypeList; }
            set
            {
                orderTypeList = value;
                RaisePropertyChanged(nameof(OrderTypeList));
            }
        }

        private ObservableCollection<ItemOrderModel> itemOrderList;
        public ObservableCollection<ItemOrderModel> ItemOrderList
        {
            get { return itemOrderList; }
            set
            {
                itemOrderList = value;
                RaisePropertyChanged(nameof(ItemOrderList));
            }
        }

        private ItemOrderModel selectedItemOrder;
        public ItemOrderModel SelectedItemOrder
        {
            get { return selectedItemOrder; }
            set
            {
                selectedItemOrder = value;
                RaisePropertyChanged(nameof(SelectedItemOrder));
            }
        }

        #endregion


        #region Event handlers

        private void LoadSampleOrders()
        {
            ObservableCollection<Items> items = new ObservableCollection<Items>();
            items.Add(new Items()
            {
                Name = "Pancit Canton",
                Price = 20,
                Quantity = 2,
                Total = 20 * 2
            });
            items.Add(new Items()
            {
                Name = "Coke",
                Price = 15,
                Quantity = 2,
                Total = 15 * 2
            });
            items.Add(new Items()
            {
                Name = "Pancit Canton",
                Price = 20,
                Quantity = 2,
                Total = 20 * 2
            });
            items.Add(new Items()
            {
                Name = "Coke",
                Price = 15,
                Quantity = 2,
                Total = 15 * 2
            });
            items.Add(new Items()
            {
                Name = "Pancit Canton",
                Price = 20,
                Quantity = 2,
                Total = 20 * 2
            });
            items.Add(new Items()
            {
                Name = "Coke",
                Price = 15,
                Quantity = 2,
                Total = 15 * 2
            });
            items.Add(new Items()
            {
                Name = "Pancit Canton",
                Price = 20,
                Quantity = 2,
                Total = 20 * 2
            });
            items.Add(new Items()
            {
                Name = "Coke",
                Price = 15,
                Quantity = 2,
                Total = 15 * 2
            });
            items.Add(new Items()
            {
                Name = "Pancit Canton",
                Price = 20,
                Quantity = 2,
                Total = 20 * 2
            });
            items.Add(new Items()
            {
                Name = "Coke",
                Price = 15,
                Quantity = 2,
                Total = 15 * 2
            });
            items.Add(new Items()
            {
                Name = "Pancit Canton",
                Price = 20,
                Quantity = 2,
                Total = 20 * 2
            });
            items.Add(new Items()
            {
                Name = "Coke",
                Price = 15,
                Quantity = 2,
                Total = 15 * 2
            });

            CustomerDetail customerDetail = new CustomerDetail()
            {
                AccountBalance = 1000,
                CustomerName = "Lorenz Ong",
                PcName = "PC 01",
                TotalAmount = 150
            };

            ItemOrderList.Add(new ItemOrderModel()
            {
                OrderDate = "12/21/2017",
                OrderTime = "1:00 PM",
                OrderDateTime = "12/21/2017 1:00 PM",
                OrderNumber = "Order# 1",
                ItemList = items,
                CustomerDetail = customerDetail,
                IsAccepted = true
            });
            items = new ObservableCollection<Items>();
            items.Add(new Items()
            {
                Name = "Coke",
                Price = 15,
                Quantity = 2,
                Total = 15 * 2
            });

            customerDetail = new CustomerDetail()
            {
                AccountBalance = 500,
                CustomerName = "Jerameel Resco",
                PcName = "PC 02",
                TotalAmount = 100
            };

            ItemOrderList.Add(new ItemOrderModel()
            {
                OrderDate = "12/21/2017",
                OrderTime = "2:00 PM",
                OrderDateTime = "12/21/2017 2:00 PM",
                OrderNumber = "Order# 2",
                ItemList = items,
                CustomerDetail = customerDetail,
                IsAccepted = false
            });

            customerDetail = new CustomerDetail()
            {
                AccountBalance = 200,
                CustomerName = "Rodjemar Coso",
                PcName = "PC 03",
                TotalAmount = 50
            };

            ItemOrderList.Add(new ItemOrderModel()
            {
                OrderDate = "12/21/2017",
                OrderTime = "5:00 PM",
                OrderDateTime = "12/21/2017 5:00 PM",
                OrderNumber = "Order# 3",
                ItemList = items,
                CustomerDetail = customerDetail,
                IsAccepted = false
            });

            customerDetail = new CustomerDetail()
            {
                AccountBalance = 100,
                CustomerName = "Francis Dar",
                PcName = "PC 04",
                TotalAmount = 20
            };

            ItemOrderList.Add(new ItemOrderModel()
            {
                OrderDate = "12/21/2017",
                OrderTime = "11:00 AM",
                OrderDateTime = "12/21/2017 11:00 AM",
                OrderNumber = "Order# 4",
                ItemList = items,
                CustomerDetail = customerDetail,
                IsAccepted = false
            });
        }

        #endregion
    }
}
