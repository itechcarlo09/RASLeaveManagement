﻿using gocafe_cashier.DataModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model.InventoryModels;
using gocafe_cashier.ViewModelMediator;

namespace gocafe_cashier.Model
{
    public class InventoryManagerModel: BaseModel, IDataErrorInfo
    {

        private bool isAdjustmentReasonFirstLoad = true;
        private bool isReceiptNumberFirstLoad = true;
        public enum ChangeType { None, AdjustmentOrder, PurchaseOrder };

        public InventoryManagerModel()
        {
            Mediator.Instance.Register(this, Messages.InventoryManagerModel);
            Initialize();
        }

        public override void SendData(string message, object data)
        {
            switch(message)
            {
                case Messages.IsModified:
                    IsModified = true;
                    RaisePropertyChanged(nameof(AdjustmentReason));
                    RaisePropertyChanged(nameof(ReceiptNumber));
                    break;
            }
        }

        private void Initialize()
        {
            Items = new ObservableCollection<ItemModel>();
            CategoryList = new ObservableCollection<String>();
            UserNameList = new ObservableCollection<String>();
            ItemList = new ObservableCollection<String>();
            UpdateLists();
            isAdjustmentReasonFirstLoad = true;
            isReceiptNumberFirstLoad = true;
        }

        private void UpdateLists()
        {
            ObservableCollection<String> temporaryCollection = new ObservableCollection<String>();
            temporaryCollection.Add("All Categories");
            foreach (ItemModel item in items)
            {
                temporaryCollection.Add(item.Product.Category.Name);
            }
            CategoryList = new ObservableCollection<string>(temporaryCollection.Distinct());

            temporaryCollection.Clear();
            temporaryCollection.Add("All Items");
            foreach (ItemModel item in items)
            {
                temporaryCollection.Add(item.Product.Name);
            }
            ItemList = new ObservableCollection<string>(temporaryCollection.Distinct());
        }

        private ObservableCollection<String> categoryList;

        public ObservableCollection<String> CategoryList
        {
            get { return categoryList; }
            set { categoryList = value; RaisePropertyChanged(nameof(CategoryList)); }
        }

        private ObservableCollection<String> userNameList;

        public ObservableCollection<String> UserNameList
        {
            get { return userNameList; }
            set { userNameList = value; RaisePropertyChanged(nameof(UserNameList)); }
        }

        private ObservableCollection<String> itemList;

        public ObservableCollection<String> ItemList
        {
            get { return itemList; }
            set { itemList = value; RaisePropertyChanged(nameof(ItemList)); }
        }

        private ObservableCollection<ItemModel> items;

        public ObservableCollection<ItemModel> Items
        {
            get
            {
                UpdateLists();
                return items;
            }
            set
            {
                items = value;
                RaisePropertyChanged(nameof(Items));
            }
        }

        private string adjustmentReason;

        public string AdjustmentReason
        {
            get { return adjustmentReason; }
            set
            {
                if (adjustmentReason != value)
                {
                    IsModified = true;
                }
                adjustmentReason = value;
                RaisePropertyChanged(nameof(AdjustmentReason));
            }
        }

        private string receiptNumber;

        public string ReceiptNumber
        {
            get { return receiptNumber; }
            set
            {
                if (receiptNumber != value)
                {
                    IsModified = true;
                }
                receiptNumber = value;
                RaisePropertyChanged(nameof(ReceiptNumber));
            }
        }

        private bool isSubmitButtonEnabled;

        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

        private bool isModified;

        public bool IsModified
        {
            get { return isModified; }
            set
            {
                isModified = value;
                RaisePropertyChanged(nameof(IsModified));
            }
        }

        public string Error { get; set; }

        public string this[string name]
        {
            get
            {
                string result = null;
                if (name == "AdjustmentReason")
                {
                    if (IsModified)
                    { 
                        if (AdjustmentReason == null || AdjustmentReason == "")
                        {
                            result = StandardMessageResource.ErrorReasonForAdjustmentEmpty;
                        }
                    }
                }
                else if (name == "ReceiptNumber")
                {
                    if (IsModified)
                    {
                        if (ReceiptNumber == null || ReceiptNumber.Trim() == string.Empty)
                        {
                            result = StandardMessageResource.ErrorReasonForAdjustmentEmpty;
                        }
                    }
                }
                return result;
            }
        }

        public void ResetFirstLoadFields()
        {
            foreach(ItemModel item in items)
            {
                item.ResetFirstLoadFields();
            }
            IsModified = false;
            RaisePropertyChanged(nameof(AdjustmentReason));
            RaisePropertyChanged(nameof(ReceiptNumber));
        }

        public void ValidateAdjustmentOrder(string changeType, out string validationError, out ObservableCollection<ItemModel> itemsToAdjust)
        {
            validationError = string.Empty;
            itemsToAdjust = new ObservableCollection<ItemModel>();

            validationError = StandardMessageResource.ErrorNoItemToAdjust;
            foreach (ItemModel item in items)
            {
                if (item.Adjustment != 0)
                {
                    itemsToAdjust.Add(item);
                    validationError = string.Empty;
                }
            }

            if (changeType == ChangeType.AdjustmentOrder.ToString() &&
                (AdjustmentReason == null || AdjustmentReason == string.Empty))
            {
                validationError = StandardMessageResource.ErrorReasonForAdjustmentEmpty;
            }
        }

        public void ValidatePurchaseOrder(string changeType, out string validationError, out ObservableCollection<ItemModel> itemsToAdjust)
        {
            validationError = string.Empty;
            itemsToAdjust = new ObservableCollection<ItemModel>();

            validationError = StandardMessageResource.ErrorNoItemToAdjust;
            foreach (ItemModel item in items)
            {
                if (item.ErrorList.Count > 0)
                {
                    validationError = StandardMessageResource.ErrorResolveHighlightedErrors;
                    break;
                }
                else if (item.Adjustment < 0)
                {
                    validationError = StandardMessageResource.ErrorNegativeQuantity;
                    break;
                }
                else if (item.Adjustment != 0)
                {
                    itemsToAdjust.Add(item);
                    validationError = string.Empty;
                }
            }

            if (changeType == ChangeType.PurchaseOrder.ToString() &&
                (ReceiptNumber == null || ReceiptNumber.Trim() == string.Empty))
            {
                validationError = StandardMessageResource.ErrorReceiptNumberEmpty;
            }

        }

    }
}