﻿using System;

namespace gocafe_cashier.Model
{
    public class CashierLeftControlModel : BaseModel
    {
        public CashierLeftControlModel()
        {

        }

        #region EventHandlers

        private void Initialize()
        {
            SelectedWorkStationModel = new WorkstationModel();
            HasSelectedWorkStation = false;
            PcNumber = "--";
            IDNumber = "--";
            CashierName = "--";
            BranchName = "--";
        }

        #endregion

        #region Properties

        private bool hasSelectedWorkStation;
        public bool HasSelectedWorkStation
        {
            get { return hasSelectedWorkStation; }
            set
            {
                hasSelectedWorkStation = value;
                RaisePropertyChanged(nameof(HasSelectedWorkStation));
            }
        }

        private WorkstationModel selectedWorkStationModel;
        public WorkstationModel SelectedWorkStationModel
        {
            get { return selectedWorkStationModel; }
            set
            {
                selectedWorkStationModel = value;
                RaisePropertyChanged(nameof(SelectedWorkStationModel));
            }
        }

        private String pcNumber;
        public String PcNumber
        {
            get { return pcNumber; }
            set
            {
                pcNumber = value;
                RaisePropertyChanged(nameof(PcNumber));
            }
        }

        private String idNumber;
        public String IDNumber
        {
            get { return idNumber; }
            set
            {
                idNumber = value;
                RaisePropertyChanged(nameof(IDNumber));
            }
        }

        private String cashierName;
        public String CashierName
        {
            get { return cashierName; }
            set
            {
                cashierName = value;
                RaisePropertyChanged(nameof(CashierName));
            }
        }

        private String branchName;
        public String BranchName
        {
            get { return branchName; }
            set
            {
                branchName = value;
                RaisePropertyChanged(nameof(BranchName));
            }
        }

        #endregion
    }
}
