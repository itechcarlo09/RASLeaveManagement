﻿using gocafe_cashier.DataModel;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Model;
using gocafe_cashier.ViewModelMediator;
using System.ComponentModel;

namespace gocafe_agent.Model
{
    public class CouponStationTypeModel : BaseModel
    {

        public CouponStationTypeModel()
        {
            StationType = new StationTypeDataModel();
            Initialization();
        }

        private StationTypeDataModel stationtype;
        public StationTypeDataModel StationType
        {
            get { return stationtype; }
            set
            {
                stationtype = value;
                RaisePropertyChanged(nameof(StationType));
            }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = $" {value}";
                RaisePropertyChanged(nameof(Name));
            }
        }

        private string iD;
        public string ID
        {
            get { return iD; }
            set
            {
                iD = value;
                RaisePropertyChanged(nameof(ID));
            }
        }


        private bool restarted;
        public bool Restarted
        {
            get { return restarted; }
            set
            {
                restarted = value;
                RaisePropertyChanged(nameof(Restarted));
            }
        }


        private bool isChecked;
        public bool IsChecked
        {
            get { return isChecked; }
            set
            {
                isChecked = value;
                SelectAllTrigger();
                RaisePropertyChanged(nameof(IsChecked));
            }
        }

        private bool enableDurationButton;
        public bool EnableDurationButton
        {
            get { return enableDurationButton; }
            set
            {
                enableDurationButton = value;
                RaisePropertyChanged(nameof(EnableDurationButton));
            }
        }

        private bool elementIsChild;
        public bool ElementIsChild
        {
            get { return elementIsChild; }
            set
            {
                elementIsChild = value;
                RaisePropertyChanged(nameof(ElementIsChild));
            }
        }

        private void Initialization()
        {
            Name = StationType.Name;
            ID = StationType.ID;
            Restarted = false;
        }

        private void SelectAllTrigger()
        {
            if (Name == $" {StandardMessageResource.TransactSelectAll}" && Restarted == true)
            {
                Mediator.Instance.NotifyViewModel(Messages.CouponManagerViewModel, Messages.SelectAllStationType, IsChecked);
            }
            if (Name != $" {StandardMessageResource.TransactSelectAll}" && Restarted == true)
            {
                Mediator.Instance.NotifyViewModel(Messages.CouponManagerViewModel, Messages.UnSelectAllStationType, IsChecked);
            }
            restarted = true;
        }



    }
}
