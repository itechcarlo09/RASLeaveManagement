﻿using System;

namespace gocafe_cashier.Model
{
    public class TransactionModel : BaseModel
    {
        public TransactionModel()
        {
            Initialize();
        }


        #region EventHandlers

        private void Initialize()
        {
            TransactionTime = "--";
            TransactionType = "--";
            CustomerName = "--";
            CustomerID = "--";
            TransactionAmount = "--";
            TransactionRemarks = "--";
            ID = Guid.NewGuid();
            IsSelected = false;
        }

        #endregion


        #region Properties

        private Guid id;
        public Guid ID
        {
            get { return id; }
            set
            {
                id = value;
                RaisePropertyChanged(nameof(ID));
            }
        }

        private string transactionTime;
        public string TransactionTime
        {
            get { return transactionTime; }
            set
            {
                transactionTime = value;
                RaisePropertyChanged(nameof(TransactionTime));
            }
        }

        private string transactionType;
        public string TransactionType
        {
            get { return transactionType; }
            set
            {
                transactionType = value;
                RaisePropertyChanged(nameof(TransactionType));
            }
        }

        private string cashierName;

        public string CashierName
        {
            get { return cashierName; }
            set
            {
                cashierName = value;
                RaisePropertyChanged(nameof(CashierName));
            }
        }


        private string customerName;
        public string CustomerName
        {
            get { return customerName; }
            set
            {
                customerName = value;
                RaisePropertyChanged(nameof(CustomerName));
            }
        }

        private string customerID;
        public string CustomerID
        {
            get { return customerID; }
            set
            {
                customerID = value;
                RaisePropertyChanged(nameof(CustomerID));
            }
        }

        private string transactionAmount;
        public string TransactionAmount
        {
            get { return transactionAmount; }
            set
            {
                transactionAmount = value;
                RaisePropertyChanged(nameof(TransactionAmount));
            }
        }

        private string transactionRemarks;
        public string TransactionRemarks
        {
            get { return transactionRemarks; }
            set
            {
                transactionRemarks = value;
                RaisePropertyChanged(nameof(TransactionRemarks));
            }
        }

        private string memberType;
        public string MemberType
        {
            get { return memberType; }
            set
            {
                memberType = value;
                RaisePropertyChanged(nameof(MemberType));
            }
        }

        private string orderNumber;
        public string OrderNumber
        {
            get { return orderNumber; }
            set
            {
                orderNumber = value;
                RaisePropertyChanged(nameof(OrderNumber));
            }
        }


        private bool isSelected;
        public bool IsSelected
        {
            get { return isSelected; }
            set
            {
                isSelected = value;
                RaisePropertyChanged(nameof(isSelected));
            }
        }

        #endregion

    }
}
