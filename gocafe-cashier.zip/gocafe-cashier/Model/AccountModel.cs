﻿using System;
using System.Collections.Generic;

namespace gocafe_cashier.Model
{
    public class AccountModel : BaseModel
    {
        public AccountModel()
        {
            Initialize();
        } 

        private void Initialize()
        {
            IdNumber = "--";
            Customer = "--";
            StartTime = "--";
            TimeElapsed = "--";
            Status = "Available";
            Balance = "--";
            CardNumber = "--";
            Username = "--";
            UserType = "--";
            ChargingType = "--";
        }

        private string username;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                RaisePropertyChanged(nameof(Username));
            }
        }
        
        private string cardNumber;
        public string CardNumber
        {
            get { return cardNumber; }
            set
            {
                cardNumber = value;
                RaisePropertyChanged(nameof(CardNumber));
            }
        }

        private String idNumber;
        public String IdNumber
        {
            get { return idNumber; }
            set
            {
                idNumber = value;
                RaisePropertyChanged(nameof(IdNumber));
            }
        }

        private String customer;
        public String Customer
        {
            get { return customer; }
            set
            {
                customer = value;
                RaisePropertyChanged(nameof(Customer));
            }
        }

        private String startTime;
        public String StartTime
        {
            get { return startTime; }
            set
            {
                startTime = value;
                RaisePropertyChanged(nameof(StartTime));
            }
        }

        private String timeElapsed;
        public String TimeElapsed
        {
            get { return timeElapsed; }
            set
            {
                timeElapsed = value;
                RaisePropertyChanged(nameof(TimeElapsed));
            }
        }

        private String status;
        public String Status
        {
            get { return status; }
            set
            {
                status = value;
                RaisePropertyChanged(nameof(Status));
            }
        }

        private String balance;
        public String Balance
        {
            get { return balance; }
            set
            {
                balance = value;
                RaisePropertyChanged(nameof(Balance));
            }
        }

        private string userType;
        public string UserType
        {
            get { return userType; }
            set
            {
                userType = value;
                RaisePropertyChanged(nameof(UserType));
            }
        }

        private string chargingType;
        public string ChargingType
        {
            get { return chargingType; }
            set
            {
                chargingType = value;
                RaisePropertyChanged(nameof(ChargingType));
            }
        }

        //Sample Accounts
        public static List<AccountModel> SampleAccounts()
        {
            List<AccountModel> sampleAccounts = new List<AccountModel>();

            sampleAccounts.Add(new Model.AccountModel
            {
                StartTime = "08:00 AM",
                Customer = "Mark Lorenz Ong",
                IdNumber = "06002017",
                TimeElapsed = "04:00 PM",
                Status = "Available",
                Balance = "1000"
            });

            sampleAccounts.Add(new Model.AccountModel
            {
                StartTime = "09:00 AM",
                Customer = "Arthur Dychiching",
                IdNumber = "07002017",
                TimeElapsed = "05:00 PM",
                Status = "Available",
                Balance = "1000"
            });

            sampleAccounts.Add(new Model.AccountModel
            {
                StartTime = "10:00 AM",
                Customer = "Roland Christian Chua",
                IdNumber = "08002017",
                TimeElapsed = "06:00 PM",
                Status = "Available",
                Balance = "1000"
            });

            sampleAccounts.Add(new Model.AccountModel
            {
                StartTime = "07:00 AM",
                Customer = "Kriza Sy",
                IdNumber = "01002017",
                TimeElapsed = "03:00 PM",
                Status = "Available",
                Balance = "1000"
            });

            sampleAccounts.Add(new Model.AccountModel
            {
                StartTime = "11:00 AM",
                Customer = "Princess Carabeo",
                IdNumber = "09002017",
                TimeElapsed = "07:00 PM",
                Status = "Available",
                Balance = "1000"
            });

            sampleAccounts.Add(new Model.AccountModel
            {
                StartTime = "11:00 AM",
                Customer = "Zsannen Mariano",
                IdNumber = "04002017",
                TimeElapsed = "07:00 PM",
                Status = "Available",
                Balance = "1000"
            });

            return sampleAccounts;
        }
    }
}
