﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.Model
{
    public sealed class EShopManagerModel : BaseModel
    {
        private static readonly EShopManagerModel instance = new EShopManagerModel();

        private EShopManagerModel() { }

        public static EShopManagerModel Instance
        {
            get
            {
                return instance;
            }
        }

        private decimal totalFee;

        public decimal TotalFee
        {
            get { return totalFee; }
            set
            {
                totalFee = value;
                ChangeFee = TenderedMoney - TotalFee;

                if (TotalFee > 0)
                {
                    IsSubmitButtonEnabled = true;
                }
                else
                {
                    IsSubmitButtonEnabled = false;
                }

                RaisePropertyChanged(nameof(TotalFee));
            }
        }

        private decimal tenderedMoney;

        public decimal TenderedMoney
        {
            get { return tenderedMoney; }
            set
            {
                tenderedMoney = value;
                ChangeFee = TenderedMoney - TotalFee;
                RaisePropertyChanged(nameof(TenderedMoney));
            }
        }

        private decimal changeFee;

        public decimal ChangeFee
        {
            get { return changeFee; }
            set
            {
                changeFee = value;

                if (TotalFee > 0)
                {
                    IsSubmitButtonEnabled = true;
                }
                else
                {
                    IsSubmitButtonEnabled = false;
                }

                RaisePropertyChanged(nameof(ChangeFee));
            }
        }

        private bool isSubmitButtonEnabled;

        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

    }
}
