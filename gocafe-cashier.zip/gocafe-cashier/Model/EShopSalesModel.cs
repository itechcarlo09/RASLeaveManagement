﻿using gocafe_cashier.Model;
using System.ComponentModel;

namespace gocafe_cashier.Model.FnBModels
{
    public class EShopSalesModel : BaseModel, IDataErrorInfo
    {
        private EShopManagerModel eShopManagerModel = EShopManagerModel.Instance;

        public string ProductName { get; set; }

        public string RetailID { get; set; }

        private int quantity;
        public int Quantity
        {
            get { return quantity; }
            set
            {
                eShopManagerModel.TotalFee -= Price * quantity;
                eShopManagerModel.TotalFee += value * Price;
                quantity = value;
                RaisePropertyChanged(nameof(Total));
            }
        }

        private decimal price;
        public decimal Price
        {
            get
            {
                return price;
            }
            set
            {
                eShopManagerModel.TotalFee -= price * Quantity;
                eShopManagerModel.TotalFee += value * Quantity;
                price = value;
                RaisePropertyChanged(nameof(Total));
            }
        }

        private int retailPrice;
        public int RetailPrice
        {
            get { return retailPrice; }
            set
            {
                retailPrice = value;
                Price = RetailPrice / 100;
            }
        }

        public decimal Total
        {
            get
            {
                return Price * Quantity;
            }

            set { }
        }

        public string Error { get; set; }

        public string this[string name]
        {
            get
            {
                string result = string.Empty;
                if (name == "Quantity")
                {
                    if (Quantity < 1) result = "Invalid Quantity";
                }

                if (result != string.Empty)
                    eShopManagerModel.IsSubmitButtonEnabled = false;

                return result;
            }
        }
    }
}

