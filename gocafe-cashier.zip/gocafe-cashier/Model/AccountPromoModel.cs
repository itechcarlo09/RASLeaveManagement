﻿namespace gocafe_cashier.Model
{
    public class AccountPromoModel : BaseModel
    {
        public AccountPromoModel()
        {
            IsSelected = false;
        }

        private string packageCode;
        public string PackageCode
        {
            get { return packageCode; }
            set
            {
                packageCode = value;
                RaisePropertyChanged(nameof(PackageCode));
            }
        }

        private string packageID;
        public string PackageID
        {
            get { return packageID; }
            set
            {
                packageID = value;
                RaisePropertyChanged(nameof(PackageID));
            }
        }

        private string packageDescription;
        public string PackageDescription
        {
            get { return packageDescription; }
            set
            {
                packageDescription = value;
                RaisePropertyChanged(nameof(PackageDescription));
            }
        }

        private string startTime;
        public string StartTime
        {
            get { return startTime; }
            set
            {
                startTime = value;
                RaisePropertyChanged(nameof(StartTime));
            }
        }

        private string endTime;
        public string EndTime
        {
            get { return endTime; }
            set
            {
                endTime = value;
                RaisePropertyChanged(nameof(EndTime));
            }
        }

        private string promoAvailability;
        public string PromoAvailability
        {
            get { return promoAvailability; }
            set
            {
                promoAvailability = value;
                RaisePropertyChanged(nameof(PromoAvailability));
            }
        }

        private string duration;
        public string Duration
        {
            get { return duration; }
            set
            {
                duration = value;
                RaisePropertyChanged(nameof(Duration));
            }
        }

        private decimal amount;
        public decimal Amount
        {
            get { return amount; }
            set
            {
                amount = value;
                RaisePropertyChanged(nameof(Amount));
            }
        }

        private string packageType;
        public string PackageType
        {
            get { return packageType; }
            set
            {
                packageType = value;
                RaisePropertyChanged(nameof(PackageType));
            }
        }

        private bool isSelected;
        public bool IsSelected
        {
            get { return isSelected; }
            set
            {
                isSelected = value;
                RaisePropertyChanged(nameof(IsSelected));
            }
        }
    }
}
