﻿using gocafe_cashier.ViewModelMediator;
using GocafeShared.Model;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace gocafe_cashier.Model.FnBModels
{
    public class FnbManagerModel : BaseModel
    {

        #region Properties

        private ObservableCollection<BranchRetailModel> productList;

        public ObservableCollection<BranchRetailModel> ProductList
        {
            get { return productList; }
            set
            {
                productList = value;
                RaisePropertyChanged(nameof(ProductList));
            }
        }

        private ObservableCollection<BranchRetailModel> filteredProductList;

        public ObservableCollection<BranchRetailModel> FilteredProductList
        {
            get { return filteredProductList; }
            set
            {
                filteredProductList = value;
                RaisePropertyChanged(nameof(FilteredProductList));
            }
        }

        private List<string> categoryList;

        public List<string> CategoryList
        {
            get { return categoryList; }
            set
            {
                categoryList = value;
                RaisePropertyChanged(nameof(CategoryList));
            }
        }

        private string selectedCategory;

        public string SelectedCategory
        {
            get { return selectedCategory; }
            set
            {
                selectedCategory = value;
                RaisePropertyChanged(nameof(SelectedCategory));
                Mediator.Instance.NotifyViewModel(Messages.FoodAndBeverageManagerWindowViewModel, Messages.FilterFoodAndBeverageList, null);
            }
        }


        private string searchText;

        public string SearchText
        {
            get { return searchText; }
            set
            {
                searchText = value;
                RaisePropertyChanged(nameof(SearchText));
                Mediator.Instance.NotifyViewModel(Messages.FoodAndBeverageManagerWindowViewModel, Messages.SearchFoodAndBeverage, null);
            }
        }

        private ItemObservableCollection<SalesRetailModel> orders;

        public ItemObservableCollection<SalesRetailModel> Orders
        {
            get { return orders; }
            set
            {
                orders = value;
                RaisePropertyChanged(nameof(Orders));
            }
        }

        private bool printIsChecked;

        public bool PrintIsChecked
        {
            get { return printIsChecked; }
            set
            {
                printIsChecked = value;
                RaisePropertyChanged(nameof(PrintIsChecked));
            }
        }

        private decimal totalFee;

        public decimal TotalFee
        {
            get { return totalFee; }
            set
            {
                totalFee = value;
                ChangeFee = TenderedMoney - TotalFee;

                if (TotalFee > 0)
                {
                    IsSubmitButtonEnabled = true;
                }
                else
                {
                    IsSubmitButtonEnabled = false;
                }

                RaisePropertyChanged(nameof(TotalFee));
            }
        }

        private decimal tenderedMoney;

        public decimal TenderedMoney
        {
            get { return tenderedMoney; }
            set
            {
                tenderedMoney = value;
                ChangeFee = TenderedMoney - TotalFee;
                RaisePropertyChanged(nameof(TenderedMoney));
            }
        }

        private decimal changeFee;

        public decimal ChangeFee
        {
            get { return changeFee; }
            set
            {
                changeFee = value;

                if (TotalFee > 0)
                {
                    IsSubmitButtonEnabled = true;
                }
                else
                {
                    IsSubmitButtonEnabled = false;
                }

                RaisePropertyChanged(nameof(ChangeFee));
            }
        }

        private bool isSubmitButtonEnabled;

        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }


        #endregion

    }
}
