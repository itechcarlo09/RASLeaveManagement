﻿using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.FnBDataModels;

namespace gocafe_cashier.Model.FnBModels
{
    public class BranchRetailModel : BaseModel
    {
        public RetailModel Retail { get; set; }

        private decimal retailPrice;
        public decimal RetailPrice
        {
            get
            {
                return retailPrice;
            }
            set
            {
                retailPrice = value / 100;
            }
        }

        public string LastUpdate { get; set; }

        public bool IsPreparationRequired { get; set; }

        public string ID { get; set; }

        public int StockQuantity { get; set; }

        public bool IsOutOfStock
        {
            get
            {
                if (StockQuantity > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public string Category { get; set; }

        public string Name { get; set; }
    }
}
