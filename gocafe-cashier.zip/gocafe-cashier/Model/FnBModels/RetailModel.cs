﻿using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.FnBDataModels;

namespace gocafe_cashier.Model.FnBModels
{
    public class RetailModel
    {
        public ProductDataModel CompositeProduct { get; set; }

        public ProductDataModel Product { get; set; }

        public string SKU { get; set; }

        public string ID { get; set; }

        public ProductDataModel RetailProduct
        {
            get
            {
                if (Product != null) return Product;
                else return CompositeProduct;
            }
        }
    }
}