﻿using System.ComponentModel;

namespace gocafe_cashier.Model.FnBModels
{
    public class SalesRetailModel: BaseModel, IDataErrorInfo
    {
        public string ProductName { get; set; }
        public string RetailID { get; set; }
        public bool IsRequirePreparation { get; set; }

        private int quantity;
        public int Quantity
        {
            get { return quantity; }
            set
            {
                quantity = value;
                RaisePropertyChanged(nameof(Quantity));
                RaisePropertyChanged(nameof(Total));
            }
        }

        private decimal price;
        public decimal Price
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
                RaisePropertyChanged(nameof(Price));
                RaisePropertyChanged(nameof(Total));
            }
        }

        private int retailPrice;
        public int RetailPrice
        {
            get { return retailPrice; }
            set
            {
                retailPrice = value;
                Price = RetailPrice / 100;
            }
        }

        public decimal Total
        {
            get
            {
                return Price * Quantity;
            }
        }

        public string Error { get; set; }

        public string this[string name]
        {
            get
            {
                string result = string.Empty;
                if (name == "Quantity")
                {
                    if (Quantity < 1) result = "Invalid Quantity";
                }

                return result;
            }
        }
    }
}

