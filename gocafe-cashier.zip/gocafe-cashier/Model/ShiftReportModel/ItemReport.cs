﻿using System.Collections.Generic;

namespace gocafe_cashier.Model.ShiftReportModel
{
    public class ItemReport
    {
        public string ItemName { get; set; }
        public string Stock { get; set; }
        public List<CashierDetails> CashierSalesDetails { get; set; }

        public ItemReport()
        {
            CashierSalesDetails = new List<CashierDetails>();
        }
    }

    public class CashierDetails
    {
        public string CashierName { get; set; }
        public CashierSumReport CashierSumReports { get; set; }

        public CashierDetails()
        {
            CashierSumReports = new CashierSumReport();
        }
    }

    public class CashierSumReport
    {
        public int Cash { get; set; }
        public int OKTOPay { get; set; }
        public int Sales { get; set; }
        public int CashQuantity { get; set; }
        public int OktoPayQuantity { get; set; }
        public int SalesQuantity { get; set; }
    }
}
