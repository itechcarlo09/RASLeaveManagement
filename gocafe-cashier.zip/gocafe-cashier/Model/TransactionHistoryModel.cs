﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.Model
{
    public class TransactionHistoryModel: BaseModel
    {

        public TransactionHistoryModel()
        {
            Initialize();
        }

        #region Properties

        private string referenceNumber;
        public string ReferenceNumber
        {
            get { return referenceNumber; }
            set
            {
                referenceNumber = value;
                RaisePropertyChanged(nameof(ReferenceNumber));
            }
        }


        private string date;
        public string Date
        {
            get { return date; }
            set
            {
                date = value;
                RaisePropertyChanged(nameof(Date));
            }
        }

        private string time;
        public string Time
        {
            get { return time; }
            set
            {
                time = value;
                RaisePropertyChanged(nameof(Time));
            }
        }

        private string activity;
        public string Activity
        {
            get { return activity; }
            set
            {
                activity = value;
                RaisePropertyChanged(nameof(Activity));
            }
        }

        private string customerName;
        public string CustomerName
        {
            get { return customerName; }
            set
            {
                customerName = value;
                RaisePropertyChanged(nameof(CustomerName));
            }
        }

        private string amount;
        public string Amount
        {
            get { return amount; }
            set
            {
                amount = value;
                RaisePropertyChanged(nameof(Amount));
            }
        }

        private string remarks;
        public string Remarks
        {
            get { return remarks; }
            set
            {
                remarks = value;
                RaisePropertyChanged(nameof(Remarks));
            }
        }

        private bool isRemarksNull;
        public bool IsRemarksNull
        {
            get { return isRemarksNull; }
            set
            {
                isRemarksNull = value;
                RaisePropertyChanged(nameof(IsRemarksNull));
            }
        }

        private string orderNumber;
        public string OrderNumber
        {
            get { return orderNumber; }
            set
            {
                orderNumber = value;
                RaisePropertyChanged(nameof(OrderNumber));
            }
        }

        private string availedPromoCode;
        public string AvailedPromoCode
        {
            get { return availedPromoCode; }
            set
            {
                availedPromoCode = value;
                RaisePropertyChanged(nameof(AvailedPromoCode));
            }
        }

        private string cashierName;
        public string CashierName
        {
            get { return cashierName; }
            set
            {
                cashierName = value;
                RaisePropertyChanged(nameof(CashierName));
            }
        }

        private string memberType;
        public string MemberType
        {
            get { return memberType; }
            set
            {
                memberType = value;
                RaisePropertyChanged(nameof(MemberType));
            }
        }

        private string voidStatus;
        public string VoidStatus
        {
            get { return voidStatus; }
            set
            {
                voidStatus = value;
                RaisePropertyChanged(nameof(VoidStatus));
            }
        }

        private bool isMoreDetailsShown;
        public bool IsMoreDetailsShown
        {
            get { return isMoreDetailsShown; }
            set
            {
                isMoreDetailsShown = value;
                RaisePropertyChanged(nameof(IsMoreDetailsShown));
            }
        }

        private bool isTransactionVoidable;
        public bool IsTransactionVoidable
        {
            get { return isTransactionVoidable; }
            set
            {
                isTransactionVoidable = value;
                RaisePropertyChanged(nameof(IsTransactionVoidable));
            }
        }


        #endregion

        #region Private Methods

        private void Initialize()
        {
            Date = "--";
            Time = "--";
            Activity = "--";
            CustomerName = "--";
            Remarks = "--";
            OrderNumber = "--";
            CashierName = "--";
            AvailedPromoCode = "N/A";
            Amount = "--";
            ReferenceNumber = "--";
            VoidStatus = "--";
        }

        #endregion
    }
}
