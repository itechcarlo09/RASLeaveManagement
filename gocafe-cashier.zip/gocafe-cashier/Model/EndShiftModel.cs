﻿using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.Inventory;
using System.Collections.Generic;

namespace gocafe_cashier.Model
{
    public class EndShiftModel: BaseModel
    {
        #region Properties

        private string endTime;
        public string EndTime
        {
            get { return endTime; }
            set
            {
                endTime = value;
                RaisePropertyChanged(nameof(EndTime));
            }
        }

        private string startTime;
        public string StartTime
        {
            get { return startTime; }
            set
            {
                startTime = value;
                RaisePropertyChanged(nameof(StartTime));
            }
        }

        private string totalSales;
        public string TotalSales
        {
            get { return totalSales; }
            set
            {
                totalSales = value;
                RaisePropertyChanged(nameof(TotalSales));
            }
        }

        private List<ShiftModel> shifts;
        public List<ShiftModel> Shifts
        {
            get { return shifts; }
            set
            {
                shifts = value;
                RaisePropertyChanged(nameof(Shifts));
            }
        }

        private List<ItemDataModel> inventoryItems;
        public List<ItemDataModel> InventoryItems
        {
            get { return inventoryItems; }
            set
            {
                inventoryItems = value;
                RaisePropertyChanged(nameof(InventoryItems));
            }
        }

        #endregion
    }
}
