﻿using gocafe_cashier.ViewModelMediator;

namespace gocafe_cashier.Model
{
    public class CouponMemberTypeModel : BaseModel
    {

        public CouponMemberTypeModel()
        {
        }

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = $" {value}";
                RaisePropertyChanged(nameof(Name));
            }
        }

        private int id;
        public int ID
        {
            get { return id; }
            set
            {
                id = value;
                RaisePropertyChanged(nameof(ID));
            }
        }

        private bool isChecked;
        public bool IsChecked
        {
            get { return isChecked; }
            set
            {
                isChecked = value;
                CheckValidation();
                RaisePropertyChanged(nameof(IsChecked));
            }
        }

        private bool validated;
        public bool Validated
        {
            get { return validated; }
            set
            {
                validated = value;
                RaisePropertyChanged(nameof(Validated));
            }
        }

        private void CheckValidation()
        {
            if(Validated)
            {
                Mediator.Instance.NotifyViewModel(Messages.CouponManagerViewModel, Messages.SelectMemberType, Name);
            }
            Validated = true;
        }

    }
}
