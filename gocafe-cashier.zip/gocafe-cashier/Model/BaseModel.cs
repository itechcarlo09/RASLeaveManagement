﻿using gocafe_cashier.DataModel;
using gocafe_cashier.View.PopUp;
using gocafe_cashier.ViewModelMediator;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Windows;
using System;
using System.Drawing;
using System.Drawing.Printing;
using gocafe_cashier.MessageResource;
using gocafe_cashier.Cache;

namespace gocafe_cashier.Model
{
    public class BaseModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public BaseModel()
        {
            CurrencySymbol = DataCacheContext.CurrencySymbol;
            PriceCurrencySymbol = DataCacheContext.PriceCurrencySymbol;
        }

        public void RaisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
            handler(this, new PropertyChangedEventArgs(propertyName));
        }

        public virtual void SendData(string message, object data)
        {

        }

        protected bool ShowConfirmationWindow(string warningMessage, string mode, Window owner=null)
        {
            bool? windowDialogResult = false;

            return Application.Current.Dispatcher.Invoke(() =>
            {
                try
                {
                    GenericDialogWindow genericWindow = new GenericDialogWindow();

                    Mediator.Instance.NotifyViewModel(Messages.ConfirmationWindowViewModel, Messages.ConfirmationWindow, genericWindow);
                    Mediator.Instance.NotifyViewModel(Messages.ConfirmationWindowViewModel, mode, warningMessage);

                    Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);

                    try
                    {
                        if (owner == null)
                        {
                            genericWindow.Owner = App.Current.MainWindow;
                        }
                        else
                        {
                            genericWindow.Owner = owner;
                        }
                    }
                    catch
                    {
                        // do nothing for now. this should be ok since owners were created for aesthetic purposes only
                    }
                    windowDialogResult = genericWindow.ShowDialog();
                    Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);
                }
                catch(Exception ex)
                {

                }

                return windowDialogResult.Value;
            });
        }

        protected bool ShowPasswordConfirmation(string username, Window owner = null)
        {
            PasswordConfirmationPopUpWindow passworConfirmation = new PasswordConfirmationPopUpWindow();

            try
            {
                if (owner == null)
                {
                    passworConfirmation.Owner = App.Current.MainWindow;
                }
                else
                {
                    passworConfirmation.Owner = owner;
                }
            }
            catch
            {
                // do nothing for now. this should be ok since owners were created for aesthetic purposes only
            }
            Mediator.Instance.NotifyViewModel(Messages.PasswordConfirmationWindowViewModel, Messages.PasswordConfirmationWindow, passworConfirmation);
            Mediator.Instance.NotifyViewModel(Messages.PasswordConfirmationWindowViewModel, Messages.Username, username);

            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, true);
            var windowDialogResult = passworConfirmation.ShowDialog();
            Mediator.Instance.NotifyViewModel(Messages.CashierViewModel, Messages.ShowBlurBackground, false);

            return windowDialogResult.Value;
        }

        protected ErrorDataModel ConvertErrorDataModel(string response)
        {
            ErrorDataModel errorModel = JsonConvert.DeserializeObject<ErrorDataModel>(response);
            return errorModel;
        }

        private bool isCardDetected;
        public bool IsCardDetected
        {
            get { return isCardDetected; }
            set
            {
                isCardDetected = value;
                RaisePropertyChanged(nameof(IsCardDetected));
            }
        }

        private bool isProcessing;
        public bool IsProcessing
        {
            get { return isProcessing; }
            set
            {
                isProcessing = value;
                RaisePropertyChanged(nameof(IsProcessing));
            }
        }

        private string processingText;

        public string ProcessingText
        {
            get { return processingText; }
            set
            {
                processingText = value;
                RaisePropertyChanged(nameof(ProcessingText));
            }
        }

        private bool isWindowOpen;

        public bool IsWindowOpen
        {
            get { return isWindowOpen; }
            set
            {
                isWindowOpen = value;
                RaisePropertyChanged(nameof(IsWindowOpen));
            }
        }

        private bool isCriticalRequestBeingProcessed;

        public bool IsCriticalRequestBeingProcessed
        {
            get { return isCriticalRequestBeingProcessed; }
            set
            {
                isCriticalRequestBeingProcessed = value;
                RaisePropertyChanged(nameof(IsCriticalRequestBeingProcessed));
            }
        }

        private string currencySymbol;
        public string CurrencySymbol
        {
            get { return currencySymbol; }
            set
            {
                currencySymbol = value;
                RaisePropertyChanged(nameof(CurrencySymbol));
            }
        }

        private string priceCurrencySymbol;
        public string PriceCurrencySymbol
        {
            get { return priceCurrencySymbol; }
            set
            {
                priceCurrencySymbol = value;
                RaisePropertyChanged(nameof(PriceCurrencySymbol));
            }
        }

        public int PrintExcessCharacterOnNewLine(PrintPageEventArgs e, string labelName, string displayName, bool isCenterAlign, int charLimit, int xAxisFirstLine, int xAxisSecondLine, int yAxis, int yMargin, int yLine, System.Drawing.FontStyle fontStyle)
        {
            if (displayName.Length > charLimit && displayName.Substring(charLimit) != "")
            {
                string cropNameFirstLine;
                string cropNameSecondLine;
                for (int x = charLimit; x >= 0; x--)
                {
                    if (displayName.Substring(x, 1) == " ")
                    {
                        cropNameFirstLine = displayName.Substring(0, x);
                        cropNameSecondLine = displayName.Substring(x);
                        if (isCenterAlign)
                        {
                            e.Graphics.DrawString($"{cropNameFirstLine}", new Font("Arial Narrow", 9F, fontStyle), new SolidBrush(Color.Black), 85 - Convert.ToInt32(cropNameFirstLine.Length * 2.273), yAxis += (yMargin * yLine));
                            e.Graphics.DrawString($"{cropNameSecondLine}", new Font("Arial Narrow", 9F, fontStyle), new SolidBrush(Color.Black), 85 - Convert.ToInt32(cropNameSecondLine.Length * 2.273), yAxis += yMargin);
                        }
                        else
                        {
                            e.Graphics.DrawString($"{labelName} {cropNameFirstLine}", new Font("Arial Narrow", 9F, fontStyle), new SolidBrush(Color.Black), xAxisFirstLine, yAxis += (yMargin * yLine));
                            e.Graphics.DrawString($"{cropNameSecondLine}", new Font("Arial Narrow", 9F, fontStyle), new SolidBrush(Color.Black), xAxisSecondLine, yAxis += yMargin);
                        }
                        break;
                    }
                }
            }
            else if (displayName.Length <= charLimit)
            {
                if (isCenterAlign)
                {
                    e.Graphics.DrawString($"{displayName}", new Font("Arial Narrow", 9F, fontStyle), new SolidBrush(Color.Black), 85 - Convert.ToInt32(displayName.Length * 2.273), yAxis += (yMargin * yLine));
                }
                else
                {
                    e.Graphics.DrawString($"{PrinterMessageResource.Name} {displayName}", new Font("Arial Narrow", 9F, fontStyle), new SolidBrush(Color.Black), xAxisFirstLine, yAxis += (yMargin * yLine));
                }
            }
            return yAxis;
        }


    }
}
