﻿using gocafe_cashier.DataModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;

namespace gocafe_cashier.Model
{
    public class CashierRightControlModel : BaseModel
    {
        private List<AccountModel> sampleAccounts = new List<AccountModel>();

        public CashierRightControlModel()
        {
            Initialize();
        }

        #region EventHandlers

        private void Initialize()
        {
            SelectedWorkStations = new List<WorkstationModel>();

            IsRegularWorkStationListEmpty = false;
            RegularPanelWidth = 1525;
            RegularPanelHeight = 290;
            RegularSortMode = "ALL";
            RegularWrapPanelHeight = 290;
            RegularWorkStationList = new ObservableCollection<WorkstationModel>();

            IsGoldWorkStationListEmpty = false;
            GoldPanelWidth = 1525;
            GoldPanelHeight = 150;
            GoldSortMode = "ALL";
            GoldWrapPanelHeight = 150;
            GoldWorkStationList = new ObservableCollection<WorkstationModel>();

            IsVIPWorkStationListEmpty = false;
            VIPPanelWidth = 1525;
            VIPPanelHeight = 260;
            VIPSortMode = "ALL";
            VIPWrapPanelHeight = 260;
            VIPWorkStationList = new ObservableCollection<WorkstationModel>();
            AllWorkStationList = new ObservableCollection<WorkstationModel>();

            StationTypeList = new List<StationTypeDataModel>();

            IsOrderByArea = false;
            IsOrderByStatus = false;
            IsOrderByUserType = false;
            IsOrderByName = false;

            sampleAccounts = AccountModel.SampleAccounts();
            TransactionLogsList = new ObservableCollection<TransactionModel>();
            SelectedTransactionModel = new TransactionModel();
            //LoadSampleRegularAccounts(100);
            //LoadSampleGoldAccounts(25);
            //LoadSampleVIPAccounts(10);
        }

        public void LoadStationInfo(List<StationDataModel> stationList)
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                RegularWorkStationList = new ObservableCollection<WorkstationModel>();
                VIPWorkStationList = new ObservableCollection<WorkstationModel>();
                GoldWorkStationList = new ObservableCollection<WorkstationModel>();

                // Hide or collapse the loading indicator at station panels
                IsShownLoading = false;

                foreach (StationDataModel station in stationList)
                {
                    WorkstationModel workStation = new WorkstationModel();
                    workStation.StationModel = station;
                    workStation.AccountModel = new AccountModel();

                    workStation.StationModel.PcNumber = GetNumberFromInt(station.Name);

                    if (station.StationType.Name == "Regular")
                    {
                        RegularWorkStationList.Add(workStation);
                    }
                    else if (station.StationType.Name == "Gold")
                    {
                        GoldWorkStationList.Add(workStation);
                    }
                    else if (station.StationType.Name == "VIP")
                    {
                        VIPWorkStationList.Add(workStation);
                    }
                }
                
                if (RegularWorkStationList.Count > 0)
                {
                    RegularWorkStationList = new ObservableCollection<WorkstationModel>(RegularWorkStationList.OrderByDescending(x => x.StationModel.PcNumber));
                    RegularWorkStationList = new ObservableCollection<WorkstationModel>(RegularWorkStationList.Reverse());
                    RegularWorkStationList.ToList().ForEach(x => x.ShowInUIBy("ALL"));
                    IsRegularPCCountGreaterThanZero = true;
                }
                else
                {
                    IsRegularPCCountGreaterThanZero = false;
                }

                if (GoldWorkStationList.Count > 0)
                {
                    GoldWorkStationList = new ObservableCollection<WorkstationModel>(GoldWorkStationList.OrderByDescending(x => x.StationModel.PcNumber));
                    GoldWorkStationList = new ObservableCollection<WorkstationModel>(GoldWorkStationList.Reverse());
                    GoldWorkStationList.ToList().ForEach(x => x.ShowInUIBy("ALL"));
                    IsGoldPCCountGreaterThanZero = true;
                }
                else
                {
                    IsGoldPCCountGreaterThanZero = false;
                }

                if (VIPWorkStationList.Count > 0)
                {
                    VIPWorkStationList = new ObservableCollection<WorkstationModel>(VIPWorkStationList.OrderByDescending(x => x.StationModel.PcNumber));
                    VIPWorkStationList = new ObservableCollection<WorkstationModel>(VIPWorkStationList.Reverse());
                    VIPWorkStationList.ToList().ForEach(x => x.ShowInUIBy("ALL"));
                    IsVIPPCCountGreaterThanZero = true;
                }
                else
                {
                    IsVIPPCCountGreaterThanZero = false;
                }
                LoadAllWorkStation();
            });
        }

        private int GetNumberFromInt(string pcName)
        {
            var regex = new Regex("(\\d+)");

            // run the regex on both strings
            var xRegexResult = regex.Match(pcName);

            // check if they are both numbers
            if (xRegexResult.Success)
            {
                return int.Parse(xRegexResult.Groups[1].Value);
            }
            else
            {
                return -1;
            }
        }

        private void CalculatePcPanelWidth()
        {
            if (RegularWorkStationList.Count <= (11 * (int)Math.Floor((decimal)RegularWrapPanelHeight / 70)))
            {
                RegularPanelWidth = 1525;
            }
            else
            {
                RegularPanelWidth = ((int)Math.Ceiling((decimal)(RegularWorkStationList.Count) / (int)Math.Floor((decimal)RegularWrapPanelHeight / 70)) * 130) + 10;
            }

            if (GoldWorkStationList.Count <= (11 * (int)Math.Floor((decimal)GoldWrapPanelHeight / 70)))
            {
                GoldPanelWidth = 1525;
            }
            else
            {
                GoldPanelWidth = ((int)Math.Ceiling((decimal)(GoldWorkStationList.Count) / (int)Math.Floor((decimal)GoldWrapPanelHeight / 70)) * 130) + 10;
            }

            if (VIPWorkStationList.Count <= (11 * (int)Math.Floor((decimal)VIPWrapPanelHeight / 70)))
            {
                VIPPanelWidth = 1525;
            }
            else
            {
                VIPPanelWidth = ((int)Math.Ceiling((decimal)(VIPWorkStationList.Count) / (int)Math.Floor((decimal)VIPWrapPanelHeight / 70)) * 130) + 10;
            }
        }

        private void CalculatePcPanelHeight()
        {
            if (RegularWorkStationList.Count > 0)
            {
                RegularPanelHeight = 330;
            }
            else
            {
                RegularPanelHeight = 0;
            }

            if (GoldWorkStationList.Count > 0)
            {
                GoldPanelHeight = 190;
            }
            else
            {
                GoldPanelHeight = 0;
            }

            if (VIPWorkStationList.Count > 0)
            {
                VIPPanelHeight = 190;
            }
            else
            {
                VIPPanelHeight = 0;
            }

            if (RegularPanelHeight == 0)
            {
                if (GoldPanelHeight != 0 && VIPPanelHeight != 0)
                {
                    GoldPanelHeight += 140;
                    VIPPanelHeight += 140;
                }
                else
                {
                    if (GoldPanelHeight != 0)
                    {
                        GoldPanelHeight += 280;
                    }
                    else if (VIPPanelHeight != 0)
                    {
                        VIPPanelHeight += 280;
                    }
                }
            }

            if (GoldPanelHeight == 0)
            {
                if (RegularPanelHeight != 0 && VIPPanelHeight != 0)
                {
                    RegularPanelHeight += 70;
                    VIPPanelHeight += 70;
                }
                else
                {
                    if (RegularPanelHeight != 0)
                    {
                        RegularPanelHeight += 140;
                    }
                    else if (VIPPanelHeight != 0)
                    {
                        VIPPanelHeight += 140;
                    }
                }
            }

            if (VIPPanelHeight == 0)
            {
                if (RegularPanelHeight != 0 && GoldPanelHeight != 0)
                {
                    RegularPanelHeight += 70;
                    GoldPanelHeight += 70;
                }
                else
                {
                    if (RegularPanelHeight != 0)
                    {
                        RegularPanelHeight += 140;
                    }
                    else if (GoldPanelHeight != 0)
                    {
                        GoldPanelHeight += 140;
                    }
                }
            }

            if (VIPPanelHeight == 0 && GoldPanelHeight == 0)
            {
                RegularPanelHeight += 70;
            }

            RegularWrapPanelHeight = RegularPanelHeight - 30;
            VIPWrapPanelHeight = VIPPanelHeight - 30;
            GoldWrapPanelHeight = GoldPanelHeight - 30;
        }

        #region LoadSampleAccounts
        //private void LoadSampleRegularAccounts(int pcCount)
        //{
        //    for (int x = 1; x <= pcCount; x++)
        //    {
        //        RegularWorkStationList.Add(new Model.WorkstationModel
        //        {
        //            PcStatus = "Offline",
        //            PcNumber = (x < 10) ? "PC 0" + x : "PC " + x,
        //            BackgroundImage = "#625E2B",
        //            PcType = Model.WorkstationModel.PcOption.Regular.ToString(),
        //            AccountModel = sampleAccounts.OrderBy(y => Guid.NewGuid()).FirstOrDefault()
        //        });
        //    }
        //}

        //private void LoadSampleGoldAccounts(int pcCount)
        //{
        //    for (int x = 1; x <= pcCount; x++)
        //    {
        //        GoldWorkStationList.Add(new Model.WorkstationModel
        //        {
        //            PcStatus = "Offline",
        //            PcNumber = (x < 10) ? "PC 0" + x : "PC " + x,
        //            BackgroundImage = "#625E2B",
        //            PcType = Model.WorkstationModel.PcOption.Gold.ToString(),
        //            AccountModel = sampleAccounts.OrderBy(y => Guid.NewGuid()).FirstOrDefault()
        //        });
        //    }
        //}

        //private void LoadSampleVIPAccounts(int pcCount)
        //{
        //    for (int x = 1; x <= pcCount; x++)
        //    {
        //        VIPWorkStationList.Add(new Model.WorkstationModel
        //        {
        //            PcStatus = "Offline",
        //            PcNumber = (x < 10) ? "PC 0" + x : "PC " + x,
        //            BackgroundImage = "#625E2B",
        //            PcType = Model.WorkstationModel.PcOption.VIP.ToString(),
        //            AccountModel = sampleAccounts.OrderBy(y => Guid.NewGuid()).FirstOrDefault()
        //        });
        //    }
        //}
        #endregion

        private void LoadAllWorkStation()
        {
            AllWorkStationList = new ObservableCollection<WorkstationModel>();
            RegularWorkStationList.ToList().ForEach(x => AllWorkStationList.Add(x));
            GoldWorkStationList.ToList().ForEach(x => AllWorkStationList.Add(x));
            VIPWorkStationList.ToList().ForEach(x => AllWorkStationList.Add(x));
        }

        public void SortAllWorkStationBy(string name)
        {
            switch (name)
            {
                case "PCSTATUS":
                    SortAllWorkStationByStatus();
                    break;
                case "PCUSERTYPE":

                    break;
                case "PCAREA":
                    SortAllWorkStationByArea();
                    break;
                case "PCNAME":
                    SortAllWorkStationByPcName();
                    break;
                default:

                    break;
            }
        }

        private void SortAllWorkStationByPcName()
        {
            if (IsOrderByName)
            {
                AllWorkStationList = new ObservableCollection<WorkstationModel>(AllWorkStationList.OrderBy(x => x.StationModel.Name));
                IsOrderByName = false;
            }
            else
            {
                AllWorkStationList = new ObservableCollection<WorkstationModel>(AllWorkStationList.OrderByDescending(x => x.StationModel.Name));
                IsOrderByName = true;
            }
        }

        private void SortAllWorkStationByStatus()
        {
            if (IsOrderByStatus)
            {
                AllWorkStationList = new ObservableCollection<WorkstationModel>(AllWorkStationList.OrderBy(x => x.PcStatus));
                IsOrderByStatus = false;
            }
            else
            {
                AllWorkStationList = new ObservableCollection<WorkstationModel>(AllWorkStationList.OrderByDescending(x => x.PcStatus));
                IsOrderByStatus = true;
            }
        }

        private void SortAllWorkStationByArea()
        {
            if (IsOrderByArea)
            {
                AllWorkStationList = new ObservableCollection<WorkstationModel>(AllWorkStationList.OrderBy(x => x.StationModel.StationType.Name));
                IsOrderByArea = false;
            }
            else
            {
                AllWorkStationList = new ObservableCollection<WorkstationModel>(AllWorkStationList.OrderByDescending(x => x.StationModel.StationType.Name));
                IsOrderByArea = true;
            }
        }

        private void SortAllWorkingStationByUserType()
        {
            if (IsOrderByUserType)
            {
                IsOrderByUserType = false;
            }
            else
            {
                IsOrderByUserType = true;
            }
        }

        public List<WorkstationModel> GetAvailableWorkStation()
        {
            if (AllWorkStationList.Count > 0)
            {
                List<WorkstationModel> availableWorkStation = new List<WorkstationModel>();
                foreach (WorkstationModel workStation in AllWorkStationList)
                {
                    if (!workStation.IsOccupied && !workStation.IsOff)
                    {
                        availableWorkStation.Add(workStation);
                    }
                }

                return availableWorkStation;
            }

            return new List<WorkstationModel>();
        }

        #endregion

        #region Properties

        private bool isShownLoading;
        public bool IsShownLoading
        {
            get
            {
                return isShownLoading;
            }
            set
            {
                isShownLoading = value;
                RaisePropertyChanged(nameof(IsShownLoading));
            }
        }

        private bool isLogoutPCButtonShown;
        public bool IsLogoutPCButtonShown
        {
            get
            {
                return isLogoutPCButtonShown;
            }
            set
            {
                isLogoutPCButtonShown = value;
                RaisePropertyChanged(nameof(IsLogoutPCButtonShown));
            }
        }

        private bool isTopUpPCButtonShown;
        public bool IsTopUpPCButtonShown
        {
            get
            {
                return isTopUpPCButtonShown;
            }
            set
            {
                isTopUpPCButtonShown = value;
                RaisePropertyChanged(nameof(IsTopUpPCButtonShown));
            }
        }

        private bool isPowerOnPCButtonShown;
        public bool IsPowerOnPCButtonShown
        {
            get { return isPowerOnPCButtonShown; }
            set
            {
                isPowerOnPCButtonShown = value;
                RaisePropertyChanged(nameof(IsPowerOnPCButtonShown));
            }
        }

        private bool isTransferPcButtonShown;
        public bool IsTransferPcButtonShown
        {
            get { return isTransferPcButtonShown; }
            set
            {
                isTransferPcButtonShown = value;
                RaisePropertyChanged(nameof(IsTransferPcButtonShown));
            }
        }

        private bool isLoginGuestButtonShown;
        public bool IsLoginGuestButtonShown
        {
            get
            {
                return isLoginGuestButtonShown;
            }
            set
            {
                isLoginGuestButtonShown = value;
                RaisePropertyChanged(nameof(IsLoginGuestButtonShown));
            }
        }

        private bool isEndPromoButtonShown;
        public bool IsEndPromoButtonShown
        {
            get { return isEndPromoButtonShown; }
            set
            {
                isEndPromoButtonShown = value;
                RaisePropertyChanged(nameof(IsEndPromoButtonShown));
            }
        }

        private bool isTransactionShownLoading;
        public bool IsTransactionShownLoading
        {
            get
            {
                return isTransactionShownLoading;
            }
            set
            {
                isTransactionShownLoading = value;
                RaisePropertyChanged(nameof(IsTransactionShownLoading));
            }
        }

        private bool isWorkStationShow;
        public bool IsWorkStationShow
        {
            get { return isWorkStationShow; }
            set
            {
                isWorkStationShow = value;
                RaisePropertyChanged(nameof(IsWorkStationShow));
            }
        }

        private List<WorkstationModel> selectedWorkStations;
        public List<WorkstationModel> SelectedWorkStations
        {
            get { return selectedWorkStations; }
            set
            {
                selectedWorkStations = value;
                RaisePropertyChanged(nameof(SelectedWorkStations));
            }
        }

        private bool isRegularWorkStationListEmpty;
        public bool IsRegularWorkStationListEmpty
        {
            get { return isRegularWorkStationListEmpty; }
            set
            {
                isRegularWorkStationListEmpty = value;
                RaisePropertyChanged(nameof(IsRegularWorkStationListEmpty));
            }
        }

        private int regularPanelWidth;
        public int RegularPanelWidth
        {
            get { return regularPanelWidth; }
            set
            {
                regularPanelWidth = value;
                RaisePropertyChanged(nameof(RegularPanelWidth));
            }
        }

        private int regularPanelHeight;
        public int RegularPanelHeight
        {
            get { return regularPanelHeight; }
            set
            {
                regularPanelHeight = value;
                RaisePropertyChanged(nameof(RegularPanelHeight));
            }
        }

        private int regularWrapPanelHeight;
        public int RegularWrapPanelHeight
        {
            get { return regularWrapPanelHeight; }
            set
            {
                regularWrapPanelHeight = value;
                RaisePropertyChanged(nameof(RegularWrapPanelHeight));
            }
        }

        private string regularSortMode;
        public string RegularSortMode
        {
            get { return regularSortMode; }
            set
            {
                regularSortMode = value;
                RaisePropertyChanged(nameof(RegularSortMode));
            }
        }

        private ObservableCollection<WorkstationModel> regularWorkStationList;
        public ObservableCollection<WorkstationModel> RegularWorkStationList
        {
            get { return regularWorkStationList; }
            set
            {
                regularWorkStationList = value;
                RaisePropertyChanged(nameof(RegularWorkStationList));
                RaisePropertyChanged(nameof(AvailableRegularPCCount));
            }
        }

        private bool isGoldWorkStationListEmpty;
        public bool IsGoldWorkStationListEmpty
        {
            get { return isGoldWorkStationListEmpty; }
            set
            {
                isGoldWorkStationListEmpty = value;
                RaisePropertyChanged(nameof(IsGoldWorkStationListEmpty));
            }
        }

        private int goldPanelWidth;
        public int GoldPanelWidth
        {
            get { return goldPanelWidth; }
            set
            {
                goldPanelWidth = value;
                RaisePropertyChanged(nameof(GoldPanelWidth));
            }
        }

        private int goldPanelHeight;
        public int GoldPanelHeight
        {
            get { return goldPanelHeight; }
            set
            {
                goldPanelHeight = value;
                RaisePropertyChanged(nameof(GoldPanelHeight));
            }
        }

        private int goldWrapPanelHeight;
        public int GoldWrapPanelHeight
        {
            get { return goldWrapPanelHeight; }
            set
            {
                goldWrapPanelHeight = value;
                RaisePropertyChanged(nameof(GoldWrapPanelHeight));
            }
        }

        private string goldSortMode;
        public string GoldSortMode
        {
            get { return goldSortMode; }
            set
            {
                goldSortMode = value;
                RaisePropertyChanged(nameof(GoldSortMode));
            }
        }

        private ObservableCollection<WorkstationModel> goldWorkStationList;
        public ObservableCollection<WorkstationModel> GoldWorkStationList
        {
            get { return goldWorkStationList; }
            set
            {
                goldWorkStationList = value;
                RaisePropertyChanged(nameof(GoldWorkStationList));
                RaisePropertyChanged(nameof(AvailableGoldPCCount));
            }
        }

        private bool isVIPWorkStationListEmpty;
        public bool IsVIPWorkStationListEmpty
        {
            get { return isVIPWorkStationListEmpty; }
            set
            {
                isVIPWorkStationListEmpty = value;
                RaisePropertyChanged(nameof(IsVIPWorkStationListEmpty));
            }
        }

        private int vipPanelWidth;
        public int VIPPanelWidth
        {
            get { return vipPanelWidth; }
            set
            {
                vipPanelWidth = value;
                RaisePropertyChanged(nameof(VIPPanelWidth));
            }
        }

        private int vipPanelHeight;
        public int VIPPanelHeight
        {
            get { return vipPanelHeight; }
            set
            {
                vipPanelHeight = value;
                RaisePropertyChanged(nameof(VIPPanelHeight));
            }
        }

        private int vipWrapPanelHeight;
        public int VIPWrapPanelHeight
        {
            get { return vipWrapPanelHeight; }
            set
            {
                vipWrapPanelHeight = value;
                RaisePropertyChanged(nameof(VIPWrapPanelHeight));
            }
        }

        private string vipSortMode;
        public string VIPSortMode
        {
            get { return vipSortMode; }
            set
            {
                vipSortMode = value;
                RaisePropertyChanged(nameof(VIPSortMode));
            }
        }

        private ObservableCollection<WorkstationModel> vipWorkStationList;
        public ObservableCollection<WorkstationModel> VIPWorkStationList
        {
            get { return vipWorkStationList; }
            set
            {
                vipWorkStationList = value;
                RaisePropertyChanged(nameof(VIPWorkStationList));
                RaisePropertyChanged(nameof(AvailableVIPPCCount));
            }
        }

        private bool isOrderByName;
        public bool IsOrderByName
        {
            get { return isOrderByName; }
            set
            {
                isOrderByName = value;
                RaisePropertyChanged(nameof(IsOrderByName));
            }
        }

        private bool isOrderByArea;
        public bool IsOrderByArea
        {
            get { return isOrderByArea; }
            set
            {
                isOrderByArea = value;
                RaisePropertyChanged(nameof(IsOrderByArea));
            }
        }

        private bool isOrderByStatus;
        public bool IsOrderByStatus
        {
            get { return isOrderByStatus; }
            set
            {
                isOrderByStatus = value;
                RaisePropertyChanged(nameof(IsOrderByStatus));
            }
        }

        private bool isOrderByUserType;
        public bool IsOrderByUserType
        {
            get { return isOrderByUserType; }
            set
            {
                isOrderByUserType = value;
                RaisePropertyChanged(nameof(IsOrderByUserType));
            }
        }

        private ObservableCollection<WorkstationModel> allWorkStationList;
        public ObservableCollection<WorkstationModel> AllWorkStationList
        {
            get { return allWorkStationList; }
            set
            {
                allWorkStationList = value;
                RaisePropertyChanged(nameof(AllWorkStationList));
            }
        }

        private List<StationTypeDataModel> stationTypeList;
        public List<StationTypeDataModel> StationTypeList
        {
            get { return stationTypeList; }
            set
            {
                stationTypeList = value;
                RaisePropertyChanged(nameof(StationTypeList));
            }
        }

        private ObservableCollection<TransactionModel> transactionLogsList;
        public ObservableCollection<TransactionModel> TransactionLogsList
        {
            get { return transactionLogsList; }
            set
            {
                transactionLogsList = value;
                RaisePropertyChanged(nameof(TransactionLogsList));
            }
        }

        private ViewModel.NotifyTaskCompletionViewModel<TransactionModel> transactionLogsListTask;
        public ViewModel.NotifyTaskCompletionViewModel<TransactionModel> TransactionLogsListTask
        {
            get { return transactionLogsListTask; }
            set
            {
                transactionLogsListTask = value;
                RaisePropertyChanged(nameof(TransactionLogsListTask));
            }
        }

        private TransactionModel selectedTransactionModel;
        public TransactionModel SelectedTransactionModel
        {
            get { return selectedTransactionModel; }
            set
            {
                selectedTransactionModel = value;
                RaisePropertyChanged(nameof(SelectedTransactionModel));
            }
        }

        private bool isRegularPCCountGreaterThanZero;
        public bool IsRegularPCCountGreaterThanZero
        {
            get { return isRegularPCCountGreaterThanZero; }
            set
            {
                isRegularPCCountGreaterThanZero = value;
                RaisePropertyChanged(nameof(IsRegularPCCountGreaterThanZero));
            }
        }

        private bool isGoldPCCountGreaterThanZero;
        public bool IsGoldPCCountGreaterThanZero
        {
            get { return isGoldPCCountGreaterThanZero; }
            set
            {
                isGoldPCCountGreaterThanZero = value;
                RaisePropertyChanged(nameof(IsGoldPCCountGreaterThanZero));
            }
        }

        private bool isVIPPCCountGreaterThanZero;
        public bool IsVIPPCCountGreaterThanZero
        {
            get { return isVIPPCCountGreaterThanZero; }
            set
            {
                isVIPPCCountGreaterThanZero = value;
                RaisePropertyChanged(nameof(IsVIPPCCountGreaterThanZero));
            }
        }

        private int occupiedRegularPCCount;
        public int OccupiedRegularPCCount
        {
            get { return occupiedRegularPCCount; }
            set
            {
                occupiedRegularPCCount = value;
                RaisePropertyChanged(nameof(OccupiedRegularPCCount));
                RaisePropertyChanged(nameof(AvailableRegularPCCount));
            }
        }

        private int occupiedVIPPCCount;
        public int OccupiedVIPPCCount
        {
            get { return occupiedVIPPCCount; }
            set
            {
                occupiedVIPPCCount = value;
                RaisePropertyChanged(nameof(OccupiedVIPPCCount));
                RaisePropertyChanged(nameof(AvailableVIPPCCount));
            }
        }

        private int occupiedGoldPCCount;
        public int OccupiedGoldPCCount
        {
            get { return occupiedGoldPCCount; }
            set
            {
                occupiedGoldPCCount = value;
                RaisePropertyChanged(nameof(OccupiedGoldPCCount));
                RaisePropertyChanged(nameof(AvailableGoldPCCount));
            }
        }

        public int AvailableRegularPCCount
        {
            get { return RegularWorkStationList.Count - OccupiedRegularPCCount; }
        }

        public int AvailableVIPPCCount
        {
            get { return VIPWorkStationList.Count - OccupiedVIPPCCount; }
        }

        public int AvailableGoldPCCount
        {
            get { return GoldWorkStationList.Count - OccupiedGoldPCCount; }
        }
        #endregion
    }
}
