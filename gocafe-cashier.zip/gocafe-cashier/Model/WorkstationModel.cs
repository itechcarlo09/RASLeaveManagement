﻿using gocafe_cashier.DataModel;
using NetworkCommsDotNet.Connections;

namespace gocafe_cashier.Model
{
    public class WorkstationModel : BaseModel
    {
        public WorkstationModel()
        {
            Initialize();
        }

        #region EventHandlers

        private void Initialize()
        {
            IsShowInUI = false;
            IsShow = false;
            IsOccupied = false;
            IsOff = true;
            PcStatus = "Offline";
            SortMode = string.Empty;
            AccountModel = new AccountModel();
            StationModel = new StationDataModel();
            IsLocked = false;
        }

        public void ShowInUIBy(string mode)
        {
            SortMode = mode;
            switch (mode)
            {
                case "ALL":
                    IsShowInUI = true;
                    break;

                case "OCCUPIED":
                    if (PcStatus == "Occupied")
                    {
                        IsShowInUI = true;
                    }
                    else
                    {
                        IsShowInUI = false;
                    }
                    break;

                case "AVAILABLE":
                    if ((PcStatus == "Available") || (PcStatus == "Offline"))
                    {
                        IsShowInUI = true;
                    }
                    else
                    {
                        IsShowInUI = false;
                    }
                    break;

                default:
                    break;
            }
        }

        #endregion


        #region Properties

        private bool isShowInUI;
        public bool IsShowInUI
        {
            get { return isShowInUI; }
            set
            {
                isShowInUI = value;
                RaisePropertyChanged(nameof(IsShowInUI));
            }
        }

        private string sortMode;
        public string SortMode
        {
            get { return sortMode; }
            set
            {
                sortMode = value;
                RaisePropertyChanged(nameof(SortMode));
            }
        }

        private bool isShow;
        public bool IsShow
        {
            get { return isShow; }
            set
            {
                isShow = value;
                RaisePropertyChanged(nameof(IsShow));
            }
        }

        private bool isOccupied;
        public bool IsOccupied
        {
            get { return isOccupied; }
            set
            {
                isOccupied = value;
                RaisePropertyChanged(nameof(IsOccupied));
            }
        }

        private bool isLocked;
        public bool IsLocked
        {
            get { return isLocked; }
            set
            {
                isLocked = value;
                RaisePropertyChanged(nameof(IsLocked));
            }
        }

        private bool isOff;
        public bool IsOff
        {
            get { return isOff; }
            set
            {
                isOff = value;
                RaisePropertyChanged(nameof(IsOff));
            }
        }

        private string pcStatus;
        public string PcStatus
        {
            get { return pcStatus; }
            set
            {
                pcStatus = value;
                RaisePropertyChanged(nameof(PcStatus));
            }
        }

        private AccountModel accountModel;
        public AccountModel AccountModel
        {
            get { return accountModel; }
            set
            {
                accountModel = value;
                RaisePropertyChanged(nameof(AccountModel));
            }
        }

        private Connection pcConnection;
        public Connection PcConnection
        {
            get { return pcConnection; }
            set
            {
                pcConnection = value;
                RaisePropertyChanged(nameof(PcConnection));
            }
        }

        private StationDataModel stationModel;
        public StationDataModel StationModel
        {
            get { return stationModel; }
            set
            {
                stationModel = value;
                RaisePropertyChanged(nameof(StationModel));
            }
        }

        private bool isSelected;
        public bool IsSelected
        {
            get { return isSelected; }
            set
            {
                isSelected = value;
                RaisePropertyChanged(nameof(IsSelected));
            }
        }

        #endregion
    }
}
