﻿using System;

namespace gocafe_cashier.Model
{
    public class GuestMemberReceiptModel
    {

        public GuestMemberReceiptModel()
        {
            Initilization();
        }

        private string cashier;
        public string Cashier
        {
            get { return cashier; }
            set
            {
                cashier = value;
            }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
            }
        }

        private string userName;
        public string UserName
        {
            get { return userName; }
            set
            {
                userName = value;
            }
        }

        private string password;
        public string Password
        {
            get { return password; }
            set
            {
                password = value;
            }
        }

        private string userLevel;
        public string UserLevel
        {
            get { return userLevel; }
            set
            {
                userLevel = value;
            }
        }

        private DateTime expirationDate;
        public DateTime ExpirationDate
        {
            get { return expirationDate; }
            set
            {
                expirationDate = value;
            }
        }

        private int duration;
        public int Duration
        {
            get { return duration; }
            set
            {
                duration = value;
            }
        }

        private void Initilization()
        {
            Cashier = string.Empty;
            Name = string.Empty;
            UserName = string.Empty;
            Password = string.Empty;
            UserLevel = string.Empty;
        }
    }
}
