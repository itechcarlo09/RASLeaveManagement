﻿using gocafe_cashier.Cache;
using gocafe_cashier.MessageResource;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;

namespace gocafe_cashier.Model
{
    public class TopUpManagerModel : BaseModel, IDataErrorInfo
    {
        public TopUpManagerModel()
        {
            Initialize();
        }

        private void Initialize()
        {
            ErrorList = new List<string>();
            IsMember = true;
            SelectedPromoPrice = 0;
            SelectedPromoID = string.Empty;
            TotalFee = 0;
            TenderedMoney = 0;
            ChangeFee = 0;
            HasSelectedPromo = false;
            BranchCreated = string.Empty;
            IsTopUpByUser = false;
            WorkStationList = new List<WorkstationModel>();
            SelectedWorkStation = new WorkstationModel();
            ValidatorTopUpFee = "0.00";
            ValidatorTenderedMoney = "0.00";
            IsPrintChecked = true;
            IsPromoEmpty = false;
        }

        #region Event Handlers

        public void ComputeTotalFee()
        {
            TotalFee = (SelectedPromoPrice + TopUpFee);
        }

        public void ComputeChange()
        {
            ChangeFee = (TenderedMoney - TotalFee);

            //if (ChangeFee < 0)
            //{
            //    if (!ErrorList.Contains("ChangeFee"))
            //    {
            //        ErrorList.Add("ChangeFee");
            //    }
            //}
            //else
            //{
            //    if (ErrorList.Contains("ChangeFee"))
            //    {
            //        ErrorList.Remove("ChangeFee");
            //    }
            //}
        }

        private bool ValidateMinimumTopup(decimal topupValue, out string error)
        {

            //Fix me: temporarily commenting this out. Not sure what the purpose of this is.
            //if (IsMember)
            //{
            //    if (topupValue <= 0)
            //    {
            //        error = string.Empty;
            //        return false;
            //    }
            //}

            if (HasSelectedPromo)
            {
                if (topupValue < 0)
                {
                    error = "Must be more than P0";
                    return true;
                }
                else
                {
                    error = string.Empty;
                    return false;
                }
            }
            else
            {
                if (topupValue < 1)
                {
                    error = "Enter amount or pick a promo";
                    return true;
                }
                else
                {
                    error = string.Empty;
                    return false;
                }
            }
        }

        #endregion

        #region Properties

        private bool isUserFound;

        public bool IsUserFound
        {
            get { return isUserFound; }
            set
            {
                isUserFound = value;
                RaisePropertyChanged(nameof(IsUserFound));
            }
        }


        private bool isShownLoading;
        public bool IsShownLoading
        {
            get { return isShownLoading; }
            set
            {
                isShownLoading = value;
                RaisePropertyChanged(nameof(IsShownLoading));
            }
        }

        private WorkstationModel selectedWorkStation;
        public WorkstationModel SelectedWorkStation
        {
            get { return selectedWorkStation; }
            set
            {
                selectedWorkStation = value;
                RaisePropertyChanged(nameof(SelectedWorkStation));
            }
        }

        private List<WorkstationModel> workStationList;
        public List<WorkstationModel> WorkStationList
        {
            get { return workStationList; }
            set
            {
                workStationList = value;
                RaisePropertyChanged(nameof(WorkStationList));
            }
        }

        private decimal topUpFee;
        public decimal TopUpFee
        {
            get { return topUpFee; }
            set
            {
                topUpFee = value;
                RaisePropertyChanged(nameof(TopUpFee));

                ComputeTotalFee();
                ComputeChange();
            }
        }

        private string guestUsername;
        public string GuestUsername
        {
            get { return guestUsername; }
            set
            {
                guestUsername = value;
                RaisePropertyChanged(nameof(GuestUsername));
            }
        }

        private string cardIDNumber;
        public string CardIDNumber
        {
            get { return cardIDNumber; }
            set
            {
                cardIDNumber = value;
                RaisePropertyChanged(nameof(CardIDNumber));
            }
        }

        private string username;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                RaisePropertyChanged(nameof(Username));
            }
        }

        private string firstName;
        public string FirstName
        {
            get { return firstName; }
            set
            {
                firstName = value;
                RaisePropertyChanged(nameof(FirstName));
            }
        }

        private string lastName;
        public string LastName
        {
            get { return lastName; }
            set
            {
                lastName = value;
                RaisePropertyChanged(nameof(LastName));
            }
        }

        private bool isMember;
        public bool IsMember
        {
            get { return isMember; }
            set
            {
                isMember = value;
                RaisePropertyChanged(nameof(IsMember));
                Mediator.Instance.NotifyViewModel(Messages.TopUpManagerViewModel, Messages.GuestAccount, null);
                IsUserFound = false;
            }
        }

        private bool isTopUpByUser;
        public bool IsTopUpByUser
        {
            get { return isTopUpByUser; }
            set
            {
                isTopUpByUser = value;
                RaisePropertyChanged(nameof(IsTopUpByUser));
            }
        }

        private bool isTopUpByGuest;
        public bool IsTopUpByGuest
        {
            get { return isTopUpByGuest; }
            set
            {
                isTopUpByGuest = value;
                RaisePropertyChanged(nameof(IsTopUpByGuest));
            }
        }

        private string branchCreated;
        public string BranchCreated
        {
            get { return branchCreated; }
            set
            {
                branchCreated = value;
                RaisePropertyChanged(nameof(BranchCreated));
            }
        }

        private string dateCreated;
        public string DateCreated
        {
            get { return dateCreated; }
            set
            {
                dateCreated = value;
                RaisePropertyChanged(nameof(DateCreated));
            }
        }

        private string points;
        public string Points
        {
            get { return points; }
            set
            {
                points = value;
                RaisePropertyChanged(nameof(Points));
            }
        }

        private string accountBalance;
        public string AccountBalance
        {
            get { return accountBalance; }
            set
            {
                accountBalance = value;
                RaisePropertyChanged(nameof(AccountBalance));
            }
        }

        private decimal totalFee;
        public decimal TotalFee
        {
            get { return totalFee; }
            set
            {
                totalFee = value;
                RaisePropertyChanged(nameof(TotalFee));
            }
        }

        private decimal changeFee;
        public decimal ChangeFee
        {
            get { return changeFee; }
            set
            {
                changeFee = value;
                RaisePropertyChanged(nameof(ChangeFee));
            }
        }

        private decimal tenderedMoney;
        public decimal TenderedMoney
        {
            get { return tenderedMoney; }
            set
            {
                tenderedMoney = value;
                RaisePropertyChanged(nameof(TenderedMoney));

                ComputeTotalFee();
                ComputeChange();
            }
        }

        private bool isPromoEmpty;
        public bool IsPromoEmpty
        {
            get { return isPromoEmpty; }
            set
            {
                isPromoEmpty = value;
                RaisePropertyChanged(nameof(IsPromoEmpty));
            }
        }

        private ObservableCollection<AccountPromoModel> accountPromo;
        public ObservableCollection<AccountPromoModel> AccountPromo
        {
            get { return accountPromo; }
            set
            {
                accountPromo = value;
                RaisePropertyChanged(nameof(AccountPromo));
            }
        }

        private string selectedPromoDescription;
        public string SelectedPromoDescription
        {
            get { return selectedPromoDescription; }
            set
            {
                selectedPromoDescription = value;
                RaisePropertyChanged(nameof(SelectedPromoDescription));
            }
        }

        private decimal selectedPromoPrice;
        public decimal SelectedPromoPrice
        {
            get { return selectedPromoPrice; }
            set
            {
                selectedPromoPrice = value;
                RaisePropertyChanged(nameof(SelectedPromoPrice));
            }
        }

        private string selectedPromoID;
        public string SelectedPromoID
        {
            get { return selectedPromoID; }
            set
            {
                selectedPromoID = value;
                RaisePropertyChanged(nameof(SelectedPromoID));
            }
        }

        private bool hasSelectedPromo;
        public bool HasSelectedPromo
        {
            get { return hasSelectedPromo; }
            set
            {
                hasSelectedPromo = value;
                RaisePropertyChanged(nameof(HasSelectedPromo));
            }
        }

        private bool hasError;
        public bool HasError
        {
            get { return hasError; }
            set
            {
                hasError = value;
                RaisePropertyChanged(nameof(HasError));
            }
        }

        private bool isSubmitButtonEnabled;
        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

        private bool isPrintChecked;
        public bool IsPrintChecked
        {
            get { return isPrintChecked; }
            set
            {
                isPrintChecked = value;
                RaisePropertyChanged(nameof(IsPrintChecked));
            }
        }

        public decimal TopupMaximumAmount
        {
            get { return DataCacheContext.TopupMaximumAmount; }
        }

        #endregion

        #region TopUpManager Text Change Event

        //TopUp Textbox
        private Visibility topUpVisibilityError;
        public Visibility TopUpVisibilityError
        {
            get { return topUpVisibilityError; }
            set
            {
                topUpVisibilityError = value;
                RaisePropertyChanged(nameof(TopUpVisibilityError));
            }
        }


        private SolidColorBrush topUpBorderBrush;
        public SolidColorBrush TopUpBorderBrush
        {
            get { return topUpBorderBrush; }
            set
            {
                topUpBorderBrush = value;
                RaisePropertyChanged(nameof(TopUpBorderBrush));
            }
        }

        private string error;
        public string Error
        {
            get { return error; }
            set
            {
                error = value;
                RaisePropertyChanged(nameof(Error));
            }
        }

        private string validatorTopUpFee;
        public string ValidatorTopUpFee
        {
            get
            {
                return validatorTopUpFee;
            }
            set
            {
                validatorTopUpFee = value;
                RaisePropertyChanged(nameof(ValidatorTopUpFee));
            }
        }

        private bool isErrorMessageShown;
        public bool IsErrorMessageShown
        {
            get { return isErrorMessageShown; }
            set
            {
                isErrorMessageShown = value;
                RaisePropertyChanged(nameof(IsErrorMessageShown));
            }
        }

        //Tendered Textbox
        private Visibility tenderedVisibilityError;
        public Visibility TenderedVisibilityError
        {
            get { return tenderedVisibilityError; }
            set
            {
                tenderedVisibilityError = value;
                RaisePropertyChanged(nameof(TenderedVisibilityError));
            }
        }

        private SolidColorBrush tenderedBorderBrush;
        public SolidColorBrush TenderedBorderBrush
        {
            get { return tenderedBorderBrush; }
            set
            {
                tenderedBorderBrush = value;
                RaisePropertyChanged(nameof(TenderedBorderBrush));
            }
        }

        private string tenderedError;
        public string TenderedError
        {
            get { return tenderedError; }
            set
            {
                tenderedError = value;
                RaisePropertyChanged(nameof(TenderedError));
            }
        }

        private string validatorTenderedMoney;
        public string ValidatorTenderedMoney
        {
            get
            {
                return validatorTenderedMoney;
            }
            set
            {
                validatorTenderedMoney = value;
                RaisePropertyChanged(nameof(ValidatorTenderedMoney));
            }
        }

        private bool isTenderedErrorMessageShown;
        public bool IsTenderedErrorMessageShown
        {
            get { return isTenderedErrorMessageShown; }
            set
            {
                isTenderedErrorMessageShown = value;
                RaisePropertyChanged(nameof(IsTenderedErrorMessageShown));
            }
        }

        private bool isPCAssigned;
        public bool IsPCAssigned
        {
            get { return isPCAssigned; }
            set
            {
                isPCAssigned = value;
                RaisePropertyChanged(nameof(IsPCAssigned));
            }
        }

        private List<string> errorList;
        public List<string> ErrorList
        {
            get { return errorList; }
            set
            {
                errorList = value;
                RaisePropertyChanged(nameof(ErrorList));
            }
        }

        #endregion

        private bool isUsernameFirstLoad = true;
        private bool isGuestUsernameFirstLoad = true;

        public void LostFocus()
        {
            RaisePropertyChanged(nameof(TenderedMoney));
        }

        public void ResetFirstLoadFields()
        {
            isUsernameFirstLoad = true;
            isGuestUsernameFirstLoad = true;
            ErrorList.Clear();
        }

        public string this[string name]
        {
            get
            {
                string result = null;

                try
                {
                    if (name == "ValidatorTopUpFee")
                    {
                        if (ValidatorTopUpFee == null)
                        {
                            ValidatorTopUpFee = "0.00";
                        }

                        decimal topUpFee = Convert.ToDecimal(ValidatorTopUpFee);
                        string error = string.Empty;
                        if (ValidateMinimumTopup(topUpFee, out error))
                        {
                            TopUpBorderBrush = Brushes.Red;
                            IsErrorMessageShown = true;
                            TopUpVisibilityError = Visibility.Visible;
                            Error = error;

                            if (!ErrorList.Contains(name))
                            {
                                ErrorList.Add(name);
                            }
                        }
                        else if (topUpFee > TopupMaximumAmount)
                        {
                            TopUpBorderBrush = Brushes.Red;
                            IsErrorMessageShown = true;
                            TopUpVisibilityError = Visibility.Visible;
                            Error = "Maximum: "+ TopupMaximumAmount;

                            if (!ErrorList.Contains(name))
                            {
                                ErrorList.Add(name);
                            }
                        }
                        else
                        {
                            if (ErrorList.Contains(name))
                            {
                                ErrorList.Remove(name);
                            }

                            TopUpBorderBrush = Brushes.Transparent;
                            IsErrorMessageShown = false;
                            TopUpVisibilityError = Visibility.Hidden;
                        }

                        TopUpFee = topUpFee;
                    }
                    else if (name == "Username")
                    {
                        if (isUsernameFirstLoad)
                        {
                            isUsernameFirstLoad = false;
                        }
                        else if (Username == null || Username == string.Empty)
                        {
                            result = StandardMessageResource.ErrorTopUpUsernameIsNullorEmpty;

                            if (!ErrorList.Contains(name))
                            {
                                ErrorList.Add(name);
                            }
                        }
                        else if (Username.Length < 4)
                        {
                            result = StandardMessageResource.ErrorUsernameLessThan4;

                            if (!ErrorList.Contains(name))
                            {
                                ErrorList.Add(name);
                            }
                        }
                        else
                        {
                            if (ErrorList.Contains(name))
                            {
                                ErrorList.Remove(name);
                            }
                        }
                    }
                    else if (name == "GuestUsername")
                    {
                        if (isGuestUsernameFirstLoad)
                        {
                            isGuestUsernameFirstLoad = false;
                        }
                        else if (GuestUsername == null || GuestUsername == string.Empty)
                        {
                            result = StandardMessageResource.ErrorTopUpGuestUsernameIsNullorEmpty;

                            if (!ErrorList.Contains(name))
                            {
                                ErrorList.Add(name);
                            }
                        }
                        else if (GuestUsername.Length < 4)
                        {
                            result = StandardMessageResource.ErrorUsernameLessThan4;

                            if (!ErrorList.Contains(name))
                            {
                                ErrorList.Add(name);
                            }
                        }
                        else
                        {
                            if (ErrorList.Contains(name))
                            {
                                ErrorList.Remove(name);
                            }
                        }
                    }
                    else if (name == nameof(TotalFee))
                    {
                        if (TotalFee < 1)
                        {
                            Error = StandardMessageResource.ErrorTopUpValueLessThan1;
                            if (!ErrorList.Contains(name))
                            {
                                ErrorList.Add(name);
                            }
                        }
                    }
                    else if (name == "ValidatorTenderedMoney")
                    {
                        //decimal tenderedMoney = Convert.ToDecimal(ValidatorTenderedMoney);
                        //if (tenderedMoney < 0)
                        //{
                        //    TenderedBorderBrush = Brushes.Red;
                        //    IsTenderedErrorMessageShown = true;
                        //    TenderedVisibilityError = Visibility.Visible;
                        //    TenderedError = StandardMessageResource.ErrorTopUpValueLessThanZero;

                        //    if (!ErrorList.Contains(name))
                        //    {
                        //        ErrorList.Add(name);
                        //    }
                        //}
                        //else if (tenderedMoney > 10000)
                        //{
                        //    TenderedBorderBrush = Brushes.Red;
                        //    IsTenderedErrorMessageShown = true;
                        //    TenderedVisibilityError = Visibility.Visible;
                        //    TenderedError = StandardMessageResource.ErrorTopUFeeOrTenderedGreaterThan10k;

                        //    if (!ErrorList.Contains(name))
                        //    {
                        //        ErrorList.Add(name);
                        //    }
                        //}
                        //else
                        //{
                        //    if (ErrorList.Contains(name))
                        //    {
                        //        ErrorList.Remove(name);
                        //    }

                        //    TenderedBorderBrush = Brushes.Transparent;
                        //    IsTenderedErrorMessageShown = false;
                        //    TenderedVisibilityError = Visibility.Hidden;
                        //}

                        //TenderedMoney = tenderedMoney;
                    }

                    if (ErrorList.Count > 0)
                    {
                        HasError = true;
                    }
                    else
                    {
                        HasError = false;
                    }

                    if (IsMember)
                    {
                        IsSubmitButtonEnabled = ValidateMemberFields();
                    }
                    else
                    {
                        IsSubmitButtonEnabled = ValidateGuestFields();
                    }
                    
                }
                catch
                {

                }
                return result;
            }
        }

        private bool ValidateMemberFields()
        {
            if (TopUpFee > 10000)
            {
                return false;
            }
            else if (Username == null || Username == string.Empty || Username.Length < 4)
            {
                return false;
            }
            else if (TopUpFee < 1 && HasSelectedPromo == false)
            {
                return false;
            }
            //else if (IsUserFound == false)
            //{
            //    return false;
            //}
            else
            {
                return true;
            }
        }

        private bool ValidateGuestFields()
        {
            if (TopUpFee > 10000)
            {
                return false;
            }
            else if (GuestUsername == null || GuestUsername == string.Empty || GuestUsername.Length < 4)
            {
                return false;
            }
            else if (TopUpFee < 1 && HasSelectedPromo == false)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

    }
}
