﻿namespace gocafe_cashier.Model.Definition
{
    public static class MemberType
    {
        public const string Regular = "Regular";
    }
}