﻿using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.FnBDataModels;

namespace gocafe_cashier.Model.EShopModels
{
    public class EShopCodeModel
    {
        public string CodeType { get; set; }

        public string Code { get; set; }

    }
}