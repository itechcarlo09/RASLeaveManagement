﻿using gocafe_cashier.MessageResource;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Media;

namespace gocafe_cashier.Model
{
    public class LoginModel : BaseModel, IDataErrorInfo
    {
        public LoginModel()
        {
            PasswordBorderBrush = Brushes.Transparent;
            ErrorList = new List<string>();
            UsernameFirstLoad = true;
            PasswordKeyUp = false;
            ButtonIsEnabled = false;
        }

        private bool usernameFirstLoad;
        public bool UsernameFirstLoad
        {
            get { return usernameFirstLoad; }
            set
            {
                usernameFirstLoad = value;
                RaisePropertyChanged(nameof(UsernameFirstLoad));
            }
        }

        private bool buttonIsEnabled;
        public bool ButtonIsEnabled
        {
            get { return buttonIsEnabled; }
            set
            {
                buttonIsEnabled = value;
                RaisePropertyChanged(nameof(ButtonIsEnabled));
            }
        }

        private bool passwordKeyUp;
        public bool PasswordKeyUp
        {
            get { return passwordKeyUp; }
            set
            {
                passwordKeyUp = value;
                RaisePropertyChanged(nameof(PasswordKeyUp));
            }
        }

        private int passwordLength;
        public int PasswordLength
        {
            get { return passwordLength; }
            set
            {
                passwordLength = value;
                RaisePropertyChanged(nameof(PasswordLength));
            }
        }

        private string username;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                RaisePropertyChanged(nameof(Username));
            }
        }

        private string error;
        public string Error
        {
            get { return error; }
            set
            {
                error = value;
                RaisePropertyChanged(nameof(Error));
            }
        }

        private List<string> errorList;
        public List<string> ErrorList
        {
            get { return errorList; }
            set
            {
                errorList = value;
                RaisePropertyChanged(nameof(ErrorList));
            }
        }

        private bool isErrorMessageShown;
        public bool IsErrorMessageShown
        {
            get { return isErrorMessageShown; }
            set
            {
                isErrorMessageShown = value;
                RaisePropertyChanged(nameof(IsErrorMessageShown));
            }
        }

        private SolidColorBrush usernameBorderBrush;
        public SolidColorBrush UsernameBorderBrush
        {
            get { return usernameBorderBrush; }
            set
            {
                usernameBorderBrush = value;
                RaisePropertyChanged(nameof(UsernameBorderBrush));
            }
        }

        private SolidColorBrush passwordBorderBrush;
        public SolidColorBrush PasswordBorderBrush
        {
            get { return passwordBorderBrush; }
            set
            {
                passwordBorderBrush = value;
                RaisePropertyChanged(nameof(PasswordBorderBrush));
            }
        }

        private string passwordErrorMessage;
        public string PasswordErrorMessage
        {
            get { return passwordErrorMessage; }
            set
            {
                passwordErrorMessage = value;
                RaisePropertyChanged(nameof(PasswordErrorMessage));
            }
        }

        private string usernameErrorMessage;
        public string UsernameErrorMessage
        {
            get { return usernameErrorMessage; }
            set
            {
                usernameErrorMessage = value;
                RaisePropertyChanged(nameof(UsernameErrorMessage));
            }
        }

        private bool isUsernameInvalid;
        public bool IsUsernameInvalid
        {
            get { return isUsernameInvalid; }
            set
            {
                isUsernameInvalid = value;
                RaisePropertyChanged(nameof(IsUsernameInvalid));
            }
        }

        private bool isPasswordInvalid;
        public bool IsPasswordInvalid
        {
            get { return isPasswordInvalid; }
            set
            {
                isPasswordInvalid = value;
                RaisePropertyChanged(nameof(IsPasswordInvalid));
            }
        }

        public string this[string varName]
        {
            get
            {
                string result = null;

                return result;
            }
        }
    }
}
