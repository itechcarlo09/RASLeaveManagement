﻿using gocafe_cashier.DataModel;
using gocafe_cashier.DataModel.Inventory;
using gocafe_cashier.MessageResource;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.Model.InventoryModels
{
    public class ItemModel : BaseModel, IDataErrorInfo
    {
        public ItemModel()
        {
            ErrorList = new List<string>();
        }

        private enum ChangeTypes { None, AdjustmentOrder, PurchaseOrder };

        private BranchDataModel branch;
        public BranchDataModel Branch
        {
            get { return branch; }
            set { branch = value; }
        }

        private ProductDataModel product;
        public ProductDataModel Product
        {
            get { return product; }
            set
            {
                product = value;
                RaisePropertyChanged(nameof(Product));
            }
        }

        private int quantityInStock;
        public int QuantityInStock
        {
            get { return quantityInStock; }
            set
            {
                quantityInStock = value;
                RaisePropertyChanged(nameof(QuantityInStock));
            }
        }

        private int adjustment;
        public int Adjustment
        {
            get { return adjustment; }
            set
            {
                if (adjustment != value)
                {
                    IsModified = true;
                    Mediator.Instance.NotifyViewModel(Messages.InventoryManagerModel, Messages.IsModified, null);
                }
                adjustment = value;
                RaisePropertyChanged(nameof(Adjustment));
                RaisePropertyChanged(nameof(TotalCost));
                RaisePropertyChanged(nameof(UnitCost));
            }
        }

        private decimal unitCost;
        public decimal UnitCost
        {
            get { return unitCost; }
            set
            {
                if (unitCost != value)
                {
                    IsModified = true;
                    Mediator.Instance.NotifyViewModel(Messages.InventoryManagerModel, Messages.IsModified, null);
                }
                unitCost = value;
                RaisePropertyChanged(nameof(UnitCost));
                RaisePropertyChanged(nameof(TotalCost));
                RaisePropertyChanged(nameof(Adjustment));
            }
        }

        public decimal TotalCost
        {
            get { return UnitCost*Adjustment; }
        }

        private string adjustmentStatus;
        public string AdjustmentStatus
        {
            get { return adjustmentStatus; }
            set
            {
                adjustmentStatus = value;
                RaisePropertyChanged(nameof(AdjustmentStatus));
            }
        }

        private bool isSelected;
        public bool IsSelected
        {
            get { return isSelected; }
            set
            {
                isSelected = value;
                RaisePropertyChanged(nameof(IsSelected));
            }
        }

        private bool isModified;
        public bool IsModified
        {
            get { return isModified; }
            set
            {
                isModified = value;
                RaisePropertyChanged(nameof(IsModified));
            }
        }

        private List<string> errorList;
        public List<string> ErrorList
        {
            get { return errorList; }
            set
            {
                errorList = value;
                RaisePropertyChanged(nameof(ErrorList));
            }
        }

        private string changeType;
        public string ChangeType
        {
            get { return changeType; }
            set
            {
                changeType = value;
                RaisePropertyChanged(nameof(ChangeType));
            }
        }

        public void ResetFirstLoadFields()
        {
            IsModified = false;
            ErrorList = new List<string>();
        }

        public string Error { get; set; }

        public string this[string name]
        {
            get
            {
                string result = null;
                if (name == nameof(Adjustment))
                {
                    if (IsModified)
                    {
                        if (ErrorList.Contains(nameof(Adjustment)))
                        {
                            ErrorList.Remove(nameof(Adjustment));
                        }
                        if (adjustment == 0 && unitCost != 0 && changeType == ChangeTypes.AdjustmentOrder.ToString())
                        {
                            result = StandardMessageResource.ErrorZeroQuantity;
                            ErrorList.Add(nameof(Adjustment));
                        }
                        else if(adjustment < 1 && unitCost != 0  && changeType == ChangeTypes.PurchaseOrder.ToString())
                        {
                            result = StandardMessageResource.ErrorNegativeQuantity;
                            ErrorList.Add(nameof(Adjustment));
                        }
                    }
                }
                else if (name == nameof(UnitCost))
                {
                    if (IsModified)
                    {
                        if (ErrorList.Contains(nameof(UnitCost)))
                        {
                            ErrorList.Remove(nameof(UnitCost));
                        }
                        if (unitCost < 0 || (unitCost == 0 && adjustment != 0))
                        {
                            result = StandardMessageResource.ErrorUnitCostNotGreaterThanZero;
                            ErrorList.Add(nameof(UnitCost));
                        }
                    }
                }
                return result;
            }
        }
    }
}