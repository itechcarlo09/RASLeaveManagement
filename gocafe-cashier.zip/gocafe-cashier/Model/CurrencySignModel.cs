﻿using gocafe_cashier.Manager;

namespace gocafe_cashier.Model
{
    public class CurrencySignModel
    {
        public CurrencySignModel()
        {
            Initialization();
        }

        public void Initialization()
        {
            CurrencySignAssigned();

        }

        private string selectedCurrency;
        public string SelectedCurrency
        {
            get { return selectedCurrency; }
            set
            {
                selectedCurrency = value;
            }
        }

        private const string PhilippinePeso = "\u20B1";
        private const string ChineseYen = "\u00A5";
        private const string IndianRupee = "\u20B9";
        private const string MalaysianRinggit = "RM";
        private const string IndonesiaRupiah = "Rp";
        private const string SingaporeDollar = "S\u0024";
        private const string USDollar = "\u0024";

        public void CurrencySignAssigned()
        {
            string currencyInput = AppSettingManager.Instance[AppSettingKey.CurrencySign];

            switch(currencyInput)
            {
                case "PHP":
                    SelectedCurrency = PhilippinePeso;
                    break;
                case "YEN":
                    SelectedCurrency = ChineseYen;
                    break;
                case "RUPEE":
                    SelectedCurrency = IndianRupee;
                    break;
                case "RINGGIT":
                    SelectedCurrency = MalaysianRinggit;
                    break;
                case "RUPIAH":
                    SelectedCurrency = IndonesiaRupiah;
                    break;
                case "SDOLLAR":
                    SelectedCurrency = SingaporeDollar;
                    break;
                case "DOLLAR":
                    SelectedCurrency = USDollar;
                    break;
                default:
                    SelectedCurrency = PhilippinePeso;
                    break;
            }
        }
    }
}
