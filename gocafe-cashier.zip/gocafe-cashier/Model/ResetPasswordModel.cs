﻿using gocafe_cashier.MessageResource;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text.RegularExpressions;

namespace gocafe_cashier.Model
{
    public class ResetPasswordModel : BaseModel, IDataErrorInfo
    {
        private int windowsFirstLoadElement;

        public ResetPasswordModel()
        {
            Initialization();
        }

        private void Initialization()
        {
            IsButtonReady = false;
            EmailAddressIsValid = true;
            MobileNumberIsValid = true;
            CardID = string.Empty;
            EmailAddress = string.Empty;
            MobileNumber = string.Empty;
            EmailAddressError = string.Empty;
            MobileNumberError = string.Empty;
            ErrorList = new Dictionary<string, string>();
            windowsFirstLoadElement = 3;
            WindowsFirstLoad = new bool[windowsFirstLoadElement];
            WindowsFirstloadSetValue(true);
        }

        private string cardID;
        public string CardID
        {
            get { return cardID; }
            set
            {
                cardID = value;
                RaisePropertyChanged(nameof(CardID));
            }
        }

        private string emailAddress;
        public string EmailAddress
        {
            get { return emailAddress; }
            set
            {
                emailAddress = value;
                RaisePropertyChanged(nameof(EmailAddress));
            }
        }

        private bool emailAddressIsValid;
        public bool EmailAddressIsValid
        {
            get { return emailAddressIsValid; }
            set
            {
                emailAddressIsValid = value;
                RaisePropertyChanged(nameof(EmailAddressIsValid));
            }
        }

        private string emailAddressError;
        public string EmailAddressError
        {
            get { return emailAddressError; }
            set
            {
                emailAddressError = value;
                RaisePropertyChanged(nameof(EmailAddressError));
            }
        }

        private string mobileNumber;
        public string MobileNumber
        {
            get { return mobileNumber; }
            set
            {
                mobileNumber = value;
                RaisePropertyChanged(nameof(MobileNumber));
            }
        }
        private bool mobileNumberIsValid;
        public bool MobileNumberIsValid
        {
            get { return mobileNumberIsValid; }
            set
            {
                mobileNumberIsValid = value;
                RaisePropertyChanged(nameof(MobileNumberIsValid));
            }
        }

        private string mobileNumberError;
        public string MobileNumberError
        {
            get { return mobileNumberError; }
            set
            {
                mobileNumberError = value;
                RaisePropertyChanged(nameof(MobileNumberError));
            }
        }

        private bool isButtonReady;
        public bool IsButtonReady
        {
            get { return isButtonReady; }
            set
            {
                isButtonReady = value;
                IsSubmitButtonEnabled = IsCardDetected & IsButtonReady;
                RaisePropertyChanged(nameof(IsButtonReady));
            }
        }

        private bool[] windowsFirstLoad;
        public bool[] WindowsFirstLoad
        {
            get { return windowsFirstLoad; }
            set
            {
                windowsFirstLoad = value;
                RaisePropertyChanged(nameof(WindowsFirstLoad));
            }
        }

        private Dictionary<string, string> errorList;
        public Dictionary<string, string> ErrorList
        {
            get { return errorList; }
            set
            {
                errorList = value;
                RaisePropertyChanged(nameof(ErrorList));
            }
        }

        public string Error { get; set; }

        public string this[string varName]
        {
            get
            {
                string result = null;

                if (varName == nameof(MobileNumber) )
                {
                    if(WindowsFirstLoad[0] == false)
                    {
                        if (MobileNumber == null || MobileNumber == string.Empty)
                        {
                            result = StandardMessageResource.ErorrTopUpMobileNumberIsNullorEmpty;
                            MobileNumberError = result;
                            MobileNumberIsValid = true;
                            MobileNumberIsValid = false;
                            if (!ErrorList.ContainsKey(varName))
                            {
                                ErrorList.Add(varName, result);
                            }
                        }
                        else if (!IsValidPhoneNumber())
                        {
                            result = StandardMessageResource.ErrorTopUpMobileNumberIsNotValid;
                            MobileNumberError = StandardMessageResource.ErrorMobileNumber;
                            MobileNumberIsValid = true;
                            MobileNumberIsValid = false;
                            if (!ErrorList.ContainsKey(varName))
                            {
                                ErrorList.Add(varName, result);
                            }
                        }
                        else
                        {
                            MobileNumberIsValid = true;
                            if (ErrorList.ContainsKey(varName))
                            {
                                ErrorList.Remove(varName);
                            }
                        }
                    }
                    WindowsFirstLoad[0] = false;
                }
                else if (varName == nameof(EmailAddress))
                {
                    if (WindowsFirstLoad[1] == false)
                    {
                        if (EmailAddress == null || EmailAddress == string.Empty)
                        {
                            result = StandardMessageResource.ErrorTopUpEmailIsNullorEmpty;
                            EmailAddressError = result;
                            EmailAddressIsValid = true;
                            EmailAddressIsValid = false;
                            if (!ErrorList.ContainsKey(varName))
                            {
                                ErrorList.Add(varName, result);
                            }
                        }
                        else if (!IsValidEmail())
                        {
                            result = StandardMessageResource.ErrorTopUpEmailIsValid;
                            EmailAddressError = result;
                            EmailAddressIsValid = true;
                            EmailAddressIsValid = false;
                            if (!ErrorList.ContainsKey(varName))
                            {
                                ErrorList.Add(varName, result);
                            }
                        }
                        else
                        {
                            EmailAddressIsValid = true;
                            if (ErrorList.ContainsKey(varName))
                            {
                                ErrorList.Remove(varName);
                            }
                        }
                    }
                    WindowsFirstLoad[1] = false;
                }

                else if (varName == nameof(CardID))
                {
                    if (WindowsFirstLoad[2] == false)
                    {
                        if (CardID == string.Empty)
                        {
                            result = StandardMessageResource.ErrorCardIsRecommended;
                            if (!ErrorList.ContainsKey(varName))
                            {
                                ErrorList.Add(varName, result);
                            }
                        }
                        else
                        {
                            if (ErrorList.ContainsKey(varName))
                            {
                                ErrorList.Remove(varName);
                            }
                        }
                    }
                    WindowsFirstLoad[2] = false;
                }

                if (ErrorList.Count > 0)
                {
                    IsButtonReady = false;
                }
                else if(EmailAddress != string.Empty && MobileNumber != string.Empty && ErrorList.Count == 0)
                {
                    IsButtonReady = true;
                }
                return result;
            }
        }

        private void WindowsFirstloadSetValue(bool vlaue)
        {
            for (int countFirstLoad = 0; countFirstLoad < WindowsFirstLoad.Length; countFirstLoad++)
            {
                WindowsFirstLoad[countFirstLoad] = vlaue;
            }
        }

        private bool IsValidEmail()
        {
            if (EmailAddress == null)
            {
                return false;
            }

            return Regex.IsMatch(EmailAddress, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        }

        private bool IsValidPhoneNumber()
        {
            if (MobileNumber == null)
            {
                return false;
            }

            return Regex.Match(MobileNumber, @"^(((0)[0-9]{10})|\+63[0-9]{10})$").Success;
        }

        private bool isCardDetected;

        public new bool IsCardDetected
        {
            get { return isCardDetected; }
            set
            {
                isCardDetected = value;
                if(EmailAddress != string.Empty && MobileNumber != string.Empty)
                {
                    IsSubmitButtonEnabled = IsCardDetected & IsButtonReady;
                }
                RaisePropertyChanged(nameof(IsCardDetected));
            }
        }

        private bool isSubmitButtonEnabled;

        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

    }
}
