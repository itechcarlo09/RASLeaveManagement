﻿using gocafe_cashier.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.Model
{
    public class ShiftModel : BaseModel
    {
        #region Properties

        private string cashierName;
        public string CashierName
        {
            get { return cashierName; }
            set
            {
                cashierName = value;
                RaisePropertyChanged(nameof(CashierName));
            }
        }

        private string endTime;
        public string EndTime
        {
            get { return endTime; }
            set
            {
                endTime = value;
                RaisePropertyChanged(nameof(EndTime));
            }
        }

        private string startTime;
        public string StartTime
        {
            get { return startTime; }
            set
            {
                startTime = value;
                RaisePropertyChanged(nameof(StartTime));
            }
        }

        private string totalSales;
        public string TotalSales
        {
            get { return totalSales; }
            set
            {
                totalSales = value;
                RaisePropertyChanged(nameof(TotalSales));
            }
        }

        private string totalHours;
        public string TotalHours
        {
            get { return totalHours; }
            set
            {
                totalHours = value;
                RaisePropertyChanged(nameof(TotalHours));
            }
        }

        private Dictionary<string, string> breakdown;
        public Dictionary<string, string> Breakdown
        {
            get { return breakdown; }
            set
            {
                breakdown = value;
                RaisePropertyChanged(nameof(Breakdown));
            }
        }

        private List<ProductBreakdownDataModel> productBreakdownData;
        public List<ProductBreakdownDataModel> ProductBreakdownData
        {
            get { return productBreakdownData; }
            set
            {
                productBreakdownData = value;
                RaisePropertyChanged(nameof(ProductBreakdownData));
            }
        }

        #endregion
    }
}
