﻿using gocafe_cashier.Cache;
using gocafe_cashier.Definition;
using gocafe_cashier.MessageResource;
using gocafe_cashier.ViewModelMediator;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Media;

namespace gocafe_cashier.Model
{
    public class AccountManagerModel : BaseModel, IDataErrorInfo
    {
        public AccountManagerModel()
        {
            Initialize();
        }

        private void Initialize()
        {
            
            ErrorList = new List<string>();
            IsMember = true;
            SelectedPromoPrice = 0;
            SelectedGuestPromoPrice = "0.00";
            SelectedPromoID = string.Empty;
            MemberShipFee = 0;
            InitialMemberLoad = 0;

            PondoFee = 0;
            TotalFee = 0;
            TopUpFee = 0;
            TenderedMoney = 0;
            ChangeFee = 0;
            BirthDate = DateTime.Now;
            IsMale = true;
            HasSelectedPromo = false;
            WorkStationList = new List<WorkstationModel>();
            TestErrorList = new Dictionary<string, string>();
            ValidatorTopUpFee = "0.00";
            ValidatorTenderedMoney = "0.00";
            UIDatePickerEndDate = DateTime.Now;

            IsPromoEmpty = false;
            ShowUsernameErrorToolTip = false;
            ShowMobileNumberErrorToolTip = false;
            ShowSelectedErrorToolTip = false;
            ShowEmailErrorToolTip = false;
            ShowFirstnameErrorToolTip = false;
            ShowLastnameErrorToolTip = false;
        }

        #region Properties

        private decimal PondoFee;

        private bool isPondoChecked;
        public bool IsPondoChecked
        {
            get { return isPondoChecked; }
            set
            {
                isPondoChecked = value;
                RaisePropertyChanged(nameof(IsPondoChecked));
            }
        }

        private bool isPromoEmpty;
        public bool IsPromoEmpty
        {
            get { return isPromoEmpty; }
            set
            {
                isPromoEmpty = value;
                RaisePropertyChanged(nameof(IsPromoEmpty));
            }
        }

        private string cashierID;
        public string CashierID
        {
            get { return cashierID; }
            set
            {
                cashierID = value;
                RaisePropertyChanged(nameof(CashierID));
            }
        }

        private string cardIDNumber;
        public string CardIDNumber
        {
            get { return cardIDNumber; }
            set
            {
                cardIDNumber = value;
                RaisePropertyChanged(nameof(CardIDNumber));
            }
        }

        private string guestID;
        public string GuestID
        {
            get { return guestID; }
            set
            {
                guestID = value;
                RaisePropertyChanged(nameof(GuestID));
            }
        }

        private string guestPassword;
        public string GuestPassword
        {
            get { return guestPassword; }
            set
            {
                guestPassword = value;
                RaisePropertyChanged(nameof(GuestPassword));
            }
        }

        private List<WorkstationModel> workStationList;
        public List<WorkstationModel> WorkStationList
        {
            get { return workStationList; }
            set
            {
                workStationList = value;
                RaisePropertyChanged(nameof(WorkStationList));
            }
        }

        private string firstName;
        public string FirstName
        {
            get { return firstName; }
            set
            {
                firstName = value;
                RaisePropertyChanged(nameof(FirstName));
            }
        }

        private string middleName;
        public string MiddleName
        {
            get { return middleName; }
            set
            {
                middleName = value;
                RaisePropertyChanged(nameof(MiddleName));
            }
        }

        private string lastName;
        public string LastName
        {
            get { return lastName; }
            set
            {
                lastName = value;
                RaisePropertyChanged(nameof(LastName));
            }
        }

        private bool isMale;
        public bool IsMale
        {
            get { return isMale; }
            set
            {
                isMale = value;
                RaisePropertyChanged(nameof(IsMale));
            }
        }

        private bool isMember;
        public bool IsMember
        {
            get { return isMember; }
            set
            {
                isMember = value;
                RaisePropertyChanged(nameof(IsMember));
                IsCardDetected = false;
                Mediator.Instance.NotifyViewModel(Messages.AccountManagerViewModel, Messages.GuestAccount, null);
            }
        }

        private bool isGuestLogin;
        public bool IsGuestLogin
        {
            get { return isGuestLogin; }
            set
            {
                isGuestLogin = value;
                RaisePropertyChanged(nameof(IsGuestLogin));
            }
        }

        private DateTime birthDate;
        public DateTime BirthDate
        {
            get { return birthDate; }
            set
            {
                birthDate = value;
                SelectedDate = birthDate.ToString(DateFormatDefinition.DefaultDateFormat);
                RaisePropertyChanged(nameof(BirthDate));
            }
        }

        private DateTime uiDatePickerEndDate;
        public DateTime UIDatePickerEndDate
        {
            get { return uiDatePickerEndDate; }
            set
            {
                uiDatePickerEndDate = value;
                RaisePropertyChanged(nameof(UIDatePickerEndDate));
            }
        }

        private string selectedDate;
        public string SelectedDate
        {
            get { return selectedDate; }
            set
            {
                selectedDate = value;
                RaisePropertyChanged(nameof(SelectedDate));
            }
        }

        private bool showSelectedErrorToolTip;
        public bool ShowSelectedErrorToolTip
        {
            get { return showSelectedErrorToolTip; }
            set
            {
                showSelectedErrorToolTip = value;
                RaisePropertyChanged(nameof(ShowSelectedErrorToolTip));
            }
        }

        private string selectedDateError;
        public string SelectedDateError
        {
            get { return selectedDateError; }
            set
            {
                selectedDateError = value;
                RaisePropertyChanged(nameof(SelectedDateError));
            }
        }

        private string username;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                RaisePropertyChanged(nameof(Username));
            }
        }

        private string pondoUsername;
        public string PondoUsername
        {
            get { return pondoUsername; }
            set
            {
                pondoUsername = value;
                RaisePropertyChanged(nameof(PondoUsername));
            }
        }

        private bool showUsernameErrorToolTip;
        public bool ShowUsernameErrorToolTip
        {
            get { return showUsernameErrorToolTip; }
            set
            {
                showUsernameErrorToolTip = value;
                RaisePropertyChanged(nameof(ShowUsernameErrorToolTip));
            }
        }

        private bool showFirstnameErrorToolTip;
        public bool ShowFirstnameErrorToolTip
        {
            get { return showFirstnameErrorToolTip; }
            set
            {
                showFirstnameErrorToolTip = value;
                RaisePropertyChanged(nameof(ShowFirstnameErrorToolTip));
            }
        }

        private bool showLastnameErrorToolTip;
        public bool ShowLastnameErrorToolTip
        {
            get { return showLastnameErrorToolTip; }
            set
            {
                showLastnameErrorToolTip = value;
                RaisePropertyChanged(nameof(ShowLastnameErrorToolTip));
            }
        }

        private string branchCreated;
        public string BranchCreated
        {
            get { return branchCreated; }
            set
            {
                branchCreated = value;
                RaisePropertyChanged(nameof(BranchCreated));
            }
        }

        private string dateCreated;
        public string DateCreated
        {
            get { return dateCreated; }
            set
            {
                dateCreated = value;
                RaisePropertyChanged(nameof(DateCreated));
            }
        }

        private string points;
        public string Points
        {
            get { return points; }
            set
            {
                points = value;
                RaisePropertyChanged(nameof(Points));
            }
        }

        private string accountBalance;
        public string AccountBalance
        {
            get { return accountBalance; }
            set
            {
                accountBalance = value;
                RaisePropertyChanged(nameof(AccountBalance));
            }
        }

        private decimal initialBonusLoad;
        public decimal InitialBonusLoad
        {
            get { return initialBonusLoad; }
            set
            {
                initialBonusLoad = value;
                RaisePropertyChanged(nameof(InitialBonusLoad));
            }
        }

        private decimal memberShipFee;
        public decimal MemberShipFee
        {
            get { return memberShipFee; }
            set
            {
                memberShipFee = value;
                RaisePropertyChanged(nameof(MemberShipFee));
                RaisePropertyChanged(nameof(TopupMaximumAmount));
            }
        }

        private decimal initialMemberLoad;
        public decimal InitialMemberLoad
        {
            get { return initialMemberLoad; }
            set
            {
                initialMemberLoad = value;
                RaisePropertyChanged(nameof(InitialMemberLoad));
            }
        }

        private decimal topUpFee;
        public decimal TopUpFee
        {
            get { return topUpFee; }
            set
            {
                topUpFee = value;
                RaisePropertyChanged(nameof(TopUpFee));

                ComputeTotalFee();
                ComputeChange();
            }
        }

        private decimal totalFee;
        public decimal TotalFee
        {
            get { return totalFee; }
            set
            {
                totalFee = value;
                RaisePropertyChanged(nameof(TotalFee));
            }
        }

        private decimal changeFee;
        public decimal ChangeFee
        {
            get { return changeFee; }
            set
            {
                changeFee = value;
                RaisePropertyChanged(nameof(ChangeFee));
            }
        }

        private decimal tenderedMoney;
        public decimal TenderedMoney
        {
            get { return tenderedMoney; }
            set
            {
                tenderedMoney = value;
                RaisePropertyChanged(nameof(TenderedMoney));

                ComputeTotalFee();
                ComputeChange();
            }
        }

        private ObservableCollection<AccountPromoModel> accountPromo;
        public ObservableCollection<AccountPromoModel> AccountPromo
        {
            get { return accountPromo; }
            set
            {
                accountPromo = value;
                RaisePropertyChanged(nameof(AccountPromo));
            }
        }

        private bool isShownLoading;
        public bool IsShownLoading
        {
            get { return isShownLoading; }
            set
            {
                isShownLoading = value;
                RaisePropertyChanged(nameof(IsShownLoading));
            }
        }

        private string selectedPromoDescription;
        public string SelectedPromoDescription
        {
            get { return selectedPromoDescription; }
            set
            {
                selectedPromoDescription = value;
                RaisePropertyChanged(nameof(SelectedPromoDescription));
            }
        }

        private string selectedGuestPromoDescription;
        public string SelectedGuestPromoDescription
        {
            get { return selectedGuestPromoDescription; }
            set
            {
                selectedGuestPromoDescription = value;
                RaisePropertyChanged(nameof(SelectedGuestPromoDescription));
            }
        }

        private decimal selectedPromoPrice;
        public decimal SelectedPromoPrice
        {
            get { return selectedPromoPrice; }
            set
            {
                selectedPromoPrice = value;
                RaisePropertyChanged(nameof(SelectedPromoPrice));
            }
        }

        private string selectedPromoID;
        public string SelectedPromoID
        {
            get { return selectedPromoID; }
            set
            {
                selectedPromoID = value;
                RaisePropertyChanged(nameof(SelectedPromoID));
            }
        }

        private string selectedGuestPromoPrice;
        public string SelectedGuestPromoPrice
        {
            get { return selectedGuestPromoPrice; }
            set
            {
                selectedGuestPromoPrice = value;
                RaisePropertyChanged(nameof(SelectedGuestPromoPrice));
            }
        }

        private bool hasSelectedPromo;
        public bool HasSelectedPromo
        {
            get { return hasSelectedPromo; }
            set
            {
                hasSelectedPromo = value;
                RaisePropertyChanged(nameof(HasSelectedPromo));
            }
        }

        private bool hasNegativeNumber;
        public bool HasNegativeNumber
        {
            get { return hasNegativeNumber; }
            set
            {
                hasNegativeNumber = value;
                if (IsMember)
                {
                    IsSubmitButtonEnabled = IsCardDetected & !HasNegativeNumber & ValidateMemberFields();
                }
                else
                {
                    IsSubmitButtonEnabled = ValidateGuestFields();
                }
                RaisePropertyChanged(nameof(HasNegativeNumber));
            }
        }

        private bool isSubmitButtonEnabled;
        public bool IsSubmitButtonEnabled
        {
            get { return isSubmitButtonEnabled; }
            set
            {
                isSubmitButtonEnabled = value;
                RaisePropertyChanged(nameof(IsSubmitButtonEnabled));
            }
        }

        private bool isCardDetected;
        public new bool IsCardDetected
        {
            get { return isCardDetected; }
            set
            {
                isCardDetected = value;
                IsSubmitButtonEnabled = IsCardDetected & !HasNegativeNumber;
                RaisePropertyChanged(nameof(IsCardDetected));
            }
        }

        private bool isPCAssigned;
        public bool IsPCAssigned
        {
            get { return isPCAssigned; }
            set
            {
                isPCAssigned = value;
                RaisePropertyChanged(nameof(IsPCAssigned));
            }
        }

        public decimal TopupMaximumAmount
        {
            get { return DataCacheContext.TopupMaximumAmount - InitialMemberLoad; }
        }

        public void ComputeTotalFee()
        {
            if (!IsMember)
            {
                //MemberShipFee = 0;
                TotalFee = (SelectedPromoPrice + TopUpFee);
            }
            else
            {
                TotalFee = (MemberShipFee + SelectedPromoPrice + TopUpFee);
            }
        }

        public void ComputeChange()
        {
            ChangeFee = (TenderedMoney - TotalFee);
        }

        public bool ValidateMember()
        {
            bool hasError = false;

            if (Username == null || Username == string.Empty)
            {
                hasError = true;
                Username = string.Empty;
            }

            if (FirstName == null || FirstName == string.Empty)
            {
                hasError = true;
                FirstName = string.Empty;
            }

            if (LastName == null || LastName == string.Empty)
            {
                hasError = true;
                LastName = string.Empty;
            }

            if (EmailAddress == null || EmailAddress == string.Empty)
            {
                hasError = true;
                EmailAddress = string.Empty;
            }

            if (MobileNumber == null || MobileNumber == string.Empty)
            {
                hasError = true;
                MobileNumber = string.Empty;
            }

            return hasError;
        }

        #endregion

        #region AcountManager Text Change Event

        private Dictionary<string, string> testErrorList;
        public Dictionary<string, string> TestErrorList
        {
            get { return testErrorList; }
            set
            {
                testErrorList = value;
                RaisePropertyChanged(nameof(TestErrorList));
            }
        }

        private string emailAddress;
        public string EmailAddress
        {
            get { return emailAddress; }
            set
            {
                emailAddress = value;
                RaisePropertyChanged(nameof(EmailAddress));
            }
        }

        private bool showEmailErrorToolTip;
        public bool ShowEmailErrorToolTip
        {
            get { return showEmailErrorToolTip; }
            set
            {
                showEmailErrorToolTip = value;
                RaisePropertyChanged(nameof(ShowEmailErrorToolTip));
            }
        }

        private string mobileNumber;
        public string MobileNumber
        {
            get { return mobileNumber; }
            set
            {
                mobileNumber = value;
                RaisePropertyChanged(nameof(MobileNumber));
            }
        }

        private bool showMobileNumberErrorToolTip;
        public bool ShowMobileNumberErrorToolTip
        {
            get { return showMobileNumberErrorToolTip; }
            set
            {
                showMobileNumberErrorToolTip = value;
                RaisePropertyChanged(nameof(ShowMobileNumberErrorToolTip));
            }
        }

        private string occupation;
        public string Occupation
        {
            get { return occupation; }
            set
            {
                occupation = value;
                RaisePropertyChanged(nameof(Occupation));
            }
        }

        //TopUp Textbox
        private Visibility topUpVisibilityError;
        public Visibility TopUpVisibilityError
        {
            get { return topUpVisibilityError; }
            set
            {
                topUpVisibilityError = value;
                RaisePropertyChanged(nameof(TopUpVisibilityError));
            }
        }


        private SolidColorBrush topUpBorderBrush;
        public SolidColorBrush TopUpBorderBrush
        {
            get { return topUpBorderBrush; }
            set
            {
                topUpBorderBrush = value;
                RaisePropertyChanged(nameof(TopUpBorderBrush));
            }
        }

        private string error;
        public string Error
        {
            get { return error; }
            set
            {
                error = value;
                RaisePropertyChanged(nameof(Error));
            }
        }

        private string validatorTopUpFee;
        public string ValidatorTopUpFee
        {
            get
            {
                return validatorTopUpFee;
            }
            set
            {
                validatorTopUpFee = value;
                RaisePropertyChanged(nameof(ValidatorTopUpFee));
            }
        }

        private bool isErrorMessageShown;
        public bool IsErrorMessageShown
        {
            get { return isErrorMessageShown; }
            set
            {
                isErrorMessageShown = value;
                RaisePropertyChanged(nameof(IsErrorMessageShown));
            }
        }

        //Tendered Textbox
        private Visibility tenderedVisibilityError;
        public Visibility TenderedVisibilityError
        {
            get { return tenderedVisibilityError; }
            set
            {
                tenderedVisibilityError = value;
                RaisePropertyChanged(nameof(TenderedVisibilityError));
            }
        }

        private SolidColorBrush tenderedBorderBrush;
        public SolidColorBrush TenderedBorderBrush
        {
            get { return tenderedBorderBrush; }
            set
            {
                tenderedBorderBrush = value;
                RaisePropertyChanged(nameof(TenderedBorderBrush));
            }
        }

        private string tenderedError;
        public string TenderedError
        {
            get { return tenderedError; }
            set
            {
                tenderedError = value;
                RaisePropertyChanged(nameof(TenderedError));
            }
        }

        private string validatorTenderedMoney;
        public string ValidatorTenderedMoney
        {
            get
            {
                return validatorTenderedMoney;
            }
            set
            {
                validatorTenderedMoney = value;
                RaisePropertyChanged(nameof(ValidatorTenderedMoney));
            }
        }

        private bool isTenderedErrorMessageShown;
        public bool IsTenderedErrorMessageShown
        {
            get { return isTenderedErrorMessageShown; }
            set
            {
                isTenderedErrorMessageShown = value;
                RaisePropertyChanged(nameof(IsTenderedErrorMessageShown));
            }
        }

        private List<string> errorList;
        public List<string> ErrorList
        {
            get { return errorList; }
            set
            {
                errorList = value;
                RaisePropertyChanged(nameof(ErrorList));
            }
        }

        private bool isFirstNameFirstLoad = true;
        private bool isMiddleNameFirstLoad = true;
        private bool isLastNameFirstLoad = true;
        private bool isUsernameFirstLoad = true;
        private bool isEmailAddressNameFirstLoad = true;
        private bool isMobileNumberNameFirstLoad = true;

        public void ResetFirstLoadFields()
        {
            isFirstNameFirstLoad = true;
            isMiddleNameFirstLoad = true;
            isLastNameFirstLoad = true;
            isUsernameFirstLoad = true;
            isEmailAddressNameFirstLoad = true;
            isMobileNumberNameFirstLoad = true;
            ShowEmailErrorToolTip = false;
            ShowUsernameErrorToolTip = false;
            ShowFirstnameErrorToolTip = false;
            ShowLastnameErrorToolTip = false;
            ShowMobileNumberErrorToolTip = false;
            ShowSelectedErrorToolTip = false;
            ErrorList.Clear();
        }

        private bool IsValidBirthday()
        {
            DateTime dateTime;
            bool dateValidation = DateTime.TryParseExact(SelectedDate, DateFormatDefinition.DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime);

            return dateValidation;
        }

        private bool IsBirthdayBehind()
        {
            DateTime dateTime;
            bool dateValidation = DateTime.TryParseExact(SelectedDate, DateFormatDefinition.DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTime);


            if (dateTime > DateTime.Now.Date)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        private bool IsValidEmail()
        {
            if (EmailAddress == null)
            {
                return false;
            }

            return Regex.IsMatch(EmailAddress, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        }

        private bool IsNotValidName(string name)
        {
            if (name == null)
            {
                return false;
            }

            return Regex.IsMatch(name, @"[^A-Za-z\s]+", RegexOptions.IgnoreCase);
        }

        private bool DoessContainsSymbols(string username)
        {
            if (username == null)
            {
                return false;
            }

            return Regex.IsMatch(username, @"[^._\w]", RegexOptions.IgnoreCase);
        }

        private bool IsValidPhoneNumber()
        {
            if (MobileNumber == null)
            {
                return false;
            }

            return Regex.Match(MobileNumber, @"^(((0)[0-9]{10})|\+63[0-9]{10})$").Success;
        }

        private bool ValidateMinimumTopup(decimal topupValue, out string error)
        {
            if (IsMember)
            {
                if (topupValue <= 0)
                {
                    error = string.Empty;
                    return false;
                }
            }

            if (HasSelectedPromo)
            {
                if (topupValue < 0)
                {
                    error = StandardMessageResource.ErrorTopUpValueLessThanZero;
                    return true;
                }
                else
                {
                    error = string.Empty;
                    return false;
                }
            }
            else
            {
                if (topupValue < 1)
                {
                    error = StandardMessageResource.ErrorTopUpValueLessThan1;
                    return true;
                }
                else
                {
                    error = string.Empty;
                    return false;
                }
            }
        }

        public void LostFocus()
        {
            RaisePropertyChanged(nameof(TenderedMoney));
        }

        #endregion

        public string this[string name]
        {
            get
            {
                string result = null;
                if (name == "FirstName")
                {
                    if (isFirstNameFirstLoad)
                    {
                        isFirstNameFirstLoad = false;
                    }
                    else if (IsNotValidName(FirstName))
                    {
                        result = StandardMessageResource.ErrorNameIsNotValid;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowFirstnameErrorToolTip = true;
                        }
                    }
                    else if (FirstName == null || FirstName == string.Empty)
                    {
                        result = StandardMessageResource.ErrorTopUpFirstIsNullorEmpty;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowFirstnameErrorToolTip = true;
                        }
                    }
                    else
                    {
                        if (ErrorList.Contains(name))
                        {
                            ErrorList.Remove(name);
                            ShowFirstnameErrorToolTip = false;
                        }
                    }
                }
                if (name == "MiddleName")
                {
                    if (isMiddleNameFirstLoad)
                    {
                        isMiddleNameFirstLoad = false;
                    }
                    else if (IsNotValidName(MiddleName))
                    {
                        result = StandardMessageResource.ErrorNameIsNotValid;
                    }
                    else
                    {

                    }
                }
                else if (name == "LastName")
                {
                    if (isLastNameFirstLoad)
                    {
                        isLastNameFirstLoad = false;
                    }
                    else if (IsNotValidName(LastName))
                    {
                        result = StandardMessageResource.ErrorNameIsNotValid;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowLastnameErrorToolTip = true;
                        }
                    }
                    else if (LastName == null || LastName == string.Empty)
                    {
                        result = StandardMessageResource.ErrorTopUpLastNameIsNullorEmpty;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowLastnameErrorToolTip = true;
                        }
                    }
                    else
                    {
                        if (ErrorList.Contains(name))
                        {
                            ErrorList.Remove(name);
                            ShowLastnameErrorToolTip = false;
                        }
                    }
                }
                else if (name == "Username")
                {
                    if (isUsernameFirstLoad)
                    {
                        isUsernameFirstLoad = false;
                    }
                    else if (Username == null || Username == string.Empty)
                    {
                        result = StandardMessageResource.ErrorTopUpUsernameIsNullorEmpty;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowUsernameErrorToolTip = true;
                        }
                    }
                    else if(Username.Length < 4)
                    {
                        result = StandardMessageResource.ErrorUsernameLessThan4;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowUsernameErrorToolTip = true;
                        }
                    }
                    else if (DoessContainsSymbols(Username))
                    {
                        result = StandardMessageResource.ErrorUsernameContainsSymbols;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowUsernameErrorToolTip = true;
                        }
                    }
                    else
                    {
                        if (ErrorList.Contains(name))
                        {
                            ErrorList.Remove(name);
                            ShowUsernameErrorToolTip = false;
                        }
                    }
                }
                else if (name == "EmailAddress")
                {
                    if (isEmailAddressNameFirstLoad)
                    {
                        isEmailAddressNameFirstLoad = false;
                    }
                    else if (EmailAddress == null || EmailAddress == string.Empty)
                    {
                        result = StandardMessageResource.ErrorTopUpEmailIsNullorEmpty;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowEmailErrorToolTip = true;
                        }
                    }
                    else if (!IsValidEmail())
                    {
                        result = StandardMessageResource.ErrorTopUpEmailIsValid;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowEmailErrorToolTip = true;
                        }
                    }
                    else
                    {
                        if (ErrorList.Contains(name))
                        {
                            ErrorList.Remove(name);
                            ShowEmailErrorToolTip = false;
                        }
                    }
                }
                else if (name == "MobileNumber")
                {
                    if (isMobileNumberNameFirstLoad)
                    {
                        isMobileNumberNameFirstLoad = false;
                    }
                    else if (MobileNumber == null || MobileNumber == string.Empty)
                    {
                        result = StandardMessageResource.ErorrTopUpMobileNumberIsNullorEmpty;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowMobileNumberErrorToolTip = true;
                        }
                    }
                    else if (!IsValidPhoneNumber())
                    {
                        result = StandardMessageResource.ErrorTopUpMobileNumberIsNotValid;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            ShowMobileNumberErrorToolTip = true;
                        }
                    }
                    else
                    {
                        if (ErrorList.Contains(name))
                        {
                            ErrorList.Remove(name);
                            ShowMobileNumberErrorToolTip = false;
                        }
                    }
                }
                else if (name == "ValidatorTopUpFee")
                {
                    if (ValidatorTopUpFee == null)
                    {
                        ValidatorTopUpFee = "0.00";
                    }
                    decimal topUpFee = Convert.ToDecimal(ValidatorTopUpFee);
                    string error = string.Empty;
                    if (ValidateMinimumTopup(topUpFee, out error))
                    {
                        TopUpBorderBrush = Brushes.Red;
                        IsErrorMessageShown = true;
                        TopUpVisibilityError = Visibility.Visible;
                        Error = error;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                        }
                    }
                    else if (topUpFee > 10000)
                    {
                        TopUpBorderBrush = Brushes.Red;
                        IsErrorMessageShown = true;
                        TopUpVisibilityError = Visibility.Visible;
                        Error = StandardMessageResource.ErrorTopUFeeOrTenderedGreaterThan10k;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                        }
                    }
                    else
                    {
                        if (ErrorList.Contains(name))
                        {
                            ErrorList.Remove(name);
                        }

                        TopUpBorderBrush = Brushes.Transparent;
                        IsErrorMessageShown = false;
                        TopUpVisibilityError = Visibility.Hidden;
                    }

                    TopUpFee = topUpFee;
                }
                else if (name == "ValidatorTenderedMoney")
                {
                    //decimal tenderedMoney = Convert.ToDecimal(ValidatorTenderedMoney);
                    //string error = string.Empty;
                    //if (tenderedMoney < 0)
                    //{
                    //    TenderedBorderBrush = Brushes.Red;
                    //    IsTenderedErrorMessageShown = true;
                    //    TenderedVisibilityError = Visibility.Visible;
                    //    TenderedError = StandardMessageResource.ErrorTopUFeeOrTenderedLessThan0;

                    //    if (!ErrorList.Contains(name))
                    //    {
                    //        ErrorList.Add(name);
                    //    }
                    //}
                    //else if (tenderedMoney > 10000)
                    //{
                    //    TenderedBorderBrush = Brushes.Red;
                    //    IsTenderedErrorMessageShown = true;
                    //    TenderedVisibilityError = Visibility.Visible;
                    //    TenderedError = StandardMessageResource.ErrorTopUFeeOrTenderedGreaterThan10k;

                    //    if (!ErrorList.Contains(name))
                    //    {
                    //        ErrorList.Add(name);
                    //    }
                    //}
                    //else
                    //{
                    //    if (ErrorList.Contains(name))
                    //    {
                    //        ErrorList.Remove(name);
                    //    }

                    //    TenderedBorderBrush = Brushes.Transparent;
                    //    IsTenderedErrorMessageShown = false;
                    //    TenderedVisibilityError = Visibility.Hidden;
                    //}

                    //TenderedMoney = tenderedMoney;
                }
                else if (name == "BirthDate")
                {
                    if(BirthDate.Date > DateTime.Now.Date)
                    {
                        result = StandardMessageResource.ErrorBirthDateIsBehind;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                        }
                    }
                    else
                    {
                        if (ErrorList.Contains(name))
                        {
                            ErrorList.Remove(name);
                        }
                    }
                }
                else if (name == "SelectedDate")
                {
                    if (SelectedDate == null || SelectedDate == string.Empty)
                    {
                        result = StandardMessageResource.ErrorBirthdayNullOrEmpty;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            SelectedDateError = result;
                            ShowSelectedErrorToolTip = true;
                        }
                        else
                        {
                            SelectedDateError = result;
                            ShowSelectedErrorToolTip = true;
                        }
                    }
                    else if (!IsValidBirthday())
                    {
                        result = StandardMessageResource.ErrorBirthdayInput;
                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            SelectedDateError = result;
                            ShowSelectedErrorToolTip = true;
                        }
                        else
                        {
                            SelectedDateError = result;
                            ShowSelectedErrorToolTip = true;
                        }
                    }
                    else if (!IsBirthdayBehind())
                    {
                        result = StandardMessageResource.ErrorBirthDateIsBehind;

                        if (!ErrorList.Contains(name))
                        {
                            ErrorList.Add(name);
                            SelectedDateError = result;
                            ShowSelectedErrorToolTip = true;
                        }
                        else
                        {
                            SelectedDateError = result;
                            ShowSelectedErrorToolTip = true;
                        }
                    }
                    else
                    {
                        if (ErrorList.Contains(name))
                        {
                            ErrorList.Remove(name);
                            SelectedDateError = null;
                            ShowSelectedErrorToolTip = false;
                        }
                    }
                }


                if (ErrorList.Count > 0)
                {
                    HasNegativeNumber = true;
                }
                else
                {
                    HasNegativeNumber = false;
                }
                return result;
            }
        }

        public bool ValidateMemberFields()
        {
            if (IsNotValidName(FirstName))
            {
                return false;
            }
            else if (FirstName == null || FirstName == string.Empty)
            {
                return false;
            }
            else if (IsNotValidName(LastName))
            {
                return false;
            }
            else if (LastName == null || LastName == string.Empty)
            {
                return false;
            }
            else if (Username == null || Username == string.Empty || Username.Length < 4)
            {
                return false;
            }
            else if (DoessContainsSymbols(Username))
            {
                return false;
            }
            else if (EmailAddress == null || EmailAddress == string.Empty)
            {
                return false;
            }
            else if (!IsValidEmail())
            {
                return false;
            }
            else if (MobileNumber == null || MobileNumber == string.Empty)
            {
                return false;
            }
            else if (!IsValidPhoneNumber())
            {
                return false;
            }
            else if (TopUpFee > TopupMaximumAmount)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        private bool ValidateGuestFields()
        {
            if (TopUpFee < 1 && !HasSelectedPromo)
            {
                return false;
            }
            else if (TopUpFee > TopupMaximumAmount)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public void ChangeFeeByPondo()
        {
            if (isPondoChecked)
            {
                PondoFee = MemberShipFee;
                MemberShipFee = 0;
                TotalFee = (SelectedPromoPrice + TopUpFee);
            }
            else if (!isPondoChecked && MemberShipFee == 0)
            {
                MemberShipFee = PondoFee;
                TotalFee = (MemberShipFee + SelectedPromoPrice + TopUpFee);
            }
            else if (!isPondoChecked && MemberShipFee != 0)
            {
                PondoFee = MemberShipFee;
                TotalFee = (SelectedPromoPrice + TopUpFee);
            }
        }

    }
}
