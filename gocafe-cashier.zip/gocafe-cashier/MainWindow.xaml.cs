﻿using gocafe_cashier.Helper;
using MahApps.Metro.Controls;
using System.Diagnostics;
using System.Windows;

namespace gocafe_cashier
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MetroWindow, IView
    {
        public MainWindow()
        {
            InitializeComponent();
            ((Window)this).Loaded += CashierMainControlLoaded;
        }

        private void CashierMainControlLoaded(object sender, RoutedEventArgs e)
        {
            App.Current.MainWindow = this;
        }
    }
}
