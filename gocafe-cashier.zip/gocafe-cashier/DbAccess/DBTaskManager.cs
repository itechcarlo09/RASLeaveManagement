﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gocafe_cashier.DbAccess
{
    public sealed class DBTaskManager
    {
        private static readonly DBTaskManager instance = new DBTaskManager();

        private DBTaskManager()
        {
        }

        public static DBTaskManager Instance
        {
            get
            {
                return instance;
            }
        }

        public Task LocalDatabaseTask;
    }
}
